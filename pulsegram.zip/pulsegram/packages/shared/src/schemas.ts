import { z } from 'zod';
import {
  CHANNEL_CATEGORIES,
  DENSITIES,
  LANGUAGES,
  LIMITS,
  MEMBER_ROLES,
  PRESENCE_MODES,
  PRIVACY_AUDIENCES,
  REPORT_REASONS,
  THEMES,
  USERNAME_RE,
} from './constants';

const trimmed = (max: number) => z.string().trim().max(max);

export const usernameSchema = z
  .string()
  .trim()
  .regex(USERNAME_RE, 'username_invalid');

export const emailSchema = z.string().trim().toLowerCase().pipe(z.email('email_invalid')).pipe(z.string().max(254));

export const passwordSchema = z
  .string()
  .min(8, 'password_too_short')
  .max(256, 'password_too_long')
  .refine((p) => /[a-zA-Zа-яА-ЯёЁ]/.test(p) && /[0-9\W_]/.test(p), 'password_too_weak');

export const displayNameSchema = z.string().trim().min(1, 'required').max(LIMITS.displayName);

export const registerSchema = z.object({
  displayName: displayNameSchema,
  username: usernameSchema,
  email: emailSchema,
  password: passwordSchema,
  acceptTerms: z.literal(true, { error: 'terms_required' }),
  /** Honeypot: must be empty. Bots tend to fill every field. */
  website: z.string().max(0).optional(),
  captchaToken: z.string().max(4096).optional(),
  language: z.enum(LANGUAGES).optional(),
});
export type RegisterInput = z.infer<typeof registerSchema>;

export const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1).max(256),
  deviceName: z.string().trim().max(64).optional(),
});
export type LoginInput = z.infer<typeof loginSchema>;

export const tokenSchema = z.object({ token: z.string().min(16).max(256) });

export const forgotPasswordSchema = z.object({ email: emailSchema, captchaToken: z.string().max(4096).optional() });

export const resetPasswordSchema = z.object({
  token: z.string().min(16).max(256),
  password: passwordSchema,
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1).max(256),
  newPassword: passwordSchema,
});

export const updateProfileSchema = z
  .object({
    displayName: displayNameSchema,
    username: usernameSchema,
    bio: trimmed(LIMITS.bio),
    phone: z
      .string()
      .trim()
      .regex(/^\+?[0-9 ()-]{5,20}$/, 'phone_invalid')
      .or(z.literal('')),
    publicEmail: z.boolean(),
    statusText: trimmed(LIMITS.statusText),
    presenceMode: z.enum(PRESENCE_MODES),
  })
  .partial();
export type UpdateProfileInput = z.infer<typeof updateProfileSchema>;

export const privacySettingsSchema = z.object({
  lastSeen: z.enum(PRIVACY_AUDIENCES),
  online: z.enum(PRIVACY_AUDIENCES),
  avatar: z.enum(PRIVACY_AUDIENCES),
  phone: z.enum(PRIVACY_AUDIENCES),
  groupInvites: z.enum(PRIVACY_AUDIENCES),
  calls: z.enum(PRIVACY_AUDIENCES),
});
export type PrivacySettings = z.infer<typeof privacySettingsSchema>;

export const notificationSettingsSchema = z.object({
  enabled: z.boolean(),
  sound: z.boolean(),
  preview: z.boolean(),
  /** Show message text in system notifications when the device is locked. */
  lockScreenPreview: z.boolean(),
  direct: z.boolean(),
  groups: z.boolean(),
  channels: z.boolean(),
  mentions: z.boolean(),
  calls: z.boolean(),
  /** ISO date until which all notifications are paused. */
  pausedUntil: z.string().datetime().nullable(),
});
export type NotificationSettings = z.infer<typeof notificationSettingsSchema>;

export const appearanceSettingsSchema = z.object({
  theme: z.enum(THEMES),
  accent: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  density: z.enum(DENSITIES),
  fontScale: z.number().min(0.85).max(1.3),
  language: z.enum(LANGUAGES),
  timeFormat: z.enum(['12h', '24h']),
  dateFormat: z.enum(['dmy', 'mdy', 'ymd']),
  enterToSend: z.boolean(),
  reduceMotion: z.boolean(),
});
export type AppearanceSettings = z.infer<typeof appearanceSettingsSchema>;

export const updatePreferencesSchema = z.object({
  privacy: privacySettingsSchema.partial().optional(),
  notifications: notificationSettingsSchema.partial().optional(),
  appearance: appearanceSettingsSchema.partial().optional(),
});
export type UpdatePreferencesInput = z.infer<typeof updatePreferencesSchema>;

export const groupSettingsSchema = z.object({
  membersCanSend: z.boolean(),
  membersCanSendMedia: z.boolean(),
  membersCanInvite: z.boolean(),
  membersCanPin: z.boolean(),
  historyVisibleToNewMembers: z.boolean(),
  /** Seconds a regular member must wait between messages (0 = off). */
  slowModeSeconds: z.number().int().min(0).max(3600),
  /** Channel only: allow subscribers to react. */
  reactionsEnabled: z.boolean(),
  /** Channel only: show author signature on posts. */
  signPosts: z.boolean(),
});
export type GroupSettings = z.infer<typeof groupSettingsSchema>;

export const createGroupSchema = z.object({
  title: z.string().trim().min(1).max(LIMITS.title),
  description: trimmed(LIMITS.description).optional(),
  memberIds: z.array(z.uuid()).max(200).default([]),
  isPublic: z.boolean().default(false),
  username: usernameSchema.optional(),
});
export type CreateGroupInput = z.infer<typeof createGroupSchema>;

export const createChannelSchema = z.object({
  title: z.string().trim().min(1).max(LIMITS.title),
  description: trimmed(LIMITS.description).optional(),
  isPublic: z.boolean().default(true),
  username: usernameSchema.optional(),
  category: z.enum(CHANNEL_CATEGORIES).default('other'),
});
export type CreateChannelInput = z.infer<typeof createChannelSchema>;

export const updateConversationSchema = z.object({
  title: z.string().trim().min(1).max(LIMITS.title).optional(),
  description: trimmed(LIMITS.description).optional(),
  isPublic: z.boolean().optional(),
  username: usernameSchema.nullable().optional(),
  category: z.enum(CHANNEL_CATEGORIES).optional(),
  settings: groupSettingsSchema.partial().optional(),
  discussionGroupId: z.uuid().nullable().optional(),
});
export type UpdateConversationInput = z.infer<typeof updateConversationSchema>;

export const updateMembershipSchema = z.object({
  isPinned: z.boolean().optional(),
  isArchived: z.boolean().optional(),
  /** ISO timestamp, "forever", or null to unmute. */
  mutedUntil: z.union([z.iso.datetime(), z.literal('forever'), z.null()]).optional(),
  draft: z.string().max(LIMITS.messageText).optional(),
  markUnread: z.boolean().optional(),
});
export type UpdateMembershipInput = z.infer<typeof updateMembershipSchema>;

export const sendMessageSchema = z
  .object({
    /** Client-generated id used for idempotency and optimistic UI. */
    clientId: z.uuid(),
    text: z.string().max(LIMITS.messageText).default(''),
    replyToId: z.uuid().optional(),
    attachmentIds: z.array(z.uuid()).max(LIMITS.attachmentsPerMessage).default([]),
    stickerId: z.uuid().optional(),
    gif: z
      .object({
        url: z.url().max(2048),
        previewUrl: z.url().max(2048),
        width: z.number().int().positive().max(4096),
        height: z.number().int().positive().max(4096),
        title: z.string().max(200).optional(),
      })
      .optional(),
    silent: z.boolean().optional(),
  })
  .refine((m) => m.text.trim().length > 0 || m.attachmentIds.length > 0 || m.stickerId || m.gif, {
    message: 'message_empty',
  });
export type SendMessageInput = z.input<typeof sendMessageSchema>;

export const editMessageSchema = z.object({ text: z.string().max(LIMITS.messageText) });

export const reactionSchema = z.object({
  emoji: z
    .string()
    .min(1)
    .max(16)
    .refine((e) => /\p{Extended_Pictographic}/u.test(e), 'emoji_invalid'),
});

export const forwardSchema = z.object({
  messageIds: z.array(z.uuid()).min(1).max(LIMITS.forwardBatch),
  toConversationIds: z.array(z.uuid()).min(1).max(20),
  hideSender: z.boolean().default(false),
});

export const deleteMessagesSchema = z.object({
  messageIds: z.array(z.uuid()).min(1).max(LIMITS.forwardBatch),
  forEveryone: z.boolean().default(false),
});

export const readSchema = z.object({ seq: z.coerce.number().int().nonnegative() });

export const historyQuerySchema = z.object({
  before: z.coerce.number().int().positive().optional(),
  after: z.coerce.number().int().nonnegative().optional(),
  around: z.coerce.number().int().positive().optional(),
  limit: z.coerce.number().int().min(1).max(100).default(LIMITS.pageSize),
});

export const searchQuerySchema = z.object({
  q: z.string().trim().max(200).default(''),
  conversationId: z.uuid().optional(),
  senderId: z.uuid().optional(),
  type: z.enum(['text', 'image', 'video', 'audio', 'voice', 'file', 'link']).optional(),
  from: z.iso.datetime().optional(),
  to: z.iso.datetime().optional(),
  limit: z.coerce.number().int().min(1).max(50).default(20),
  /** Pagination cursor (message seq). */
  before: z.coerce.number().int().positive().optional(),
});
export type SearchQuery = z.infer<typeof searchQuerySchema>;

export const memberRoleUpdateSchema = z.object({ role: z.enum(MEMBER_ROLES).exclude(['owner']) });

export const addMembersSchema = z.object({ userIds: z.array(z.uuid()).min(1).max(200) });

export const createInviteSchema = z.object({
  expiresInHours: z.number().int().min(1).max(24 * 365).nullable().default(null),
  maxUses: z.number().int().min(1).max(100000).nullable().default(null),
});

export const reportSchema = z.object({
  targetType: z.enum(['user', 'message', 'conversation']),
  targetId: z.uuid(),
  reason: z.enum(REPORT_REASONS),
  details: trimmed(1000).optional(),
});

export const folderSchema = z.object({
  name: z.string().trim().min(1).max(32),
  emoji: z.string().max(16).optional(),
  includeTypes: z.array(z.enum(['direct', 'group', 'channel'])).default([]),
  includeIds: z.array(z.uuid()).max(500).default([]),
  excludeIds: z.array(z.uuid()).max(500).default([]),
  unreadOnly: z.boolean().default(false),
  excludeMuted: z.boolean().default(false),
  excludeArchived: z.boolean().default(true),
});
export type FolderInput = z.infer<typeof folderSchema>;

export const startCallSchema = z.object({
  conversationId: z.uuid(),
  video: z.boolean().default(false),
});

export const deleteAccountSchema = z.object({ password: z.string().min(1).max(256), confirm: z.literal('DELETE') });

export const pushSubscriptionSchema = z.object({
  endpoint: z.url().max(2048),
  keys: z.object({ p256dh: z.string().max(256), auth: z.string().max(256) }),
});
