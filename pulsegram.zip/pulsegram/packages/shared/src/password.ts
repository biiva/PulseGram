/**
 * Lightweight password strength estimate for UI feedback (0..4).
 * The server enforces the hard rules via `passwordSchema`; this is purely advisory.
 */
const COMMON = new Set([
  'password',
  'password1',
  '12345678',
  '123456789',
  'qwertyuiop',
  'qwerty123',
  '11111111',
  'iloveyou',
  'admin123',
  'letmein1',
  'pulsegram',
  'йцукенгш',
]);

export function passwordStrength(pw: string): 0 | 1 | 2 | 3 | 4 {
  if (!pw) return 0;
  if (COMMON.has(pw.toLowerCase())) return 0;
  let classes = 0;
  if (/[a-zа-яё]/.test(pw)) classes++;
  if (/[A-ZА-ЯЁ]/.test(pw)) classes++;
  if (/[0-9]/.test(pw)) classes++;
  if (/[^a-zA-Zа-яА-ЯёЁ0-9]/.test(pw)) classes++;
  const unique = new Set(pw).size;
  let score = 0;
  if (pw.length >= 8) score++;
  if (pw.length >= 12) score++;
  if (classes >= 3) score++;
  if (pw.length >= 16 || (classes === 4 && pw.length >= 10)) score++;
  if (unique < 5) score = Math.min(score, 1);
  return Math.max(0, Math.min(4, score)) as 0 | 1 | 2 | 3 | 4;
}
