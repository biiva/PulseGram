import { z } from 'zod';
import type {
  CallDto,
  ConversationDto,
  ConversationMembership,
  MessageDto,
  NotificationDto,
  PresenceView,
  ReactionSummary,
} from './types';

/**
 * PulseGram realtime protocol (WebSocket, JSON frames).
 *
 * Server → client frames: { t: <event name>, d: <payload>, ts: <server ISO time> }
 * Client → server frames: { t: <command name>, d: <payload>, id?: <correlation id> }
 *
 * Messages themselves are sent over REST (idempotent via clientId) so that retries are safe;
 * the socket carries fan-out events and ephemeral signals (typing, presence, call signalling).
 * After a reconnect the client calls GET /api/sync?since=<last server time> to recover anything
 * missed while disconnected.
 */

export type ConversationPatch = Partial<
  Pick<
    ConversationDto,
    | 'title'
    | 'description'
    | 'username'
    | 'avatarUrl'
    | 'isPublic'
    | 'category'
    | 'settings'
    | 'memberCount'
    | 'discussionGroupId'
    | 'linkedChannelId'
    | 'peerReadSeq'
  >
>;

export interface ServerEvents {
  'session:ready': { userId: string; serverTime: string; heartbeatMs: number };
  'message:new': { message: MessageDto };
  'message:updated': { message: MessageDto };
  'message:deleted': { conversationId: string; messageIds: string[] };
  /**
   * `reactions[].mine` is always false here (one payload for every recipient); clients keep their own
   * `mine` flags, and when `actorId` is themselves (another device) they take `actorEmojis`.
   */
  'message:reactions': {
    conversationId: string;
    messageId: string;
    reactions: ReactionSummary[];
    actorId: string;
    actorEmojis: string[];
  };
  'message:views': { conversationId: string; views: Record<string, number> };
  'conversation:read': { conversationId: string; userId: string; seq: number };
  /** A conversation appeared for this user (new DM, added to a group, joined) — full per-user DTO. */
  'conversation:new': { conversation: ConversationDto };
  /** Shared fields changed (title, avatar, settings, member count…). Per-user fields are never included. */
  'conversation:updated': { conversationId: string; patch: ConversationPatch };
  /** The current user's own membership changed on another device (pin, archive, mute, draft, role). */
  'conversation:membership': { conversationId: string; me: ConversationMembership };
  'conversation:removed': { conversationId: string; reason: 'left' | 'kicked' | 'deleted' | 'blocked' };
  'conversation:pins': { conversationId: string; pinnedMessageIds: string[] };
  'typing:update': { conversationId: string; userId: string; kind: 'text' | 'voice' | 'upload' | null };
  'presence:updated': { userId: string; presence: PresenceView };
  'call:incoming': { call: CallDto };
  'call:updated': { call: CallDto };
  'call:signal': { callId: string; fromUserId: string; signal: CallSignal };
  'notification:new': { notification: NotificationDto };
  'user:updated': { userId: string };
  'session:revoked': { sessionId: string };
  error: { code: string; message: string; ref?: string };
  pong: { at: string };
}

export type ServerEventName = keyof ServerEvents;
export interface ServerFrame<K extends ServerEventName = ServerEventName> {
  t: K;
  d: ServerEvents[K];
  ts: string;
}

export const callSignalSchema = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('offer'), sdp: z.string().max(20000) }),
  z.object({ kind: z.literal('answer'), sdp: z.string().max(20000) }),
  z.object({
    kind: z.literal('ice'),
    candidate: z.string().max(2000),
    sdpMid: z.string().max(64).nullable(),
    sdpMLineIndex: z.number().int().min(0).max(64).nullable(),
  }),
  z.object({ kind: z.literal('media-state'), audio: z.boolean(), video: z.boolean() }),
  z.object({ kind: z.literal('restart') }),
]);
export type CallSignal = z.infer<typeof callSignalSchema>;

export const clientFrameSchema = z.discriminatedUnion('t', [
  z.object({ t: z.literal('ping'), id: z.string().max(64).optional(), d: z.object({}).optional() }),
  z.object({
    t: z.literal('typing'),
    id: z.string().max(64).optional(),
    d: z.object({ conversationId: z.uuid(), kind: z.enum(['text', 'voice', 'upload']).nullable() }),
  }),
  z.object({
    t: z.literal('presence:subscribe'),
    id: z.string().max(64).optional(),
    d: z.object({ userIds: z.array(z.uuid()).max(500) }),
  }),
  z.object({
    t: z.literal('focus'),
    id: z.string().max(64).optional(),
    /** Client reports whether the tab is focused — drives "online" vs "idle" presence. */
    d: z.object({ active: z.boolean() }),
  }),
  z.object({
    t: z.literal('call:signal'),
    id: z.string().max(64).optional(),
    d: z.object({ callId: z.uuid(), signal: callSignalSchema }),
  }),
]);
export type ClientFrame = z.infer<typeof clientFrameSchema>;

export const WS_CLOSE = {
  unauthorized: 4401,
  sessionRevoked: 4403,
  rateLimited: 4429,
  serverShutdown: 4503,
} as const;
