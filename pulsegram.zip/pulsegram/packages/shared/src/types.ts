import type {
  AttachmentKind,
  ChannelCategory,
  ConversationType,
  MemberRole,
  MessageType,
  PresenceMode,
} from './constants';
import type { AppearanceSettings, GroupSettings, NotificationSettings, PrivacySettings } from './schemas';

/** Presence as seen by a specific viewer, already filtered by the target's privacy settings. */
export type PresenceView =
  | { kind: 'online'; dnd?: boolean }
  | { kind: 'last_seen'; at: string }
  | { kind: 'recently' } // within ~3 days
  | { kind: 'within_week' }
  | { kind: 'within_month' }
  | { kind: 'long_ago' }
  | { kind: 'hidden' }; // e.g. blocked, or service accounts

export interface UserSummary {
  id: string;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  presence: PresenceView;
  /** Custom status text; may be empty. */
  statusText: string;
  isDemo?: boolean;
  deleted?: boolean;
}

export interface UserProfile extends UserSummary {
  bio: string;
  phone: string | null;
  email: string | null;
  createdAt: string;
  isContact: boolean;
  isBlocked: boolean;
  /** True if this user blocked the viewer. */
  blockedViewer: boolean;
  commonGroups: Array<{ id: string; title: string; avatarUrl: string | null }>;
  canCall: boolean;
  canInviteToGroups: boolean;
}

export interface Me {
  id: string;
  email: string;
  emailVerified: boolean;
  username: string;
  displayName: string;
  avatarUrl: string | null;
  bio: string;
  phone: string | null;
  publicEmail: boolean;
  statusText: string;
  presenceMode: PresenceMode;
  createdAt: string;
  profileCompleted: boolean;
  isDemo: boolean;
}

export interface Preferences {
  privacy: PrivacySettings;
  notifications: NotificationSettings;
  appearance: AppearanceSettings;
}

export interface SessionInfo {
  id: string;
  deviceName: string;
  userAgent: string;
  ip: string | null;
  createdAt: string;
  lastActiveAt: string;
  current: boolean;
}

export interface AttachmentDto {
  id: string;
  kind: AttachmentKind;
  mime: string;
  size: number;
  name: string;
  url: string;
  thumbUrl: string | null;
  width: number | null;
  height: number | null;
  durationMs: number | null;
  /** Normalised 0..1 amplitude samples for voice messages. */
  waveform: number[] | null;
}

export interface ReactionSummary {
  emoji: string;
  count: number;
  /** Whether the viewer reacted with this emoji. */
  mine: boolean;
  /** Up to 3 recent reactors (for direct/group chats). */
  userIds: string[];
}

export interface ReplyPreview {
  id: string;
  seq: number;
  senderId: string | null;
  senderName: string;
  text: string;
  type: MessageType;
  deleted: boolean;
}

export interface ForwardInfo {
  fromName: string;
  fromUserId: string | null;
  fromConversationId: string | null;
  originalDate: string;
}

export interface StickerDto {
  id: string;
  setId: string;
  emoji: string;
  url: string;
  animated: boolean;
}

export interface GifDto {
  url: string;
  previewUrl: string;
  width: number;
  height: number;
  title?: string;
}

export interface MessageDto {
  id: string;
  seq: number;
  conversationId: string;
  senderId: string | null;
  clientId: string | null;
  type: MessageType;
  text: string;
  createdAt: string;
  editedAt: string | null;
  deletedAt: string | null;
  replyTo: ReplyPreview | null;
  forward: ForwardInfo | null;
  attachments: AttachmentDto[];
  sticker: StickerDto | null;
  gif: GifDto | null;
  reactions: ReactionSummary[];
  /** Channel posts: unique viewers. Null for other chat types. */
  views: number | null;
  /** System message payload, e.g. { action: 'member_joined', userId }. */
  system: Record<string, unknown> | null;
  mentions: string[];
  /** Channel posts signed by the author when enabled. */
  signature: string | null;
}

export interface ConversationMembership {
  role: MemberRole;
  isPinned: boolean;
  pinnedAt: string | null;
  isArchived: boolean;
  mutedUntil: string | null;
  draft: string;
  draftUpdatedAt: string | null;
  lastReadSeq: number;
  markedUnread: boolean;
  joinedAt: string;
}

export interface ConversationDto {
  id: string;
  type: ConversationType;
  title: string;
  description: string;
  username: string | null;
  avatarUrl: string | null;
  isPublic: boolean;
  category: ChannelCategory | null;
  settings: GroupSettings;
  memberCount: number;
  createdAt: string;
  lastMessage: MessageDto | null;
  lastActivityAt: string;
  unreadCount: number;
  unreadMentions: number;
  /** Highest seq any *other* member has read (direct chats) — drives the double tick. */
  peerReadSeq: number;
  /** For direct chats: the other participant. */
  peer: UserSummary | null;
  me: ConversationMembership | null;
  pinnedMessageIds: string[];
  discussionGroupId: string | null;
  linkedChannelId: string | null;
  isDemo: boolean;
}

export interface MemberDto {
  user: UserSummary;
  role: MemberRole;
  joinedAt: string;
}

export interface InviteDto {
  id: string;
  token: string;
  url: string;
  createdAt: string;
  expiresAt: string | null;
  maxUses: number | null;
  uses: number;
  revokedAt: string | null;
  createdBy: string;
}

export interface InvitePreview {
  conversation: Pick<ConversationDto, 'id' | 'type' | 'title' | 'description' | 'avatarUrl' | 'memberCount'>;
  alreadyMember: boolean;
}

export interface AuditLogDto {
  id: string;
  action: string;
  actor: UserSummary | null;
  targetUser: UserSummary | null;
  data: Record<string, unknown>;
  createdAt: string;
}

export interface NotificationDto {
  id: string;
  type: 'message' | 'mention' | 'reply' | 'invite' | 'call' | 'admin' | 'contact' | 'system';
  title: string;
  body: string;
  conversationId: string | null;
  messageId: string | null;
  actor: UserSummary | null;
  readAt: string | null;
  createdAt: string;
}

export interface CallDto {
  id: string;
  conversationId: string;
  caller: UserSummary;
  callee: UserSummary;
  video: boolean;
  status: 'ringing' | 'accepted' | 'rejected' | 'missed' | 'ended' | 'failed' | 'busy' | 'cancelled';
  createdAt: string;
  answeredAt: string | null;
  endedAt: string | null;
  durationSec: number | null;
}

export interface FolderDto {
  id: string;
  name: string;
  emoji: string | null;
  includeTypes: Array<'direct' | 'group' | 'channel'>;
  includeIds: string[];
  excludeIds: string[];
  unreadOnly: boolean;
  excludeMuted: boolean;
  excludeArchived: boolean;
  position: number;
}

export interface StickerSetDto {
  id: string;
  name: string;
  title: string;
  isDemo: boolean;
  stickers: StickerDto[];
}

export interface PublicConfig {
  appVersion: string;
  emailConfigured: boolean;
  emailVerificationRequired: boolean;
  smsConfigured: boolean;
  oauth: { google: boolean };
  captcha: { provider: 'turnstile' | null; siteKey: string | null };
  turnConfigured: boolean;
  gifConfigured: boolean;
  pushConfigured: boolean;
  vapidPublicKey: string | null;
  storage: 'local' | 's3';
  maxUploadBytes: number;
  e2ee: false;
  isProduction: boolean;
}

export interface SearchResults {
  users: UserSummary[];
  conversations: ConversationDto[];
  publicConversations: ConversationDto[];
  messages: Array<{ message: MessageDto; conversation: Pick<ConversationDto, 'id' | 'title' | 'type' | 'avatarUrl'> }>;
}

export interface Paginated<T> {
  items: T[];
  hasMore: boolean;
}

export interface SyncResponse {
  serverTime: string;
  conversations: ConversationDto[];
  /** Messages created, edited, deleted or re-reacted since the cursor (deleted ones carry deletedAt). */
  messages: MessageDto[];
  /** Too many changes to replay — the client should drop its message caches and refetch. */
  truncated: boolean;
}

export interface ApiErrorBody {
  error: {
    code: string;
    message: string;
    details?: unknown;
  };
}
