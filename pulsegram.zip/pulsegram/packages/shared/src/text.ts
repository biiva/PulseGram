/**
 * Message text tokenizer used by the client renderer and server (mentions, link detection).
 * Produces plain tokens — the client renders them as React nodes, never as raw HTML,
 * which keeps message rendering XSS-safe by construction.
 */
export type TextToken =
  | { kind: 'text'; value: string }
  | { kind: 'link'; value: string; href: string }
  | { kind: 'mention'; value: string; username: string }
  | { kind: 'code'; value: string }
  | { kind: 'pre'; value: string; lang: string | null }
  | { kind: 'bold'; value: string }
  | { kind: 'italic'; value: string };

const URL_RE = /\bhttps?:\/\/[^\s<>"'`]+[^\s<>"'`.,;:!?)\]}]/giu;
const MENTION_RE = /(^|[^\w@])@([a-zA-Z][a-zA-Z0-9_]{3,31})\b/g;

/** Only http(s) links are ever made clickable. */
export function safeHref(raw: string): string | null {
  try {
    const u = new URL(raw);
    if (u.protocol !== 'http:' && u.protocol !== 'https:') return null;
    return u.toString();
  } catch {
    return null;
  }
}

function tokenizeInline(text: string): TextToken[] {
  const out: TextToken[] = [];
  // Split by inline code first.
  const parts = text.split(/(`[^`\n]+`)/g);
  for (const part of parts) {
    if (!part) continue;
    if (part.startsWith('`') && part.endsWith('`') && part.length > 2) {
      out.push({ kind: 'code', value: part.slice(1, -1) });
      continue;
    }
    out.push(...tokenizeLinksAndMentions(part));
  }
  return out;
}

function tokenizeEmphasis(text: string): TextToken[] {
  const out: TextToken[] = [];
  const re = /\*\*([^*\n]+)\*\*|__([^_\n]+)__/g;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push({ kind: 'text', value: text.slice(last, m.index) });
    if (m[1] !== undefined) out.push({ kind: 'bold', value: m[1] });
    else if (m[2] !== undefined) out.push({ kind: 'italic', value: m[2] });
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push({ kind: 'text', value: text.slice(last) });
  return out;
}

function tokenizeLinksAndMentions(text: string): TextToken[] {
  const out: TextToken[] = [];
  let last = 0;
  const matches: Array<{ start: number; end: number; token: TextToken }> = [];
  for (const m of text.matchAll(URL_RE)) {
    const href = safeHref(m[0]);
    if (href && m.index !== undefined) matches.push({ start: m.index, end: m.index + m[0].length, token: { kind: 'link', value: m[0], href } });
  }
  for (const m of text.matchAll(MENTION_RE)) {
    if (m.index === undefined || m[2] === undefined) continue;
    const start = m.index + (m[1]?.length ?? 0);
    const end = start + 1 + m[2].length;
    if (matches.some((x) => start < x.end && end > x.start)) continue;
    matches.push({ start, end, token: { kind: 'mention', value: `@${m[2]}`, username: m[2] } });
  }
  matches.sort((a, b) => a.start - b.start);
  for (const x of matches) {
    if (x.start > last) out.push(...tokenizeEmphasis(text.slice(last, x.start)));
    out.push(x.token);
    last = x.end;
  }
  if (last < text.length) out.push(...tokenizeEmphasis(text.slice(last)));
  return out;
}

export function tokenizeMessage(text: string): TextToken[] {
  const out: TextToken[] = [];
  const re = /```([a-zA-Z0-9_+-]*)\n?([\s\S]*?)```/g;
  let last = 0;
  let m: RegExpExecArray | null;
  while ((m = re.exec(text))) {
    if (m.index > last) out.push(...tokenizeInline(text.slice(last, m.index)));
    out.push({ kind: 'pre', value: (m[2] ?? '').replace(/\n$/, ''), lang: m[1] || null });
    last = m.index + m[0].length;
  }
  if (last < text.length) out.push(...tokenizeInline(text.slice(last)));
  return out;
}

export function extractMentions(text: string): string[] {
  const set = new Set<string>();
  for (const t of tokenizeMessage(text)) if (t.kind === 'mention') set.add(t.username.toLowerCase());
  return [...set];
}

export function extractLinks(text: string): string[] {
  return tokenizeMessage(text)
    .filter((t): t is Extract<TextToken, { kind: 'link' }> => t.kind === 'link')
    .map((t) => t.href);
}
