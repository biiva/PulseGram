import { describe, expect, it } from 'vitest';
import {
  can,
  DEFAULT_CHANNEL_SETTINGS,
  DEFAULT_GROUP_SETTINGS,
  extractMentions,
  passwordStrength,
  registerSchema,
  safeHref,
  sendMessageSchema,
  tokenizeMessage,
} from './index';

describe('permissions', () => {
  const group = (role: 'owner' | 'admin' | 'moderator' | 'member') => ({ type: 'group' as const, role, settings: DEFAULT_GROUP_SETTINGS });
  const channel = (role: 'owner' | 'admin' | 'moderator' | 'member') => ({ type: 'channel' as const, role, settings: DEFAULT_CHANNEL_SETTINGS });

  it('only admins post in channels', () => {
    expect(can.sendMessage(channel('member'))).toBe(false);
    expect(can.sendMessage(channel('moderator'))).toBe(false);
    expect(can.sendMessage(channel('admin'))).toBe(true);
  });

  it('respects membersCanSend in groups', () => {
    const ctx = { ...group('member'), settings: { ...DEFAULT_GROUP_SETTINGS, membersCanSend: false } };
    expect(can.sendMessage(ctx)).toBe(false);
    expect(can.sendMessage({ ...ctx, role: 'moderator' })).toBe(true);
  });

  it('cannot kick equal or higher roles', () => {
    expect(can.kick(group('moderator'), 'member')).toBe(true);
    expect(can.kick(group('moderator'), 'moderator')).toBe(false);
    expect(can.kick(group('admin'), 'owner')).toBe(false);
    expect(can.kick(group('member'), 'member')).toBe(false);
  });

  it('admins cannot grant admin, owners can; nobody grants owner', () => {
    expect(can.changeRole(group('admin'), 'member', 'moderator')).toBe(true);
    expect(can.changeRole(group('admin'), 'member', 'admin')).toBe(false);
    expect(can.changeRole(group('admin'), 'admin', 'member')).toBe(false);
    expect(can.changeRole(group('owner'), 'member', 'admin')).toBe(true);
    expect(can.changeRole(group('owner'), 'member', 'owner')).toBe(false);
    expect(can.changeRole(group('member'), 'member', 'moderator')).toBe(false);
  });
});

describe('schemas', () => {
  it('validates registration input', () => {
    const ok = registerSchema.safeParse({
      displayName: 'Ann',
      username: 'ann_k',
      email: 'Ann@Example.com ',
      password: 'correct horse 9',
      acceptTerms: true,
    });
    expect(ok.success).toBe(true);
    if (ok.success) expect(ok.data.email).toBe('ann@example.com');
    expect(registerSchema.safeParse({ displayName: 'a', username: '1bad', email: 'x', password: 'p', acceptTerms: true }).success).toBe(false);
    expect(
      registerSchema.safeParse({ displayName: 'a', username: 'good_name', email: 'a@b.co', password: 'longenough1', acceptTerms: false }).success,
    ).toBe(false);
  });

  it('rejects honeypot submissions', () => {
    const r = registerSchema.safeParse({
      displayName: 'Bot',
      username: 'botname',
      email: 'bot@example.com',
      password: 'longenough1',
      acceptTerms: true,
      website: 'http://spam',
    });
    expect(r.success).toBe(false);
  });

  it('rejects empty messages', () => {
    expect(sendMessageSchema.safeParse({ clientId: crypto.randomUUID(), text: '   ' }).success).toBe(false);
    expect(sendMessageSchema.safeParse({ clientId: crypto.randomUUID(), text: 'hi' }).success).toBe(true);
  });
});

describe('text tokenizer', () => {
  it('never makes javascript: links clickable', () => {
    expect(safeHref('javascript:alert(1)')).toBeNull();
    const tokens = tokenizeMessage('see javascript:alert(1) and https://example.com/a?b=1.');
    const links = tokens.filter((t) => t.kind === 'link');
    expect(links).toHaveLength(1);
    expect(links[0]).toMatchObject({ href: 'https://example.com/a?b=1' });
  });

  it('extracts mentions and code', () => {
    expect(extractMentions('hi @alice and @Bob_99, email a@b.com')).toEqual(['alice', 'bob_99']);
    const t = tokenizeMessage('run `npm i` then\n```ts\nconst a = 1;\n```');
    expect(t.some((x) => x.kind === 'code' && x.value === 'npm i')).toBe(true);
    expect(t.some((x) => x.kind === 'pre' && x.lang === 'ts' && x.value === 'const a = 1;')).toBe(true);
  });

  it('treats html as plain text', () => {
    const t = tokenizeMessage('<img src=x onerror=alert(1)>');
    expect(t).toEqual([{ kind: 'text', value: '<img src=x onerror=alert(1)>' }]);
  });
});

describe('password strength', () => {
  it('scores', () => {
    expect(passwordStrength('password')).toBe(0);
    expect(passwordStrength('Abcdef12')).toBeGreaterThanOrEqual(2);
    expect(passwordStrength('Tr0ub4dor&3-horse-staple')).toBe(4);
  });
});
