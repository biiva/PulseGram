export const APP_NAME = 'PulseGram';
export const APP_SLOGAN = 'Connect to your pulse.';
export const APP_VERSION = '0.1.0';

export const CONVERSATION_TYPES = ['direct', 'group', 'channel', 'saved'] as const;
export type ConversationType = (typeof CONVERSATION_TYPES)[number];

/** Ordered from most to least privileged. */
export const MEMBER_ROLES = ['owner', 'admin', 'moderator', 'member'] as const;
export type MemberRole = (typeof MEMBER_ROLES)[number];

export const MESSAGE_TYPES = [
  'text',
  'media', // one or more attachments (image/video/audio/file), optional caption
  'voice',
  'sticker',
  'gif',
  'system',
] as const;
export type MessageType = (typeof MESSAGE_TYPES)[number];

export const ATTACHMENT_KINDS = ['image', 'video', 'audio', 'voice', 'file'] as const;
export type AttachmentKind = (typeof ATTACHMENT_KINDS)[number];

export const PRIVACY_AUDIENCES = ['everybody', 'contacts', 'nobody'] as const;
export type PrivacyAudience = (typeof PRIVACY_AUDIENCES)[number];

export const PRESENCE_MODES = ['auto', 'dnd', 'invisible'] as const;
export type PresenceMode = (typeof PRESENCE_MODES)[number];

export const THEMES = ['light', 'dark', 'system'] as const;
export type Theme = (typeof THEMES)[number];

export const DENSITIES = ['comfortable', 'compact'] as const;
export type Density = (typeof DENSITIES)[number];

export const LANGUAGES = ['en', 'ru'] as const;
export type Language = (typeof LANGUAGES)[number];

export const REPORT_REASONS = ['spam', 'abuse', 'violence', 'illegal', 'impersonation', 'other'] as const;
export type ReportReason = (typeof REPORT_REASONS)[number];

export const CHANNEL_CATEGORIES = [
  'news',
  'tech',
  'gaming',
  'music',
  'education',
  'art',
  'business',
  'lifestyle',
  'other',
] as const;
export type ChannelCategory = (typeof CHANNEL_CATEGORIES)[number];

export const LIMITS = {
  messageText: 4096,
  captionText: 1024,
  displayName: 64,
  bio: 280,
  statusText: 70,
  title: 128,
  description: 1000,
  attachmentsPerMessage: 10,
  reactionsPerUserPerMessage: 3,
  pageSize: 50,
  maxGroupMembers: 10000,
  forwardBatch: 100,
} as const;

/** Reactions available in the quick picker. Any single emoji is accepted by the server. */
export const QUICK_REACTIONS = ['👍', '❤️', '😂', '🔥', '😮', '😢', '🎉', '👀'] as const;

export const USERNAME_RE = /^[a-zA-Z][a-zA-Z0-9_]{3,31}$/;
