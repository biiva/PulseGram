import type { ConversationType, MemberRole } from './constants';
import type { GroupSettings } from './schemas';

/**
 * Permission rules shared by server (authoritative) and client (UI hints only).
 * The server ALWAYS re-checks these; hiding a button on the client is never a security boundary.
 */

const RANK: Record<MemberRole, number> = { owner: 4, admin: 3, moderator: 2, member: 1 };

export function roleRank(role: MemberRole): number {
  return RANK[role];
}

export function atLeast(role: MemberRole, min: MemberRole): boolean {
  return RANK[role] >= RANK[min];
}

export const DEFAULT_GROUP_SETTINGS: GroupSettings = {
  membersCanSend: true,
  membersCanSendMedia: true,
  membersCanInvite: true,
  membersCanPin: false,
  historyVisibleToNewMembers: true,
  slowModeSeconds: 0,
  reactionsEnabled: true,
  signPosts: false,
};

export const DEFAULT_CHANNEL_SETTINGS: GroupSettings = {
  ...DEFAULT_GROUP_SETTINGS,
  membersCanSend: false,
  membersCanSendMedia: false,
  membersCanInvite: false,
  membersCanPin: false,
};

export interface PermissionContext {
  type: ConversationType;
  role: MemberRole;
  settings: GroupSettings;
}

export const can = {
  sendMessage({ type, role, settings }: PermissionContext): boolean {
    if (type === 'direct' || type === 'saved') return true;
    if (type === 'channel') return atLeast(role, 'admin');
    return settings.membersCanSend || atLeast(role, 'moderator');
  },
  sendMedia(ctx: PermissionContext): boolean {
    if (!can.sendMessage(ctx)) return false;
    if (ctx.type !== 'group') return true;
    return ctx.settings.membersCanSendMedia || atLeast(ctx.role, 'moderator');
  },
  react({ type, settings }: PermissionContext): boolean {
    if (type === 'channel' || type === 'group') return settings.reactionsEnabled;
    return true;
  },
  pin({ type, role, settings }: PermissionContext): boolean {
    if (type === 'direct' || type === 'saved') return true;
    if (type === 'channel') return atLeast(role, 'admin');
    return settings.membersCanPin || atLeast(role, 'moderator');
  },
  /** Delete messages written by other people. */
  deleteOthers({ type, role }: PermissionContext): boolean {
    if (type === 'direct' || type === 'saved') return false;
    if (type === 'channel') return atLeast(role, 'admin');
    return atLeast(role, 'moderator');
  },
  invite({ type, role, settings }: PermissionContext): boolean {
    if (type === 'direct' || type === 'saved') return false;
    if (type === 'channel') return atLeast(role, 'admin');
    return settings.membersCanInvite || atLeast(role, 'admin');
  },
  manageInviteLinks({ type, role }: PermissionContext): boolean {
    if (type === 'direct' || type === 'saved') return false;
    return atLeast(role, 'admin');
  },
  editInfo({ type, role }: PermissionContext): boolean {
    if (type === 'direct' || type === 'saved') return false;
    return atLeast(role, 'admin');
  },
  viewAuditLog({ type, role }: PermissionContext): boolean {
    if (type === 'direct' || type === 'saved') return false;
    return atLeast(role, 'admin');
  },
  /** Can `actor` remove `target` from the conversation? */
  kick(ctx: PermissionContext, targetRole: MemberRole): boolean {
    if (ctx.type === 'direct' || ctx.type === 'saved') return false;
    if (!atLeast(ctx.role, 'moderator')) return false;
    return RANK[ctx.role] > RANK[targetRole];
  },
  /** Can `actor` change `target` from `targetRole` to `newRole`? */
  changeRole(ctx: PermissionContext, targetRole: MemberRole, newRole: MemberRole): boolean {
    if (ctx.type === 'direct' || ctx.type === 'saved') return false;
    if (newRole === 'owner') return false; // use transferOwnership
    if (!atLeast(ctx.role, 'admin')) return false;
    if (ctx.role === 'owner') return targetRole !== 'owner';
    // Admins may only manage roles strictly below their own, and may not grant admin.
    return RANK[targetRole] < RANK['admin'] && RANK[newRole] < RANK['admin'];
  },
  transferOwnership({ type, role }: PermissionContext): boolean {
    return (type === 'group' || type === 'channel') && role === 'owner';
  },
  deleteConversation({ type, role }: PermissionContext): boolean {
    return (type === 'group' || type === 'channel') && role === 'owner';
  },
  /** Slow mode applies to plain members only. */
  bypassSlowMode({ role }: PermissionContext): boolean {
    return atLeast(role, 'moderator');
  },
};

/** How long a sender may edit their own message. Channels/saved: unlimited. */
export const EDIT_WINDOW_MS = 48 * 60 * 60 * 1000;
