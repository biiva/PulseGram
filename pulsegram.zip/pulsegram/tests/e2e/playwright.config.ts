import { defineConfig } from '@playwright/test';

/**
 * End-to-end tests against a running PulseGram (default: the dev setup on http://localhost:5173).
 *   npm run dev            # in another terminal
 *   npx playwright install chromium
 *   npm run test:e2e
 * Set PLAYWRIGHT_CHROMIUM_PATH to use an existing Chromium binary instead of the downloaded one.
 */
export default defineConfig({
  testDir: '.',
  outputDir: './results',
  timeout: 60_000,
  fullyParallel: false,
  workers: 1,
  reporter: [['list']],
  use: {
    baseURL: process.env.E2E_BASE_URL ?? 'http://localhost:5173',
    viewport: { width: 1440, height: 900 },
    locale: 'en-US',
    permissions: ['microphone', 'camera'],
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
    launchOptions: {
      executablePath: process.env.PLAYWRIGHT_CHROMIUM_PATH || undefined,
      args: ['--use-fake-ui-for-media-stream', '--use-fake-device-for-media-stream', '--disable-gpu', '--no-sandbox'],
    },
  },
});
