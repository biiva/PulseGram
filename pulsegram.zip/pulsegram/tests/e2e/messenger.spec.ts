import { expect, test, type Browser, type Page } from '@playwright/test';

const PASSWORD = 'Secret-pass1';
const uniq = () => `${Date.now().toString(36)}${Math.floor(Math.random() * 1e4)}`;

async function newPage(browser: Browser): Promise<Page> {
  const ctx = await browser.newContext();
  // Keep tests hermetic: no third-party requests.
  await ctx.route(/^https?:\/\/(?!localhost|127\.0\.0\.1)/, (r) => r.abort());
  return ctx.newPage();
}

async function register(page: Page, name: string, username: string) {
  await page.goto('/register');
  await page.getByLabel('Your name').fill(name);
  await page.getByLabel('Username').fill(username);
  await expect(page.getByText(`@${username} is available`)).toBeVisible();
  await page.getByLabel('Email').fill(`${username}@example.com`);
  await page.getByLabel('Password', { exact: true }).fill(PASSWORD);
  await page.getByLabel('Repeat password').fill(PASSWORD);
  await page.getByRole('checkbox').check();
  await page.getByRole('button', { name: 'Create account' }).click();
  await page.waitForURL(/setup-profile/);
  await page.getByRole('button', { name: 'Skip for now' }).click();
  await page.waitForURL(/\/chat/);
}

async function send(page: Page, text: string) {
  const box = page.getByLabel('Message', { exact: true });
  await box.fill(text);
  await box.press('Enter');
}

test('register → find user → private chat → realtime delivery → persisted history', async ({ browser }) => {
  const id = uniq();
  const alice = await newPage(browser);
  const bob = await newPage(browser);
  await register(alice, 'Alice E2E', `alice${id}`);
  await register(bob, 'Bob E2E', `bob${id}`);

  await alice.getByLabel('Search', { exact: true }).fill(`bob${id}`);
  await alice.getByRole('button', { name: /Bob E2E/ }).first().click();
  await alice.waitForURL(/\/chat\/.+/);
  await send(alice, 'Hello from Alice');

  // Bob receives it in real time — without reloading.
  await expect(bob.getByRole('button', { name: /Alice E2E/ })).toBeVisible();
  await expect(bob.getByRole('button', { name: /Alice E2E/ }).getByText('1', { exact: true })).toBeVisible();
  await bob.getByRole('button', { name: /Alice E2E/ }).first().click();
  await expect(bob.getByRole('log')).toContainText('Hello from Alice');
  await send(bob, 'Hi Alice!');
  await expect(alice.getByRole('log')).toContainText('Hi Alice!');

  // History survives a reload (stored in the database, not just in memory).
  await alice.reload();
  await expect(alice.getByRole('log')).toContainText('Hello from Alice');
  await expect(alice.getByRole('log')).toContainText('Hi Alice!');
});

test('reactions, replies, editing and deleting', async ({ browser }) => {
  const id = uniq();
  const a = await newPage(browser);
  const b = await newPage(browser);
  await register(a, 'Ann E2E', `ann${id}`);
  await register(b, 'Ben E2E', `ben${id}`);
  await a.getByLabel('Search', { exact: true }).fill(`ben${id}`);
  await a.getByRole('button', { name: /Ben E2E/ }).first().click();
  await send(a, 'Original text');

  await b.getByRole('button', { name: /Ann E2E/ }).first().click();
  const bubble = b.locator('[data-mid]').filter({ hasText: 'Original text' });
  await bubble.click({ button: 'right' });
  await b.getByRole('button', { name: '❤️' }).click();
  await expect(a.locator('[data-mid]').filter({ hasText: 'Original text' })).toContainText('❤️');

  // Edit via ↑ in an empty composer.
  await a.getByLabel('Message', { exact: true }).press('ArrowUp');
  await a.getByLabel('Message', { exact: true }).fill('Edited text');
  await a.getByLabel('Message', { exact: true }).press('Enter');
  await expect(b.getByRole('log')).toContainText('Edited text');
  await expect(b.getByRole('log')).toContainText('edited');

  // Delete for everyone.
  await a.locator('[data-mid]').filter({ hasText: 'Edited text' }).click({ button: 'right' });
  await a.getByRole('menuitem', { name: 'Delete' }).click();
  await a.getByRole('button', { name: 'Delete for everyone' }).click();
  await expect(b.getByRole('log')).not.toContainText('Edited text');
});

test('groups: create, mention, and admin-only info', async ({ browser }) => {
  const id = uniq();
  const owner = await newPage(browser);
  const member = await newPage(browser);
  await register(owner, 'Olga E2E', `olga${id}`);
  await register(member, 'Max E2E', `max${id}`);
  await owner.getByLabel('New message', { exact: true }).first().click();
  await owner.getByRole('menuitem', { name: 'New group' }).click();
  await owner.getByPlaceholder('Search by name or @username').fill(`max${id}`);
  await owner.getByRole('button', { name: /Max E2E/ }).click();
  await owner.getByRole('button', { name: 'Continue' }).click();
  await owner.getByLabel('Group name').fill(`Crew ${id}`);
  await owner.getByRole('button', { name: 'Create group' }).click();
  await send(owner, `@max${id} welcome`);
  await expect(member.getByRole('button', { name: new RegExp(`Crew ${id}`) })).toBeVisible();
  await member.getByRole('button', { name: new RegExp(`Crew ${id}`) }).first().click();
  await expect(member.getByRole('log')).toContainText('welcome');
  // Members don't see admin tools.
  await member.getByLabel('Info').click();
  await expect(member.getByRole('button', { name: 'Permissions' })).toHaveCount(0);
});
