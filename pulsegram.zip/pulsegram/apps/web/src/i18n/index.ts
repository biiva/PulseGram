import { useCallback } from 'react';
import type { Language } from '@pulsegram/shared';
import { en, type Dict, type MessageKey } from './en';
import { ru } from './ru';
import { usePrefs } from '../stores/prefs';

/** Register new languages here; the Dict type guarantees every key is translated. */
export const dictionaries: Record<Language, Dict> = { en, ru };
export const LANGUAGE_NAMES: Record<Language, string> = { en: 'English', ru: 'Русский' };

export type TFn = (key: MessageKey, vars?: Record<string, string | number>) => string;

export function translate(lang: Language, key: MessageKey, vars?: Record<string, string | number>): string {
  let s: string = dictionaries[lang]?.[key] ?? en[key] ?? key;
  if (vars) for (const [k, v] of Object.entries(vars)) s = s.replaceAll(`{${k}}`, String(v));
  return s;
}

export function useT(): TFn {
  const lang = usePrefs((s) => s.appearance.language);
  return useCallback<TFn>((key, vars) => translate(lang, key, vars), [lang]);
}

export function useLang(): Language {
  return usePrefs((s) => s.appearance.language);
}

export type { MessageKey };
