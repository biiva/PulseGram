import { clsx } from 'clsx';
import { X } from 'lucide-react';
import { useEffect, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { create } from 'zustand';
import { useT } from '../../i18n';
import { Button, IconButton } from './Button';
import { Input } from './Field';

const FOCUSABLE = 'a[href],button:not([disabled]),input:not([disabled]),textarea:not([disabled]),select:not([disabled]),[tabindex]:not([tabindex="-1"])';

export function Modal({
  open,
  onClose,
  title,
  children,
  footer,
  width = 440,
  className,
  bare,
}: {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  children: ReactNode;
  footer?: ReactNode;
  width?: number;
  className?: string;
  /** No padding/header — for full-bleed content like the media viewer. */
  bare?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const t = useT();

  useEffect(() => {
    if (!open) return;
    const prev = document.activeElement as HTMLElement | null;
    const node = ref.current;
    const first = node?.querySelector<HTMLElement>('[data-autofocus]') ?? node?.querySelector<HTMLElement>(FOCUSABLE);
    first?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        onClose();
      }
      if (e.key === 'Tab' && node) {
        const els = [...node.querySelectorAll<HTMLElement>(FOCUSABLE)];
        if (els.length === 0) return;
        const a = els[0]!;
        const z = els[els.length - 1]!;
        if (e.shiftKey && document.activeElement === a) {
          e.preventDefault();
          z.focus();
        } else if (!e.shiftKey && document.activeElement === z) {
          e.preventDefault();
          a.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey, true);
    return () => {
      document.removeEventListener('keydown', onKey, true);
      prev?.focus?.();
    };
  }, [open, onClose]);

  if (!open) return null;
  return createPortal(
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center" role="presentation">
      <div className="anim-fade absolute inset-0 bg-[rgb(10_8_24/0.5)] backdrop-blur-[2px]" onClick={onClose} />
      <div
        ref={ref}
        role="dialog"
        aria-modal="true"
        aria-label={typeof title === 'string' ? title : undefined}
        className={clsx(
          'anim-sheet relative flex max-h-[92dvh] w-full flex-col overflow-hidden bg-raised shadow-pop',
          'rounded-t-[var(--r-modal)] sm:rounded-[var(--r-modal)]',
          className,
        )}
        style={{ maxWidth: width }}
      >
        {!bare && title !== undefined && (
          <div className="flex items-center gap-3 px-5 pt-4 pb-2">
            <h2 className="min-w-0 flex-1 truncate text-[1.08rem] font-bold text-ink">{title}</h2>
            <IconButton label={t('common.close')} onClick={onClose} size={34}>
              <X size={18} />
            </IconButton>
          </div>
        )}
        <div className={clsx('scroll-y min-h-0 flex-1', !bare && 'px-5 pb-5')}>{children}</div>
        {footer && <div className="flex justify-end gap-2 border-t border-line px-5 py-3">{footer}</div>}
      </div>
    </div>,
    document.body,
  );
}

// ── Imperative confirm dialog ─────────────────────────────────────────────

interface ConfirmOptions {
  title: string;
  body?: ReactNode;
  confirmLabel?: string;
  danger?: boolean;
  /** Ask for a password (or other text) before confirming. */
  input?: { label: string; type?: string };
  /** Optional extra choice rendered as a secondary button (resolves with 'alt'). */
  alt?: string;
}
type ConfirmResult = { ok: true; value: string; alt?: boolean } | { ok: false };

const useConfirmStore = create<{ req: (ConfirmOptions & { resolve: (r: ConfirmResult) => void }) | null }>(() => ({ req: null }));

export function confirmDialog(opts: ConfirmOptions): Promise<ConfirmResult> {
  return new Promise((resolve) => useConfirmStore.setState({ req: { ...opts, resolve } }));
}

export function ConfirmHost() {
  const req = useConfirmStore((s) => s.req);
  const [value, setValue] = useState('');
  const t = useT();
  const done = (r: ConfirmResult) => {
    req?.resolve(r);
    useConfirmStore.setState({ req: null });
    setValue('');
  };
  return (
    <Modal open={Boolean(req)} onClose={() => done({ ok: false })} title={req?.title} width={400}>
      {req && (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            if (req.input && !value) return;
            done({ ok: true, value });
          }}
        >
          {req.body && <div className="text-[0.93rem] leading-relaxed text-ink-2">{req.body}</div>}
          {req.input && (
            <Input
              className="mt-4"
              wrapClassName="mt-4"
              label={req.input.label}
              type={req.input.type ?? 'text'}
              value={value}
              onChange={(e) => setValue(e.target.value)}
              data-autofocus
            />
          )}
          <div className="mt-6 flex flex-wrap justify-end gap-2">
            <Button variant="ghost" onClick={() => done({ ok: false })}>
              {t('common.cancel')}
            </Button>
            {req.alt && (
              <Button variant="secondary" onClick={() => done({ ok: true, value, alt: true })}>
                {req.alt}
              </Button>
            )}
            <Button type="submit" variant={req.danger ? 'danger' : 'primary'} disabled={Boolean(req.input) && !value} data-autofocus={!req.input || undefined}>
              {req.confirmLabel ?? t('common.yes')}
            </Button>
          </div>
        </form>
      )}
    </Modal>
  );
}
