import { clsx } from 'clsx';
import type { ReactNode } from 'react';

export function Spinner({ size = 20, className }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" className={clsx('spin', className)} aria-hidden="true">
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeOpacity=".2" strokeWidth="3" />
      <path d="M21 12a9 9 0 0 0-9-9" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

/** The brand mark: a heartbeat line inside a rounded tile. */
export function Logo({ size = 36, withText = false, className }: { size?: number; withText?: boolean; className?: string }) {
  return (
    <span className={clsx('inline-flex items-center gap-2.5', className)}>
      <svg width={size} height={size} viewBox="0 0 64 64" aria-hidden="true">
        <rect width="64" height="64" rx="18" fill="var(--accent)" />
        <path d="M10 34h11l5-12 8 22 6-16 3 6h11" fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="54" cy="34" r="3.5" fill="var(--accent-2)" />
      </svg>
      {withText && <span className="text-[1.2rem] font-extrabold tracking-[-0.02em] text-ink">PulseGram</span>}
    </span>
  );
}

/** Large animated pulse line — the signature brand element (empty states, welcome). */
export function PulseLine({ className, color = 'var(--accent)', animate = true }: { className?: string; color?: string; animate?: boolean }) {
  return (
    <svg viewBox="0 0 600 120" className={clsx(animate && 'pulse-draw', className)} aria-hidden="true" preserveAspectRatio="none">
      <path
        d="M0 60h170l18-34 26 78 22-62 14 26 10-8h340"
        fill="none"
        stroke={color}
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
        style={{ ['--len' as string]: 760 }}
      />
    </svg>
  );
}

export function EmptyState({ icon, title, body, action, className }: { icon?: ReactNode; title: string; body?: string; action?: ReactNode; className?: string }) {
  return (
    <div className={clsx('flex flex-col items-center justify-center px-8 py-12 text-center', className)}>
      {icon && <div className="mb-4 grid size-14 place-items-center rounded-2xl bg-soft text-accent">{icon}</div>}
      <p className="text-[1.02rem] font-semibold text-ink">{title}</p>
      {body && <p className="mt-1.5 max-w-[34ch] text-[0.9rem] leading-relaxed text-ink-3">{body}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function Badge({ count, muted, className }: { count: number; muted?: boolean; className?: string }) {
  if (count <= 0) return null;
  return (
    <span
      className={clsx(
        'inline-flex h-5 min-w-5 items-center justify-center rounded-full px-1.5 text-[0.72rem] font-bold tabular-nums',
        muted ? 'bg-ink-3/25 text-ink-2' : 'bg-accent text-white',
        className,
      )}
    >
      {count > 999 ? '999+' : count}
    </span>
  );
}

export function Skeleton({ className }: { className?: string }) {
  return <div className={clsx('animate-pulse rounded-lg bg-sunken', className)} />;
}

export function Kbd({ children }: { children: ReactNode }) {
  return <kbd className="rounded-md border border-line bg-sunken px-1.5 py-0.5 font-mono text-[0.75rem] text-ink-2">{children}</kbd>;
}
