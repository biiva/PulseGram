import { clsx } from 'clsx';
import { Bookmark, Megaphone, Users } from 'lucide-react';
import { useState } from 'react';
import { initials, toneFor } from '../../lib/format';

export interface AvatarProps {
  id: string;
  name: string;
  src?: string | null;
  size?: number;
  online?: boolean;
  kind?: 'user' | 'group' | 'channel' | 'saved';
  className?: string;
}

export function Avatar({ id, name, src, size = 44, online, kind = 'user', className }: AvatarProps) {
  const [failed, setFailed] = useState(false);
  const showImg = src && !failed;
  const iconSize = Math.round(size * 0.44);
  return (
    <span className={clsx('relative inline-block shrink-0', className)} style={{ width: size, height: size }}>
      {kind === 'saved' ? (
        <span className="grid size-full place-items-center rounded-full bg-gradient-to-br from-accent to-accent-2 text-white">
          <Bookmark size={iconSize} fill="currentColor" />
        </span>
      ) : showImg ? (
        <img
          src={src}
          alt=""
          loading="lazy"
          decoding="async"
          onError={() => setFailed(true)}
          className="size-full rounded-full bg-sunken object-cover"
        />
      ) : (
        <span
          aria-hidden="true"
          className="grid size-full place-items-center rounded-full font-semibold text-white select-none"
          style={{ background: toneFor(id), fontSize: Math.max(11, size * 0.36) }}
        >
          {name ? initials(name) : kind === 'group' ? <Users size={iconSize} /> : kind === 'channel' ? <Megaphone size={iconSize} /> : '?'}
        </span>
      )}
      {online && (
        <span
          className="absolute right-0 bottom-0 rounded-full border-2 border-bg bg-success"
          style={{ width: Math.max(10, size * 0.28), height: Math.max(10, size * 0.28) }}
          aria-label="online"
        />
      )}
    </span>
  );
}
