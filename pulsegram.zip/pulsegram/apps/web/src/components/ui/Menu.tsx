import { clsx } from 'clsx';
import { useEffect, useLayoutEffect, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { create } from 'zustand';

export interface MenuItem {
  label: string;
  icon?: ReactNode;
  onSelect?: () => void;
  danger?: boolean;
  disabled?: boolean;
  /** Nested items rendered inline under a divider heading. */
  children?: MenuItem[];
  divider?: boolean;
}

interface MenuState {
  menu: { x: number; y: number; items: MenuItem[]; header?: ReactNode } | null;
  openAt: (x: number, y: number, items: MenuItem[], header?: ReactNode) => void;
  close: () => void;
}

export const useMenu = create<MenuState>((set) => ({
  menu: null,
  openAt: (x, y, items, header) => set({ menu: { x, y, items, header } }),
  close: () => set({ menu: null }),
}));

/** Open a context menu at the pointer, or under an element for keyboard/button triggers. */
export function openMenu(e: { clientX?: number; clientY?: number; currentTarget?: EventTarget | null } | null, items: MenuItem[], header?: ReactNode) {
  let x = e?.clientX ?? 0;
  let y = e?.clientY ?? 0;
  const el = e?.currentTarget as HTMLElement | null | undefined;
  if ((!x && !y) || (el && 'getBoundingClientRect' in el && !e?.clientX)) {
    const r = el?.getBoundingClientRect?.();
    if (r) {
      x = r.right - 8;
      y = r.bottom + 4;
    }
  }
  useMenu.getState().openAt(x, y, items, header);
}

export function MenuHost() {
  const menu = useMenu((s) => s.menu);
  const close = useMenu((s) => s.close);
  const ref = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState<{ left: number; top: number } | null>(null);
  const [active, setActive] = useState(-1);

  const flat = (menu?.items ?? []).flatMap((i) => (i.children ? i.children : [i])).filter((i) => !i.divider);

  useLayoutEffect(() => {
    if (!menu || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const left = Math.max(8, Math.min(menu.x, window.innerWidth - r.width - 8));
    const top = menu.y + r.height > window.innerHeight - 8 ? Math.max(8, menu.y - r.height) : menu.y;
    setPos({ left, top });
    setActive(-1);
    ref.current.focus();
  }, [menu]);

  useEffect(() => {
    if (!menu) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        close();
      } else if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
        e.preventDefault();
        setActive((a) => {
          const n = flat.length;
          let i = a;
          for (let k = 0; k < n; k++) {
            i = (i + (e.key === 'ArrowDown' ? 1 : -1) + n) % n;
            if (!flat[i]?.disabled) break;
          }
          return i;
        });
      } else if (e.key === 'Enter' && active >= 0) {
        e.preventDefault();
        const it = flat[active];
        if (it && !it.disabled) {
          close();
          it.onSelect?.();
        }
      }
    };
    const onDown = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) close();
    };
    document.addEventListener('keydown', onKey, true);
    document.addEventListener('mousedown', onDown, true);
    window.addEventListener('resize', close);
    window.addEventListener('blur', close);
    return () => {
      document.removeEventListener('keydown', onKey, true);
      document.removeEventListener('mousedown', onDown, true);
      window.removeEventListener('resize', close);
      window.removeEventListener('blur', close);
    };
  }, [menu, close, active, flat]);

  if (!menu) return null;
  let idx = -1;
  const renderItem = (it: MenuItem, key: string) => {
    if (it.divider) return <div key={key} className="my-1 h-px bg-line" />;
    idx++;
    const my = idx;
    return (
      <button
        key={key}
        type="button"
        role="menuitem"
        disabled={it.disabled}
        onMouseEnter={() => setActive(my)}
        onClick={() => {
          close();
          it.onSelect?.();
        }}
        className={clsx(
          'flex w-full items-center gap-3 rounded-[10px] px-3 py-2 text-left text-[0.9rem] disabled:opacity-40',
          it.danger ? 'text-danger' : 'text-ink',
          active === my && (it.danger ? 'bg-danger/10' : 'bg-sunken'),
        )}
      >
        {it.icon && <span className={clsx('shrink-0', it.danger ? 'text-danger' : 'text-ink-3')}>{it.icon}</span>}
        <span className="truncate">{it.label}</span>
      </button>
    );
  };
  return createPortal(
    <div
      ref={ref}
      role="menu"
      tabIndex={-1}
      className="anim-pop fixed z-[60] min-w-52 max-w-72 rounded-[14px] border border-line bg-raised p-1.5 shadow-pop outline-none"
      style={{ left: pos?.left ?? menu.x, top: pos?.top ?? menu.y, visibility: pos ? 'visible' : 'hidden' }}
      onContextMenu={(e) => e.preventDefault()}
    >
      {menu.header && <div className="border-b border-line px-1.5 pb-1.5 mb-1">{menu.header}</div>}
      {menu.items.map((it, i) =>
        it.children ? (
          <div key={i}>
            <div className="px-3 pt-2 pb-1 text-[0.75rem] font-semibold text-ink-3">{it.label}</div>
            {it.children.map((c, j) => renderItem(c, `${i}-${j}`))}
          </div>
        ) : (
          renderItem(it, String(i))
        ),
      )}
    </div>,
    document.body,
  );
}
