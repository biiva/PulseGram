import { clsx } from 'clsx';
import { useUi } from '../../stores/ui';

export function Toasts() {
  const toasts = useUi((s) => s.toasts);
  const dismiss = useUi((s) => s.dismiss);
  return (
    <div aria-live="polite" className="pointer-events-none fixed inset-x-0 bottom-20 z-[70] flex flex-col items-center gap-2 px-4 md:bottom-6">
      {toasts.map((t) => (
        <div
          key={t.id}
          role="status"
          className={clsx(
            'anim-pop pointer-events-auto flex max-w-md items-center gap-3 rounded-[14px] px-4 py-2.5 text-[0.9rem] shadow-pop',
            t.tone === 'danger' ? 'bg-danger text-white' : 'bg-ink text-bg',
          )}
        >
          <span className="min-w-0 flex-1">{t.text}</span>
          {t.action && (
            <button
              type="button"
              className="shrink-0 font-semibold text-accent-2"
              onClick={() => {
                t.action!.run();
                dismiss(t.id);
              }}
            >
              {t.action.label}
            </button>
          )}
        </div>
      ))}
    </div>
  );
}
