import { clsx } from 'clsx';
import { forwardRef, type ButtonHTMLAttributes, type ReactNode } from 'react';
import { Spinner } from './misc';

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'soft';
type Size = 'sm' | 'md' | 'lg';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant;
  size?: Size;
  loading?: boolean;
  icon?: ReactNode;
  block?: boolean;
}

const variants: Record<Variant, string> = {
  primary: 'bg-accent text-white hover:brightness-110 active:brightness-95 shadow-[0_6px_18px_-6px_var(--accent)]',
  secondary: 'bg-raised text-ink border border-line hover:border-line-strong hover:bg-sunken',
  ghost: 'text-ink-2 hover:bg-sunken hover:text-ink',
  danger: 'bg-danger text-white hover:brightness-110',
  soft: 'bg-soft text-accent hover:brightness-[0.97]',
};
const sizes: Record<Size, string> = {
  sm: 'h-8 px-3 text-[0.85rem] gap-1.5 rounded-[10px]',
  md: 'h-10 px-4 text-[0.92rem] gap-2 rounded-[12px]',
  lg: 'h-12 px-6 text-base gap-2 rounded-full',
};

/** Buttons disable themselves while `loading` to prevent double submits. */
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'primary', size = 'md', loading, icon, block, className, children, disabled, type = 'button', ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      disabled={disabled || loading}
      aria-busy={loading || undefined}
      className={clsx(
        'inline-flex select-none items-center justify-center font-semibold whitespace-nowrap transition-[filter,background,border-color,color,transform] duration-150 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-55',
        variants[variant],
        sizes[size],
        block && 'w-full',
        className,
      )}
      {...rest}
    >
      {loading ? <Spinner size={16} /> : icon}
      {children}
    </button>
  );
});

export interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  label: string;
  active?: boolean;
  size?: number;
  tone?: 'default' | 'accent' | 'danger';
}

export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(function IconButton(
  { label, active, size = 40, tone = 'default', className, children, type = 'button', ...rest },
  ref,
) {
  return (
    <button
      ref={ref}
      type={type}
      aria-label={label}
      title={label}
      style={{ width: size, height: size }}
      className={clsx(
        // Respect a caller-provided `hidden` (e.g. "hidden sm:inline-flex") instead of forcing a display value.
        !/(^|\s)hidden(\s|$)/.test(className ?? '') && 'inline-flex',
        'shrink-0 items-center justify-center rounded-full transition-colors duration-150 disabled:opacity-40',
        tone === 'accent' ? 'text-accent hover:bg-soft' : tone === 'danger' ? 'text-danger hover:bg-danger/10' : 'text-ink-2 hover:bg-sunken hover:text-ink',
        active && 'bg-soft text-accent',
        className,
      )}
      {...rest}
    >
      {children}
    </button>
  );
});
