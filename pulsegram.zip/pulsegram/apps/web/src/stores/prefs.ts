import { create } from 'zustand';
import type { AppearanceSettings, Language, NotificationSettings, Preferences, PrivacySettings } from '@pulsegram/shared';

function detectLanguage(): Language {
  try {
    const stored = localStorage.getItem('pg.lang');
    if (stored === 'ru' || stored === 'en') return stored;
  } catch {
    /* storage unavailable */
  }
  return navigator.language?.toLowerCase().startsWith('ru') ? 'ru' : 'en';
}

const defaultAppearance = (): AppearanceSettings => {
  const lang = detectLanguage();
  let theme: AppearanceSettings['theme'] = 'system';
  try {
    const t = localStorage.getItem('pg.theme');
    if (t === 'light' || t === 'dark' || t === 'system') theme = t;
  } catch {
    /* ignore */
  }
  return {
    theme,
    accent: '#7C4DFF',
    density: 'comfortable',
    fontScale: 1,
    language: lang,
    timeFormat: lang === 'ru' ? '24h' : '12h',
    dateFormat: lang === 'ru' ? 'dmy' : 'mdy',
    enterToSend: true,
    reduceMotion: false,
  };
};

interface PrefsState extends Preferences {
  loaded: boolean;
  set: (p: Preferences) => void;
  setAppearanceLocal: (a: Partial<AppearanceSettings>) => void;
}

export const usePrefs = create<PrefsState>((set) => ({
  loaded: false,
  privacy: {} as PrivacySettings,
  notifications: {} as NotificationSettings,
  appearance: defaultAppearance(),
  set: (p) => set({ ...p, loaded: true }),
  setAppearanceLocal: (a) => set((s) => ({ appearance: { ...s.appearance, ...a } })),
}));

/** Reflect appearance settings onto the document (theme, accent, density, text size, motion). */
export function applyAppearance(a: AppearanceSettings) {
  const root = document.documentElement;
  const mq = window.matchMedia('(prefers-color-scheme: dark)');
  const dark = a.theme === 'dark' || (a.theme === 'system' && mq.matches);
  root.dataset.theme = dark ? 'dark' : 'light';
  root.dataset.density = a.density;
  root.dataset.reduceMotion = String(a.reduceMotion);
  root.style.setProperty('--accent', a.accent);
  root.style.setProperty('--font-scale', String(a.fontScale));
  root.lang = a.language;
  try {
    localStorage.setItem('pg.theme', a.theme);
    localStorage.setItem('pg.accent', a.accent);
    localStorage.setItem('pg.density', a.density);
    localStorage.setItem('pg.lang', a.language);
  } catch {
    /* ignore */
  }
}
