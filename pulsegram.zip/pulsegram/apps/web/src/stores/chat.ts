import { create } from 'zustand';
import type {
  ConversationDto,
  ConversationMembership,
  ConversationPatch,
  MessageDto,
  PresenceView,
  ReactionSummary,
  UserSummary,
} from '@pulsegram/shared';

export interface PendingUpload {
  file: File;
  progress: number; // 0..1
  abort?: () => void;
  asFile?: boolean;
  voice?: { durationMs: number };
  previewUrl?: string;
}

export interface LocalState {
  status: 'sending' | 'failed';
  error?: string;
  uploads?: PendingUpload[];
}

export type ClientMessage = MessageDto & { local?: LocalState };

export interface History {
  items: ClientMessage[];
  hasMoreBefore: boolean;
  hasMoreAfter: boolean;
  loaded: boolean;
}

export type ConnectionState = 'connecting' | 'online' | 'offline' | 'syncing';

interface TypingEntry {
  kind: 'text' | 'voice' | 'upload';
  until: number;
}

interface ChatState {
  conversations: Record<string, ConversationDto>;
  listLoaded: boolean;
  histories: Record<string, History>;
  users: Record<string, UserSummary>;
  presence: Record<string, PresenceView>;
  typing: Record<string, Record<string, TypingEntry>>;
  connection: ConnectionState;
  activeId: string | null;
  myId: string | null;

  reset: () => void;
  setMyId: (id: string | null) => void;
  setActive: (id: string | null) => void;
  setConnection: (c: ConnectionState) => void;
  setConversations: (list: ConversationDto[]) => void;
  upsertConversation: (c: ConversationDto) => void;
  patchConversation: (id: string, patch: ConversationPatch | Partial<ConversationDto>) => void;
  setMembership: (id: string, me: ConversationMembership) => void;
  removeConversation: (id: string) => void;
  setPins: (id: string, pins: string[]) => void;

  setHistory: (convId: string, items: MessageDto[], flags: { hasMoreBefore?: boolean; hasMoreAfter?: boolean }, mode: 'replace' | 'prepend' | 'append') => void;
  dropHistories: () => void;
  upsertMessage: (m: ClientMessage, opts?: { fromRealtime?: boolean }) => void;
  updateLocal: (convId: string, clientId: string, local: LocalState | undefined) => void;
  removeLocal: (convId: string, clientId: string) => void;
  removeMessages: (convId: string, ids: string[]) => void;
  setReactions: (convId: string, messageId: string, reactions: ReactionSummary[], mineEmojis: string[] | null) => void;
  setViews: (convId: string, views: Record<string, number>) => void;
  markRead: (convId: string, userId: string, seq: number) => void;

  addUsers: (users: UserSummary[]) => void;
  setPresence: (userId: string, p: PresenceView) => void;
  setTyping: (convId: string, userId: string, kind: TypingEntry['kind'] | null) => void;
}

const sortItems = (items: ClientMessage[]) =>
  items.sort((a, b) => {
    // Pending messages (seq 0) always sort after confirmed ones, by creation time.
    if (a.seq && b.seq) return a.seq - b.seq;
    if (!a.seq && !b.seq) return a.createdAt.localeCompare(b.createdAt);
    return a.seq ? -1 : 1;
  });

function mergeReactions(prev: ReactionSummary[] | undefined, next: ReactionSummary[], mineEmojis: string[] | null): ReactionSummary[] {
  const mine = mineEmojis ? new Set(mineEmojis) : new Set((prev ?? []).filter((r) => r.mine).map((r) => r.emoji));
  return next.map((r) => ({ ...r, mine: mine.has(r.emoji) }));
}

const initial = {
  conversations: {},
  listLoaded: false,
  histories: {},
  users: {},
  presence: {},
  typing: {},
  connection: 'connecting' as ConnectionState,
  activeId: null,
  myId: null,
};

export const useChat = create<ChatState>((set, get) => ({
  ...initial,

  reset: () => set({ ...initial }),
  setMyId: (id) => set({ myId: id }),
  setActive: (id) => set({ activeId: id }),
  setConnection: (connection) => set({ connection }),

  setConversations: (list) =>
    set((s) => {
      const conversations: Record<string, ConversationDto> = {};
      const users = { ...s.users };
      for (const c of list) {
        conversations[c.id] = c;
        if (c.peer) users[c.peer.id] = c.peer;
      }
      // Drop histories of chats we no longer belong to.
      const histories = Object.fromEntries(Object.entries(s.histories).filter(([id]) => conversations[id]));
      return { conversations, users, histories, listLoaded: true };
    }),

  upsertConversation: (c) =>
    set((s) => ({
      conversations: { ...s.conversations, [c.id]: c },
      users: c.peer ? { ...s.users, [c.peer.id]: c.peer } : s.users,
    })),

  patchConversation: (id, patch) =>
    set((s) => {
      const c = s.conversations[id];
      if (!c) return s;
      return { conversations: { ...s.conversations, [id]: { ...c, ...patch } } };
    }),

  setMembership: (id, me) =>
    set((s) => {
      const c = s.conversations[id];
      if (!c) return s;
      const unreadCount = me.lastReadSeq >= (c.lastMessage?.seq ?? 0) ? 0 : c.unreadCount;
      return { conversations: { ...s.conversations, [id]: { ...c, me, unreadCount } } };
    }),

  removeConversation: (id) =>
    set((s) => {
      const conversations = { ...s.conversations };
      delete conversations[id];
      const histories = { ...s.histories };
      delete histories[id];
      return { conversations, histories };
    }),

  setPins: (id, pins) => get().patchConversation(id, { pinnedMessageIds: pins }),

  setHistory: (convId, items, flags, mode) =>
    set((s) => {
      const prev = s.histories[convId];
      let merged: ClientMessage[];
      if (mode === 'replace' || !prev) {
        // Keep optimistic messages that are still pending.
        const pending = prev?.items.filter((m) => m.local) ?? [];
        merged = [...items, ...pending.filter((p) => !items.some((i) => i.clientId && i.clientId === p.clientId))];
      } else {
        const byId = new Map(prev.items.map((m) => [m.id, m]));
        for (const m of items) byId.set(m.id, { ...byId.get(m.id), ...m });
        merged = [...byId.values()];
      }
      sortItems(merged);
      return {
        histories: {
          ...s.histories,
          [convId]: {
            items: merged,
            loaded: true,
            hasMoreBefore: mode === 'append' && prev ? prev.hasMoreBefore : (flags.hasMoreBefore ?? false),
            hasMoreAfter: mode === 'prepend' && prev ? prev.hasMoreAfter : (flags.hasMoreAfter ?? false),
          },
        },
      };
    }),

  dropHistories: () => set({ histories: {} }),

  upsertMessage: (m, opts = {}) =>
    set((s) => {
      const convId = m.conversationId;
      const h = s.histories[convId];
      let histories = s.histories;
      let isNew = true;
      if (h) {
        const items = [...h.items];
        const idx = items.findIndex((x) => x.id === m.id || (m.clientId && x.clientId === m.clientId && x.senderId === m.senderId));
        if (idx >= 0) {
          isNew = Boolean(items[idx]!.local) && !m.local;
          const prevMsg = items[idx]!;
          items[idx] = { ...prevMsg, ...m, reactions: m.local ? m.reactions : mergeReactions(prevMsg.reactions, m.reactions, prevMsg.local ? [] : null) };
          if (!m.local) delete (items[idx] as ClientMessage).local;
          if (prevMsg.local?.uploads) for (const u of prevMsg.local.uploads) if (u.previewUrl && !m.local) setTimeout(() => URL.revokeObjectURL(u.previewUrl!), 5000);
        } else if (!h.hasMoreAfter || m.local) {
          items.push(m);
        } else {
          // We are viewing an older window; the message will be loaded when the user jumps to latest.
        }
        sortItems(items);
        histories = { ...s.histories, [convId]: { ...h, items } };
      }
      if (m.local) return { histories };

      const c = s.conversations[convId];
      if (!c) return { histories };
      const isMine = m.senderId === s.myId;
      const newer = !c.lastMessage || m.seq >= c.lastMessage.seq;
      let conv: ConversationDto = c;
      if (newer && !m.deletedAt) {
        conv = { ...conv, lastMessage: m, lastActivityAt: m.createdAt };
      } else if (c.lastMessage?.id === m.id) {
        conv = { ...conv, lastMessage: m };
      }
      if (opts.fromRealtime && isNew && m.type !== 'system') {
        // Sending a message marks everything before it as read (the server does the same).
        if (isMine && conv.me) conv = { ...conv, unreadCount: 0, unreadMentions: 0, me: { ...conv.me, lastReadSeq: Math.max(conv.me.lastReadSeq, m.seq), draft: '', markedUnread: false } };
        else if (!isMine && conv.type !== 'saved' && newer) {
          conv = {
            ...conv,
            unreadCount: conv.unreadCount + 1,
            unreadMentions: conv.unreadMentions + (s.myId && m.mentions.includes(s.myId) ? 1 : 0),
          };
        }
      }
      return { histories, conversations: { ...s.conversations, [convId]: conv } };
    }),

  updateLocal: (convId, clientId, local) =>
    set((s) => {
      const h = s.histories[convId];
      if (!h) return s;
      return {
        histories: {
          ...s.histories,
          [convId]: { ...h, items: h.items.map((m) => (m.clientId === clientId && m.local ? { ...m, local } : m)) },
        },
      };
    }),

  removeLocal: (convId, clientId) =>
    set((s) => {
      const h = s.histories[convId];
      if (!h) return s;
      return { histories: { ...s.histories, [convId]: { ...h, items: h.items.filter((m) => !(m.local && m.clientId === clientId)) } } };
    }),

  removeMessages: (convId, ids) =>
    set((s) => {
      const h = s.histories[convId];
      const idSet = new Set(ids);
      const histories = h ? { ...s.histories, [convId]: { ...h, items: h.items.filter((m) => !idSet.has(m.id)) } } : s.histories;
      const c = s.conversations[convId];
      let conversations = s.conversations;
      if (c) {
        let next = c;
        if (c.lastMessage && idSet.has(c.lastMessage.id)) {
          const remaining = histories[convId]?.items.filter((m) => !m.local) ?? [];
          next = { ...next, lastMessage: remaining[remaining.length - 1] ?? null };
        }
        if (c.pinnedMessageIds.some((p) => idSet.has(p))) next = { ...next, pinnedMessageIds: c.pinnedMessageIds.filter((p) => !idSet.has(p)) };
        conversations = { ...s.conversations, [convId]: next };
      }
      return { histories, conversations };
    }),

  setReactions: (convId, messageId, reactions, mineEmojis) =>
    set((s) => {
      const h = s.histories[convId];
      if (!h) return s;
      return {
        histories: {
          ...s.histories,
          [convId]: {
            ...h,
            items: h.items.map((m) => (m.id === messageId ? { ...m, reactions: mergeReactions(m.reactions, reactions, mineEmojis) } : m)),
          },
        },
      };
    }),

  setViews: (convId, views) =>
    set((s) => {
      const h = s.histories[convId];
      if (!h) return s;
      return {
        histories: { ...s.histories, [convId]: { ...h, items: h.items.map((m) => (views[m.id] !== undefined ? { ...m, views: views[m.id]! } : m)) } },
      };
    }),

  markRead: (convId, userId, seq) =>
    set((s) => {
      const c = s.conversations[convId];
      if (!c) return s;
      if (userId === s.myId) {
        if (!c.me) return s;
        const lastReadSeq = Math.max(c.me.lastReadSeq, seq);
        const unread = lastReadSeq >= (c.lastMessage?.seq ?? 0) ? 0 : Math.max(0, c.unreadCount);
        const h = s.histories[convId];
        const exact = h ? h.items.filter((m) => !m.local && m.seq > lastReadSeq && m.senderId !== s.myId && m.type !== 'system').length : unread;
        return {
          conversations: {
            ...s.conversations,
            [convId]: { ...c, me: { ...c.me, lastReadSeq, markedUnread: false }, unreadCount: h && !h.hasMoreAfter ? exact : unread, unreadMentions: unread === 0 ? 0 : c.unreadMentions },
          },
        };
      }
      return { conversations: { ...s.conversations, [convId]: { ...c, peerReadSeq: Math.max(c.peerReadSeq, seq) } } };
    }),

  addUsers: (list) =>
    set((s) => {
      if (list.length === 0) return s;
      const users = { ...s.users };
      const presence = { ...s.presence };
      for (const u of list) {
        users[u.id] = u;
        if (!presence[u.id]) presence[u.id] = u.presence;
      }
      return { users, presence };
    }),

  setPresence: (userId, p) => set((s) => ({ presence: { ...s.presence, [userId]: p } })),

  setTyping: (convId, userId, kind) =>
    set((s) => {
      const cur = { ...(s.typing[convId] ?? {}) };
      if (kind) cur[userId] = { kind, until: Date.now() + 6000 };
      else delete cur[userId];
      return { typing: { ...s.typing, [convId]: cur } };
    }),
}));

/** Conversation list ordering: pinned first (by pin time), then most recent activity. */
export function sortConversations(list: ConversationDto[]): ConversationDto[] {
  return [...list].sort((a, b) => {
    const ap = a.me?.isPinned ? 1 : 0;
    const bp = b.me?.isPinned ? 1 : 0;
    if (ap !== bp) return bp - ap;
    if (ap && bp) return (a.me?.pinnedAt ?? '').localeCompare(b.me?.pinnedAt ?? '');
    return b.lastActivityAt.localeCompare(a.lastActivityAt);
  });
}

export function isMuted(c: ConversationDto): boolean {
  return Boolean(c.me?.mutedUntil && new Date(c.me.mutedUntil).getTime() > Date.now());
}
