import { create } from 'zustand';
import type { MessageDto } from '@pulsegram/shared';

export type ChatFilter = 'all' | 'direct' | 'group' | 'channel' | 'unread' | 'archive' | `folder:${string}`;

export interface Toast {
  id: number;
  text: string;
  tone?: 'default' | 'success' | 'danger';
  action?: { label: string; run: () => void };
}

export type Dialog =
  | { kind: 'new-message' }
  | { kind: 'new-group' }
  | { kind: 'new-channel' }
  | { kind: 'forward'; conversationId: string; messageIds: string[] }
  | { kind: 'report'; targetType: 'user' | 'message' | 'conversation'; targetId: string }
  | { kind: 'user'; userId: string }
  | { kind: 'media'; items: MessageDto[]; index: number }
  | { kind: 'add-members'; conversationId: string }
  | null;

interface UiState {
  filter: ChatFilter;
  infoOpen: boolean;
  searchOpen: boolean;
  dialog: Dialog;
  toasts: Toast[];
  setFilter: (f: ChatFilter) => void;
  setInfoOpen: (v: boolean) => void;
  setSearchOpen: (v: boolean) => void;
  open: (d: Dialog) => void;
  close: () => void;
  toast: (t: Omit<Toast, 'id'> | string) => void;
  dismiss: (id: number) => void;
}

let toastId = 0;

export const useUi = create<UiState>((set) => ({
  filter: 'all',
  infoOpen: false,
  searchOpen: false,
  dialog: null,
  toasts: [],
  setFilter: (filter) => set({ filter }),
  setInfoOpen: (infoOpen) => set({ infoOpen }),
  setSearchOpen: (searchOpen) => set({ searchOpen }),
  open: (dialog) => set({ dialog }),
  close: () => set({ dialog: null }),
  toast: (t) => {
    const id = ++toastId;
    const toast = typeof t === 'string' ? { id, text: t } : { ...t, id };
    set((s) => ({ toasts: [...s.toasts.slice(-3), toast] }));
    setTimeout(() => set((s) => ({ toasts: s.toasts.filter((x) => x.id !== id) })), toast.action ? 6000 : 3500);
  },
  dismiss: (id) => set((s) => ({ toasts: s.toasts.filter((x) => x.id !== id) })),
}));

export const toast = (t: Omit<Toast, 'id'> | string) => useUi.getState().toast(t);
