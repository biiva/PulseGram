import { beforeEach, describe, expect, it } from 'vitest';
import type { ConversationDto, MessageDto } from '@pulsegram/shared';
import { DEFAULT_GROUP_SETTINGS } from '@pulsegram/shared';
import { sortConversations, useChat } from './chat';

const ME = 'me-1';
const PEER = 'peer-1';

function msg(over: Partial<MessageDto>): MessageDto {
  return {
    id: crypto.randomUUID(),
    seq: 1,
    conversationId: 'c1',
    senderId: PEER,
    clientId: null,
    type: 'text',
    text: 'hi',
    createdAt: new Date().toISOString(),
    editedAt: null,
    deletedAt: null,
    replyTo: null,
    forward: null,
    attachments: [],
    sticker: null,
    gif: null,
    reactions: [],
    views: null,
    system: null,
    mentions: [],
    signature: null,
    ...over,
  };
}

function conv(over: Partial<ConversationDto> = {}): ConversationDto {
  return {
    id: 'c1',
    type: 'direct',
    title: 'Peer',
    description: '',
    username: null,
    avatarUrl: null,
    isPublic: false,
    category: null,
    settings: DEFAULT_GROUP_SETTINGS,
    memberCount: 2,
    createdAt: new Date().toISOString(),
    lastMessage: null,
    lastActivityAt: '2026-01-01T00:00:00.000Z',
    unreadCount: 0,
    unreadMentions: 0,
    peerReadSeq: 0,
    peer: null,
    me: { role: 'member', isPinned: false, pinnedAt: null, isArchived: false, mutedUntil: null, draft: '', draftUpdatedAt: null, lastReadSeq: 0, markedUnread: false, joinedAt: '' },
    pinnedMessageIds: [],
    discussionGroupId: null,
    linkedChannelId: null,
    isDemo: false,
    ...over,
  };
}

beforeEach(() => {
  useChat.getState().reset();
  useChat.getState().setMyId(ME);
  useChat.getState().setConversations([conv()]);
  useChat.getState().setHistory('c1', [], { hasMoreBefore: false }, 'replace');
});

describe('chat store', () => {
  it('replaces the optimistic message when the server copy arrives (no duplicates)', () => {
    const s = useChat.getState();
    s.upsertMessage({ ...msg({ id: 'local-x', seq: 0, senderId: ME, clientId: 'cid-1', text: 'yo' }), local: { status: 'sending' } });
    s.upsertMessage(msg({ id: 'server-x', seq: 5, senderId: ME, clientId: 'cid-1', text: 'yo' }), { fromRealtime: true });
    // The same event delivered twice (HTTP response + websocket) must not duplicate either.
    s.upsertMessage(msg({ id: 'server-x', seq: 5, senderId: ME, clientId: 'cid-1', text: 'yo' }), { fromRealtime: true });
    const items = useChat.getState().histories.c1!.items;
    expect(items).toHaveLength(1);
    expect(items[0]!.id).toBe('server-x');
    expect(items[0]!.local).toBeUndefined();
  });

  it('counts unread for incoming realtime messages; sending clears them (like the server)', () => {
    const s = useChat.getState();
    s.upsertMessage(msg({ seq: 2 }), { fromRealtime: true });
    s.upsertMessage(msg({ seq: 3 }), { fromRealtime: true });
    expect(useChat.getState().conversations.c1!.unreadCount).toBe(2);
    s.upsertMessage(msg({ seq: 4, senderId: ME }), { fromRealtime: true });
    const c = useChat.getState().conversations.c1!;
    expect(c.unreadCount).toBe(0);
    expect(c.me!.lastReadSeq).toBe(4);
    expect(c.lastMessage!.seq).toBe(4);
  });

  it('keeps messages ordered by server sequence, pending ones last', () => {
    const s = useChat.getState();
    s.upsertMessage({ ...msg({ id: 'p', seq: 0, senderId: ME, clientId: 'c' }), local: { status: 'sending' } });
    s.upsertMessage(msg({ id: 'b', seq: 9 }));
    s.upsertMessage(msg({ id: 'a', seq: 7 }));
    expect(useChat.getState().histories.c1!.items.map((m) => m.id)).toEqual(['a', 'b', 'p']);
  });

  it('preserves my reaction flags when a generic reaction update arrives', () => {
    const s = useChat.getState();
    const m = msg({ id: 'r', seq: 2 });
    s.upsertMessage(m);
    s.setReactions('c1', 'r', [{ emoji: '🔥', count: 1, mine: true, userIds: [ME] }], ['🔥']);
    s.setReactions('c1', 'r', [{ emoji: '🔥', count: 2, mine: false, userIds: [PEER, ME] }], null);
    expect(useChat.getState().histories.c1!.items[0]!.reactions[0]).toMatchObject({ count: 2, mine: true });
  });

  it('removes deleted messages and fixes the chat preview', () => {
    const s = useChat.getState();
    const a = msg({ id: 'a', seq: 1, text: 'first' });
    const b = msg({ id: 'b', seq: 2, text: 'second' });
    s.upsertMessage(a, { fromRealtime: true });
    s.upsertMessage(b, { fromRealtime: true });
    s.removeMessages('c1', ['b']);
    expect(useChat.getState().conversations.c1!.lastMessage!.id).toBe('a');
  });

  it('marks read and clears unread', () => {
    const s = useChat.getState();
    s.upsertMessage(msg({ seq: 3 }), { fromRealtime: true });
    s.markRead('c1', ME, 3);
    expect(useChat.getState().conversations.c1!.unreadCount).toBe(0);
    s.markRead('c1', PEER, 3);
    expect(useChat.getState().conversations.c1!.peerReadSeq).toBe(3);
  });

  it('sorts pinned chats first, then by activity', () => {
    const list = sortConversations([
      conv({ id: 'old', lastActivityAt: '2026-01-01T00:00:00Z' }),
      conv({ id: 'new', lastActivityAt: '2026-03-01T00:00:00Z' }),
      conv({ id: 'pin', lastActivityAt: '2025-01-01T00:00:00Z', me: { ...conv().me!, isPinned: true, pinnedAt: '2026-01-01T00:00:00Z' } }),
    ]);
    expect(list.map((c) => c.id)).toEqual(['pin', 'new', 'old']);
  });
});
