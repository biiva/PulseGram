import { create } from 'zustand';
import type { Me, Preferences, PublicConfig } from '@pulsegram/shared';
import { http } from '../lib/api';
import { usePrefs } from './prefs';

type Status = 'loading' | 'anon' | 'authed';

interface AuthState {
  status: Status;
  me: Me | null;
  config: PublicConfig | null;
  setSession: (me: Me, prefs: Preferences) => void;
  setMe: (me: Me) => void;
  clear: () => void;
  bootstrap: () => Promise<void>;
}

export const useAuth = create<AuthState>((set) => ({
  status: 'loading',
  me: null,
  config: null,
  setSession: (me, prefs) => {
    usePrefs.getState().set(prefs);
    set({ me, status: 'authed' });
  },
  setMe: (me) => set({ me }),
  clear: () => set({ me: null, status: 'anon' }),
  bootstrap: async () => {
    const [config, session] = await Promise.all([
      http.get<PublicConfig>('/api/config').catch(() => null),
      http.get<{ me: Me; preferences: Preferences }>('/api/auth/me', { quiet401: true }).catch(() => null),
    ]);
    set({ config });
    if (session) {
      usePrefs.getState().set(session.preferences);
      set({ me: session.me, status: 'authed' });
    } else set({ status: 'anon' });
  },
}));
