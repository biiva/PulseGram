import type { AppearanceSettings, PresenceView } from '@pulsegram/shared';
import type { TFn } from '../i18n';

type Fmt = Pick<AppearanceSettings, 'timeFormat' | 'dateFormat' | 'language'>;

export function formatTime(iso: string | Date, f: Fmt): string {
  const d = typeof iso === 'string' ? new Date(iso) : iso;
  return d.toLocaleTimeString(f.language === 'ru' ? 'ru-RU' : 'en-US', {
    hour: f.timeFormat === '24h' ? '2-digit' : 'numeric',
    minute: '2-digit',
    hour12: f.timeFormat === '12h',
  });
}

export function formatDate(iso: string | Date, f: Fmt, withYear = true): string {
  const d = typeof iso === 'string' ? new Date(iso) : iso;
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yy = String(d.getFullYear());
  if (f.dateFormat === 'ymd') return withYear ? `${yy}-${mm}-${dd}` : `${mm}-${dd}`;
  if (f.dateFormat === 'mdy') return withYear ? `${mm}/${dd}/${yy}` : `${mm}/${dd}`;
  return withYear ? `${dd}.${mm}.${yy}` : `${dd}.${mm}`;
}

export function isSameDay(a: Date, b: Date) {
  return a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
}

/** Compact timestamp for the chat list: time today, weekday this week, date otherwise. */
export function formatListTime(iso: string, f: Fmt): string {
  const d = new Date(iso);
  const now = new Date();
  if (isSameDay(d, now)) return formatTime(d, f);
  const diffDays = (now.getTime() - d.getTime()) / 86_400_000;
  if (diffDays < 6) return d.toLocaleDateString(f.language === 'ru' ? 'ru-RU' : 'en-US', { weekday: 'short' });
  return formatDate(d, f, d.getFullYear() !== now.getFullYear());
}

/** Day divider label inside a chat. */
export function formatDayLabel(iso: string, f: Fmt, t: TFn): string {
  const d = new Date(iso);
  const now = new Date();
  if (isSameDay(d, now)) return t('chat.today');
  const y = new Date(now);
  y.setDate(now.getDate() - 1);
  if (isSameDay(d, y)) return t('chat.yesterday');
  return d.toLocaleDateString(f.language === 'ru' ? 'ru-RU' : 'en-US', {
    day: 'numeric',
    month: 'long',
    year: d.getFullYear() === now.getFullYear() ? undefined : 'numeric',
  });
}

export function formatRelative(iso: string, f: Fmt, t: TFn): string {
  const d = new Date(iso);
  const now = new Date();
  const diffMin = Math.floor((now.getTime() - d.getTime()) / 60_000);
  if (diffMin < 1) return t('time.justNow');
  if (diffMin < 60) return t('time.minAgo', { n: diffMin });
  if (isSameDay(d, now)) return t('time.today', { t: formatTime(d, f) });
  const y = new Date(now);
  y.setDate(now.getDate() - 1);
  if (isSameDay(d, y)) return t('time.yesterday', { t: formatTime(d, f) });
  return t('time.on', { d: formatDate(d, f), t: formatTime(d, f) });
}

export function presenceText(p: PresenceView | undefined, f: Fmt, t: TFn): string {
  if (!p) return '';
  switch (p.kind) {
    case 'online':
      return p.dnd ? `${t('chat.online')} · ${t('chat.dnd')}` : t('chat.online');
    case 'last_seen':
      return t('chat.lastSeenAt', { time: formatRelative(p.at, f, t) });
    case 'recently':
      return t('chat.lastSeenRecently');
    case 'within_week':
      return t('chat.lastSeenWeek');
    case 'within_month':
      return t('chat.lastSeenMonth');
    case 'long_ago':
      return t('chat.lastSeenLongAgo');
    default:
      return '';
  }
}

export function formatBytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(n < 10 * 1024 ? 1 : 0)} KB`;
  if (n < 1024 ** 3) return `${(n / 1024 / 1024).toFixed(1)} MB`;
  return `${(n / 1024 ** 3).toFixed(2)} GB`;
}

export function formatDuration(ms: number | null | undefined): string {
  if (ms === null || ms === undefined || !Number.isFinite(ms)) return '0:00';
  const total = Math.max(0, Math.round(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const s = total % 60;
  return h ? `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${m}:${String(s).padStart(2, '0')}`;
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  const chars = parts.length > 1 ? [parts[0]![0], parts[1]![0]] : [...(parts[0] ?? '?')].slice(0, 2);
  return chars.join('').toUpperCase();
}

/** Deterministic avatar hue from an id — 8 brand-compatible tones. */
const AVATAR_TONES = ['#7C4DFF', '#35B6FF', '#FF6B9A', '#1FAE6B', '#F2994A', '#9B6BFF', '#2CC3B5', '#E5484D'];
export function toneFor(id: string): string {
  let h = 0;
  for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
  return AVATAR_TONES[Math.abs(h) % AVATAR_TONES.length]!;
}
