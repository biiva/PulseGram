import type {
  AttachmentDto,
  ConversationDto,
  ConversationMembership,
  GifDto,
  MessageDto,
  ReactionSummary,
  StickerDto,
  UpdateMembershipInput,
  UserSummary,
} from '@pulsegram/shared';
import { ApiError, http } from './api';
import { uploadFile } from './upload';
import { useChat, type ClientMessage, type PendingUpload } from '../stores/chat';
import { useAuth } from '../stores/auth';
import { queryClient } from './queryClient';

const PAGE = 50;

export async function loadConversations() {
  const list = await http.get<ConversationDto[]>('/api/conversations');
  useChat.getState().setConversations(list);
  // Names for chat-list previews ("Ann: …", "Ann pinned …").
  void fetchMissingUsers(list.flatMap((c) => (c.lastMessage ? [c.lastMessage] : [])));
  return list;
}

export async function ensureConversation(id: string): Promise<ConversationDto | null> {
  const existing = useChat.getState().conversations[id];
  if (existing) return existing;
  try {
    const c = await http.get<ConversationDto>(`/api/conversations/${id}`);
    if (c.me) useChat.getState().upsertConversation(c);
    return c;
  } catch {
    return null;
  }
}

interface HistoryPage {
  items: MessageDto[];
  hasMoreBefore: boolean;
  hasMoreAfter: boolean;
}

const inflight = new Map<string, Promise<void>>();

function once(key: string, fn: () => Promise<void>) {
  const cur = inflight.get(key);
  if (cur) return cur;
  const p = fn().finally(() => inflight.delete(key));
  inflight.set(key, p);
  return p;
}

export function loadLatest(convId: string) {
  return once(`latest:${convId}`, async () => {
    const page = await http.get<HistoryPage>(`/api/conversations/${convId}/messages?limit=${PAGE}`);
    useChat.getState().setHistory(convId, page.items, { hasMoreBefore: page.hasMoreBefore, hasMoreAfter: false }, 'replace');
    await fetchMissingUsers(page.items);
  });
}

export function loadOlder(convId: string) {
  return once(`older:${convId}`, async () => {
    const h = useChat.getState().histories[convId];
    const first = h?.items.find((m) => m.seq);
    if (!h || !first || !h.hasMoreBefore) return;
    const page = await http.get<HistoryPage>(`/api/conversations/${convId}/messages?before=${first.seq}&limit=${PAGE}`);
    useChat.getState().setHistory(convId, page.items, { hasMoreBefore: page.hasMoreBefore }, 'prepend');
    await fetchMissingUsers(page.items);
  });
}

export function loadNewer(convId: string) {
  return once(`newer:${convId}`, async () => {
    const h = useChat.getState().histories[convId];
    const confirmed = h?.items.filter((m) => m.seq) ?? [];
    const last = confirmed[confirmed.length - 1];
    if (!h || !last || !h.hasMoreAfter) return;
    const page = await http.get<HistoryPage>(`/api/conversations/${convId}/messages?after=${last.seq}&limit=${PAGE}`);
    useChat.getState().setHistory(convId, page.items, { hasMoreAfter: page.hasMoreAfter }, 'append');
    await fetchMissingUsers(page.items);
  });
}

/** Load a window of history around a message (jump to reply / pinned / search result). */
export async function loadAround(convId: string, seq: number) {
  const h = useChat.getState().histories[convId];
  if (h?.items.some((m) => m.seq === seq)) return;
  const page = await http.get<HistoryPage>(`/api/conversations/${convId}/messages?around=${seq}&limit=${PAGE}`);
  useChat.getState().setHistory(convId, page.items, { hasMoreBefore: page.hasMoreBefore, hasMoreAfter: page.hasMoreAfter }, 'replace');
  await fetchMissingUsers(page.items);
}

const userFetchQueue = new Set<string>();
let userFetchTimer: ReturnType<typeof setTimeout> | null = null;

export async function fetchMissingUsers(messages: MessageDto[]) {
  const s = useChat.getState();
  const ids = new Set<string>();
  for (const m of messages) {
    if (m.senderId && !s.users[m.senderId]) ids.add(m.senderId);
    const sys = m.system as { actorId?: string; userId?: string; userIds?: string[] } | null;
    if (sys?.actorId && !s.users[sys.actorId]) ids.add(sys.actorId);
    if (sys?.userId && !s.users[sys.userId]) ids.add(sys.userId);
    for (const u of sys?.userIds ?? []) if (!s.users[u]) ids.add(u);
    for (const r of m.reactions) for (const u of r.userIds) if (!s.users[u]) ids.add(u);
  }
  if (ids.size === 0) return;
  for (const id of ids) userFetchQueue.add(id);
  if (userFetchTimer) return;
  await new Promise<void>((resolve) => {
    userFetchTimer = setTimeout(async () => {
      const batch = [...userFetchQueue].slice(0, 200);
      batch.forEach((b) => userFetchQueue.delete(b));
      userFetchTimer = null;
      try {
        const users = await http.get<UserSummary[]>(`/api/users?ids=${batch.join(',')}`);
        useChat.getState().addUsers(users);
      } catch {
        /* non-fatal */
      }
      resolve();
    }, 30);
  });
}

// ── Sending ─────────────────────────────────────────────────────────────────

export interface Outgoing {
  text: string;
  replyToId?: string;
  files?: Array<{ file: File; asFile?: boolean }>;
  voice?: { blob: Blob; durationMs: number };
  sticker?: StickerDto;
  gif?: GifDto;
  silent?: boolean;
}

const uploadsInProgress = new Map<string, Array<() => void>>();

function optimistic(convId: string, clientId: string, o: Outgoing, uploads: PendingUpload[]): ClientMessage {
  const me = useAuth.getState().me!;
  const conv = useChat.getState().conversations[convId];
  const replied = o.replyToId ? useChat.getState().histories[convId]?.items.find((m) => m.id === o.replyToId) : undefined;
  return {
    id: `local-${clientId}`,
    seq: 0,
    conversationId: convId,
    senderId: me.id,
    clientId,
    type: o.voice ? 'voice' : o.sticker ? 'sticker' : o.gif ? 'gif' : uploads.length ? 'media' : 'text',
    text: o.text,
    createdAt: new Date().toISOString(),
    editedAt: null,
    deletedAt: null,
    replyTo: replied
      ? {
          id: replied.id,
          seq: replied.seq,
          senderId: replied.senderId,
          senderName: useChat.getState().users[replied.senderId ?? '']?.displayName ?? '',
          text: replied.text,
          type: replied.type,
          deleted: false,
        }
      : null,
    forward: null,
    attachments: uploads.map((u, i) => localAttachment(u, i)),
    sticker: o.sticker ?? null,
    gif: o.gif ?? null,
    reactions: [],
    views: conv?.type === 'channel' ? 0 : null,
    system: null,
    mentions: [],
    signature: null,
    local: { status: 'sending', uploads },
  };
}

function localAttachment(u: PendingUpload, i: number): AttachmentDto {
  const isImg = u.file.type.startsWith('image/') && !u.asFile;
  const isVid = u.file.type.startsWith('video/') && !u.asFile;
  return {
    id: `local-${i}`,
    kind: u.voice ? 'voice' : isImg ? 'image' : isVid ? 'video' : u.file.type.startsWith('audio/') && !u.asFile ? 'audio' : 'file',
    mime: u.file.type,
    size: u.file.size,
    name: u.file.name,
    url: u.previewUrl ?? '',
    thumbUrl: isImg ? (u.previewUrl ?? null) : null,
    width: null,
    height: null,
    durationMs: u.voice?.durationMs ?? null,
    waveform: null,
  };
}

const sendQueue = new Map<string, Outgoing>();

export async function sendMessage(convId: string, o: Outgoing, clientId: string = crypto.randomUUID()) {
  const s = useChat.getState();
  const uploads: PendingUpload[] = [];
  if (o.voice) uploads.push({ file: new File([o.voice.blob], 'voice.webm', { type: o.voice.blob.type || 'audio/webm' }), progress: 0, voice: { durationMs: o.voice.durationMs } });
  for (const f of o.files ?? []) {
    uploads.push({
      file: f.file,
      progress: 0,
      asFile: f.asFile,
      previewUrl: f.file.type.startsWith('image/') || f.file.type.startsWith('video/') ? URL.createObjectURL(f.file) : undefined,
    });
  }
  sendQueue.set(clientId, o);
  s.upsertMessage(optimistic(convId, clientId, o, uploads));
  await deliver(convId, clientId, o, uploads);
}

async function deliver(convId: string, clientId: string, o: Outgoing, uploads: PendingUpload[]) {
  const s = useChat.getState();
  try {
    const attachmentIds: string[] = [];
    const aborts: Array<() => void> = [];
    uploadsInProgress.set(clientId, aborts);
    for (let i = 0; i < uploads.length; i++) {
      const u = uploads[i]!;
      const handle = uploadFile(u.file, u.file.name, {
        as: u.voice ? 'voice' : u.asFile ? 'file' : undefined,
        onProgress: (p) => {
          uploads[i] = { ...u, progress: p };
          useChat.getState().updateLocal(convId, clientId, { status: 'sending', uploads: [...uploads] });
        },
      });
      aborts.push(handle.abort);
      const att = await handle.promise;
      attachmentIds.push(att.id);
    }
    uploadsInProgress.delete(clientId);
    const msg = await http.post<MessageDto>(`/api/conversations/${convId}/messages`, {
      clientId,
      text: o.text,
      replyToId: o.replyToId,
      attachmentIds,
      stickerId: o.sticker?.id,
      gif: o.gif,
      silent: o.silent,
    });
    sendQueue.delete(clientId);
    s.upsertMessage(msg, { fromRealtime: true });
  } catch (err) {
    uploadsInProgress.delete(clientId);
    if ((err as Error).name === 'AbortError') {
      useChat.getState().removeLocal(convId, clientId);
      sendQueue.delete(clientId);
      return;
    }
    // Permanent client errors (4xx except 429) won't succeed on retry; show them but keep the draft visible.
    const error = err instanceof ApiError ? err.code : 'network';
    useChat.getState().updateLocal(convId, clientId, { status: 'failed', error, uploads });
  }
}

/** Retries are safe: the same clientId makes the server return the original message. */
export async function retrySend(convId: string, clientId: string) {
  const o = sendQueue.get(clientId);
  const h = useChat.getState().histories[convId];
  const m = h?.items.find((x) => x.clientId === clientId && x.local);
  if (!o || !m) return;
  const uploads = (m.local?.uploads ?? []).map((u) => ({ ...u, progress: 0 }));
  useChat.getState().updateLocal(convId, clientId, { status: 'sending', uploads });
  await deliver(convId, clientId, o, uploads);
}

export function cancelSend(convId: string, clientId: string) {
  for (const a of uploadsInProgress.get(clientId) ?? []) a();
  uploadsInProgress.delete(clientId);
  sendQueue.delete(clientId);
  useChat.getState().removeLocal(convId, clientId);
}

// Retry everything that failed due to the network once we are back online.
if (typeof window !== 'undefined') {
  window.addEventListener('online', () => {
    const { histories } = useChat.getState();
    for (const [convId, h] of Object.entries(histories)) {
      for (const m of h.items) if (m.local?.status === 'failed' && m.local.error === 'network' && m.clientId) void retrySend(convId, m.clientId);
    }
  });
}

// ── Other actions ───────────────────────────────────────────────────────────

export async function editMessage(id: string, text: string) {
  const m = await http.patch<MessageDto>(`/api/messages/${id}`, { text });
  useChat.getState().upsertMessage(m);
}

export async function deleteMessages(convId: string, ids: string[], forEveryone: boolean) {
  await http.post('/api/messages/delete', { messageIds: ids, forEveryone });
  useChat.getState().removeMessages(convId, ids);
}

export async function toggleReaction(convId: string, messageId: string, emoji: string) {
  const s = useChat.getState();
  const m = s.histories[convId]?.items.find((x) => x.id === messageId);
  // Optimistic update.
  if (m) {
    const existing = m.reactions.find((r) => r.emoji === emoji);
    let next: ReactionSummary[];
    if (existing?.mine) next = m.reactions.map((r) => (r.emoji === emoji ? { ...r, count: r.count - 1, mine: false } : r)).filter((r) => r.count > 0);
    else if (existing) next = m.reactions.map((r) => (r.emoji === emoji ? { ...r, count: r.count + 1, mine: true } : r));
    else next = [...m.reactions, { emoji, count: 1, mine: true, userIds: [useAuth.getState().me!.id] }];
    s.setReactions(convId, messageId, next, next.filter((r) => r.mine).map((r) => r.emoji));
  }
  try {
    const res = await http.post<{ reactions: ReactionSummary[] }>(`/api/messages/${messageId}/reactions`, { emoji });
    useChat.getState().setReactions(convId, messageId, res.reactions, res.reactions.filter((r) => r.mine).map((r) => r.emoji));
  } catch (err) {
    if (m) useChat.getState().setReactions(convId, messageId, m.reactions, m.reactions.filter((r) => r.mine).map((r) => r.emoji));
    throw err;
  }
}

export async function setPinned(convId: string, messageId: string, pinned: boolean) {
  const r = pinned
    ? await http.post<{ pinnedMessageIds: string[] }>(`/api/messages/${messageId}/pin`)
    : await http.del<{ pinnedMessageIds: string[] }>(`/api/messages/${messageId}/pin`);
  useChat.getState().setPins(convId, r.pinnedMessageIds);
}

export async function updateMembership(convId: string, patch: UpdateMembershipInput) {
  const me = await http.patch<ConversationMembership>(`/api/conversations/${convId}/me`, patch);
  useChat.getState().setMembership(convId, me);
  return me;
}

const readTimers = new Map<string, ReturnType<typeof setTimeout>>();
const pendingRead = new Map<string, number>();

/** Debounced read receipt — at most one request per chat every 600 ms. */
export function markRead(convId: string, seq: number) {
  const c = useChat.getState().conversations[convId];
  if (!c?.me) return;
  if (seq <= c.me.lastReadSeq && !c.me.markedUnread) return;
  useChat.getState().markRead(convId, useAuth.getState().me!.id, seq);
  pendingRead.set(convId, Math.max(pendingRead.get(convId) ?? 0, seq));
  if (readTimers.has(convId)) return;
  readTimers.set(
    convId,
    setTimeout(() => {
      readTimers.delete(convId);
      const s = pendingRead.get(convId)!;
      pendingRead.delete(convId);
      void http.post(`/api/conversations/${convId}/read`, { seq: s }).catch(() => {});
    }, 600),
  );
}

const draftTimers = new Map<string, ReturnType<typeof setTimeout>>();
/** Drafts sync to the server so they follow you to other devices. */
export function saveDraft(convId: string, text: string) {
  const prev = draftTimers.get(convId);
  if (prev) clearTimeout(prev);
  draftTimers.set(
    convId,
    setTimeout(() => {
      draftTimers.delete(convId);
      const c = useChat.getState().conversations[convId];
      if (!c?.me || c.me.draft === text) return;
      void updateMembership(convId, { draft: text }).catch(() => {});
    }, 800),
  );
}

export async function openDirectWith(userId: string): Promise<ConversationDto> {
  const c = await http.post<ConversationDto>('/api/conversations/direct', { userId });
  useChat.getState().upsertConversation(c);
  return c;
}

export function invalidateUser(userId: string) {
  void queryClient.invalidateQueries({ queryKey: ['user', userId] });
}

export async function forwardMessages(messageIds: string[], toConversationIds: string[], hideSender: boolean) {
  const r = await http.post<{ messages: MessageDto[] }>('/api/messages/forward', { messageIds, toConversationIds, hideSender });
  for (const m of r.messages) useChat.getState().upsertMessage(m, { fromRealtime: true });
}

export function savedConversationId(): string | null {
  const c = Object.values(useChat.getState().conversations).find((x) => x.type === 'saved');
  return c?.id ?? null;
}
