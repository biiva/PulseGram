import type { ClientFrame, ServerEventName, ServerEvents, ServerFrame, SyncResponse } from '@pulsegram/shared';
import { WS_CLOSE } from '@pulsegram/shared';
import { http } from './api';
import { useChat } from '../stores/chat';

type Handler<K extends ServerEventName> = (d: ServerEvents[K]) => void;

/**
 * WebSocket client with exponential-backoff reconnect, heartbeats and gap recovery:
 * after every reconnect it asks /api/sync for everything that changed since the last
 * server timestamp it saw, so no event is lost while offline.
 */
class RealtimeClient {
  private ws: WebSocket | null = null;
  private handlers = new Map<string, Set<(d: unknown) => void>>();
  private attempts = 0;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private pingTimer: ReturnType<typeof setInterval> | null = null;
  private lastServerTime: string | null = null;
  private stopped = true;
  private everConnected = false;
  private presenceIds: string[] = [];
  onAuthLost: (() => void) | null = null;

  start() {
    if (!this.stopped) return;
    this.stopped = false;
    window.addEventListener('online', this.onOnline);
    window.addEventListener('offline', this.onOffline);
    document.addEventListener('visibilitychange', this.onVisibility);
    this.connect();
  }

  stop() {
    this.stopped = true;
    window.removeEventListener('online', this.onOnline);
    window.removeEventListener('offline', this.onOffline);
    document.removeEventListener('visibilitychange', this.onVisibility);
    if (this.timer) clearTimeout(this.timer);
    if (this.pingTimer) clearInterval(this.pingTimer);
    this.ws?.close(1000, 'bye');
    this.ws = null;
    this.everConnected = false;
    this.lastServerTime = null;
  }

  on<K extends ServerEventName>(t: K, fn: Handler<K>): () => void {
    let set = this.handlers.get(t);
    if (!set) this.handlers.set(t, (set = new Set()));
    set.add(fn as (d: unknown) => void);
    return () => set!.delete(fn as (d: unknown) => void);
  }

  send(frame: ClientFrame): boolean {
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(frame));
      return true;
    }
    return false;
  }

  subscribePresence(userIds: string[]) {
    const ids = [...new Set(userIds)].slice(0, 500).sort();
    if (ids.join() === this.presenceIds.join()) return;
    this.presenceIds = ids;
    this.send({ t: 'presence:subscribe', d: { userIds: ids } });
  }

  private onOnline = () => {
    if (this.ws?.readyState !== WebSocket.OPEN) this.reconnectNow();
  };
  private onOffline = () => useChat.getState().setConnection('offline');
  private onVisibility = () => {
    this.send({ t: 'focus', d: { active: document.visibilityState === 'visible' } });
    if (document.visibilityState === 'visible' && this.ws?.readyState !== WebSocket.OPEN) this.reconnectNow();
  };

  private reconnectNow() {
    if (this.timer) clearTimeout(this.timer);
    this.attempts = 0;
    this.connect();
  }

  private connect() {
    if (this.stopped) return;
    if (this.ws && (this.ws.readyState === WebSocket.OPEN || this.ws.readyState === WebSocket.CONNECTING)) return;
    useChat.getState().setConnection(navigator.onLine === false ? 'offline' : 'connecting');
    const url = `${location.protocol === 'https:' ? 'wss' : 'ws'}://${location.host}/ws`;
    const ws = new WebSocket(url);
    this.ws = ws;
    ws.onmessage = (ev) => {
      let f: ServerFrame;
      try {
        f = JSON.parse(String(ev.data)) as ServerFrame;
      } catch {
        return;
      }
      if (f.t === 'session:ready') {
        this.attempts = 0;
        void this.afterConnect();
        return;
      }
      if (f.ts && f.t !== 'pong' && f.t !== 'typing:update' && f.t !== 'presence:updated') this.lastServerTime = f.ts;
      this.dispatch(f.t, f.d);
    };
    ws.onclose = (ev) => {
      if (this.pingTimer) clearInterval(this.pingTimer);
      if (this.ws !== ws) return;
      this.ws = null;
      if (ev.code === WS_CLOSE.unauthorized || ev.code === WS_CLOSE.sessionRevoked) {
        this.stopped = true;
        this.onAuthLost?.();
        return;
      }
      if (this.stopped) return;
      useChat.getState().setConnection(navigator.onLine === false ? 'offline' : 'connecting');
      const delay = Math.min(30_000, 500 * 2 ** this.attempts) * (0.7 + Math.random() * 0.6);
      this.attempts++;
      this.timer = setTimeout(() => this.connect(), delay);
    };
    ws.onerror = () => {
      /* onclose follows */
    };
  }

  private async afterConnect() {
    const store = useChat.getState();
    if (this.pingTimer) clearInterval(this.pingTimer);
    this.pingTimer = setInterval(() => this.send({ t: 'ping', d: {} }), 30_000);
    this.send({ t: 'focus', d: { active: document.visibilityState === 'visible' } });
    if (this.presenceIds.length) this.send({ t: 'presence:subscribe', d: { userIds: this.presenceIds } });
    if (this.everConnected && this.lastServerTime) {
      store.setConnection('syncing');
      try {
        const res = await http.get<SyncResponse>(`/api/sync?since=${encodeURIComponent(this.lastServerTime)}`);
        this.applySync(res);
      } catch {
        /* the next reconnect will try again */
      }
    }
    this.everConnected = true;
    this.lastServerTime ??= new Date().toISOString();
    this.dispatch('session:ready', { userId: '', serverTime: this.lastServerTime, heartbeatMs: 0 });
    useChat.getState().setConnection('online');
  }

  private applySync(res: SyncResponse) {
    const s = useChat.getState();
    s.setConversations(res.conversations);
    if (res.truncated) s.dropHistories();
    else
      for (const m of res.messages) {
        if (m.deletedAt) s.removeMessages(m.conversationId, [m.id]);
        else s.upsertMessage(m);
      }
    this.lastServerTime = res.serverTime;
  }

  private dispatch(t: string, d: unknown) {
    for (const fn of this.handlers.get(t) ?? []) {
      try {
        fn(d);
      } catch (err) {
        console.error('[realtime] handler failed', t, err);
      }
    }
  }
}

export const realtime = new RealtimeClient();
