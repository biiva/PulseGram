import { describe, expect, it } from 'vitest';
import { translate } from '../i18n';
import { en } from '../i18n/en';
import { ru } from '../i18n/ru';
import { formatBytes, formatDate, formatDuration, formatTime, initials, presenceText } from './format';

const t = (key: Parameters<typeof translate>[1], vars?: Record<string, string | number>) => translate('en', key, vars);

describe('format helpers', () => {
  it('formats sizes and durations', () => {
    expect(formatBytes(512)).toBe('512 B');
    expect(formatBytes(1536)).toBe('1.5 KB');
    expect(formatBytes(5 * 1024 * 1024)).toBe('5.0 MB');
    expect(formatDuration(65_000)).toBe('1:05');
    expect(formatDuration(3_725_000)).toBe('1:02:05');
  });

  it('respects date and time preferences', () => {
    const d = new Date(2026, 2, 7, 15, 4);
    expect(formatDate(d, { dateFormat: 'dmy', timeFormat: '24h', language: 'ru' })).toBe('07.03.2026');
    expect(formatDate(d, { dateFormat: 'mdy', timeFormat: '12h', language: 'en' })).toBe('03/07/2026');
    expect(formatDate(d, { dateFormat: 'ymd', timeFormat: '24h', language: 'en' })).toBe('2026-03-07');
    expect(formatTime(d, { dateFormat: 'dmy', timeFormat: '24h', language: 'ru' })).toBe('15:04');
  });

  it('describes presence without leaking hidden times', () => {
    const f = { dateFormat: 'mdy' as const, timeFormat: '12h' as const, language: 'en' as const };
    expect(presenceText({ kind: 'online' }, f, t)).toBe('online');
    expect(presenceText({ kind: 'recently' }, f, t)).toBe('last seen recently');
  });

  it('builds initials', () => {
    expect(initials('Ava Lindqvist')).toBe('AL');
    expect(initials('Ирина')).toBe('ИР');
  });
});

describe('translations', () => {
  it('Russian covers every English key and keeps placeholders', () => {
    for (const key of Object.keys(en) as Array<keyof typeof en>) {
      expect(typeof ru[key], key).toBe('string');
      if (en[key]) expect(ru[key], key).not.toBe('');
      const placeholders = (en[key].match(/\{\w+\}/g) ?? []).sort();
      expect((ru[key].match(/\{\w+\}/g) ?? []).sort(), key).toEqual(placeholders);
    }
  });
});
