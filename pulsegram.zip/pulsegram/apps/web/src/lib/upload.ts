import type { AttachmentDto } from '@pulsegram/shared';
import { ApiError, csrfToken } from './api';

export interface UploadHandle {
  promise: Promise<AttachmentDto>;
  abort: () => void;
}

/** Multipart upload via XHR so we get progress events and can cancel. */
export function uploadFile(
  file: Blob,
  name: string,
  opts: { as?: 'voice' | 'file'; url?: string; method?: 'POST' | 'PUT'; onProgress?: (p: number) => void } = {},
): UploadHandle {
  const xhr = new XMLHttpRequest();
  const promise = new Promise<AttachmentDto>((resolve, reject) => {
    const url = opts.url ?? `/api/files${opts.as ? `?as=${opts.as}` : ''}`;
    xhr.open(opts.method ?? 'POST', url);
    xhr.withCredentials = true;
    const csrf = csrfToken();
    if (csrf) xhr.setRequestHeader('X-CSRF-Token', csrf);
    xhr.upload.onprogress = (e) => {
      if (e.lengthComputable) opts.onProgress?.(e.loaded / e.total);
    };
    xhr.onload = () => {
      let json: unknown;
      try {
        json = JSON.parse(xhr.responseText);
      } catch {
        json = undefined;
      }
      if (xhr.status >= 200 && xhr.status < 300) resolve(json as AttachmentDto);
      else {
        const e = (json as { error?: { code: string; message: string; details?: unknown } } | undefined)?.error;
        reject(new ApiError(xhr.status, e?.code ?? `http_${xhr.status}`, e?.message ?? 'Upload failed', e?.details));
      }
    };
    xhr.onerror = () => reject(new ApiError(0, 'network', 'Network error'));
    xhr.onabort = () => reject(new DOMException('Upload cancelled', 'AbortError'));
    const fd = new FormData();
    fd.append('file', file, name);
    xhr.send(fd);
  });
  return { promise, abort: () => xhr.abort() };
}
