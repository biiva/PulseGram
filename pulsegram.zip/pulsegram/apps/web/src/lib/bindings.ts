import type { ConversationDto, MessageDto } from '@pulsegram/shared';
import { translate } from '../i18n';
import { useAuth } from '../stores/auth';
import { isMuted, useChat } from '../stores/chat';
import { usePrefs } from '../stores/prefs';
import { useUi } from '../stores/ui';
import { ensureConversation, fetchMissingUsers, invalidateUser } from './chatActions';
import { queryClient } from './queryClient';
import { realtime } from './realtime';
import { playChime } from './sound';

function previewOf(m: MessageDto): string {
  const lang = usePrefs.getState().appearance.language;
  if (m.text) return m.text;
  if (m.type === 'voice') return translate(lang, 'chat.voiceMessage');
  if (m.type === 'sticker') return `${m.sticker?.emoji ?? ''} ${translate(lang, 'chat.sticker')}`;
  if (m.type === 'gif') return translate(lang, 'chat.gif');
  const k = m.attachments[0]?.kind;
  return translate(lang, k === 'image' ? 'chat.photo' : k === 'video' ? 'chat.video' : k === 'audio' ? 'chat.audio' : 'chat.file');
}

function shouldNotify(c: ConversationDto, m: MessageDto): boolean {
  const me = useAuth.getState().me;
  const prefs = usePrefs.getState().notifications;
  if (!me || m.senderId === me.id || m.type === 'system' || c.type === 'saved') return false;
  if (!prefs.enabled) return false;
  if (me.presenceMode === 'dnd') return false;
  if (prefs.pausedUntil && new Date(prefs.pausedUntil) > new Date()) return false;
  const mentioned = m.mentions.includes(me.id);
  if (isMuted(c) && !mentioned) return false;
  if (c.type === 'direct') return prefs.direct;
  if (c.type === 'group') return prefs.groups || (mentioned && prefs.mentions);
  return prefs.channels;
}

function notifyNewMessage(c: ConversationDto, m: MessageDto) {
  if (!shouldNotify(c, m)) return;
  const active = useChat.getState().activeId === c.id && document.visibilityState === 'visible' && document.hasFocus();
  if (active) return;
  const prefs = usePrefs.getState().notifications;
  if (prefs.sound) playChime('message');
  if (document.visibilityState === 'visible' && document.hasFocus()) return; // in-app: the badge is enough
  if (typeof Notification === 'undefined' || Notification.permission !== 'granted') return;
  const sender = useChat.getState().users[m.senderId ?? '']?.displayName ?? '';
  const title = c.type === 'direct' ? c.title : c.title;
  const body = prefs.preview ? (c.type === 'group' ? `${sender}: ${previewOf(m)}` : previewOf(m)) : translate(usePrefs.getState().appearance.language, 'chat.newMessages');
  try {
    const n = new Notification(title, { body: body.slice(0, 180), tag: c.id, icon: '/favicon.svg' });
    n.onclick = () => {
      window.focus();
      window.history.pushState({}, '', `/chat/${c.id}`);
      window.dispatchEvent(new PopStateEvent('popstate'));
      n.close();
    };
  } catch {
    /* some browsers require a service worker for notifications */
  }
}

let installed = false;

export function installRealtimeBindings() {
  if (installed) return;
  installed = true;
  const S = () => useChat.getState();

  realtime.on('message:new', ({ message }) => {
    void (async () => {
      // A chat we did not know yet is fetched fresh — its unread count already includes this message.
      const known = Boolean(S().conversations[message.conversationId]);
      if (!known) await ensureConversation(message.conversationId);
      S().upsertMessage(message, { fromRealtime: known });
      S().setTyping(message.conversationId, message.senderId ?? '', null);
      await fetchMissingUsers([message]);
      const fresh = S().conversations[message.conversationId];
      if (fresh) notifyNewMessage(fresh, message);
    })();
  });
  realtime.on('message:updated', ({ message }) => S().upsertMessage(message));
  realtime.on('message:deleted', ({ conversationId, messageIds }) => S().removeMessages(conversationId, messageIds));
  realtime.on('message:reactions', ({ conversationId, messageId, reactions, actorId, actorEmojis }) => {
    const me = useAuth.getState().me?.id;
    S().setReactions(conversationId, messageId, reactions, actorId === me ? actorEmojis : null);
  });
  realtime.on('message:views', ({ conversationId, views }) => S().setViews(conversationId, views));
  realtime.on('conversation:read', ({ conversationId, userId, seq }) => S().markRead(conversationId, userId, seq));
  realtime.on('conversation:new', ({ conversation }) => S().upsertConversation(conversation));
  realtime.on('conversation:updated', ({ conversationId, patch }) => {
    S().patchConversation(conversationId, patch);
    void queryClient.invalidateQueries({ queryKey: ['members', conversationId] });
  });
  realtime.on('conversation:membership', ({ conversationId, me }) => S().setMembership(conversationId, me));
  realtime.on('conversation:removed', ({ conversationId }) => {
    S().removeConversation(conversationId);
    if (S().activeId === conversationId) {
      window.history.pushState({}, '', '/chat');
      window.dispatchEvent(new PopStateEvent('popstate'));
    }
  });
  realtime.on('conversation:pins', ({ conversationId, pinnedMessageIds }) => S().setPins(conversationId, pinnedMessageIds));
  realtime.on('typing:update', ({ conversationId, userId, kind }) => S().setTyping(conversationId, userId, kind));
  realtime.on('presence:updated', ({ userId, presence }) => S().setPresence(userId, presence));
  realtime.on('user:updated', ({ userId }) => {
    invalidateUser(userId);
    void import('./api').then(({ http }) =>
      http.get<import('@pulsegram/shared').UserSummary[]>(`/api/users?ids=${userId}`).then((u) => {
        S().addUsers(u);
        // Refresh peer data shown in the chat list.
        for (const c of Object.values(S().conversations)) {
          if (c.peer?.id === userId && u[0]) S().patchConversation(c.id, { peer: u[0], title: u[0].displayName, avatarUrl: u[0].avatarUrl });
        }
      }),
    );
  });
  realtime.on('notification:new', ({ notification }) => {
    void queryClient.invalidateQueries({ queryKey: ['notifications'] });
    if (notification.type === 'invite' || notification.type === 'admin') useUi.getState().toast(notification.title);
  });
}
