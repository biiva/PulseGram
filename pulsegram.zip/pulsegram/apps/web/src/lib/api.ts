import type { ApiErrorBody } from '@pulsegram/shared';
import type { MessageKey, TFn } from '../i18n';
import { en } from '../i18n/en';

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
    public details?: unknown,
  ) {
    super(message);
  }
  /** Field-level validation issues returned by the server. */
  get fieldErrors(): Record<string, string> {
    const out: Record<string, string> = {};
    if (Array.isArray(this.details)) {
      for (const d of this.details as Array<{ path?: string; code?: string }>) if (d.path && d.code && !out[d.path]) out[d.path] = d.code;
    }
    return out;
  }
  get retryAfterSec(): number | undefined {
    return (this.details as { retryAfterSec?: number } | undefined)?.retryAfterSec;
  }
}

function readCookie(name: string): string | null {
  const m = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
  return m ? decodeURIComponent(m[1]!) : null;
}

let onUnauthorized: (() => void) | null = null;
export function setUnauthorizedHandler(fn: () => void) {
  onUnauthorized = fn;
}

export interface RequestOptions {
  signal?: AbortSignal;
  /** Don't trigger the global sign-out on 401 (used by the initial /me probe). */
  quiet401?: boolean;
}

export async function api<T>(method: string, path: string, body?: unknown, opts: RequestOptions = {}): Promise<T> {
  const headers: Record<string, string> = { Accept: 'application/json' };
  const isForm = typeof FormData !== 'undefined' && body instanceof FormData;
  if (method !== 'GET' && method !== 'HEAD') {
    const csrf = readCookie('pg_csrf');
    if (csrf) headers['X-CSRF-Token'] = csrf;
    if (!isForm) headers['Content-Type'] = 'application/json';
  }
  let res: Response;
  try {
    res = await fetch(path, {
      method,
      headers,
      credentials: 'same-origin',
      body: method === 'GET' || method === 'HEAD' ? undefined : isForm ? (body as FormData) : JSON.stringify(body ?? {}),
      signal: opts.signal,
    });
  } catch (err) {
    if ((err as Error).name === 'AbortError') throw err;
    throw new ApiError(0, 'network', 'Network error');
  }
  if (res.status === 204) return undefined as T;
  const text = await res.text();
  let json: unknown;
  try {
    json = text ? JSON.parse(text) : undefined;
  } catch {
    json = text;
  }
  if (!res.ok) {
    const e = (json as ApiErrorBody | undefined)?.error;
    const err = new ApiError(res.status, e?.code ?? `http_${res.status}`, e?.message ?? res.statusText, e?.details);
    if (res.status === 401 && !opts.quiet401) onUnauthorized?.();
    throw err;
  }
  return json as T;
}

export const http = {
  get: <T>(path: string, opts?: RequestOptions) => api<T>('GET', path, undefined, opts),
  post: <T>(path: string, body?: unknown, opts?: RequestOptions) => api<T>('POST', path, body, opts),
  patch: <T>(path: string, body?: unknown, opts?: RequestOptions) => api<T>('PATCH', path, body, opts),
  put: <T>(path: string, body?: unknown, opts?: RequestOptions) => api<T>('PUT', path, body, opts),
  del: <T>(path: string, opts?: RequestOptions) => api<T>('DELETE', path, undefined, opts),
};

export function csrfToken() {
  return readCookie('pg_csrf');
}

/** Human message for an error, preferring a translated string for known codes. */
export function errorText(t: TFn, err: unknown): string {
  if (err instanceof ApiError) {
    const key = `error.${err.code}` as MessageKey;
    if (key in en) return t(key, { s: err.retryAfterSec ?? '' });
    if (err.status === 0) return t('error.network');
    return err.message || t('common.error');
  }
  return t('common.error');
}

export function fieldText(t: TFn, code: string | undefined): string | undefined {
  if (!code) return undefined;
  const key = `error.${code}` as MessageKey;
  return key in en ? t(key) : code;
}
