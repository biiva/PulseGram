import { lazy, Suspense, useEffect, type ReactNode } from 'react';
import { Navigate, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { ConfirmHost } from './components/ui/Modal';
import { MenuHost } from './components/ui/Menu';
import { Logo, Spinner } from './components/ui/misc';
import { Toasts } from './components/ui/Toasts';
import { LoginPage } from './features/auth/Login';
import { ProfileSetupPage } from './features/auth/ProfileSetup';
import { ForgotPasswordPage, ResetPasswordPage, VerifyEmailPage } from './features/auth/Recovery';
import { RegisterPage } from './features/auth/Register';
import { WelcomePage } from './features/auth/Welcome';
import { AppShell } from './features/layout/AppShell';
import { setUnauthorizedHandler } from './lib/api';
import { queryClient } from './lib/queryClient';
import { realtime } from './lib/realtime';
import { useAuth } from './stores/auth';
import { useChat } from './stores/chat';
import { applyAppearance, usePrefs } from './stores/prefs';

const StaticPage = lazy(() => import('./features/pages/StaticPages').then((m) => ({ default: m.StaticPage })));

function FullScreenLoader() {
  return (
    <div className="grid h-dvh place-items-center bg-bg">
      <div className="flex flex-col items-center gap-5">
        <Logo size={56} className="beat" />
        <Spinner className="text-ink-3" />
      </div>
    </div>
  );
}

function RequireAuth({ children }: { children: ReactNode }) {
  const status = useAuth((s) => s.status);
  const loc = useLocation();
  if (status === 'loading') return <FullScreenLoader />;
  if (status === 'anon') return <Navigate to="/welcome" replace state={{ from: loc.pathname + loc.search }} />;
  return <>{children}</>;
}

function GuestOnly({ children }: { children: ReactNode }) {
  const status = useAuth((s) => s.status);
  const completed = useAuth((s) => s.me?.profileCompleted);
  if (status === 'loading') return <FullScreenLoader />;
  if (status === 'authed') return <Navigate to={completed ? '/chat' : '/setup-profile'} replace />;
  return <>{children}</>;
}

export function App() {
  const bootstrap = useAuth((s) => s.bootstrap);
  const status = useAuth((s) => s.status);
  const me = useAuth((s) => s.me);
  const appearance = usePrefs((s) => s.appearance);
  const nav = useNavigate();

  useEffect(() => {
    void bootstrap();
  }, [bootstrap]);

  useEffect(() => {
    applyAppearance(appearance);
    if (appearance.theme !== 'system') return;
    const mq = window.matchMedia('(prefers-color-scheme: dark)');
    const onChange = () => applyAppearance(usePrefs.getState().appearance);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, [appearance]);

  // Session lost (expired, revoked from another device, password reset) → back to sign-in.
  useEffect(() => {
    const onLost = () => {
      realtime.stop();
      useChat.getState().reset();
      queryClient.clear();
      useAuth.getState().clear();
      nav('/login', { replace: true });
    };
    setUnauthorizedHandler(onLost);
    realtime.onAuthLost = onLost;
  }, [nav]);

  useEffect(() => {
    useChat.getState().setMyId(me?.id ?? null);
  }, [me?.id]);

  return (
    <>
      <Suspense fallback={<FullScreenLoader />}>
        <Routes>
          <Route path="/welcome" element={<GuestOnly><WelcomePage /></GuestOnly>} />
          <Route path="/login" element={<GuestOnly><LoginPage /></GuestOnly>} />
          <Route path="/register" element={<GuestOnly><RegisterPage /></GuestOnly>} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/reset-password" element={<ResetPasswordPage />} />
          <Route path="/verify-email" element={<VerifyEmailPage />} />
          <Route path="/setup-profile" element={<RequireAuth><ProfileSetupPage /></RequireAuth>} />
          {(['about', 'help', 'privacy', 'terms', 'changelog', 'status'] as const).map((p) => (
            <Route key={p} path={`/${p}`} element={<StaticPage page={p} />} />
          ))}
          <Route path="/*" element={<RequireAuth><AppShell /></RequireAuth>} />
          <Route path="/" element={status === 'authed' ? <Navigate to="/chat" replace /> : <Navigate to="/welcome" replace />} />
        </Routes>
      </Suspense>
      <MenuHost />
      <ConfirmHost />
      <Toasts />
    </>
  );
}
