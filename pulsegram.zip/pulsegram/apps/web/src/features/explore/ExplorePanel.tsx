import { useQuery } from '@tanstack/react-query';
import { clsx } from 'clsx';
import { Compass, Search } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CHANNEL_CATEGORIES, type ChannelCategory, type ConversationDto } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { Segmented } from '../../components/ui/Field';
import { EmptyState, Spinner } from '../../components/ui/misc';
import { useT, type MessageKey } from '../../i18n';
import { http } from '../../lib/api';
import { useDebounced } from '../chats/SearchResults';

export function ExplorePanel() {
  const t = useT();
  const nav = useNavigate();
  const [q, setQ] = useState('');
  const [type, setType] = useState<'channel' | 'group'>('channel');
  const [category, setCategory] = useState<ChannelCategory | ''>('');
  const dq = useDebounced(q, 300);
  const res = useQuery({
    queryKey: ['explore', dq, type, category],
    queryFn: ({ signal }) => http.get<ConversationDto[]>(`/api/explore?type=${type}&q=${encodeURIComponent(dq)}${category ? `&category=${category}` : ''}`, { signal }),
  });
  return (
    <div className="flex h-full flex-col">
      <header className="px-4 pt-4 pb-2">
        <h1 className="text-[1.35rem] font-extrabold tracking-[-0.02em] text-ink">{t('explore.title')}</h1>
        <p className="text-[0.85rem] text-ink-3">{t('explore.body')}</p>
      </header>
      <div className="flex flex-col gap-2 px-4 pb-2">
        <label className="relative flex items-center">
          <Search size={16} className="absolute left-3.5 text-ink-3" />
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('common.search')} className="h-10 w-full rounded-full bg-sunken pr-3 pl-10 text-[0.9rem] outline-none focus:ring-2 focus:ring-accent/40" />
        </label>
        <Segmented value={type} onChange={setType} options={[{ value: 'channel', label: t('explore.channels') }, { value: 'group', label: t('explore.groups') }]} />
        {type === 'channel' && (
          <div className="flex gap-1 overflow-x-auto pb-1 [scrollbar-width:none]">
            {(['', ...CHANNEL_CATEGORIES] as const).map((c) => (
              <button
                key={c || 'all'}
                type="button"
                onClick={() => setCategory(c)}
                className={clsx('shrink-0 rounded-full px-3 py-1.5 text-[0.8rem] font-semibold', category === c ? 'bg-soft text-accent' : 'text-ink-3 hover:bg-sunken')}
              >
                {c ? t(`cat.${c}` as MessageKey) : t('explore.all')}
              </button>
            ))}
          </div>
        )}
      </div>
      <div className="scroll-y min-h-0 flex-1 px-2 pb-2">
        {res.isLoading ? (
          <div className="grid h-40 place-items-center text-ink-3"><Spinner /></div>
        ) : !res.data?.length ? (
          <EmptyState icon={<Compass size={24} />} title={t('explore.empty')} />
        ) : (
          res.data.map((c) => (
            <button key={c.id} type="button" onClick={() => nav(`/chat/${c.id}`)} className="flex w-full items-start gap-3 rounded-[14px] px-2.5 py-2.5 text-left hover:bg-sunken">
              <Avatar id={c.id} name={c.title} src={c.avatarUrl} size={48} kind={c.type === 'channel' ? 'channel' : 'group'} />
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className="truncate text-[0.95rem] font-semibold text-ink">{c.title}</span>
                  {c.isDemo && <span className="rounded bg-sunken px-1 text-[0.62rem] font-semibold text-ink-3">{t('common.demo')}</span>}
                </span>
                <span className="block text-[0.8rem] text-ink-3">
                  {c.type === 'channel' ? t('common.subscribers', { n: c.memberCount }) : t('common.members', { n: c.memberCount })}
                  {c.category ? ` · ${t(`cat.${c.category}` as MessageKey)}` : ''}
                  {c.me ? ' · ✓' : ''}
                </span>
                {c.description && <span className="mt-0.5 line-clamp-2 block text-[0.84rem] text-ink-2">{c.description}</span>}
              </span>
            </button>
          ))
        )}
      </div>
    </div>
  );
}
