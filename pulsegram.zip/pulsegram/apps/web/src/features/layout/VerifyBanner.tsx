import { MailWarning } from 'lucide-react';
import { useState } from 'react';
import { useT } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { useAuth } from '../../stores/auth';
import { toast } from '../../stores/ui';

export function VerifyBanner() {
  const t = useT();
  const me = useAuth((s) => s.me);
  const config = useAuth((s) => s.config);
  const [busy, setBusy] = useState(false);
  const [sent, setSent] = useState(false);
  if (!me || me.emailVerified || !config?.emailConfigured) return null;
  return (
    <div className="flex items-start gap-2.5 border-b border-line bg-warning/10 px-4 py-2.5 text-[0.82rem] leading-snug text-ink-2">
      <MailWarning size={17} className="mt-0.5 shrink-0 text-warning" />
      <div className="min-w-0 flex-1">
        {t(config.emailVerificationRequired ? 'auth.verify.bannerRequired' : 'auth.verify.banner', { email: me.email })}{' '}
        <button
          type="button"
          disabled={busy || sent}
          className="font-semibold text-accent hover:underline disabled:opacity-60"
          onClick={async () => {
            setBusy(true);
            try {
              await http.post('/api/auth/resend-verification');
              setSent(true);
              toast(t('auth.verify.resent'));
            } catch (err) {
              toast({ text: errorText(t, err), tone: 'danger' });
            } finally {
              setBusy(false);
            }
          }}
        >
          {sent ? t('auth.verify.resent') : t('auth.verify.resend')}
        </button>
      </div>
    </div>
  );
}
