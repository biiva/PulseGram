import { lazy, Suspense } from 'react';
import { useUi } from '../../stores/ui';

const NewMessageDialog = lazy(() => import('../dialogs/NewChatDialogs').then((m) => ({ default: m.NewMessageDialog })));
const NewGroupDialog = lazy(() => import('../dialogs/NewChatDialogs').then((m) => ({ default: m.NewGroupDialog })));
const NewChannelDialog = lazy(() => import('../dialogs/NewChatDialogs').then((m) => ({ default: m.NewChannelDialog })));
const AddMembersDialog = lazy(() => import('../dialogs/NewChatDialogs').then((m) => ({ default: m.AddMembersDialog })));
const ForwardDialog = lazy(() => import('../dialogs/ForwardDialog').then((m) => ({ default: m.ForwardDialog })));
const ReportDialog = lazy(() => import('../dialogs/ReportDialog').then((m) => ({ default: m.ReportDialog })));
const UserDialog = lazy(() => import('../dialogs/UserDialog').then((m) => ({ default: m.UserDialog })));
const MediaViewer = lazy(() => import('../dialogs/MediaViewer').then((m) => ({ default: m.MediaViewer })));

export function DialogHost() {
  const d = useUi((s) => s.dialog);
  const close = useUi((s) => s.close);
  if (!d) return null;
  return (
    <Suspense fallback={null}>
      {d.kind === 'new-message' && <NewMessageDialog onClose={close} />}
      {d.kind === 'new-group' && <NewGroupDialog onClose={close} />}
      {d.kind === 'new-channel' && <NewChannelDialog onClose={close} />}
      {d.kind === 'add-members' && <AddMembersDialog conversationId={d.conversationId} onClose={close} />}
      {d.kind === 'forward' && <ForwardDialog messageIds={d.messageIds} onClose={close} />}
      {d.kind === 'report' && <ReportDialog targetType={d.targetType} targetId={d.targetId} onClose={close} />}
      {d.kind === 'user' && <UserDialog userId={d.userId} onClose={close} />}
      {d.kind === 'media' && <MediaViewer items={d.items} index={d.index} onClose={close} />}
    </Suspense>
  );
}
