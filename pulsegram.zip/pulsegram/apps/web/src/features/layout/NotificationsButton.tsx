import { useQuery } from '@tanstack/react-query';
import { clsx } from 'clsx';
import { AtSign, Bell, CornerUpLeft, PhoneMissed, ShieldAlert, UserPlus } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { NotificationDto } from '@pulsegram/shared';
import { Button } from '../../components/ui/Button';
import { Modal } from '../../components/ui/Modal';
import { EmptyState } from '../../components/ui/misc';
import { useLang, useT } from '../../i18n';
import { http } from '../../lib/api';
import { formatRelative } from '../../lib/format';
import { queryClient } from '../../lib/queryClient';
import { usePrefs } from '../../stores/prefs';

const ICONS: Record<NotificationDto['type'], typeof Bell> = {
  mention: AtSign,
  reply: CornerUpLeft,
  invite: UserPlus,
  call: PhoneMissed,
  admin: ShieldAlert,
  message: Bell,
  contact: UserPlus,
  system: Bell,
};

export function useNotifications() {
  return useQuery({
    queryKey: ['notifications'],
    queryFn: () => http.get<{ items: NotificationDto[]; unread: number }>('/api/notifications'),
  });
}

export function NotificationsButton({ compact }: { compact?: boolean }) {
  const t = useT();
  const [open, setOpen] = useState(false);
  const q = useNotifications();
  const unread = q.data?.unread ?? 0;
  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label={t('nav.notifications')}
        className={clsx(
          'group relative flex flex-col items-center gap-1 rounded-[14px] text-[0.68rem] font-medium text-ink-3 hover:text-ink',
          compact ? 'p-0' : 'w-full px-1 py-2',
        )}
      >
        <span className="relative grid size-10 place-items-center rounded-[12px] group-hover:bg-sunken">
          <Bell size={21} strokeWidth={1.9} />
          {unread > 0 && (
            <span className="absolute -top-1 -right-1.5 inline-flex h-[18px] min-w-[18px] items-center justify-center rounded-full border-2 border-bg bg-danger px-1 text-[0.62rem] font-bold text-white">
              {unread > 99 ? '99+' : unread}
            </span>
          )}
        </span>
        {!compact && <span className="leading-none">{t('nav.notifications').split(' ')[0]}</span>}
      </button>
      <NotificationsDialog open={open} onClose={() => setOpen(false)} />
    </>
  );
}

function NotificationsDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const t = useT();
  const lang = useLang();
  const fmt = usePrefs((s) => s.appearance);
  const nav = useNavigate();
  const q = useNotifications();
  const items = q.data?.items ?? [];

  const markAll = async () => {
    await http.post('/api/notifications/read', {});
    await queryClient.invalidateQueries({ queryKey: ['notifications'] });
  };

  return (
    <Modal open={open} onClose={onClose} title={t('notif.title')} width={460}>
      {items.length === 0 ? (
        <EmptyState icon={<Bell size={24} />} title={t('notif.empty')} />
      ) : (
        <>
          <div className="mb-2 flex justify-end gap-2">
            <Button size="sm" variant="ghost" onClick={() => void markAll()} disabled={!q.data?.unread}>
              {t('notif.markAll')}
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={async () => {
                await http.del('/api/notifications');
                await queryClient.invalidateQueries({ queryKey: ['notifications'] });
              }}
            >
              {t('notif.clear')}
            </Button>
          </div>
          <ul className="-mx-2 flex flex-col">
            {items.map((n) => {
              const Icon = ICONS[n.type] ?? Bell;
              return (
                <li key={n.id}>
                  <button
                    type="button"
                    className="flex w-full items-start gap-3 rounded-[12px] px-2 py-2.5 text-left hover:bg-sunken"
                    onClick={async () => {
                      if (!n.readAt) await http.post('/api/notifications/read', { ids: [n.id] }).catch(() => {});
                      void queryClient.invalidateQueries({ queryKey: ['notifications'] });
                      onClose();
                      if (n.conversationId) nav(`/chat/${n.conversationId}`);
                    }}
                  >
                    <span className={clsx('mt-0.5 grid size-9 shrink-0 place-items-center rounded-full', n.readAt ? 'bg-sunken text-ink-3' : 'bg-soft text-accent')}>
                      <Icon size={17} />
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className={clsx('block text-[0.9rem] leading-snug', n.readAt ? 'text-ink-2' : 'font-semibold text-ink')}>{n.title}</span>
                      {n.body && <span className="mt-0.5 block truncate text-[0.84rem] text-ink-3">{n.body}</span>}
                      <span className="mt-0.5 block text-[0.75rem] text-ink-3">{formatRelative(n.createdAt, { ...fmt, language: lang }, t)}</span>
                    </span>
                    {!n.readAt && <span className="mt-2 size-2 shrink-0 rounded-full bg-accent" />}
                  </button>
                </li>
              );
            })}
          </ul>
        </>
      )}
    </Modal>
  );
}
