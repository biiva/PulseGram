import { clsx } from 'clsx';
import {
  Archive,
  Bookmark,
  Compass,
  Megaphone,
  MessageCircle,
  MessagesSquare,
  PenSquare,
  Phone,
  Settings,
  User,
  Users,
  type LucideIcon,
} from 'lucide-react';
import { useMemo, type ReactNode } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { Avatar } from '../../components/ui/Avatar';
import { openMenu } from '../../components/ui/Menu';
import { Logo } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { savedConversationId } from '../../lib/chatActions';
import { useAuth } from '../../stores/auth';
import { isMuted, useChat } from '../../stores/chat';
import { useUi, type ChatFilter } from '../../stores/ui';
import { NotificationsButton } from './NotificationsButton';

function RailButton({
  label,
  icon: Icon,
  active,
  onClick,
  badge,
  children,
}: {
  label: string;
  icon?: LucideIcon;
  active?: boolean;
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void;
  badge?: number;
  children?: ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      aria-current={active ? 'page' : undefined}
      className={clsx(
        'group relative flex w-full flex-col items-center gap-1 rounded-[14px] px-1 py-2 text-[0.68rem] font-medium transition-colors',
        active ? 'text-accent' : 'text-ink-3 hover:text-ink',
      )}
    >
      <span className={clsx('relative grid size-10 place-items-center rounded-[12px] transition-colors', active ? 'bg-soft' : 'group-hover:bg-sunken')}>
        {children ?? (Icon && <Icon size={21} strokeWidth={active ? 2.3 : 1.9} />)}
        {badge ? (
          <span className="absolute -top-1 -right-1.5 inline-flex h-[18px] min-w-[18px] items-center justify-center rounded-full border-2 border-bg bg-accent px-1 text-[0.62rem] font-bold text-white tabular-nums">
            {badge > 99 ? '99+' : badge}
          </span>
        ) : null}
      </span>
      <span className="w-full truncate text-center leading-none">{label}</span>
    </button>
  );
}

export function useUnreadByFilter() {
  const conversations = useChat((s) => s.conversations);
  return useMemo(() => {
    const counts = { all: 0, direct: 0, group: 0, channel: 0, archive: 0 };
    for (const c of Object.values(conversations)) {
      const n = c.unreadCount > 0 || c.me?.markedUnread ? 1 : 0;
      if (!n || isMuted(c)) continue;
      if (c.me?.isArchived) {
        counts.archive += n;
        continue;
      }
      counts.all += n;
      if (c.type === 'direct') counts.direct += n;
      if (c.type === 'group') counts.group += n;
      if (c.type === 'channel') counts.channel += n;
    }
    return counts;
  }, [conversations]);
}

export function useNewChatMenu() {
  const t = useT();
  const open = useUi((s) => s.open);
  return (e: React.MouseEvent<HTMLElement>) =>
    openMenu(e, [
      { label: t('chats.newMessage'), icon: <User size={17} />, onSelect: () => open({ kind: 'new-message' }) },
      { label: t('chats.newGroup'), icon: <Users size={17} />, onSelect: () => open({ kind: 'new-group' }) },
      { label: t('chats.newChannel'), icon: <Megaphone size={17} />, onSelect: () => open({ kind: 'new-channel' }) },
    ]);
}

export function NavRail() {
  const t = useT();
  const me = useAuth((s) => s.me)!;
  const nav = useNavigate();
  const loc = useLocation();
  const filter = useUi((s) => s.filter);
  const setFilter = useUi((s) => s.setFilter);
  const counts = useUnreadByFilter();
  const newChat = useNewChatMenu();
  const connection = useChat((s) => s.connection);
  const activeId = useChat((s) => s.activeId);
  const savedId = useChat((s) => Object.values(s.conversations).find((c) => c.type === 'saved')?.id);
  const onChats = loc.pathname.startsWith('/chat');

  const go = (f: ChatFilter) => {
    setFilter(f);
    if (!onChats) nav('/chat');
  };
  const isFilter = (f: ChatFilter) => onChats && filter === f && activeId !== savedId;

  return (
    <nav aria-label="Main" className="hidden w-[84px] shrink-0 flex-col items-center gap-1 border-r border-line bg-bg px-2 py-3 md:flex">
      <NavLink to="/chat" className="mb-2" aria-label="PulseGram" onClick={() => setFilter('all')}>
        <Logo size={38} />
      </NavLink>
      <RailButton label={t('nav.newMessage')} icon={PenSquare} onClick={newChat} />
      <div className="my-1 h-px w-10 bg-line" />
      <div className="scroll-y flex w-full flex-1 flex-col items-center gap-0.5">
        <RailButton label={t('nav.all')} icon={MessagesSquare} active={isFilter('all')} badge={counts.all} onClick={() => go('all')} />
        <RailButton label={t('nav.direct')} icon={MessageCircle} active={isFilter('direct')} badge={counts.direct} onClick={() => go('direct')} />
        <RailButton label={t('nav.groups')} icon={Users} active={isFilter('group')} badge={counts.group} onClick={() => go('group')} />
        <RailButton label={t('nav.channels')} icon={Megaphone} active={isFilter('channel')} badge={counts.channel} onClick={() => go('channel')} />
        <RailButton
          label={t('nav.saved')}
          icon={Bookmark}
          active={onChats && activeId !== null && activeId === savedId}
          onClick={() => {
            const id = savedConversationId();
            if (id) nav(`/chat/${id}`);
          }}
        />
        <RailButton label={t('nav.archive')} icon={Archive} active={isFilter('archive')} badge={counts.archive} onClick={() => go('archive')} />
        <div className="my-1 h-px w-10 bg-line" />
        <RailButton label={t('nav.contacts')} icon={User} active={loc.pathname.startsWith('/contacts')} onClick={() => nav('/contacts')} />
        <RailButton label={t('nav.calls')} icon={Phone} active={loc.pathname.startsWith('/calls')} onClick={() => nav('/calls')} />
        <RailButton label={t('nav.explore')} icon={Compass} active={loc.pathname.startsWith('/explore')} onClick={() => nav('/explore')} />
      </div>
      <NotificationsButton />
      <RailButton label={t('nav.settings')} icon={Settings} active={loc.pathname.startsWith('/settings')} onClick={() => nav('/settings')} />
      <button
        type="button"
        onClick={() => nav('/settings/profile')}
        className="relative mt-1 rounded-full"
        aria-label={t('settings.profile')}
        title={connection === 'online' ? me.displayName : t('chat.connecting')}
      >
        <Avatar id={me.id} name={me.displayName} src={me.avatarUrl} size={40} />
        <span
          className={clsx(
            'absolute right-0 bottom-0 size-3 rounded-full border-2 border-bg',
            connection === 'online' ? 'bg-success' : connection === 'offline' ? 'bg-danger' : 'bg-warning',
          )}
        />
      </button>
    </nav>
  );
}

export function MobileTabs() {
  const t = useT();
  const loc = useLocation();
  const counts = useUnreadByFilter();
  const items: Array<{ to: string; label: string; icon: LucideIcon; badge?: number }> = [
    { to: '/chat', label: t('nav.chats'), icon: MessagesSquare, badge: counts.all },
    { to: '/contacts', label: t('nav.contacts'), icon: User },
    { to: '/calls', label: t('nav.calls'), icon: Phone },
    { to: '/settings', label: t('nav.settings'), icon: Settings },
  ];
  return (
    <nav aria-label="Tabs" className="pb-safe flex shrink-0 border-t border-line bg-bg/95 pt-1.5 backdrop-blur md:hidden">
      {items.map((it) => {
        const active = loc.pathname.startsWith(it.to);
        return (
          <NavLink key={it.to} to={it.to} className={clsx('flex flex-1 flex-col items-center gap-0.5 py-1 text-[0.7rem] font-medium', active ? 'text-accent' : 'text-ink-3')}>
            <span className="relative">
              <it.icon size={22} strokeWidth={active ? 2.3 : 1.9} />
              {it.badge ? (
                <span className="absolute -top-1.5 -right-2.5 inline-flex h-4 min-w-4 items-center justify-center rounded-full bg-accent px-1 text-[0.6rem] font-bold text-white">
                  {it.badge > 99 ? '99+' : it.badge}
                </span>
              ) : null}
            </span>
            {it.label}
          </NavLink>
        );
      })}
    </nav>
  );
}

