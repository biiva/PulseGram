import { clsx } from 'clsx';
import { lazy, Suspense, useEffect, useMemo, type ReactNode } from 'react';
import { Navigate, Route, Routes, useParams } from 'react-router-dom';
import { Spinner } from '../../components/ui/misc';
import { installRealtimeBindings } from '../../lib/bindings';
import { loadConversations } from '../../lib/chatActions';
import { realtime } from '../../lib/realtime';
import { useChat } from '../../stores/chat';
import { ChatListPanel } from '../chats/ChatListPanel';
import { ChatEmpty } from '../chat/ChatEmpty';
import { ChatView } from '../chat/ChatView';
import { DialogHost } from './DialogHost';
import { MobileTabs, NavRail } from './NavRail';
import { VerifyBanner } from './VerifyBanner';

const ContactsPanel = lazy(() => import('../contacts/ContactsPanel').then((m) => ({ default: m.ContactsPanel })));
const CallsPanel = lazy(() => import('../calls/CallsPanel').then((m) => ({ default: m.CallsPanel })));
const CallOverlay = lazy(() => import('../calls/CallOverlay').then((m) => ({ default: m.CallOverlay })));
const ExplorePanel = lazy(() => import('../explore/ExplorePanel').then((m) => ({ default: m.ExplorePanel })));
const SettingsMenu = lazy(() => import('../settings/SettingsMenu').then((m) => ({ default: m.SettingsMenu })));
const SettingsSection = lazy(() => import('../settings/SettingsSection').then((m) => ({ default: m.SettingsSection })));
const JoinPage = lazy(() => import('../pages/JoinPage').then((m) => ({ default: m.JoinPage })));
const UserLinkPage = lazy(() => import('../pages/JoinPage').then((m) => ({ default: m.UserLinkPage })));

function Loading() {
  return (
    <div className="grid h-full place-items-center text-ink-3">
      <Spinner />
    </div>
  );
}

/**
 * Three-pane layout on desktop (nav rail · list · detail). On phones only one pane is shown:
 * the list, or the detail when something is open — with a bottom tab bar on list screens.
 */
function Layout({ middle, right, detail }: { middle: ReactNode; right: ReactNode; detail: boolean }) {
  return (
    <div className="flex h-dvh overflow-hidden bg-bg">
      <NavRail />
      <section
        className={clsx(
          'flex min-w-0 flex-col border-line bg-panel md:w-[340px] md:shrink-0 md:border-r lg:w-[380px]',
          detail ? 'hidden md:flex' : 'flex w-full',
        )}
      >
        <VerifyBanner />
        <div className="min-h-0 flex-1">
          <Suspense fallback={<Loading />}>{middle}</Suspense>
        </div>
        <MobileTabs />
      </section>
      <main className={clsx('min-w-0 flex-1', detail ? 'flex' : 'hidden md:flex')}>
        <Suspense fallback={<Loading />}>
          <div className="flex h-full w-full min-w-0">{right}</div>
        </Suspense>
      </main>
    </div>
  );
}

function ChatRoute() {
  const { chatId } = useParams();
  return <Layout middle={<ChatListPanel />} right={chatId ? <ChatView key={chatId} conversationId={chatId} /> : <ChatEmpty />} detail={Boolean(chatId)} />;
}

function SettingsRoute() {
  const { section } = useParams();
  return <Layout middle={<SettingsMenu />} right={<SettingsSection section={section ?? 'profile'} />} detail={Boolean(section)} />;
}

export function AppShell() {
  const conversations = useChat((s) => s.conversations);

  useEffect(() => {
    installRealtimeBindings();
    realtime.start();
    void loadConversations().catch(() => {});
    if ('serviceWorker' in navigator) void navigator.serviceWorker.register('/sw.js').catch(() => {});
    return () => realtime.stop();
  }, []);

  // Watch presence of everyone shown in the chat list (server filters by their privacy settings).
  const peerIds = useMemo(
    () =>
      Object.values(conversations)
        .map((c) => c.peer?.id)
        .filter((x): x is string => Boolean(x))
        .sort()
        .join(','),
    [conversations],
  );
  useEffect(() => {
    realtime.subscribePresence(peerIds ? peerIds.split(',') : []);
  }, [peerIds]);

  return (
    <>
      <Routes>
        <Route path="chat" element={<ChatRoute />} />
        <Route path="chat/:chatId" element={<ChatRoute />} />
        <Route path="contacts" element={<Layout middle={<ContactsPanel />} right={<ChatEmpty />} detail={false} />} />
        <Route path="calls" element={<Layout middle={<CallsPanel />} right={<ChatEmpty />} detail={false} />} />
        <Route path="explore" element={<Layout middle={<ExplorePanel />} right={<ChatEmpty />} detail={false} />} />
        <Route path="settings" element={<SettingsRoute />} />
        <Route path="settings/:section" element={<SettingsRoute />} />
        <Route path="join/:token" element={<Layout middle={<ChatListPanel />} right={<JoinPage />} detail />} />
        <Route path="u/:username" element={<Layout middle={<ChatListPanel />} right={<UserLinkPage />} detail />} />
        <Route path="*" element={<Navigate to="/chat" replace />} />
      </Routes>
      <DialogHost />
      <Suspense fallback={null}>
        <CallOverlay />
      </Suspense>
    </>
  );
}
