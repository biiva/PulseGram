import { useQuery } from '@tanstack/react-query';
import { clsx } from 'clsx';
import { Search, Star } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { GifDto, StickerDto, StickerSetDto } from '@pulsegram/shared';
import { Spinner } from '../../components/ui/misc';
import { useT, type MessageKey } from '../../i18n';
import { ApiError, http } from '../../lib/api';
import { queryClient } from '../../lib/queryClient';
import { useAuth } from '../../stores/auth';
import { useDebounced } from '../chats/SearchResults';
import { EMOJI_CATEGORIES, type EmojiCategory } from './emojiData';

const RECENT_KEY = 'pg.recentEmoji';
export function recentEmoji(): string[] {
  try {
    return JSON.parse(localStorage.getItem(RECENT_KEY) ?? '[]') as string[];
  } catch {
    return [];
  }
}
export function pushRecentEmoji(e: string) {
  try {
    localStorage.setItem(RECENT_KEY, JSON.stringify([e, ...recentEmoji().filter((x) => x !== e)].slice(0, 32)));
  } catch {
    /* ignore */
  }
}

const CAT_ICON: Record<EmojiCategory, string> = { smileys: '😀', nature: '🐻', food: '🍔', activity: '⚽', travel: '🚗', objects: '💡', symbols: '❤️', flags: '🏁' };

function EmojiGrid({ onPick }: { onPick: (e: string) => void }) {
  const t = useT();
  const [q, setQ] = useState('');
  const [recent, setRecent] = useState(recentEmoji);
  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return null;
    return Object.values(EMOJI_CATEGORIES)
      .flat()
      .filter(([, n]) => n.includes(s))
      .slice(0, 120);
  }, [q]);
  const pick = (e: string) => {
    pushRecentEmoji(e);
    setRecent(recentEmoji());
    onPick(e);
  };
  const cell = (e: string, name?: string) => (
    <button key={e} type="button" title={name} onClick={() => pick(e)} className="grid aspect-square place-items-center rounded-[10px] text-[1.45rem] hover:bg-sunken">
      {e}
    </button>
  );
  return (
    <div className="flex h-full flex-col">
      <div className="relative px-3 pt-3 pb-2">
        <Search size={15} className="absolute top-1/2 left-6 -translate-y-1/2 text-ink-3" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('emoji.search')} className="h-9 w-full rounded-full bg-sunken pr-3 pl-9 text-[0.88rem] outline-none focus:ring-2 focus:ring-accent/40" autoFocus />
      </div>
      <div className="scroll-y min-h-0 flex-1 px-2 pb-2">
        {results ? (
          results.length ? <div className="grid grid-cols-8 gap-0.5">{results.map(([e, n]) => cell(e, n))}</div> : <p className="p-6 text-center text-[0.88rem] text-ink-3">{t('emoji.noResults')}</p>
        ) : (
          <>
            {recent.length > 0 && (
              <section>
                <h4 className="px-1.5 py-1.5 text-[0.75rem] font-semibold text-ink-3">{t('emoji.recent')}</h4>
                <div className="grid grid-cols-8 gap-0.5">{recent.map((e) => cell(e))}</div>
              </section>
            )}
            {(Object.keys(EMOJI_CATEGORIES) as EmojiCategory[]).map((cat) => (
              <section key={cat} id={`emoji-${cat}`}>
                <h4 className="sticky top-0 bg-raised/95 px-1.5 py-1.5 text-[0.75rem] font-semibold text-ink-3 backdrop-blur">{t(`emoji.${cat}` as MessageKey)}</h4>
                <div className="grid grid-cols-8 gap-0.5">{EMOJI_CATEGORIES[cat].map(([e, n]) => cell(e, n))}</div>
              </section>
            ))}
          </>
        )}
      </div>
      {!results && (
        <div className="flex justify-between border-t border-line px-2 py-1">
          {(Object.keys(EMOJI_CATEGORIES) as EmojiCategory[]).map((cat) => (
            <button
              key={cat}
              type="button"
              aria-label={t(`emoji.${cat}` as MessageKey)}
              className="grid size-8 place-items-center rounded-lg text-[1.05rem] grayscale hover:bg-sunken hover:grayscale-0"
              onClick={() => document.getElementById(`emoji-${cat}`)?.scrollIntoView({ block: 'start' })}
            >
              {CAT_ICON[cat]}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function StickerGrid({ onPick }: { onPick: (s: StickerDto) => void }) {
  const t = useT();
  const q = useQuery({ queryKey: ['stickers'], queryFn: () => http.get<{ sets: StickerSetDto[]; favorites: string[] }>('/api/stickers'), staleTime: 300_000 });
  if (q.isLoading) return <div className="grid h-full place-items-center text-ink-3"><Spinner /></div>;
  const sets = q.data?.sets ?? [];
  const all = sets.flatMap((s) => s.stickers);
  const favs = (q.data?.favorites ?? []).map((id) => all.find((s) => s.id === id)).filter((x): x is StickerDto => Boolean(x));
  const toggleFav = async (s: StickerDto) => {
    const isFav = q.data?.favorites.includes(s.id);
    if (isFav) await http.del(`/api/stickers/${s.id}/favorite`);
    else await http.post(`/api/stickers/${s.id}/favorite`);
    await queryClient.invalidateQueries({ queryKey: ['stickers'] });
  };
  const grid = (list: StickerDto[]) => (
    <div className="grid grid-cols-4 gap-1">
      {list.map((s) => (
        <button
          key={s.id}
          type="button"
          onClick={() => onPick(s)}
          onContextMenu={(e) => {
            e.preventDefault();
            void toggleFav(s);
          }}
          title={`${s.emoji} — ${q.data?.favorites.includes(s.id) ? t('emoji.removeFavorite') : t('emoji.addFavorite')} (right-click)`}
          className="aspect-square rounded-[12px] p-1 transition hover:scale-105 hover:bg-sunken"
        >
          <img src={s.url} alt={s.emoji} className="size-full" loading="lazy" draggable={false} />
        </button>
      ))}
    </div>
  );
  return (
    <div className="scroll-y h-full p-2">
      {favs.length > 0 && (
        <section className="mb-2">
          <h4 className="flex items-center gap-1 px-1.5 py-1.5 text-[0.75rem] font-semibold text-ink-3"><Star size={12} /> {t('emoji.favorites')}</h4>
          {grid(favs)}
        </section>
      )}
      {sets.map((set) => (
        <section key={set.id} className="mb-2">
          <h4 className="px-1.5 py-1.5 text-[0.75rem] font-semibold text-ink-3">{set.title}</h4>
          {grid(set.stickers)}
        </section>
      ))}
    </div>
  );
}

function GifGrid({ onPick }: { onPick: (g: GifDto) => void }) {
  const t = useT();
  const configured = useAuth((s) => s.config?.gifConfigured);
  const [q, setQ] = useState('');
  const dq = useDebounced(q, 350);
  const res = useQuery({
    queryKey: ['gifs', dq],
    queryFn: ({ signal }) => http.get<{ items: GifDto[] }>(`/api/gifs?q=${encodeURIComponent(dq)}`, { signal }),
    enabled: Boolean(configured),
    staleTime: 60_000,
  });
  if (!configured || (res.error instanceof ApiError && res.error.code === 'not_configured')) {
    return <p className="p-6 text-center text-[0.86rem] leading-relaxed text-ink-3">{t('emoji.gifNotConfigured')}</p>;
  }
  return (
    <div className="flex h-full flex-col">
      <div className="px-3 pt-3 pb-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('emoji.gifSearch')} className="h-9 w-full rounded-full bg-sunken px-4 text-[0.88rem] outline-none focus:ring-2 focus:ring-accent/40" />
      </div>
      <div className="scroll-y min-h-0 flex-1 columns-2 gap-1 px-2 pb-2">
        {res.isLoading && <Spinner className="m-6 text-ink-3" />}
        {res.data?.items.map((g) => (
          <button key={g.url} type="button" onClick={() => onPick(g)} className="mb-1 block w-full overflow-hidden rounded-[10px] hover:opacity-85">
            <img src={g.previewUrl} alt={g.title ?? 'GIF'} loading="lazy" referrerPolicy="no-referrer" className="w-full" />
          </button>
        ))}
        {res.data && res.data.items.length === 0 && <p className="p-6 text-center text-[0.88rem] text-ink-3">{t('emoji.noResults')}</p>}
      </div>
    </div>
  );
}

export function EmojiPanel({
  onEmoji,
  onSticker,
  onGif,
  allowMedia,
}: {
  onEmoji: (e: string) => void;
  onSticker: (s: StickerDto) => void;
  onGif: (g: GifDto) => void;
  allowMedia: boolean;
}) {
  const t = useT();
  const [tab, setTab] = useState<'emoji' | 'stickers' | 'gifs'>('emoji');
  return (
    <div className="anim-pop flex h-[min(400px,55dvh)] w-[min(352px,calc(100vw-1rem))] flex-col overflow-hidden rounded-[18px] border border-line bg-raised shadow-pop">
      <div className="min-h-0 flex-1">
        {tab === 'emoji' && <EmojiGrid onPick={onEmoji} />}
        {tab === 'stickers' && <StickerGrid onPick={onSticker} />}
        {tab === 'gifs' && <GifGrid onPick={onGif} />}
      </div>
      <div role="tablist" className="flex gap-1 border-t border-line p-1.5">
        {(['emoji', 'stickers', 'gifs'] as const).map((k) => (
          <button
            key={k}
            role="tab"
            type="button"
            aria-selected={tab === k}
            disabled={k !== 'emoji' && !allowMedia}
            onClick={() => setTab(k)}
            className={clsx('flex-1 rounded-[10px] py-1.5 text-[0.82rem] font-semibold disabled:opacity-40', tab === k ? 'bg-soft text-accent' : 'text-ink-3 hover:bg-sunken')}
          >
            {k === 'emoji' ? t('emoji.tabEmoji') : k === 'stickers' ? t('emoji.tabStickers') : t('emoji.tabGifs')}
          </button>
        ))}
      </div>
    </div>
  );
}

