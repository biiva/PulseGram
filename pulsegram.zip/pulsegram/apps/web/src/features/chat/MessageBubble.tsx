import { clsx } from 'clsx';
import { AlertCircle, Check, CheckCheck, Clock, CornerUpRight, Eye, MoreHorizontal, Reply, SmilePlus } from 'lucide-react';
import { memo } from 'react';
import type { ConversationDto, UserSummary } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { useT } from '../../i18n';
import { formatTime, toneFor } from '../../lib/format';
import { cancelSend, retrySend, toggleReaction } from '../../lib/chatActions';
import type { ClientMessage } from '../../stores/chat';
import { usePrefs } from '../../stores/prefs';
import { toast } from '../../stores/ui';
import { errorText } from '../../lib/api';
import { AudioPlayer, FileCard, MediaGrid, VoicePlayer } from './Attachments';
import { isEmojiOnly, RichText } from './RichText';
import { messagePreview } from '../chats/ChatListItem';

export interface BubbleProps {
  m: ClientMessage;
  conv: ConversationDto;
  out: boolean;
  /** First message in a run from the same sender (shows name in groups). */
  first: boolean;
  /** Last in a run (shows avatar + tail). */
  last: boolean;
  sender?: UserSummary;
  peerReadSeq: number;
  selected: boolean;
  selectMode: boolean;
  highlight?: string;
  canReact: boolean;
  onMenu: (e: React.MouseEvent | { clientX: number; clientY: number }, m: ClientMessage) => void;
  onReply: (m: ClientMessage) => void;
  onToggleSelect: (m: ClientMessage) => void;
  onJump: (seq: number) => void;
  onOpenUser: (id: string) => void;
}

function Status({ m, peerReadSeq, onRetry }: { m: ClientMessage; peerReadSeq: number; onRetry: () => void }) {
  const t = useT();
  if (m.local?.status === 'failed')
    return (
      <button type="button" onClick={onRetry} title={t('chat.failed')} aria-label={t('chat.failed')} className="text-danger">
        <AlertCircle size={15} />
      </button>
    );
  if (m.local) return <Clock size={13} aria-label={t('chat.sending')} />;
  return peerReadSeq >= m.seq ? <CheckCheck size={16} aria-label="read" /> : <Check size={16} aria-label="sent" />;
}

export const MessageBubble = memo(function MessageBubble(p: BubbleProps) {
  const { m, conv, out, first, last, sender, selected, selectMode } = p;
  const t = useT();
  const fmt = usePrefs((s) => s.appearance);
  const isChannel = conv.type === 'channel';
  const showSenderName = conv.type === 'group' && !out && first;
  const showAvatar = conv.type === 'group' && !out;
  const media = m.attachments.filter((a) => a.kind === 'image' || a.kind === 'video');
  const others = m.attachments.filter((a) => a.kind !== 'image' && a.kind !== 'video');
  const bigEmoji = m.type === 'text' && !m.replyTo && !m.forward && isEmojiOnly(m.text);
  const bare = m.type === 'sticker' || m.type === 'gif' || bigEmoji;
  const mediaOnly = media.length > 0 && !m.text && others.length === 0 && !m.replyTo && !m.forward;
  const time = formatTime(m.createdAt, fmt);
  const retry = () => m.clientId && void retrySend(m.conversationId, m.clientId);
  const cancel = () => m.clientId && cancelSend(m.conversationId, m.clientId);

  const meta = (
    <span className={clsx('inline-flex shrink-0 items-center gap-1 text-[0.7rem] tabular-nums select-none', bare || mediaOnly ? 'rounded-full bg-black/45 px-1.5 py-0.5 text-white' : out ? 'text-white/75' : 'text-ink-3')}>
      {isChannel && m.views !== null && (
        <span className="inline-flex items-center gap-0.5">
          <Eye size={12} /> {m.views}
        </span>
      )}
      {m.signature && <span className="max-w-24 truncate">{m.signature}</span>}
      {m.editedAt && <span>{t('chat.edited')}</span>}
      <span>{time}</span>
      {out && !isChannel && conv.type !== 'saved' && <Status m={m} peerReadSeq={p.peerReadSeq} onRetry={retry} />}
      {out && conv.type === 'saved' && m.local && <Status m={m} peerReadSeq={0} onRetry={retry} />}
    </span>
  );

  const reactions = m.reactions.length > 0 && (
    <div className={clsx('mt-1 flex flex-wrap gap-1', out && !bare ? 'justify-end' : '')}>
      {m.reactions.map((r) => (
        <button
          key={r.emoji}
          type="button"
          disabled={!p.canReact}
          onClick={() => void toggleReaction(m.conversationId, m.id, r.emoji).catch((err: unknown) => toast({ text: errorText(t, err), tone: 'danger' }))}
          aria-pressed={r.mine}
          className={clsx(
            'inline-flex h-7 items-center gap-1 rounded-full border px-2 text-[0.82rem] font-semibold transition-colors',
            r.mine
              ? out && !bare
                ? 'border-white bg-white text-accent'
                : 'border-accent bg-accent text-white'
              : out && !bare
                ? 'border-white/30 bg-white/15 text-white hover:bg-white/25'
                : 'border-line bg-sunken text-ink-2 hover:border-line-strong',
          )}
        >
          <span>{r.emoji}</span>
          <span className="tabular-nums">{r.count}</span>
        </button>
      ))}
    </div>
  );

  const body = (
    <>
      {showSenderName && (
        <button type="button" onClick={() => m.senderId && p.onOpenUser(m.senderId)} className="mb-0.5 block max-w-full truncate px-3 pt-2 text-[0.82rem] font-bold" style={{ color: toneFor(m.senderId ?? '') }}>
          {sender?.displayName ?? '…'}
        </button>
      )}
      {m.forward && (
        <div className={clsx('flex items-center gap-1 px-3 pt-2 text-[0.8rem] font-semibold', out ? 'text-white/85' : 'text-accent')}>
          <CornerUpRight size={13} /> <span className="truncate">{t('chat.forwardedFrom', { name: m.forward.fromName })}</span>
        </div>
      )}
      {m.replyTo && (
        <button
          type="button"
          onClick={() => m.replyTo && !m.replyTo.deleted && p.onJump(m.replyTo.seq)}
          className={clsx(
            'mx-2 mt-2 flex w-[calc(100%-1rem)] min-w-40 flex-col rounded-[10px] border-l-[3px] px-2.5 py-1 text-left text-[0.82rem]',
            out ? 'border-white bg-white/15' : 'border-accent bg-soft',
          )}
        >
          <span className={clsx('truncate font-semibold', out ? 'text-white' : 'text-accent')}>{m.replyTo.senderName || '…'}</span>
          <span className={clsx('truncate', out ? 'text-white/80' : 'text-ink-2')}>
            {m.replyTo.deleted ? t('chat.deleted') : m.replyTo.text || messagePreview({ ...m, type: m.replyTo.type, text: '', attachments: [], sticker: null } as ClientMessage, t)}
          </span>
        </button>
      )}
      {media.length > 0 && (
        <div className={clsx('relative', (m.text || others.length || m.replyTo || m.forward || showSenderName) && 'mt-1.5')}>
          <MediaGrid message={m} uploads={m.local?.uploads} onCancel={cancel} />
          {mediaOnly && <span className="absolute right-2 bottom-2">{meta}</span>}
        </div>
      )}
      {others.map((a, i) => (
        <div key={a.id} className="px-3 pt-2">
          {a.kind === 'voice' && !m.local ? (
            <VoicePlayer a={a} out={out} />
          ) : a.kind === 'audio' && !m.local ? (
            <AudioPlayer a={a} out={out} />
          ) : (
            <FileCard a={a} out={out} upload={m.local?.uploads?.[m.attachments.indexOf(a)]} onCancel={cancel} />
          )}
          {i === others.length - 1 && !m.text && <div className="flex justify-end pb-1.5">{meta}</div>}
        </div>
      ))}
      {m.text && (
        <div className="relative px-3 pt-1.5 pb-1.5 text-[0.95rem] leading-[1.42] whitespace-pre-wrap">
          <RichText text={m.text} highlight={p.highlight} />
          {/* Invisible spacer reserves room for the timestamp on the last line. */}
          <span aria-hidden="true" className="invisible inline-block h-3 pl-2 align-baseline text-[0.7rem] select-none">
            {m.signature ? `${m.signature.slice(0, 14)} ` : ''}
            {isChannel ? '👁 9999 ' : ''}
            {m.editedAt ? `${t('chat.edited')} ` : ''}
            {time}
            {out && !isChannel ? ' ✓✓✓' : ''}
          </span>
          <span className="absolute right-3 bottom-1.5">{meta}</span>
        </div>
      )}
      {!m.text && !media.length && !others.length && !bare && <div className="flex justify-end px-3 py-1.5">{meta}</div>}
      {!bare && reactions && <div className="px-2 pb-1.5">{reactions}</div>}
    </>
  );

  return (
    <div
      className={clsx('group relative flex w-full items-end gap-2 px-3 md:px-6', first ? 'mt-2' : 'mt-0.5', selected && 'bg-accent/10', selectMode && 'cursor-pointer')}
      data-seq={m.seq || undefined}
      data-mid={m.id}
      onClick={selectMode ? () => !m.local && p.onToggleSelect(m) : undefined}
      onContextMenu={(e) => {
        if (selectMode || m.local) return;
        e.preventDefault();
        p.onMenu(e, m);
      }}
      onDoubleClick={() => !selectMode && !m.local && p.onReply(m)}
      style={{ contentVisibility: 'auto', containIntrinsicSize: 'auto 64px' }}
    >
      {selectMode && (
        <span className={clsx('mb-2 grid size-5 shrink-0 place-items-center rounded-full border-2', selected ? 'border-accent bg-accent text-white' : 'border-line-strong')}>
          {selected && <Check size={12} strokeWidth={3} />}
        </span>
      )}
      {showAvatar && (
        <span className="w-9 shrink-0">
          {last && (
            <button type="button" onClick={() => m.senderId && p.onOpenUser(m.senderId)} aria-label={sender?.displayName}>
              <Avatar id={m.senderId ?? ''} name={sender?.displayName ?? ''} src={sender?.avatarUrl} size={36} />
            </button>
          )}
        </span>
      )}
      <div className={clsx('flex min-w-0 flex-1', out ? 'justify-end' : 'justify-start')}>
        <div className={clsx('relative flex max-w-[min(560px,85%)] flex-col', out ? 'items-end' : 'items-start')}>
          {bare ? (
            <div className="flex flex-col items-end gap-1">
              {(showSenderName || m.replyTo) && <div className={clsx('bubble', out ? 'bubble-out' : 'bubble-in', 'pb-1')}>{showSenderName && <span className="block px-3 pt-1.5 text-[0.82rem] font-bold" style={{ color: toneFor(m.senderId ?? '') }}>{sender?.displayName}</span>}</div>}
              {m.type === 'sticker' && m.sticker && <img src={m.sticker.url} alt={m.sticker.emoji} className="size-40 select-none" draggable={false} />}
              {m.type === 'gif' && m.gif && (
                <img src={m.gif.url} alt={m.gif.title ?? 'GIF'} referrerPolicy="no-referrer" className="max-h-64 max-w-[min(320px,70vw)] rounded-[var(--r-bubble)]" loading="lazy" />
              )}
              {bigEmoji && <span className="text-[3.2rem] leading-none select-text">{m.text}</span>}
              {meta}
              {reactions}
            </div>
          ) : (
            <div className={clsx('bubble anim-pop', out ? 'bubble-out' : 'bubble-in', last && 'tail', mediaOnly && 'overflow-hidden', m.local?.status === 'failed' && 'ring-2 ring-danger/50')}>{body}</div>
          )}
          {m.local?.status === 'failed' && (
            <button type="button" onClick={retry} className="mt-1 text-[0.75rem] font-semibold text-danger hover:underline">
              {t('chat.failed')}
            </button>
          )}
          {!selectMode && !m.local && (
            <div className={clsx('absolute top-1/2 z-10 hidden -translate-y-1/2 gap-0.5 rounded-full border border-line bg-raised p-0.5 shadow-2 group-hover:flex', out ? 'right-full mr-2' : 'left-full ml-2')}>
              {p.canReact && (
                <button type="button" className="grid size-7 place-items-center rounded-full text-ink-3 hover:bg-sunken hover:text-ink" aria-label="React" onClick={(e) => p.onMenu(e, m)}>
                  <SmilePlus size={15} />
                </button>
              )}
              <button type="button" className="grid size-7 place-items-center rounded-full text-ink-3 hover:bg-sunken hover:text-ink" aria-label={t('chat.reply')} onClick={() => p.onReply(m)}>
                <Reply size={15} />
              </button>
              <button type="button" className="grid size-7 place-items-center rounded-full text-ink-3 hover:bg-sunken hover:text-ink" aria-label={t('common.more')} onClick={(e) => p.onMenu(e, m)}>
                <MoreHorizontal size={15} />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
});
