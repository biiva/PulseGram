import { useQuery } from '@tanstack/react-query';
import { ChevronDown, ChevronUp, Copy, CornerUpRight, Pin, Search, Trash2, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { can, type ConversationDto, type MessageDto, type SearchResults } from '@pulsegram/shared';
import { Button, IconButton } from '../../components/ui/Button';
import { Spinner } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { setPinned } from '../../lib/chatActions';
import { useChat } from '../../stores/chat';
import { toast } from '../../stores/ui';
import { messagePreview } from '../chats/ChatListItem';
import { useDebounced } from '../chats/SearchResults';

export function PinnedBar({ conv, onJump }: { conv: ConversationDto; onJump: (m: MessageDto) => void }) {
  const t = useT();
  const [index, setIndex] = useState(0);
  const key = conv.pinnedMessageIds.join(',');
  const pins = useQuery({
    queryKey: ['pins', conv.id, key],
    queryFn: () => http.get<MessageDto[]>(`/api/conversations/${conv.id}/pins`),
    enabled: conv.pinnedMessageIds.length > 0,
  });
  const list = pins.data ?? [];
  useEffect(() => setIndex(Math.max(0, list.length - 1)), [list.length]);
  if (!conv.pinnedMessageIds.length || !list.length) return null;
  const cur = list[Math.min(index, list.length - 1)]!;
  const canUnpin = conv.me ? can.pin({ type: conv.type, role: conv.me.role, settings: conv.settings }) : false;
  return (
    <div className="flex h-13 shrink-0 items-center gap-3 border-b border-line bg-bg/95 px-3 backdrop-blur md:px-5">
      <div className="flex h-8 flex-col gap-0.5" aria-hidden="true">
        {list.slice(0, 4).map((p, i) => (
          <span key={p.id} className={`w-0.5 flex-1 rounded-full ${i === Math.min(index, 3) ? 'bg-accent' : 'bg-accent/30'}`} />
        ))}
      </div>
      <button
        type="button"
        className="min-w-0 flex-1 text-left"
        onClick={() => {
          onJump(cur);
          setIndex((i) => (i - 1 + list.length) % list.length);
        }}
      >
        <span className="block text-[0.8rem] font-semibold text-accent">{list.length > 1 ? t('chat.pinnedN', { n: index + 1 }) : t('chat.pinned')}</span>
        <span className="block truncate text-[0.88rem] text-ink-2">{messagePreview(cur, t)}</span>
      </button>
      {canUnpin && (
        <IconButton label={t('chat.unpin')} size={34} onClick={() => void setPinned(conv.id, cur.id, false).catch((err: unknown) => toast({ text: errorText(t, err), tone: 'danger' }))}>
          <X size={18} />
        </IconButton>
      )}
      <Pin size={16} className="shrink-0 rotate-45 text-ink-3" />
    </div>
  );
}

export function ChatSearchBar({ conv, onClose, onJump, onTerm }: { conv: ConversationDto; onClose: () => void; onJump: (m: MessageDto) => void; onTerm: (q: string) => void }) {
  const t = useT();
  const [q, setQ] = useState('');
  const [type, setType] = useState('');
  const [sender, setSender] = useState('');
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [cursor, setCursor] = useState(0);
  const users = useChat((s) => s.users);
  const dq = useDebounced(q, 300);
  const params = new URLSearchParams({ conversationId: conv.id, limit: '50' });
  if (dq) params.set('q', dq);
  if (type) params.set('type', type);
  if (sender) params.set('senderId', sender);
  if (from) params.set('from', new Date(from).toISOString());
  if (to) params.set('to', new Date(`${to}T23:59:59`).toISOString());
  const enabled = Boolean(dq || type || sender || from || to);
  const res = useQuery({
    queryKey: ['chat-search', params.toString()],
    queryFn: ({ signal }) => http.get<SearchResults>(`/api/search?${params}`, { signal }),
    enabled,
  });
  const list = res.data?.messages ?? [];
  useEffect(() => {
    onTerm(dq);
    setCursor(0);
  }, [dq, onTerm]);
  useEffect(() => {
    const m = list[cursor];
    if (m) onJump(m.message);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [cursor, res.data]);
  const senders = Object.values(users).slice(0, 50);
  return (
    <div className="shrink-0 border-b border-line bg-bg px-3 py-2 md:px-5">
      <div className="flex items-center gap-2">
        <label className="relative flex flex-1 items-center">
          <Search size={16} className="absolute left-3 text-ink-3" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Escape') onClose();
              if (e.key === 'Enter') setCursor((c) => Math.min(list.length - 1, c + 1));
            }}
            placeholder={t('search.inChat')}
            className="h-9 w-full rounded-full bg-sunken pr-3 pl-9 text-[0.9rem] outline-none focus:ring-2 focus:ring-accent/40"
          />
        </label>
        <span className="min-w-14 text-center text-[0.8rem] text-ink-3 tabular-nums">
          {res.isFetching ? <Spinner size={14} /> : enabled ? (list.length ? `${cursor + 1}/${list.length}` : '0') : ''}
        </span>
        <IconButton label="Older" size={34} disabled={cursor >= list.length - 1} onClick={() => setCursor((c) => c + 1)}>
          <ChevronUp size={18} />
        </IconButton>
        <IconButton label="Newer" size={34} disabled={cursor <= 0} onClick={() => setCursor((c) => c - 1)}>
          <ChevronDown size={18} />
        </IconButton>
        <IconButton label={t('common.close')} size={34} onClick={onClose}>
          <X size={18} />
        </IconButton>
      </div>
      <div className="mt-2 flex flex-wrap gap-2 text-[0.8rem]">
        <select value={type} onChange={(e) => setType(e.target.value)} aria-label={t('search.type')} className="h-8 rounded-full border border-line bg-raised px-2.5 text-ink-2">
          <option value="">{t('search.anyType')}</option>
          <option value="image">{t('chat.photo')}</option>
          <option value="video">{t('chat.video')}</option>
          <option value="file">{t('chat.file')}</option>
          <option value="audio">{t('chat.audio')}</option>
          <option value="voice">{t('chat.voiceMessage')}</option>
          <option value="link">{t('info.links')}</option>
        </select>
        {conv.type === 'group' && (
          <select value={sender} onChange={(e) => setSender(e.target.value)} aria-label={t('search.from')} className="h-8 max-w-40 rounded-full border border-line bg-raised px-2.5 text-ink-2">
            <option value="">{t('search.anyone')}</option>
            {senders.map((u) => (
              <option key={u.id} value={u.id}>
                {u.displayName}
              </option>
            ))}
          </select>
        )}
        <label className="flex items-center gap-1 text-ink-3">
          {t('search.dateFrom')}
          <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="h-8 rounded-full border border-line bg-raised px-2 text-ink-2" />
        </label>
        <label className="flex items-center gap-1 text-ink-3">
          {t('search.dateTo')}
          <input type="date" value={to} onChange={(e) => setTo(e.target.value)} className="h-8 rounded-full border border-line bg-raised px-2 text-ink-2" />
        </label>
      </div>
    </div>
  );
}

export function SelectionBar({
  count,
  onCancel,
  onForward,
  onDelete,
  onCopy,
}: {
  count: number;
  onCancel: () => void;
  onForward: () => void;
  onDelete: () => void;
  onCopy: () => void;
}) {
  const t = useT();
  return (
    <div className="pb-safe flex shrink-0 items-center gap-2 border-t border-line bg-bg px-3 py-2 md:px-6">
      <IconButton label={t('common.cancel')} onClick={onCancel}>
        <X size={20} />
      </IconButton>
      <span className="flex-1 text-[0.95rem] font-semibold text-ink">{t('chat.selected', { n: count })}</span>
      <Button variant="ghost" size="sm" icon={<Copy size={16} />} onClick={onCopy} disabled={!count}>
        {t('common.copy')}
      </Button>
      <Button variant="soft" size="sm" icon={<CornerUpRight size={16} />} onClick={onForward} disabled={!count}>
        {t('chat.forward')}
      </Button>
      <Button variant="danger" size="sm" icon={<Trash2 size={16} />} onClick={onDelete} disabled={!count}>
        {t('common.delete')}
      </Button>
    </div>
  );
}
