import { clsx } from 'clsx';
import { Check, Mic, Paperclip, Pencil, Reply, Send, Smile, X } from 'lucide-react';
import { forwardRef, useCallback, useEffect, useImperativeHandle, useLayoutEffect, useRef, useState } from 'react';
import { can, LIMITS, type ConversationDto, type MessageDto } from '@pulsegram/shared';
import { IconButton } from '../../components/ui/Button';
import { useT } from '../../i18n';
import { errorText } from '../../lib/api';
import { editMessage, saveDraft, sendMessage } from '../../lib/chatActions';
import { realtime } from '../../lib/realtime';
import { useChat } from '../../stores/chat';
import { usePrefs } from '../../stores/prefs';
import { toast } from '../../stores/ui';
import { messagePreview } from '../chats/ChatListItem';
import { AttachDialog } from './AttachDialog';
import { EmojiPanel } from './EmojiPanel';
import { RecordingBar, useVoiceRecorder, type RecorderError } from './VoiceRecorder';

export interface ComposerHandle {
  addFiles: (files: File[]) => void;
  focus: () => void;
}

interface Props {
  conv: ConversationDto;
  replyTo: MessageDto | null;
  editing: MessageDto | null;
  onClearReply: () => void;
  onClearEdit: () => void;
  onEditLast: () => void;
  onSent: () => void;
}

export const Composer = forwardRef<ComposerHandle, Props>(function Composer({ conv, replyTo, editing, onClearReply, onClearEdit, onEditLast, onSent }, ref) {
  const t = useT();
  const enterToSend = usePrefs((s) => s.appearance.enterToSend);
  const users = useChat((s) => s.users);
  const [text, setText] = useState(conv.me?.draft ?? '');
  const [files, setFiles] = useState<File[]>([]);
  const [emojiOpen, setEmojiOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const ta = useRef<HTMLTextAreaElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);
  const lastTyping = useRef(0);
  const stopTypingTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const emojiWrap = useRef<HTMLDivElement>(null);

  const perm = conv.me ? { type: conv.type, role: conv.me.role, settings: conv.settings } : null;
  const allowMedia = perm ? can.sendMedia(perm) : false;

  useImperativeHandle(ref, () => ({
    addFiles: (f) => {
      if (!allowMedia) return toast({ text: t('error.cannot_send'), tone: 'danger' });
      setFiles((prev) => [...prev, ...f].slice(0, LIMITS.attachmentsPerMessage));
    },
    focus: () => ta.current?.focus(),
  }));

  // Editing: load the message text; leaving edit mode restores the draft.
  const savedText = useRef('');
  useEffect(() => {
    if (editing) {
      savedText.current = text;
      setText(editing.text);
      requestAnimationFrame(() => {
        ta.current?.focus();
        ta.current?.setSelectionRange(editing.text.length, editing.text.length);
      });
    } else if (savedText.current) {
      setText(savedText.current);
      savedText.current = '';
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [editing?.id]);

  useEffect(() => {
    if (replyTo) ta.current?.focus();
  }, [replyTo]);

  useLayoutEffect(() => {
    const el = ta.current;
    if (!el) return;
    el.style.height = '0px';
    el.style.height = `${Math.min(el.scrollHeight, 220)}px`;
  }, [text]);

  useEffect(() => {
    if (!emojiOpen) return;
    const onDown = (e: MouseEvent) => {
      if (emojiWrap.current && !emojiWrap.current.contains(e.target as Node)) setEmojiOpen(false);
    };
    document.addEventListener('mousedown', onDown);
    return () => document.removeEventListener('mousedown', onDown);
  }, [emojiOpen]);

  const typing = () => {
    const now = Date.now();
    if (now - lastTyping.current > 2500) {
      lastTyping.current = now;
      realtime.send({ t: 'typing', d: { conversationId: conv.id, kind: 'text' } });
    }
    if (stopTypingTimer.current) clearTimeout(stopTypingTimer.current);
    stopTypingTimer.current = setTimeout(() => {
      lastTyping.current = 0;
      realtime.send({ t: 'typing', d: { conversationId: conv.id, kind: null } });
    }, 4000);
  };

  const onRecorderError = useCallback((e: RecorderError) => toast({ text: t(e === 'denied' ? 'chat.voiceDenied' : 'chat.voiceUnsupported'), tone: 'danger' }), [t]);
  const onVoice = useCallback(
    (blob: Blob, durationMs: number) => {
      void sendMessage(conv.id, { text: '', voice: { blob, durationMs }, replyToId: replyTo?.id });
      onClearReply();
      onSent();
    },
    [conv.id, replyTo?.id, onClearReply, onSent],
  );
  const recorder = useVoiceRecorder(conv.id, onVoice, onRecorderError);

  const submit = async () => {
    const value = text.replace(/\s+$/, '');
    if (busy) return;
    if (editing) {
      if (!value.trim() && editing.type === 'text') return;
      setBusy(true);
      try {
        await editMessage(editing.id, value);
        onClearEdit();
        setText(savedText.current);
        savedText.current = '';
      } catch (err) {
        toast({ text: errorText(t, err), tone: 'danger' });
      } finally {
        setBusy(false);
      }
      return;
    }
    if (!value.trim()) return;
    if (value.length > LIMITS.messageText) return toast({ text: `≤ ${LIMITS.messageText}`, tone: 'danger' });
    setText('');
    saveDraft(conv.id, '');
    realtime.send({ t: 'typing', d: { conversationId: conv.id, kind: null } });
    lastTyping.current = 0;
    const reply = replyTo?.id;
    onClearReply();
    onSent();
    await sendMessage(conv.id, { text: value, replyToId: reply });
  };

  const insertEmoji = (e: string) => {
    const el = ta.current;
    if (!el) return setText((v) => v + e);
    const start = el.selectionStart ?? text.length;
    const end = el.selectionEnd ?? text.length;
    const next = text.slice(0, start) + e + text.slice(end);
    setText(next);
    requestAnimationFrame(() => {
      el.focus();
      el.setSelectionRange(start + e.length, start + e.length);
    });
  };

  if (!perm) return null;

  const hasText = text.trim().length > 0;
  const bar = (replyTo || editing) && (
    <div className="anim-pop mx-auto flex w-full max-w-3xl items-center gap-3 px-3 pt-2">
      <span className="grid size-8 place-items-center text-accent">{editing ? <Pencil size={18} /> : <Reply size={18} />}</span>
      <div className="min-w-0 flex-1 border-l-2 border-accent pl-3">
        <p className="text-[0.82rem] font-semibold text-accent">
          {editing ? t('chat.editing') : t('chat.replyingTo', { name: users[replyTo!.senderId ?? '']?.displayName ?? '' })}
        </p>
        <p className="truncate text-[0.85rem] text-ink-2">{messagePreview((editing ?? replyTo)!, t)}</p>
      </div>
      <IconButton label={t('common.cancel')} size={34} onClick={editing ? onClearEdit : onClearReply}>
        <X size={18} />
      </IconButton>
    </div>
  );

  return (
    <div className="pb-safe shrink-0 border-t border-line bg-bg/90 backdrop-blur md:border-t-0 md:bg-transparent md:backdrop-blur-none">
      {bar}
      <div className="mx-auto flex w-full max-w-3xl items-end gap-1.5 px-2 py-2 md:px-4 md:pb-4">
        {recorder.recording ? (
          <div className="flex flex-1 items-center rounded-[22px] bg-raised px-2 py-1.5 shadow-2">
            <RecordingBar elapsed={recorder.elapsed} level={recorder.level} onCancel={recorder.cancel} onSend={recorder.stop} />
          </div>
        ) : (
          <>
            <div className="flex min-h-12 flex-1 items-end rounded-[22px] border border-line bg-raised shadow-1 transition-colors focus-within:border-accent/60 md:shadow-2">
              <div ref={emojiWrap} className="relative">
                <IconButton label={t('chat.emoji')} onClick={() => setEmojiOpen((v) => !v)} active={emojiOpen} className="m-1">
                  <Smile size={22} />
                </IconButton>
                {emojiOpen && (
                  <div className="absolute bottom-14 left-0 z-30">
                    <EmojiPanel
                      allowMedia={allowMedia && !editing}
                      onEmoji={insertEmoji}
                      onSticker={(s) => {
                        setEmojiOpen(false);
                        void sendMessage(conv.id, { text: '', sticker: s, replyToId: replyTo?.id });
                        onClearReply();
                        onSent();
                      }}
                      onGif={(g) => {
                        setEmojiOpen(false);
                        void sendMessage(conv.id, { text: '', gif: g, replyToId: replyTo?.id });
                        onClearReply();
                        onSent();
                      }}
                    />
                  </div>
                )}
              </div>
              <textarea
                ref={ta}
                rows={1}
                value={text}
                maxLength={LIMITS.messageText}
                aria-label={t('chat.placeholder')}
                placeholder={conv.type === 'channel' ? t('chat.placeholderChannel') : t('chat.placeholder')}
                className="max-h-[220px] min-h-12 flex-1 resize-none bg-transparent py-3 focus-visible:outline-none text-[0.97rem] leading-[1.4] text-ink outline-none placeholder:text-ink-3"
                onChange={(e) => {
                  setText(e.target.value);
                  if (!editing) {
                    saveDraft(conv.id, e.target.value);
                    if (e.target.value) typing();
                  }
                }}
                onPaste={(e) => {
                  const pasted = [...e.clipboardData.files];
                  if (pasted.length) {
                    e.preventDefault();
                    if (allowMedia) setFiles((f) => [...f, ...pasted]);
                  }
                }}
                onKeyDown={(e) => {
                  if (e.key === 'Enter' && !e.nativeEvent.isComposing) {
                    const send = enterToSend ? !e.shiftKey : e.ctrlKey || e.metaKey;
                    if (send) {
                      e.preventDefault();
                      void submit();
                    }
                  } else if (e.key === 'ArrowUp' && !text && !editing) {
                    e.preventDefault();
                    onEditLast();
                  } else if (e.key === 'Escape') {
                    if (editing) onClearEdit();
                    else if (replyTo) onClearReply();
                  }
                }}
              />
              {allowMedia && !editing && (
                <>
                  <IconButton label={t('chat.attach')} className="m-1" onClick={() => fileInput.current?.click()}>
                    <Paperclip size={21} />
                  </IconButton>
                  <input
                    ref={fileInput}
                    type="file"
                    multiple
                    hidden
                    onChange={(e) => {
                      const f = [...(e.target.files ?? [])];
                      e.target.value = '';
                      if (f.length) setFiles((prev) => [...prev, ...f]);
                    }}
                  />
                </>
              )}
            </div>
            {hasText || editing || !allowMedia ? (
              <button
                type="button"
                onClick={() => void submit()}
                disabled={busy || (!hasText && editing?.type === 'text') || (!hasText && !editing)}
                aria-label={editing ? t('common.save') : t('chat.send')}
                className={clsx(
                  'grid size-12 shrink-0 place-items-center rounded-full bg-accent text-white transition-transform active:scale-95 disabled:opacity-50',
                  'shadow-[0_8px_20px_-8px_var(--accent)]',
                )}
              >
                {editing ? <Check size={22} /> : <Send size={20} className="translate-x-[1px]" />}
              </button>
            ) : (
              <button
                type="button"
                onClick={() => void recorder.start()}
                aria-label={t('chat.voice')}
                title={t('chat.voice')}
                className="grid size-12 shrink-0 place-items-center rounded-full border border-line bg-raised text-ink-2 shadow-1 transition hover:text-accent active:scale-95 md:shadow-2"
              >
                <Mic size={21} />
              </button>
            )}
          </>
        )}
      </div>
      <AttachDialog
        files={files}
        onChange={setFiles}
        onClose={() => setFiles([])}
        onSend={(f, caption, asFile) => {
          setFiles([]);
          void sendMessage(conv.id, { text: caption, files: f.map((file) => ({ file, asFile })), replyToId: replyTo?.id });
          onClearReply();
          onSent();
        }}
      />
    </div>
  );
});
