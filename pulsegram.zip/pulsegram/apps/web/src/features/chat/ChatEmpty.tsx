import { MessageSquarePlus } from 'lucide-react';
import { Button } from '../../components/ui/Button';
import { PulseLine } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { useUi } from '../../stores/ui';

/** Shown in the detail pane when no chat is selected. */
export function ChatEmpty() {
  const t = useT();
  const open = useUi((s) => s.open);
  return (
    <div className="chat-wallpaper relative flex h-full w-full flex-col items-center justify-center overflow-hidden px-8">
      <PulseLine className="absolute inset-x-0 top-1/2 h-40 w-full -translate-y-1/2 opacity-60" />
      <div className="relative flex max-w-sm flex-col items-center rounded-[24px] bg-raised/85 px-8 py-9 text-center shadow-2 backdrop-blur">
        <p className="text-[1.25rem] font-extrabold tracking-[-0.02em] text-ink">{t('chat.empty.title')}</p>
        <p className="mt-2 text-[0.92rem] leading-relaxed text-ink-3">{t('chat.empty.body')}</p>
        <Button className="mt-6" icon={<MessageSquarePlus size={18} />} onClick={() => open({ kind: 'new-message' })}>
          {t('chat.empty.cta')}
        </Button>
      </div>
    </div>
  );
}
