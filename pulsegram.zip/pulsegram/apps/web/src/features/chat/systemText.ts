import type { MessageDto, UserSummary } from '@pulsegram/shared';
import type { MessageKey, TFn } from '../../i18n';

/** Human-readable text for service messages (joins, renames, pins…). */
export function systemText(m: MessageDto, users: Record<string, UserSummary>, t: TFn, myId: string | null): string {
  const s = (m.system ?? {}) as { action?: string; actorId?: string; userId?: string; userIds?: string[]; title?: string; preview?: string };
  const name = (id?: string) => (!id ? '' : id === myId ? (t('chats.you').replace(':', '') as string) : (users[id]?.displayName ?? '…'));
  const key = `sys.${s.action}` as MessageKey;
  return t(key, {
    actor: name(s.actorId),
    user: name(s.userId),
    users: (s.userIds ?? []).map(name).join(', '),
    title: s.title ?? '',
    preview: (s.preview ?? '').slice(0, 40) || '…',
  });
}
