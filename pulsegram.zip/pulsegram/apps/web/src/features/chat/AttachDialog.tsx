import { File as FileIcon, X } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import { LIMITS } from '@pulsegram/shared';
import { Button } from '../../components/ui/Button';
import { Checkbox } from '../../components/ui/Field';
import { Modal } from '../../components/ui/Modal';
import { useT } from '../../i18n';
import { formatBytes } from '../../lib/format';
import { useAuth } from '../../stores/auth';

export function AttachDialog({
  files,
  onChange,
  onSend,
  onClose,
}: {
  files: File[];
  onChange: (f: File[]) => void;
  onSend: (files: File[], caption: string, asFile: boolean) => void;
  onClose: () => void;
}) {
  const t = useT();
  const max = useAuth((s) => s.config?.maxUploadBytes ?? 50 * 1024 * 1024);
  const [caption, setCaption] = useState('');
  const [asFile, setAsFile] = useState(false);
  const previews = useMemo(() => files.map((f) => (f.type.startsWith('image/') || f.type.startsWith('video/') ? URL.createObjectURL(f) : null)), [files]);
  useEffect(() => () => previews.forEach((p) => p && URL.revokeObjectURL(p)), [previews]);
  const hasMedia = files.some((f) => f.type.startsWith('image/') || f.type.startsWith('video/'));
  const tooBig = files.filter((f) => f.size > max);
  const tooMany = files.length > LIMITS.attachmentsPerMessage;

  return (
    <Modal
      open={files.length > 0}
      onClose={onClose}
      title={t('chat.sendFiles', { n: files.length })}
      width={480}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button onClick={() => onSend(files, caption, asFile)} disabled={tooBig.length > 0 || tooMany || files.length === 0}>
            {t('chat.send')}
          </Button>
        </>
      }
    >
      <div className="grid grid-cols-3 gap-2">
        {files.map((f, i) => (
          <div key={`${f.name}-${i}`} className="group relative overflow-hidden rounded-[12px] border border-line bg-sunken">
            {previews[i] && f.type.startsWith('image/') ? (
              <img src={previews[i]!} alt="" className="aspect-square w-full object-cover" />
            ) : previews[i] ? (
              <video src={previews[i]!} muted className="aspect-square w-full object-cover" />
            ) : (
              <div className="flex aspect-square flex-col items-center justify-center gap-1 p-2 text-center">
                <FileIcon size={26} className="text-accent" />
                <span className="line-clamp-2 text-[0.72rem] break-all text-ink-2">{f.name}</span>
              </div>
            )}
            <span className={`absolute bottom-1 left-1 rounded bg-black/55 px-1 text-[0.65rem] text-white ${f.size > max ? '!bg-danger' : ''}`}>{formatBytes(f.size)}</span>
            <button
              type="button"
              aria-label={t('common.remove')}
              className="absolute top-1 right-1 grid size-6 place-items-center rounded-full bg-black/55 text-white"
              onClick={() => onChange(files.filter((_, j) => j !== i))}
            >
              <X size={14} />
            </button>
          </div>
        ))}
      </div>
      {tooBig.length > 0 && <p className="mt-3 text-[0.85rem] text-danger">{t('error.payload_too_large')} (≤ {formatBytes(max)})</p>}
      {tooMany && <p className="mt-3 text-[0.85rem] text-danger">≤ {LIMITS.attachmentsPerMessage}</p>}
      {hasMedia && (
        <div className="mt-4">
          <Checkbox checked={asFile} onChange={setAsFile}>
            {t('chat.sendAsFile')}
          </Checkbox>
        </div>
      )}
      <input
        value={caption}
        onChange={(e) => setCaption(e.target.value)}
        maxLength={LIMITS.captionText}
        placeholder={t('chat.placeholderCaption')}
        className="mt-4 h-11 w-full rounded-[12px] border border-line bg-raised px-3.5 text-[0.95rem] outline-none focus:border-accent"
        onKeyDown={(e) => {
          if (e.key === 'Enter' && !tooBig.length && !tooMany) {
            e.preventDefault();
            onSend(files, caption, asFile);
          }
        }}
        data-autofocus
      />
    </Modal>
  );
}
