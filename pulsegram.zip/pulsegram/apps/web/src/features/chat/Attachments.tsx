import { clsx } from 'clsx';
import { Download, FileArchive, FileAudio, FileText, File as FileIcon, Pause, Play, X } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import type { AttachmentDto, MessageDto } from '@pulsegram/shared';
import { Spinner } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { formatBytes, formatDuration } from '../../lib/format';
import type { PendingUpload } from '../../stores/chat';
import { useUi } from '../../stores/ui';

function Progress({ value, onCancel }: { value: number; onCancel?: () => void }) {
  const r = 18;
  const c = 2 * Math.PI * r;
  return (
    <button
      type="button"
      onClick={onCancel}
      aria-label="Cancel upload"
      className="relative grid size-12 place-items-center rounded-full bg-black/45 text-white backdrop-blur-sm"
    >
      <svg viewBox="0 0 44 44" className="absolute inset-0 -rotate-90">
        <circle cx="22" cy="22" r={r} fill="none" stroke="currentColor" strokeOpacity=".3" strokeWidth="3" />
        <circle cx="22" cy="22" r={r} fill="none" stroke="currentColor" strokeWidth="3" strokeDasharray={c} strokeDashoffset={c * (1 - Math.max(0.03, value))} strokeLinecap="round" />
      </svg>
      <X size={18} />
    </button>
  );
}

function fileIcon(a: AttachmentDto) {
  if (/zip|rar|7z|tar|gzip|bzip|xz/.test(a.mime)) return FileArchive;
  if (a.mime.startsWith('audio/')) return FileAudio;
  if (/pdf|text|word|document|sheet|presentation|rtf|epub/.test(a.mime)) return FileText;
  return FileIcon;
}

export function FileCard({ a, out, upload, onCancel }: { a: AttachmentDto; out: boolean; upload?: PendingUpload; onCancel?: () => void }) {
  const Icon = fileIcon(a);
  const ext = a.name.includes('.') ? a.name.split('.').pop()!.slice(0, 4).toUpperCase() : '';
  return (
    <div className="flex min-w-0 items-center gap-3 py-1">
      {upload ? (
        <Progress value={upload.progress} onCancel={onCancel} />
      ) : (
        <a
          href={`${a.url}?download=1`}
          download={a.name}
          className={clsx('group relative grid size-12 shrink-0 place-items-center rounded-[12px]', out ? 'bg-white/20' : 'bg-soft text-accent')}
          aria-label={`Download ${a.name}`}
        >
          <Icon size={22} className="group-hover:hidden" />
          <Download size={22} className="hidden group-hover:block" />
          {ext && <span className="absolute -bottom-1 rounded bg-black/30 px-1 text-[0.55rem] font-bold text-white">{ext}</span>}
        </a>
      )}
      <div className="min-w-0">
        <p className="truncate text-[0.9rem] font-semibold">{a.name}</p>
        <p className={clsx('text-[0.78rem]', out ? 'text-white/75' : 'text-ink-3')}>
          {upload ? `${formatBytes(Math.round(a.size * upload.progress))} / ${formatBytes(a.size)}` : formatBytes(a.size)}
        </p>
      </div>
    </div>
  );
}

/** Voice message player with the server-computed waveform. */
export function VoicePlayer({ a, out }: { a: AttachmentDto; out: boolean }) {
  const audio = useRef<HTMLAudioElement>(null);
  const [playing, setPlaying] = useState(false);
  const [pos, setPos] = useState(0);
  const [dur, setDur] = useState((a.durationMs ?? 0) / 1000);
  const [rate, setRate] = useState(1);
  const bars = a.waveform && a.waveform.length ? a.waveform : Array.from({ length: 40 }, (_, i) => 0.3 + 0.5 * Math.abs(Math.sin(i * 1.7)));
  const progress = dur ? pos / dur : 0;
  useEffect(() => {
    const el = audio.current;
    if (el) el.playbackRate = rate;
  }, [rate]);
  return (
    <div className="flex items-center gap-3 py-1">
      <audio
        ref={audio}
        src={a.url}
        preload="metadata"
        onTimeUpdate={(e) => setPos(e.currentTarget.currentTime)}
        onLoadedMetadata={(e) => Number.isFinite(e.currentTarget.duration) && setDur(e.currentTarget.duration)}
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={() => {
          setPlaying(false);
          setPos(0);
        }}
      />
      <button
        type="button"
        aria-label={playing ? 'Pause' : 'Play'}
        onClick={() => (playing ? audio.current?.pause() : void audio.current?.play())}
        className={clsx('grid size-11 shrink-0 place-items-center rounded-full', out ? 'bg-white text-accent' : 'bg-accent text-white')}
      >
        {playing ? <Pause size={20} fill="currentColor" /> : <Play size={20} fill="currentColor" className="ml-0.5" />}
      </button>
      <div className="min-w-0 flex-1">
        <div
          className="flex h-7 cursor-pointer items-center gap-[2px]"
          role="slider"
          aria-label="Seek"
          aria-valuemin={0}
          aria-valuemax={Math.round(dur)}
          aria-valuenow={Math.round(pos)}
          tabIndex={0}
          onKeyDown={(e) => {
            if (!audio.current) return;
            if (e.key === 'ArrowRight') audio.current.currentTime = Math.min(dur, pos + 3);
            if (e.key === 'ArrowLeft') audio.current.currentTime = Math.max(0, pos - 3);
          }}
          onClick={(e) => {
            const r = e.currentTarget.getBoundingClientRect();
            if (audio.current && dur) audio.current.currentTime = ((e.clientX - r.left) / r.width) * dur;
          }}
        >
          {bars.map((b, i) => (
            <span
              key={i}
              className={clsx('w-[3px] min-w-[2px] flex-1 rounded-full', i / bars.length <= progress ? (out ? 'bg-white' : 'bg-accent') : out ? 'bg-white/40' : 'bg-accent/30')}
              style={{ height: `${Math.max(12, b * 100)}%` }}
            />
          ))}
        </div>
        <div className={clsx('mt-0.5 flex items-center gap-2 text-[0.75rem] tabular-nums', out ? 'text-white/80' : 'text-ink-3')}>
          {formatDuration((playing || pos ? pos : dur) * 1000)}
          <button type="button" onClick={() => setRate((r) => (r === 1 ? 1.5 : r === 1.5 ? 2 : 1))} className="rounded px-1 font-semibold hover:bg-black/10">
            {rate}×
          </button>
        </div>
      </div>
    </div>
  );
}

export function AudioPlayer({ a, out }: { a: AttachmentDto; out: boolean }) {
  return (
    <div className="flex min-w-0 flex-col gap-1.5 py-1">
      <p className="truncate text-[0.88rem] font-semibold">{a.name}</p>
      <audio controls preload="metadata" src={a.url} className={clsx('h-9 w-64 max-w-full', out && 'invert-[0.05]')} />
      <p className={clsx('text-[0.75rem]', out ? 'text-white/75' : 'text-ink-3')}>
        {formatDuration(a.durationMs)} · {formatBytes(a.size)}
      </p>
    </div>
  );
}

/** Image/video album (1–10 items) in a justified grid. */
export function MediaGrid({ message, uploads, onCancel }: { message: MessageDto; uploads?: PendingUpload[]; onCancel?: () => void }) {
  const open = useUi((s) => s.open);
  const t = useT();
  const media = message.attachments.filter((a) => a.kind === 'image' || a.kind === 'video');
  if (media.length === 0) return null;
  const single = media.length === 1;
  const cols = media.length === 1 ? 1 : media.length === 2 || media.length === 4 ? 2 : 3;
  return (
    <div className={clsx('grid gap-0.5 overflow-hidden', single ? '' : 'w-[min(420px,70vw)]')} style={{ gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))` }}>
      {media.map((a, i) => {
        const up = uploads?.[message.attachments.indexOf(a)];
        const ratio = a.width && a.height ? a.width / a.height : 4 / 3;
        const style = single ? { aspectRatio: String(Math.min(2, Math.max(0.6, ratio))), width: `min(${Math.round(Math.min(420, Math.max(220, 320 * ratio)))}px, 70vw)` } : { aspectRatio: '1' };
        return (
          <button
            key={a.id}
            type="button"
            className="relative block overflow-hidden bg-black/10"
            style={style}
            onClick={() => !up && open({ kind: 'media', items: [message], index: i })}
            aria-label={a.kind === 'video' ? t('chat.video') : t('chat.photo')}
          >
            {a.kind === 'image' ? (
              <img src={a.thumbUrl ?? a.url} alt="" loading="lazy" decoding="async" className="size-full object-cover" />
            ) : a.thumbUrl ? (
              <img src={a.thumbUrl} alt="" loading="lazy" className="size-full object-cover" />
            ) : up?.previewUrl ? (
              <video src={up.previewUrl} muted className="size-full object-cover" />
            ) : (
              <span className="grid size-full place-items-center bg-ink/80" />
            )}
            {a.kind === 'video' && !up && (
              <>
                <span className="absolute inset-0 grid place-items-center">
                  <span className="grid size-12 place-items-center rounded-full bg-black/50 text-white backdrop-blur-sm">
                    <Play size={22} fill="currentColor" className="ml-0.5" />
                  </span>
                </span>
                {a.durationMs !== null && <span className="absolute top-1.5 left-1.5 rounded-md bg-black/55 px-1.5 py-0.5 text-[0.72rem] text-white">{formatDuration(a.durationMs)}</span>}
              </>
            )}
            {up && (
              <span className="absolute inset-0 grid place-items-center bg-black/20">
                {up.progress >= 1 ? <Spinner className="text-white" size={28} /> : <Progress value={up.progress} onCancel={onCancel} />}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}
