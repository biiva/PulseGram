import { Fragment, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { tokenizeMessage } from '@pulsegram/shared';

/**
 * Renders message text from tokens into React elements — never via innerHTML — so user content
 * cannot inject markup. Only http(s) links are clickable and they open with noopener/noreferrer.
 */
export function RichText({ text, highlight }: { text: string; highlight?: string }) {
  const nav = useNavigate();
  const tokens = useMemo(() => tokenizeMessage(text), [text]);
  const mark = (s: string) => {
    if (!highlight) return s;
    const parts = s.split(new RegExp(`(${highlight.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'ig'));
    return parts.map((p, i) => (p.toLowerCase() === highlight.toLowerCase() ? <mark key={i} className="rounded bg-accent-2/40 text-inherit">{p}</mark> : <Fragment key={i}>{p}</Fragment>));
  };
  return (
    <>
      {tokens.map((tok, i) => {
        switch (tok.kind) {
          case 'link':
            return (
              <a key={i} href={tok.href} target="_blank" rel="noopener noreferrer nofollow ugc" className="break-all">
                {tok.value}
              </a>
            );
          case 'mention':
            return (
              <button key={i} type="button" className="font-semibold hover:underline" onClick={() => nav(`/u/${tok.username}`)}>
                {tok.value}
              </button>
            );
          case 'code':
            return (
              <code key={i} className="rounded px-1 py-0.5">
                {tok.value}
              </code>
            );
          case 'pre':
            return (
              <pre key={i} className="my-1 overflow-x-auto rounded-lg px-3 py-2 whitespace-pre" data-lang={tok.lang ?? undefined}>
                {tok.value}
              </pre>
            );
          case 'bold':
            return <strong key={i}>{mark(tok.value)}</strong>;
          case 'italic':
            return <em key={i}>{mark(tok.value)}</em>;
          default:
            return <Fragment key={i}>{mark(tok.value)}</Fragment>;
        }
      })}
    </>
  );
}

/** True if the message is only 1–3 emoji (rendered large, without a bubble). */
export function isEmojiOnly(text: string): boolean {
  const t = text.trim();
  if (!t || t.length > 24) return false;
  const seg = typeof Intl !== 'undefined' && 'Segmenter' in Intl ? [...new Intl.Segmenter().segment(t)].map((s) => s.segment).filter((s) => s.trim()) : [...t];
  return seg.length <= 3 && seg.every((s) => /\p{Extended_Pictographic}/u.test(s));
}
