import { clsx } from 'clsx';
import { Bookmark, Copy, CornerUpRight, Eye, Pencil, Pin, PinOff, Reply, ShieldAlert, SquareCheck, Trash2, Upload } from 'lucide-react';
import { lazy, Suspense, useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { can, EDIT_WINDOW_MS, QUICK_REACTIONS, type ConversationDto, type MessageDto, type UserSummary } from '@pulsegram/shared';
import { Button } from '../../components/ui/Button';
import { openMenu, useMenu, type MenuItem } from '../../components/ui/Menu';
import { confirmDialog } from '../../components/ui/Modal';
import { EmptyState, Spinner } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { deleteMessages, ensureConversation, forwardMessages, loadAround, loadLatest, savedConversationId, setPinned, toggleReaction } from '../../lib/chatActions';
import { useAuth } from '../../stores/auth';
import { useChat, type ClientMessage } from '../../stores/chat';
import { toast, useUi } from '../../stores/ui';
import { ChatHeader } from './ChatHeader';
import { ChatSearchBar, PinnedBar, SelectionBar } from './ChatPanels';
import { Composer, type ComposerHandle } from './Composer';
import { MessageList } from './MessageList';

const InfoPanel = lazy(() => import('../info/InfoPanel').then((m) => ({ default: m.InfoPanel })));

function FooterBar({ conv }: { conv: ConversationDto }) {
  const t = useT();
  const [busy, setBusy] = useState(false);
  const peerBlocked = useChat((s) => (conv.peer ? s.users[conv.peer.id] : undefined));
  if (!conv.me) {
    // Public chat preview.
    return (
      <div className="pb-safe flex shrink-0 justify-center border-t border-line bg-bg p-3">
        <Button
          size="lg"
          className="w-full max-w-sm"
          loading={busy}
          onClick={async () => {
            setBusy(true);
            try {
              const c = await http.post<ConversationDto>(`/api/conversations/${conv.id}/join`);
              useChat.getState().upsertConversation(c);
              await loadLatest(conv.id);
            } catch (err) {
              toast({ text: errorText(t, err), tone: 'danger' });
            } finally {
              setBusy(false);
            }
          }}
        >
          {conv.type === 'channel' ? t('chat.joinChannel') : t('chat.joinGroup')}
        </Button>
      </div>
    );
  }
  void peerBlocked;
  return (
    <div className="pb-safe flex shrink-0 items-center justify-center border-t border-line bg-bg p-4 text-[0.9rem] text-ink-3">
      {conv.type === 'channel' ? t('chat.readOnly') : t('error.cannot_send')}
    </div>
  );
}

export function ChatView({ conversationId }: { conversationId: string }) {
  const t = useT();
  const nav = useNavigate();
  const [params, setParams] = useSearchParams();
  const conv = useChat((s) => s.conversations[conversationId]);
  const history = useChat((s) => s.histories[conversationId]);
  const myId = useAuth((s) => s.me?.id);
  const infoOpen = useUi((s) => s.infoOpen);
  const setInfoOpen = useUi((s) => s.setInfoOpen);
  const open = useUi((s) => s.open);
  const [preview, setPreview] = useState<ConversationDto | null | undefined>(undefined);
  const [replyTo, setReplyTo] = useState<MessageDto | null>(null);
  const [editing, setEditing] = useState<MessageDto | null>(null);
  const [selectMode, setSelectMode] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [searchOpen, setSearchOpen] = useState(false);
  const [term, setTerm] = useState('');
  const [flashId, setFlashId] = useState<string | null>(null);
  const [bottomSignal, setBottomSignal] = useState(0);
  const [dragging, setDragging] = useState(false);
  const composer = useRef<ComposerHandle>(null);
  const view = conv ?? preview ?? null;

  useEffect(() => {
    useChat.getState().setActive(conversationId);
    return () => useChat.getState().setActive(null);
  }, [conversationId]);

  // Non-members can preview public groups/channels.
  useEffect(() => {
    if (conv) return;
    let alive = true;
    void ensureConversation(conversationId).then((c) => alive && setPreview(c));
    return () => {
      alive = false;
    };
  }, [conv, conversationId]);

  const jumpTo = useCallback(
    async (m: { id?: string; seq: number }) => {
      try {
        await loadAround(conversationId, m.seq);
        requestAnimationFrame(() => {
          const el = document.querySelector<HTMLElement>(`[data-seq="${m.seq}"]`);
          el?.scrollIntoView({ block: 'center', behavior: 'smooth' });
          const id = el?.dataset.mid ?? m.id ?? null;
          setFlashId(id);
          setTimeout(() => setFlashId(null), 1500);
        });
      } catch (err) {
        toast({ text: errorText(t, err), tone: 'danger' });
      }
    },
    [conversationId, t],
  );

  // Deep link to a message (?msg=seq) from search results or notifications.
  const msgParam = params.get('msg');
  useEffect(() => {
    if (!msgParam || !view) return;
    void jumpTo({ seq: Number(msgParam) });
    params.delete('msg');
    setParams(params, { replace: true });
  }, [msgParam, view, jumpTo, params, setParams]);

  const perm = conv?.me ? { type: conv.type, role: conv.me.role, settings: conv.settings } : null;
  const canSend = perm ? can.sendMessage(perm) : false;

  const onReply = useCallback((m: ClientMessage) => {
    setEditing(null);
    setReplyTo(m);
  }, []);
  const onToggleSelect = useCallback((m: ClientMessage) => {
    setSelected((s) => {
      const n = new Set(s);
      if (n.has(m.id)) n.delete(m.id);
      else n.add(m.id);
      return n;
    });
  }, []);
  const onJump = useCallback((seq: number) => void jumpTo({ seq }), [jumpTo]);
  const onOpenUser = useCallback((id: string) => open({ kind: 'user', userId: id }), [open]);

  const askDelete = useCallback(
    async (ms: MessageDto[]) => {
      if (!conv?.me) return;
      const pc = { type: conv.type, role: conv.me.role, settings: conv.settings };
      const allForEveryone = ms.every((m) => conv.type === 'saved' || (m.senderId === myId && conv.type !== 'channel') || can.deleteOthers(pc));
      const onlyEveryone = conv.type === 'channel' || conv.type === 'saved';
      const r = await confirmDialog({
        title: t('chat.deleteTitle', { n: ms.length }),
        danger: true,
        confirmLabel: allForEveryone && !onlyEveryone ? t('chat.deleteForAll') : t('common.delete'),
        alt: allForEveryone && !onlyEveryone ? t('chat.deleteForMe') : undefined,
      });
      if (!r.ok) return;
      if (onlyEveryone && !allForEveryone) return toast({ text: t('common.error'), tone: 'danger' });
      const forEveryone = onlyEveryone ? true : allForEveryone && !r.alt;
      try {
        await deleteMessages(conv.id, ms.map((m) => m.id), forEveryone);
        setSelectMode(false);
        setSelected(new Set());
      } catch (err) {
        toast({ text: errorText(t, err), tone: 'danger' });
      }
    },
    [conv, myId, t],
  );

  const onMenu = useCallback(
    (e: React.MouseEvent | { clientX: number; clientY: number }, m: ClientMessage) => {
      if (!conv) return;
      const pc = conv.me ? { type: conv.type, role: conv.me.role, settings: conv.settings } : null;
      const own = m.senderId === myId;
      const editable = own && (m.type === 'text' || m.type === 'media') && (conv.type === 'channel' || conv.type === 'saved' || Date.now() - new Date(m.createdAt).getTime() < EDIT_WINDOW_MS);
      const pinned = conv.pinnedMessageIds.includes(m.id);
      const run = (p: Promise<unknown>) => p.catch((err: unknown) => toast({ text: errorText(t, err), tone: 'danger' }));
      const items: MenuItem[] = [];
      if (pc && can.sendMessage(pc)) items.push({ label: t('chat.reply'), icon: <Reply size={17} />, onSelect: () => onReply(m) });
      if (editable) items.push({ label: t('common.edit'), icon: <Pencil size={17} />, onSelect: () => { setReplyTo(null); setEditing(m); } });
      if (m.text) items.push({ label: t('chat.copyText'), icon: <Copy size={17} />, onSelect: () => void navigator.clipboard.writeText(m.text).then(() => toast(t('common.copied'))) });
      if (pc && can.pin(pc)) items.push({ label: pinned ? t('chat.unpin') : t('chat.pin'), icon: pinned ? <PinOff size={17} /> : <Pin size={17} />, onSelect: () => run(setPinned(conv.id, m.id, !pinned)) });
      items.push({ label: t('chat.forward'), icon: <CornerUpRight size={17} />, onSelect: () => open({ kind: 'forward', conversationId: conv.id, messageIds: [m.id] }) });
      if (conv.type !== 'saved')
        items.push({
          label: t('chat.saveToSaved'),
          icon: <Bookmark size={17} />,
          onSelect: () => {
            const sid = savedConversationId();
            if (sid) run(forwardMessages([m.id], [sid], false).then(() => toast(t('common.saved'))));
          },
        });
      if (conv.me) items.push({ label: t('chat.select'), icon: <SquareCheck size={17} />, onSelect: () => { setSelectMode(true); setSelected(new Set([m.id])); } });
      if (own && conv.type === 'group')
        items.push({
          label: t('chat.readBy'),
          icon: <Eye size={17} />,
          onSelect: () =>
            run(
              http.get<{ userIds: string[] }>(`/api/messages/${m.id}/read-by`).then(async (r) => {
                const users = r.userIds.length ? await http.get<UserSummary[]>(`/api/users?ids=${r.userIds.join(',')}`) : [];
                await confirmDialog({ title: t('chat.readBy'), body: users.length ? users.map((u) => u.displayName).join(', ') : '—', confirmLabel: t('common.close') });
              }),
            ),
        });
      if (!own && m.senderId) items.push({ label: t('chat.report'), icon: <ShieldAlert size={17} />, onSelect: () => open({ kind: 'report', targetType: 'message', targetId: m.id }) });
      if (conv.me) items.push({ divider: true, label: '' }, { label: t('common.delete'), icon: <Trash2 size={17} />, danger: true, onSelect: () => void askDelete([m]) });

      const header =
        pc && can.react(pc) ? (
          <div className="flex gap-0.5">
            {QUICK_REACTIONS.map((emoji) => (
              <button
                key={emoji}
                type="button"
                className={clsx('grid size-9 place-items-center rounded-full text-[1.25rem] transition hover:scale-110 hover:bg-sunken', m.reactions.find((r) => r.emoji === emoji)?.mine && 'bg-soft')}
                onClick={() => {
                  (document.activeElement as HTMLElement | null)?.blur();
                  useMenu.getState().close();
                  run(toggleReaction(conv.id, m.id, emoji));
                }}
              >
                {emoji}
              </button>
            ))}
          </div>
        ) : undefined;
      openMenu(e as React.MouseEvent, items, header);
    },
    [conv, myId, t, open, onReply, askDelete],
  );

  const onEditLast = useCallback(() => {
    const items = useChat.getState().histories[conversationId]?.items ?? [];
    const last = [...items].reverse().find((m) => m.senderId === myId && !m.local && (m.type === 'text' || m.type === 'media'));
    if (last) setEditing(last);
  }, [conversationId, myId]);

  if (view === undefined || (view === null && preview === undefined)) {
    return (
      <div className="grid h-full w-full place-items-center text-ink-3">
        <Spinner />
      </div>
    );
  }
  if (!view) {
    return (
      <div className="grid h-full w-full place-items-center">
        <EmptyState title={t('pages.notFound')} action={<Button onClick={() => nav('/chat')}>{t('pages.goHome')}</Button>} />
      </div>
    );
  }

  const selectedMessages = (history?.items ?? []).filter((m) => selected.has(m.id));

  return (
    <div className="flex h-full w-full min-w-0">
      <div
        className="relative flex h-full min-w-0 flex-1 flex-col"
        onDragEnter={(e) => {
          if (canSend && e.dataTransfer.types.includes('Files')) setDragging(true);
        }}
        onDragOver={(e) => {
          if (dragging) e.preventDefault();
        }}
        onDragLeave={(e) => {
          if (e.currentTarget === e.target) setDragging(false);
        }}
        onDrop={(e) => {
          e.preventDefault();
          setDragging(false);
          const files = [...e.dataTransfer.files];
          if (files.length) composer.current?.addFiles(files);
        }}
      >
        <ChatHeader
          conv={view}
          onSearch={() => setSearchOpen(true)}
          onSelect={() => setSelectMode(true)}
          onClear={async () => {
            const r = await confirmDialog({ title: t('chat.clearHistory'), danger: true, confirmLabel: t('common.delete') });
            if (!r.ok) return;
            await http.post(`/api/conversations/${view.id}/clear`);
            await loadLatest(view.id);
          }}
        />
        {searchOpen && (
          <ChatSearchBar
            conv={view}
            onClose={() => {
              setSearchOpen(false);
              setTerm('');
            }}
            onJump={(m) => void jumpTo(m)}
            onTerm={setTerm}
          />
        )}
        <PinnedBar conv={view} onJump={(m) => void jumpTo(m)} />
        <MessageList
          conv={view}
          history={history}
          highlight={term || undefined}
          selected={selected}
          selectMode={selectMode}
          flashId={flashId}
          onMenu={onMenu}
          onReply={onReply}
          onToggleSelect={onToggleSelect}
          onJump={onJump}
          onOpenUser={onOpenUser}
          bottomSignal={bottomSignal}
        />
        {selectMode ? (
          <SelectionBar
            count={selected.size}
            onCancel={() => {
              setSelectMode(false);
              setSelected(new Set());
            }}
            onCopy={() => {
              const text = selectedMessages.map((m) => m.text).filter(Boolean).join('\n\n');
              void navigator.clipboard.writeText(text).then(() => toast(t('common.copied')));
            }}
            onForward={() => open({ kind: 'forward', conversationId: view.id, messageIds: selectedMessages.map((m) => m.id) })}
            onDelete={() => void askDelete(selectedMessages)}
          />
        ) : canSend && conv ? (
          <Composer
            key={conv.id}
            ref={composer}
            conv={conv}
            replyTo={replyTo}
            editing={editing}
            onClearReply={() => setReplyTo(null)}
            onClearEdit={() => setEditing(null)}
            onEditLast={onEditLast}
            onSent={() => setBottomSignal((n) => n + 1)}
          />
        ) : (
          <FooterBar conv={view} />
        )}
        {dragging && (
          <div className="pointer-events-none absolute inset-3 z-20 grid place-items-center rounded-[24px] border-2 border-dashed border-accent bg-accent/10 backdrop-blur-sm">
            <span className="flex flex-col items-center gap-2 text-[1.05rem] font-bold text-accent">
              <Upload size={32} />
              {t('chat.dropFiles')}
            </span>
          </div>
        )}
      </div>
      {infoOpen && (
        <Suspense fallback={null}>
          <InfoPanel conv={view} onClose={() => setInfoOpen(false)} onJump={(m) => void jumpTo(m)} />
        </Suspense>
      )}
    </div>
  );
}
