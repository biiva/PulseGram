import { Send, Trash2 } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { IconButton } from '../../components/ui/Button';
import { useT } from '../../i18n';
import { formatDuration } from '../../lib/format';
import { realtime } from '../../lib/realtime';

const MAX_MS = 10 * 60 * 1000;

function pickMime(): string | undefined {
  const types = ['audio/webm;codecs=opus', 'audio/ogg;codecs=opus', 'audio/mp4', 'audio/webm'];
  return types.find((t) => typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(t));
}

export type RecorderError = 'denied' | 'unsupported';

/**
 * Records a voice message with MediaRecorder. The browser shows its own microphone
 * permission prompt the first time; a denial is reported back so the UI can explain it.
 */
export function useVoiceRecorder(conversationId: string, onDone: (blob: Blob, durationMs: number) => void, onError: (e: RecorderError) => void) {
  const [recording, setRecording] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [level, setLevel] = useState(0);
  const rec = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);
  const started = useRef(0);
  const cancelled = useRef(false);
  const stream = useRef<MediaStream | null>(null);
  const raf = useRef(0);
  const tick = useRef<ReturnType<typeof setInterval> | null>(null);

  const cleanup = useCallback(() => {
    if (tick.current) clearInterval(tick.current);
    cancelAnimationFrame(raf.current);
    stream.current?.getTracks().forEach((t) => t.stop());
    stream.current = null;
    setRecording(false);
    setElapsed(0);
    setLevel(0);
    realtime.send({ t: 'typing', d: { conversationId, kind: null } });
  }, [conversationId]);

  const start = useCallback(async () => {
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') return onError('unsupported');
    try {
      const s = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      stream.current = s;
      const mime = pickMime();
      const r = new MediaRecorder(s, mime ? { mimeType: mime, audioBitsPerSecond: 48_000 } : undefined);
      chunks.current = [];
      cancelled.current = false;
      r.ondataavailable = (e) => e.data.size && chunks.current.push(e.data);
      r.onstop = () => {
        const dur = Date.now() - started.current;
        const blob = new Blob(chunks.current, { type: r.mimeType || 'audio/webm' });
        cleanup();
        if (!cancelled.current && dur > 600 && blob.size > 0) onDone(blob, dur);
      };
      rec.current = r;
      r.start(250);
      started.current = Date.now();
      setRecording(true);
      tick.current = setInterval(() => {
        const e = Date.now() - started.current;
        setElapsed(e);
        if (e >= MAX_MS) r.stop();
        realtime.send({ t: 'typing', d: { conversationId, kind: 'voice' } });
      }, 250);
      // Live input level meter.
      const ac = new AudioContext();
      const an = ac.createAnalyser();
      an.fftSize = 256;
      ac.createMediaStreamSource(s).connect(an);
      const data = new Uint8Array(an.frequencyBinCount);
      const loop = () => {
        an.getByteTimeDomainData(data);
        let peak = 0;
        for (const v of data) peak = Math.max(peak, Math.abs(v - 128));
        setLevel(peak / 128);
        raf.current = requestAnimationFrame(loop);
      };
      loop();
    } catch (err) {
      cleanup();
      onError((err as DOMException).name === 'NotAllowedError' || (err as DOMException).name === 'SecurityError' ? 'denied' : 'unsupported');
    }
  }, [cleanup, conversationId, onDone, onError]);

  const stop = useCallback(() => rec.current?.state === 'recording' && rec.current.stop(), []);
  const cancel = useCallback(() => {
    cancelled.current = true;
    stop();
  }, [stop]);

  useEffect(() => () => {
    cancelled.current = true;
    if (rec.current?.state === 'recording') rec.current.stop();
    cleanup();
  }, [cleanup]);

  return { recording, elapsed, level, start, stop, cancel };
}

export function RecordingBar({ elapsed, level, onCancel, onSend }: { elapsed: number; level: number; onCancel: () => void; onSend: () => void }) {
  const t = useT();
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onCancel();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onCancel]);
  return (
    <div className="flex flex-1 items-center gap-3 px-1">
      <IconButton label={t('common.cancel')} tone="danger" onClick={onCancel}>
        <Trash2 size={20} />
      </IconButton>
      <span className="relative grid size-3 place-items-center">
        <span className="absolute size-3 rounded-full bg-danger" style={{ transform: `scale(${1 + level * 1.4})`, opacity: 0.35 }} />
        <span className="size-2.5 rounded-full bg-danger" />
      </span>
      <span className="font-mono text-[0.95rem] tabular-nums text-ink">{formatDuration(elapsed)}</span>
      <span className="min-w-0 flex-1 truncate text-[0.85rem] text-ink-3">{t('chat.voiceRelease')}</span>
      <button type="button" onClick={onSend} aria-label={t('chat.send')} className="grid size-11 shrink-0 place-items-center rounded-full bg-accent text-white shadow-[0_6px_16px_-6px_var(--accent)]">
        <Send size={19} />
      </button>
    </div>
  );
}
