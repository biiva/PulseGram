import { clsx } from 'clsx';
import { ChevronDown } from 'lucide-react';
import { Fragment, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { can, type ConversationDto } from '@pulsegram/shared';
import { Badge, EmptyState, Spinner } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { http } from '../../lib/api';
import { loadLatest, loadNewer, loadOlder, markRead } from '../../lib/chatActions';
import { formatDayLabel, isSameDay } from '../../lib/format';
import { useChat, type ClientMessage, type History } from '../../stores/chat';
import { usePrefs } from '../../stores/prefs';
import { MessageBubble } from './MessageBubble';
import { systemText } from './systemText';

const GROUP_GAP_MS = 5 * 60 * 1000;

export interface MessageListProps {
  conv: ConversationDto;
  history: History | undefined;
  highlight?: string;
  selected: Set<string>;
  selectMode: boolean;
  flashId: string | null;
  onMenu: (e: React.MouseEvent | { clientX: number; clientY: number }, m: ClientMessage) => void;
  onReply: (m: ClientMessage) => void;
  onToggleSelect: (m: ClientMessage) => void;
  onJump: (seq: number) => void;
  onOpenUser: (id: string) => void;
  /** Incremented by the parent to force "scroll to bottom" (e.g. after sending). */
  bottomSignal: number;
}

export function MessageList(p: MessageListProps) {
  const { conv, history } = p;
  const t = useT();
  const fmt = usePrefs((s) => s.appearance);
  const myId = useChat((s) => s.myId);
  const users = useChat((s) => s.users);
  const scroller = useRef<HTMLDivElement>(null);
  const topSentinel = useRef<HTMLDivElement>(null);
  const bottomSentinel = useRef<HTMLDivElement>(null);
  const [atBottom, setAtBottom] = useState(true);
  const atBottomRef = useRef(true);
  const anchor = useRef<{ height: number; top: number } | null>(null);
  const items = useMemo(() => history?.items ?? [], [history]);
  const canReact = conv.me ? can.react({ type: conv.type, role: conv.me.role, settings: conv.settings }) : false;

  // "New messages" divider position is fixed when the chat opens.
  const unreadFrom = useRef<number | null>(null);
  if (unreadFrom.current === null && history?.loaded && conv.me) {
    const firstUnread = items.find((m) => m.seq > conv.me!.lastReadSeq && m.senderId !== myId && m.type !== 'system');
    unreadFrom.current = firstUnread?.seq ?? Number.MAX_SAFE_INTEGER;
  }

  // Initial load.
  useEffect(() => {
    if (!history?.loaded) void loadLatest(conv.id);
  }, [conv.id, history?.loaded]);

  // Initial scroll position: first unread message, otherwise the bottom.
  const didInitialScroll = useRef(false);
  useLayoutEffect(() => {
    const el = scroller.current;
    if (!el || !history?.loaded || didInitialScroll.current) return;
    didInitialScroll.current = true;
    const target = unreadFrom.current && unreadFrom.current < Number.MAX_SAFE_INTEGER ? el.querySelector<HTMLElement>(`[data-seq="${unreadFrom.current}"]`) : null;
    if (target && !p.flashId) el.scrollTop = target.offsetTop - 80;
    else if (!p.flashId) el.scrollTop = el.scrollHeight;
  }, [history?.loaded, p.flashId]);

  // Keep the view pinned to the bottom when new messages arrive and we were already there.
  const lastId = items[items.length - 1]?.id;
  useLayoutEffect(() => {
    const el = scroller.current;
    if (el && atBottomRef.current && !history?.hasMoreAfter) el.scrollTop = el.scrollHeight;
  }, [lastId, history?.hasMoreAfter]);

  useLayoutEffect(() => {
    const el = scroller.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  }, [p.bottomSignal]);

  // Restore scroll position after prepending older messages.
  const firstId = items[0]?.id;
  useLayoutEffect(() => {
    const el = scroller.current;
    if (el && anchor.current) {
      el.scrollTop = el.scrollHeight - anchor.current.height + anchor.current.top;
      anchor.current = null;
    }
  }, [firstId]);

  // Infinite scroll in both directions.
  useEffect(() => {
    const root = scroller.current;
    if (!root) return;
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          if (!e.isIntersecting) continue;
          if (e.target === topSentinel.current && history?.hasMoreBefore) {
            anchor.current = { height: root.scrollHeight, top: root.scrollTop };
            void loadOlder(conv.id);
          }
          if (e.target === bottomSentinel.current && history?.hasMoreAfter) void loadNewer(conv.id);
        }
      },
      { root, rootMargin: '600px 0px' },
    );
    if (topSentinel.current) io.observe(topSentinel.current);
    if (bottomSentinel.current) io.observe(bottomSentinel.current);
    return () => io.disconnect();
  }, [conv.id, history?.hasMoreBefore, history?.hasMoreAfter]);

  // Read receipts: mark up to the last fully visible message while the tab is visible.
  const updateRead = useCallback(() => {
    const el = scroller.current;
    if (!el || !conv.me || document.visibilityState !== 'visible') return;
    const bottom = el.getBoundingClientRect().bottom;
    const nodes = el.querySelectorAll<HTMLElement>('[data-seq]');
    for (let i = nodes.length - 1; i >= 0; i--) {
      const n = nodes[i]!;
      const r = n.getBoundingClientRect();
      if (r.top + Math.min(r.height, 60) <= bottom + 4) {
        const seq = Number(n.dataset.seq);
        if (seq) markRead(conv.id, seq);
        break;
      }
    }
  }, [conv.id, conv.me]);

  useEffect(() => {
    updateRead();
    const onVis = () => updateRead();
    document.addEventListener('visibilitychange', onVis);
    window.addEventListener('focus', onVis);
    return () => {
      document.removeEventListener('visibilitychange', onVis);
      window.removeEventListener('focus', onVis);
    };
  }, [lastId, updateRead]);

  // Channel post views: one view per viewer per post, reported in batches.
  const seen = useRef(new Set<string>());
  useEffect(() => {
    if (conv.type !== 'channel') return;
    const root = scroller.current;
    if (!root) return;
    const pending = new Set<string>();
    const flush = () => {
      if (!pending.size) return;
      const ids = [...pending].slice(0, 100);
      ids.forEach((id) => pending.delete(id));
      void http
        .post<{ views: Record<string, number> }>(`/api/conversations/${conv.id}/views`, { messageIds: ids })
        .then((r) => useChat.getState().setViews(conv.id, r.views))
        .catch(() => {});
    };
    const io = new IntersectionObserver(
      (entries) => {
        for (const e of entries) {
          const id = (e.target as HTMLElement).dataset.mid;
          if (e.isIntersecting && id && !id.startsWith('local-') && !seen.current.has(id)) {
            seen.current.add(id);
            pending.add(id);
          }
        }
      },
      { root, threshold: 0.6 },
    );
    root.querySelectorAll('[data-mid]').forEach((n) => io.observe(n));
    const timer = setInterval(flush, 2000);
    return () => {
      io.disconnect();
      clearInterval(timer);
      flush();
    };
  }, [conv.id, conv.type, items.length]);

  const onScroll = () => {
    const el = scroller.current;
    if (!el) return;
    const near = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
    atBottomRef.current = near;
    if (near !== atBottom) setAtBottom(near);
    updateRead();
  };

  const jumpToLatest = async () => {
    if (history?.hasMoreAfter) {
      atBottomRef.current = true;
      await loadLatest(conv.id);
    }
    const el = scroller.current;
    el?.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  };

  if (!history?.loaded) {
    return (
      <div className="chat-wallpaper grid flex-1 place-items-center text-ink-3">
        <Spinner />
      </div>
    );
  }

  const isChannel = conv.type === 'channel';
  return (
    <div className="chat-wallpaper relative flex min-h-0 flex-1 flex-col">
      <div ref={scroller} onScroll={onScroll} className="scroll-y relative flex min-h-0 flex-1 flex-col pt-3 pb-2" role="log" aria-live="polite" aria-relevant="additions">
        <div ref={topSentinel} className="h-px shrink-0" />
        {history.hasMoreBefore && (
          <div className="flex justify-center py-3 text-ink-3">
            <Spinner size={18} />
          </div>
        )}
        <div className="mt-auto" />
        {items.length === 0 && (
          <EmptyState
            className="my-auto"
            title={isChannel ? t('chat.channelEmpty') : conv.type === 'saved' ? t('chats.saved') : t('chat.noMessages')}
            body={conv.type === 'saved' ? t('chats.savedHint') : isChannel ? undefined : t('chat.noMessagesHint')}
          />
        )}
        <div className="mx-auto w-full max-w-3xl">
          {items.map((m, i) => {
            const prev = items[i - 1];
            const next = items[i + 1];
            const d = new Date(m.createdAt);
            const newDay = !prev || !isSameDay(new Date(prev.createdAt), d);
            const sameRunPrev = prev && !newDay && prev.senderId === m.senderId && prev.type !== 'system' && m.type !== 'system' && d.getTime() - new Date(prev.createdAt).getTime() < GROUP_GAP_MS;
            const sameRunNext =
              next && isSameDay(new Date(next.createdAt), d) && next.senderId === m.senderId && next.type !== 'system' && m.type !== 'system' && new Date(next.createdAt).getTime() - d.getTime() < GROUP_GAP_MS;
            const showUnread = unreadFrom.current === m.seq && m.seq > 0;
            return (
              <Fragment key={m.clientId && m.local ? `c-${m.clientId}` : m.id}>
                {newDay && (
                  <div className="sticky top-1 z-[5] my-2 flex justify-center">
                    <span className="rounded-full bg-raised/85 px-3 py-1 text-[0.78rem] font-semibold text-ink-2 shadow-1 backdrop-blur">{formatDayLabel(m.createdAt, fmt, t)}</span>
                  </div>
                )}
                {showUnread && (
                  <div className="my-3 flex items-center gap-3 px-6" role="separator">
                    <svg viewBox="0 0 120 20" className="h-4 flex-1" preserveAspectRatio="none" aria-hidden="true">
                      <path d="M0 10h48l5-8 6 16 5-12 3 4h53" fill="none" stroke="var(--accent)" strokeWidth="1.5" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
                    </svg>
                    <span className="text-[0.78rem] font-bold text-accent">{t('chat.newMessages')}</span>
                    <span className="h-px flex-1 bg-accent/60" />
                  </div>
                )}
                {m.type === 'system' ? (
                  <div className="my-1.5 flex justify-center px-6" data-seq={m.seq} data-mid={m.id}>
                    <span className="max-w-[80%] rounded-full bg-raised/80 px-3 py-1 text-center text-[0.8rem] text-ink-2 shadow-1 backdrop-blur">{systemText(m, users, t, myId)}</span>
                  </div>
                ) : (
                  <div className={clsx(p.flashId === m.id && 'anim-flash rounded-xl')}>
                    <MessageBubble
                      m={m}
                      conv={conv}
                      out={!isChannel && m.senderId === myId}
                      first={!sameRunPrev}
                      last={!sameRunNext}
                      sender={m.senderId ? users[m.senderId] : undefined}
                      peerReadSeq={conv.peerReadSeq}
                      selected={p.selected.has(m.id)}
                      selectMode={p.selectMode}
                      highlight={p.highlight}
                      canReact={canReact}
                      onMenu={p.onMenu}
                      onReply={p.onReply}
                      onToggleSelect={p.onToggleSelect}
                      onJump={p.onJump}
                      onOpenUser={p.onOpenUser}
                    />
                  </div>
                )}
              </Fragment>
            );
          })}
        </div>
        {history.hasMoreAfter && (
          <div className="flex justify-center py-3 text-ink-3">
            <Spinner size={18} />
          </div>
        )}
        <div ref={bottomSentinel} className="h-px shrink-0" />
      </div>
      {(!atBottom || history.hasMoreAfter) && (
        <button
          type="button"
          onClick={() => void jumpToLatest()}
          aria-label={t('chat.jumpToLatest')}
          className="anim-pop absolute right-4 bottom-4 grid size-11 place-items-center rounded-full border border-line bg-raised text-ink-2 shadow-2 hover:text-accent md:right-8"
        >
          <ChevronDown size={22} />
          {conv.unreadCount > 0 && <Badge count={conv.unreadCount} className="absolute -top-2" />}
        </button>
      )}
    </div>
  );
}
