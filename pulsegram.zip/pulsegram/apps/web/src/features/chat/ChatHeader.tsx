import { ArrowLeft, Bell, BellOff, CheckSquare, Eraser, Info, LogOut, MoreVertical, Phone, Search, ShieldAlert, Trash2, Video } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import type { ConversationDto } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { IconButton } from '../../components/ui/Button';
import { openMenu, type MenuItem } from '../../components/ui/Menu';
import { confirmDialog } from '../../components/ui/Modal';
import { useT } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { updateMembership } from '../../lib/chatActions';
import { presenceText } from '../../lib/format';
import { isMuted, useChat } from '../../stores/chat';
import { usePrefs } from '../../stores/prefs';
import { toast, useUi } from '../../stores/ui';
import { startCall } from '../calls/callStore';

function TypingLine({ convId, type }: { convId: string; type: ConversationDto['type'] }) {
  const t = useT();
  const typing = useChat((s) => s.typing[convId]);
  const users = useChat((s) => s.users);
  const active = Object.entries(typing ?? {}).filter(([, v]) => v.until > Date.now());
  if (!active.length) return null;
  const [uid, entry] = active[0]!;
  const name = users[uid]?.displayName.split(' ')[0] ?? '';
  const label =
    entry.kind === 'voice'
      ? t('chat.recording')
      : entry.kind === 'upload'
        ? t('chat.uploading')
        : type === 'direct'
          ? t('chat.typing')
          : active.length > 1
            ? t('chat.typingMany', { n: active.length })
            : t('chat.typingName', { name });
  return (
    <span className="inline-flex items-center gap-1.5 text-accent">
      <span className="inline-flex gap-0.5">
        <span className="typing-dot size-1 rounded-full bg-current" />
        <span className="typing-dot size-1 rounded-full bg-current" />
        <span className="typing-dot size-1 rounded-full bg-current" />
      </span>
      {type !== 'direct' && entry.kind === 'voice' ? `${name} ${label}` : label}
    </span>
  );
}

export function ChatHeader({ conv, onSearch, onSelect, onClear }: { conv: ConversationDto; onSearch: () => void; onSelect: () => void; onClear: () => void }) {
  const t = useT();
  const nav = useNavigate();
  const fmt = usePrefs((s) => s.appearance);
  const presence = useChat((s) => (conv.peer ? s.presence[conv.peer.id] : undefined));
  const connection = useChat((s) => s.connection);
  const typing = useChat((s) => Object.values(s.typing[conv.id] ?? {}).some((v) => v.until > Date.now()));
  const infoOpen = useUi((s) => s.infoOpen);
  const setInfoOpen = useUi((s) => s.setInfoOpen);
  const open = useUi((s) => s.open);
  const isSaved = conv.type === 'saved';
  const title = isSaved ? t('chats.saved') : conv.title || t('chats.deletedAccount');

  let subtitle: React.ReactNode;
  if (connection !== 'online') subtitle = connection === 'offline' ? t('chat.waitingNetwork') : connection === 'syncing' ? t('chat.updating') : t('chat.connecting');
  else if (typing) subtitle = <TypingLine convId={conv.id} type={conv.type} />;
  else if (conv.type === 'direct') subtitle = conv.peer?.statusText ? `${presenceText(presence ?? conv.peer?.presence, fmt, t)} · ${conv.peer.statusText}` : presenceText(presence ?? conv.peer?.presence, fmt, t);
  else if (conv.type === 'group') subtitle = t('common.members', { n: conv.memberCount });
  else if (conv.type === 'channel') subtitle = t('common.subscribers', { n: conv.memberCount });
  else subtitle = t('chats.savedHint');
  const online = (presence ?? conv.peer?.presence)?.kind === 'online';

  const call = async (video: boolean) => {
    try {
      await startCall(conv, video);
    } catch (err) {
      toast({ text: errorText(t, err), tone: 'danger' });
    }
  };

  const more = (e: React.MouseEvent<HTMLButtonElement>) => {
    const muted = isMuted(conv);
    const items: MenuItem[] = [
      { label: t('chat.searchHere'), icon: <Search size={17} />, onSelect: onSearch },
      { label: t('chat.selectMode'), icon: <CheckSquare size={17} />, onSelect: onSelect },
    ];
    if (conv.me && !isSaved)
      items.push(
        muted
          ? { label: t('chats.unmute'), icon: <Bell size={17} />, onSelect: () => void updateMembership(conv.id, { mutedUntil: null }) }
          : { label: t('chats.mute'), icon: <BellOff size={17} />, onSelect: () => void updateMembership(conv.id, { mutedUntil: 'forever' }) },
      );
    if (conv.me && conv.type === 'direct') items.push({ label: t('chat.clearHistory'), icon: <Eraser size={17} />, onSelect: onClear });
    if (!isSaved) items.push({ label: t('chat.report'), icon: <ShieldAlert size={17} />, onSelect: () => open({ kind: 'report', targetType: conv.type === 'direct' ? 'user' : 'conversation', targetId: conv.type === 'direct' ? conv.peer!.id : conv.id }) });
    if (conv.me && conv.type !== 'saved') {
      items.push({ divider: true, label: '' });
      items.push(
        conv.type === 'direct'
          ? {
              label: t('chats.delete'),
              icon: <Trash2 size={17} />,
              danger: true,
              onSelect: async () => {
                const r = await confirmDialog({ title: t('chats.delete'), body: t('chats.deleteConfirm'), danger: true, confirmLabel: t('common.delete') });
                if (!r.ok) return;
                await http.post(`/api/conversations/${conv.id}/leave`);
                useChat.getState().removeConversation(conv.id);
                nav('/chat');
              },
            }
          : {
              label: t('chats.leave'),
              icon: <LogOut size={17} />,
              danger: true,
              onSelect: async () => {
                const r = await confirmDialog({ title: t('chats.leave'), body: t('chats.leaveConfirm', { title: conv.title }), danger: true, confirmLabel: t('chats.leave') });
                if (!r.ok) return;
                try {
                  await http.post(`/api/conversations/${conv.id}/leave`);
                  useChat.getState().removeConversation(conv.id);
                  nav('/chat');
                } catch (err) {
                  toast({ text: errorText(t, err), tone: 'danger' });
                }
              },
            },
      );
    }
    openMenu(e, items);
  };

  return (
    <header className="flex h-16 shrink-0 items-center gap-2 border-b border-line bg-bg/95 px-2 backdrop-blur md:px-4">
      <IconButton label={t('common.back')} className="md:hidden" onClick={() => nav('/chat')}>
        <ArrowLeft size={21} />
      </IconButton>
      <button type="button" className="flex min-w-0 flex-1 items-center gap-3 rounded-[12px] py-1 text-left" onClick={() => setInfoOpen(!infoOpen)}>
        <Avatar id={conv.peer?.id ?? conv.id} name={title} src={conv.avatarUrl} size={42} online={online && conv.type === 'direct'} kind={isSaved ? 'saved' : conv.type === 'direct' ? 'user' : conv.type} />
        <span className="min-w-0">
          <span className="block truncate text-[1rem] font-bold text-ink">{title}</span>
          <span className="block truncate text-[0.82rem] text-ink-3">{subtitle}</span>
        </span>
      </button>
      {conv.type === 'direct' && conv.me && (
        <>
          <IconButton label={t('chat.call')} onClick={() => void call(false)}>
            <Phone size={20} />
          </IconButton>
          <IconButton label={t('chat.videoCall')} className="hidden sm:inline-flex" onClick={() => void call(true)}>
            <Video size={21} />
          </IconButton>
        </>
      )}
      <IconButton label={t('chat.searchHere')} className="hidden sm:inline-flex" onClick={onSearch}>
        <Search size={20} />
      </IconButton>
      <IconButton label={t('chat.info')} active={infoOpen} className="hidden lg:inline-flex" onClick={() => setInfoOpen(!infoOpen)}>
        <Info size={20} />
      </IconButton>
      <IconButton label={t('chat.moreActions')} onClick={more}>
        <MoreVertical size={20} />
      </IconButton>
    </header>
  );
}
