import { render } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { describe, expect, it } from 'vitest';
import { isEmojiOnly, RichText } from './RichText';

const renderText = (text: string) =>
  render(
    <MemoryRouter>
      <p>
        <RichText text={text} />
      </p>
    </MemoryRouter>,
  ).container;

describe('RichText', () => {
  it('renders HTML as inert text (no XSS)', () => {
    const c = renderText('<img src=x onerror="alert(1)"><script>alert(2)</script>');
    expect(c.querySelector('img')).toBeNull();
    expect(c.querySelector('script')).toBeNull();
    expect(c.textContent).toContain('<script>');
  });

  it('only links http(s) URLs, with safe rel attributes', () => {
    const c = renderText('go https://example.com/x and javascript:alert(1)');
    const links = c.querySelectorAll('a');
    expect(links).toHaveLength(1);
    expect(links[0]!.getAttribute('href')).toBe('https://example.com/x');
    expect(links[0]!.getAttribute('rel')).toContain('noopener');
    expect(links[0]!.getAttribute('target')).toBe('_blank');
  });

  it('formats code and mentions', () => {
    const c = renderText('run `npm test` @alice_k');
    expect(c.querySelector('code')!.textContent).toBe('npm test');
    expect(c.querySelector('button')!.textContent).toBe('@alice_k');
  });

  it('detects emoji-only messages', () => {
    expect(isEmojiOnly('🎉')).toBe(true);
    expect(isEmojiOnly('👍🔥')).toBe(true);
    expect(isEmojiOnly('ok 👍')).toBe(false);
  });
});
