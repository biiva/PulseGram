import { ArrowLeft } from 'lucide-react';
import type { ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import type { Preferences, UpdatePreferencesInput } from '@pulsegram/shared';
import { IconButton } from '../../components/ui/Button';
import { useT } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { usePrefs } from '../../stores/prefs';
import { toast } from '../../stores/ui';

export function SectionPage({ title, children }: { title: string; children: ReactNode }) {
  const t = useT();
  const nav = useNavigate();
  return (
    <div className="flex h-full w-full flex-col bg-bg">
      <header className="flex h-16 shrink-0 items-center gap-2 border-b border-line px-3 md:px-6">
        <IconButton label={t('common.back')} className="md:hidden" onClick={() => nav('/settings')}>
          <ArrowLeft size={20} />
        </IconButton>
        <h2 className="text-[1.1rem] font-bold text-ink">{title}</h2>
      </header>
      <div className="scroll-y min-h-0 flex-1">
        <div className="mx-auto flex max-w-2xl flex-col gap-6 px-4 py-6 md:px-8">{children}</div>
      </div>
    </div>
  );
}

export function Group({ title, description, children }: { title?: string; description?: ReactNode; children: ReactNode }) {
  return (
    <section>
      {title && <h3 className="mb-1 px-1 text-[0.82rem] font-semibold text-ink-3">{title}</h3>}
      <div className="divide-y divide-line rounded-[16px] border border-line bg-raised px-4">{children}</div>
      {description && <p className="mt-1.5 px-1 text-[0.8rem] leading-snug text-ink-3">{description}</p>}
    </section>
  );
}

export function Row({ label, children, description }: { label: ReactNode; children: ReactNode; description?: ReactNode }) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3 py-3">
      <div className="min-w-0">
        <p className="text-[0.93rem] text-ink">{label}</p>
        {description && <p className="mt-0.5 text-[0.8rem] text-ink-3">{description}</p>}
      </div>
      {children}
    </div>
  );
}

/** Persist preferences (optimistically) and roll back on failure. */
export function useSavePrefs() {
  const t = useT();
  return async (patch: UpdatePreferencesInput) => {
    const prev = usePrefs.getState();
    const snapshot: Preferences = { privacy: prev.privacy, notifications: prev.notifications, appearance: prev.appearance };
    usePrefs.getState().set({
      privacy: { ...prev.privacy, ...patch.privacy },
      notifications: { ...prev.notifications, ...patch.notifications },
      appearance: { ...prev.appearance, ...patch.appearance },
    });
    try {
      const next = await http.patch<Preferences>('/api/me/preferences', patch);
      usePrefs.getState().set(next);
    } catch (err) {
      usePrefs.getState().set(snapshot);
      toast({ text: errorText(t, err), tone: 'danger' });
    }
  };
}
