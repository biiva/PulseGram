import { DataSettings, DevicesSettings, PrivacySettingsPage, ProfileSettings } from './AccountSettings';
import { AboutSettings, AppearanceSettings, FoldersSettings, LanguageSettings, NotificationSettings, ShortcutsSettings } from './PrefsSettings';

export function SettingsSection({ section }: { section: string }) {
  switch (section) {
    case 'privacy':
      return <PrivacySettingsPage />;
    case 'devices':
      return <DevicesSettings />;
    case 'notifications':
      return <NotificationSettings />;
    case 'appearance':
      return <AppearanceSettings />;
    case 'language':
      return <LanguageSettings />;
    case 'folders':
      return <FoldersSettings />;
    case 'shortcuts':
      return <ShortcutsSettings />;
    case 'data':
      return <DataSettings />;
    case 'about':
      return <AboutSettings />;
    default:
      return <ProfileSettings />;
  }
}
