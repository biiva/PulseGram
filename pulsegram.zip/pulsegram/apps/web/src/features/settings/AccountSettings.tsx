import { useQuery } from '@tanstack/react-query';
import { Camera, Download, Laptop, Lock, ShieldCheck, Smartphone, Trash2 } from 'lucide-react';
import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LIMITS, PRIVACY_AUDIENCES, type Me, type PrivacyAudience, type PrivacySettings, type SessionInfo, type UserSummary } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { Button } from '../../components/ui/Button';
import { Input, Segmented, Switch, Textarea } from '../../components/ui/Field';
import { confirmDialog, Modal } from '../../components/ui/Modal';
import { Spinner } from '../../components/ui/misc';
import { useT, type MessageKey } from '../../i18n';
import { ApiError, errorText, fieldText, http } from '../../lib/api';
import { formatRelative } from '../../lib/format';
import { queryClient } from '../../lib/queryClient';
import { realtime } from '../../lib/realtime';
import { uploadFile } from '../../lib/upload';
import { useAuth } from '../../stores/auth';
import { useChat } from '../../stores/chat';
import { usePrefs } from '../../stores/prefs';
import { toast } from '../../stores/ui';
import { PasswordMeter, UsernameStatus, useUsernameCheck } from '../auth/Register';
import { Group, Row, SectionPage, useSavePrefs } from './common';

export function ProfileSettings() {
  const t = useT();
  const me = useAuth((s) => s.me)!;
  const setMe = useAuth((s) => s.setMe);
  const [form, setForm] = useState({ displayName: me.displayName, username: me.username, bio: me.bio, statusText: me.statusText, phone: me.phone ?? '', publicEmail: me.publicEmail, presenceMode: me.presenceMode });
  const [errors, setErrors] = useState<Record<string, string | undefined>>({});
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const file = useRef<HTMLInputElement>(null);
  const u = useUsernameCheck(form.username, me.username);
  const set = <K extends keyof typeof form>(k: K, v: (typeof form)[K]) => {
    setForm((f) => ({ ...f, [k]: v }));
    setErrors((e) => ({ ...e, [k]: undefined }));
  };
  const dirty = JSON.stringify(form) !== JSON.stringify({ displayName: me.displayName, username: me.username, bio: me.bio, statusText: me.statusText, phone: me.phone ?? '', publicEmail: me.publicEmail, presenceMode: me.presenceMode });

  return (
    <SectionPage title={t('settings.profile')}>
      <div className="flex items-center gap-5">
        <button type="button" className="group relative rounded-full" onClick={() => file.current?.click()} aria-label={t('settings.changePhoto')}>
          <Avatar id={me.id} name={me.displayName} src={me.avatarUrl} size={96} />
          <span className="absolute inset-0 grid place-items-center rounded-full bg-black/40 text-white opacity-0 transition group-hover:opacity-100">
            {progress !== null ? `${Math.round(progress * 100)}%` : <Camera size={24} />}
          </span>
        </button>
        <div className="flex flex-col gap-2">
          <Button variant="soft" size="sm" icon={<Camera size={15} />} onClick={() => file.current?.click()}>
            {t('settings.changePhoto')}
          </Button>
          {me.avatarUrl && (
            <Button variant="ghost" size="sm" onClick={async () => setMe(await http.del<Me>('/api/me/avatar'))}>
              {t('info.removePhoto')}
            </Button>
          )}
        </div>
        <input
          ref={file}
          type="file"
          hidden
          accept="image/jpeg,image/png,image/webp,image/gif,image/avif"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            e.target.value = '';
            if (!f) return;
            setProgress(0);
            try {
              setMe((await uploadFile(f, f.name, { url: '/api/me/avatar', method: 'PUT', onProgress: setProgress }).promise) as unknown as Me);
            } catch (err) {
              toast({ text: errorText(t, err), tone: 'danger' });
            } finally {
              setProgress(null);
            }
          }}
        />
      </div>
      <form
        className="flex flex-col gap-4"
        onSubmit={async (e) => {
          e.preventDefault();
          setBusy(true);
          try {
            setMe(await http.patch<Me>('/api/me/profile', form));
            toast(t('settings.profileSaved'));
          } catch (err) {
            if (err instanceof ApiError && Object.keys(err.fieldErrors).length) setErrors(Object.fromEntries(Object.entries(err.fieldErrors).map(([k, v]) => [k, fieldText(t, v)])));
            else toast({ text: errorText(t, err), tone: 'danger' });
          } finally {
            setBusy(false);
          }
        }}
      >
        <Input label={t('auth.field.displayName')} value={form.displayName} onChange={(e) => set('displayName', e.target.value)} maxLength={LIMITS.displayName} error={errors.displayName} />
        <Input label={t('auth.field.username')} leading={<span>@</span>} value={form.username} onChange={(e) => set('username', e.target.value)} error={errors.username} hint={<UsernameStatus state={u} username={form.username} />} spellCheck={false} />
        <Textarea label={t('settings.bio')} value={form.bio} onChange={(e) => set('bio', e.target.value)} maxLength={LIMITS.bio} hint={t('settings.bioHint', { n: LIMITS.bio - form.bio.length })} className="min-h-20" />
        <Input label={t('settings.status')} value={form.statusText} onChange={(e) => set('statusText', e.target.value)} maxLength={LIMITS.statusText} hint={t('settings.statusHint')} />
        <Input label={`${t('settings.phone')} (${t('common.optional')})`} type="tel" value={form.phone} onChange={(e) => set('phone', e.target.value)} error={errors.phone} autoComplete="tel" />
        <div>
          <p className="mb-1.5 text-[0.82rem] font-semibold text-ink-2">{t('settings.presence')}</p>
          <Segmented
            value={form.presenceMode}
            onChange={(v) => set('presenceMode', v)}
            options={[
              { value: 'auto', label: t('settings.presence.auto') },
              { value: 'dnd', label: t('settings.presence.dnd') },
              { value: 'invisible', label: t('settings.presence.invisible') },
            ]}
          />
          <p className="mt-1.5 text-[0.8rem] text-ink-3">{t('settings.presenceHint')}</p>
        </div>
        <div className="rounded-[14px] border border-line px-4">
          <Switch checked={form.publicEmail} onChange={(v) => set('publicEmail', v)} label={t('settings.publicEmail')} description={me.email} />
        </div>
        <div className="flex justify-end">
          <Button type="submit" loading={busy} disabled={!dirty || u === 'taken' || u === 'invalid'}>
            {t('common.save')}
          </Button>
        </div>
      </form>
    </SectionPage>
  );
}

function AudienceSelect({ value, onChange }: { value: PrivacyAudience; onChange: (v: PrivacyAudience) => void }) {
  const t = useT();
  const labels: Record<PrivacyAudience, MessageKey> = { everybody: 'common.everybody', contacts: 'common.contacts', nobody: 'common.nobody' };
  return (
    <select value={value} onChange={(e) => onChange(e.target.value as PrivacyAudience)} className="h-9 cursor-pointer rounded-[10px] border border-line bg-sunken px-2.5 text-[0.88rem] text-ink outline-none focus:border-accent">
      {PRIVACY_AUDIENCES.map((a) => (
        <option key={a} value={a}>
          {t(labels[a])}
        </option>
      ))}
    </select>
  );
}

function ChangePassword() {
  const t = useT();
  const [open, setOpen] = useState(false);
  const [cur, setCur] = useState('');
  const [next, setNext] = useState('');
  const [err, setErr] = useState<string | undefined>();
  const [busy, setBusy] = useState(false);
  return (
    <>
      <Button variant="secondary" size="sm" icon={<Lock size={15} />} onClick={() => setOpen(true)}>
        {t('settings.changePassword')}
      </Button>
      <Modal open={open} onClose={() => setOpen(false)} title={t('settings.changePassword')} width={400}>
        <form
          className="flex flex-col gap-4"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setErr(undefined);
            try {
              await http.post('/api/auth/change-password', { currentPassword: cur, newPassword: next });
              toast(t('settings.passwordChanged'));
              setOpen(false);
              setCur('');
              setNext('');
            } catch (error) {
              setErr(error instanceof ApiError && Object.keys(error.fieldErrors).length ? fieldText(t, Object.values(error.fieldErrors)[0]) : errorText(t, error));
            } finally {
              setBusy(false);
            }
          }}
        >
          <Input label={t('auth.field.currentPassword')} type="password" autoComplete="current-password" value={cur} onChange={(e) => setCur(e.target.value)} />
          <div>
            <Input label={t('auth.field.newPassword')} type="password" autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} />
            <PasswordMeter password={next} />
          </div>
          {err && <p className="text-[0.85rem] text-danger">{err}</p>}
          <Button type="submit" loading={busy} disabled={!cur || next.length < 8}>
            {t('common.save')}
          </Button>
        </form>
      </Modal>
    </>
  );
}

export function PrivacySettingsPage() {
  const t = useT();
  const privacy = usePrefs((s) => s.privacy);
  const save = useSavePrefs();
  const blocked = useQuery({ queryKey: ['blocks'], queryFn: () => http.get<UserSummary[]>('/api/blocks') });
  const rows: Array<[keyof PrivacySettings, MessageKey, MessageKey?]> = [
    ['lastSeen', 'settings.privacy.lastSeen', 'settings.privacy.lastSeenHint'],
    ['online', 'settings.privacy.online'],
    ['avatar', 'settings.privacy.avatar'],
    ['phone', 'settings.privacy.phone'],
    ['groupInvites', 'settings.privacy.groupInvites'],
    ['calls', 'settings.privacy.calls'],
  ];
  return (
    <SectionPage title={t('settings.privacy')}>
      <Group>
        {rows.map(([k, label, hint]) => (
          <Row key={k} label={t(label)} description={hint ? t(hint) : undefined}>
            <AudienceSelect value={privacy[k]} onChange={(v) => void save({ privacy: { [k]: v } })} />
          </Row>
        ))}
      </Group>
      <Group title={t('settings.blocked')}>
        {blocked.isLoading ? (
          <Spinner className="my-3 text-ink-3" />
        ) : !blocked.data?.length ? (
          <p className="py-3 text-[0.88rem] text-ink-3">{t('settings.blockedEmpty')}</p>
        ) : (
          blocked.data.map((u) => (
            <div key={u.id} className="flex items-center gap-3 py-2.5">
              <Avatar id={u.id} name={u.displayName} src={u.avatarUrl} size={36} />
              <span className="min-w-0 flex-1 truncate text-[0.92rem] text-ink">{u.displayName}</span>
              <Button size="sm" variant="ghost" onClick={async () => { await http.del(`/api/blocks/${u.id}`); await blocked.refetch(); }}>
                {t('info.unblock')}
              </Button>
            </div>
          ))
        )}
      </Group>
      <Group title={t('settings.password')}>
        <Row label={t('settings.password')}>
          <ChangePassword />
        </Row>
      </Group>
      <Group title={t('settings.encryption')}>
        <div className="flex gap-3 py-3">
          <ShieldCheck size={20} className="mt-0.5 shrink-0 text-ink-3" />
          <p className="text-[0.86rem] leading-relaxed text-ink-2">{t('settings.encryptionBody')}</p>
        </div>
      </Group>
    </SectionPage>
  );
}

export function DevicesSettings() {
  const t = useT();
  const fmt = usePrefs((s) => s.appearance);
  const q = useQuery({ queryKey: ['sessions'], queryFn: () => http.get<SessionInfo[]>('/api/sessions') });
  const current = q.data?.find((s) => s.current);
  const others = q.data?.filter((s) => !s.current) ?? [];
  const icon = (s: SessionInfo) => (/Android|iOS/.test(s.deviceName) ? <Smartphone size={20} /> : <Laptop size={20} />);
  const row = (s: SessionInfo) => (
    <div key={s.id} className="flex items-center gap-3 py-3">
      <span className="grid size-10 shrink-0 place-items-center rounded-[12px] bg-soft text-accent">{icon(s)}</span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[0.93rem] font-semibold text-ink">{s.deviceName}</span>
        <span className="block truncate text-[0.8rem] text-ink-3">
          {s.ip ?? ''} · {s.current ? t('chat.online') : t('settings.sessions.lastActive', { time: formatRelative(s.lastActiveAt, fmt, t) })}
        </span>
      </span>
      {!s.current && (
        <Button
          size="sm"
          variant="ghost"
          className="!text-danger"
          onClick={async () => {
            await http.del(`/api/sessions/${s.id}`);
            await q.refetch();
          }}
        >
          {t('settings.sessions.terminate')}
        </Button>
      )}
    </div>
  );
  return (
    <SectionPage title={t('settings.devices')}>
      {q.isLoading ? (
        <Spinner className="text-ink-3" />
      ) : (
        <>
          <Group title={t('settings.sessions.current')}>{current && row(current)}</Group>
          <Group title={t('settings.sessions.others')}>{others.length ? others.map(row) : <p className="py-3 text-[0.88rem] text-ink-3">{t('settings.sessions.none')}</p>}</Group>
          {others.length > 0 && (
            <Button
              variant="secondary"
              className="self-start !text-danger"
              onClick={async () => {
                const r = await confirmDialog({ title: t('settings.sessions.terminateAll'), body: t('settings.sessions.terminateAllConfirm'), danger: true, confirmLabel: t('settings.sessions.terminate') });
                if (!r.ok) return;
                await http.post('/api/sessions/revoke-others');
                await q.refetch();
              }}
            >
              {t('settings.sessions.terminateAll')}
            </Button>
          )}
        </>
      )}
    </SectionPage>
  );
}

export function DataSettings() {
  const t = useT();
  const nav = useNavigate();
  const [busy, setBusy] = useState(false);
  return (
    <SectionPage title={t('settings.data')}>
      <Group title={t('settings.data.export')} description={t('settings.data.exportBody')}>
        <div className="py-3">
          <a href="/api/me/export" download className="inline-flex h-10 items-center gap-2 rounded-[12px] border border-line bg-raised px-4 text-[0.92rem] font-semibold text-ink hover:bg-sunken">
            <Download size={17} /> {t('settings.data.export')}
          </a>
        </div>
      </Group>
      <Group title={t('settings.data.delete')} description={t('settings.data.deleteBody')}>
        <div className="py-3">
          <Button
            variant="danger"
            icon={<Trash2 size={17} />}
            loading={busy}
            onClick={async () => {
              const typed = await confirmDialog({ title: t('settings.data.delete'), body: t('settings.data.deleteConfirm'), danger: true, input: { label: 'DELETE' }, confirmLabel: t('common.next') });
              if (!typed.ok || typed.value !== 'DELETE') return;
              const pw = await confirmDialog({ title: t('settings.data.delete'), danger: true, input: { label: t('auth.field.password'), type: 'password' }, confirmLabel: t('settings.data.delete') });
              if (!pw.ok) return;
              setBusy(true);
              try {
                await http.post('/api/me/delete', { password: pw.value, confirm: 'DELETE' });
                realtime.stop();
                useChat.getState().reset();
                queryClient.clear();
                useAuth.getState().clear();
                toast(t('settings.data.deleted'));
                nav('/welcome', { replace: true });
              } catch (err) {
                toast({ text: errorText(t, err), tone: 'danger' });
              } finally {
                setBusy(false);
              }
            }}
          >
            {t('settings.data.delete')}
          </Button>
        </div>
      </Group>
    </SectionPage>
  );
}

