import { useQuery } from '@tanstack/react-query';
import { clsx } from 'clsx';
import { Check, Monitor, Moon, Pencil, Plus, Sun, Trash2 } from 'lucide-react';
import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { APP_VERSION, LANGUAGES, type FolderDto, type FolderInput, type Language } from '@pulsegram/shared';
import { Button, IconButton } from '../../components/ui/Button';
import { Checkbox, Input, Segmented, Switch } from '../../components/ui/Field';
import { Modal } from '../../components/ui/Modal';
import { Kbd, Logo, Spinner } from '../../components/ui/misc';
import { LANGUAGE_NAMES, useT } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { formatDate, formatTime } from '../../lib/format';
import { queryClient } from '../../lib/queryClient';
import { playChime } from '../../lib/sound';
import { useAuth } from '../../stores/auth';
import { sortConversations, useChat } from '../../stores/chat';
import { usePrefs } from '../../stores/prefs';
import { toast } from '../../stores/ui';
import { Group, Row, SectionPage, useSavePrefs } from './common';

function urlBase64ToUint8Array(base64: string) {
  const padding = '='.repeat((4 - (base64.length % 4)) % 4);
  const raw = atob((base64 + padding).replace(/-/g, '+').replace(/_/g, '/'));
  return Uint8Array.from([...raw].map((c) => c.charCodeAt(0)));
}

export function NotificationSettings() {
  const t = useT();
  const n = usePrefs((s) => s.notifications);
  const fmt = usePrefs((s) => s.appearance);
  const config = useAuth((s) => s.config);
  const save = useSavePrefs();
  const [perm, setPerm] = useState<NotificationPermission | 'unsupported'>(typeof Notification === 'undefined' ? 'unsupported' : Notification.permission);
  const [pushOn, setPushOn] = useState(false);
  useEffect(() => {
    void navigator.serviceWorker?.ready.then((r) => r.pushManager?.getSubscription()).then((s) => setPushOn(Boolean(s))).catch(() => {});
  }, []);
  const paused = n.pausedUntil && new Date(n.pausedUntil) > new Date();

  const enablePush = async () => {
    try {
      const reg = await navigator.serviceWorker.ready;
      const sub = await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: urlBase64ToUint8Array(config!.vapidPublicKey!) });
      const json = sub.toJSON() as { endpoint: string; keys: { p256dh: string; auth: string } };
      await http.post('/api/push/subscribe', { endpoint: json.endpoint, keys: json.keys });
      setPushOn(true);
    } catch (err) {
      toast({ text: errorText(t, err), tone: 'danger' });
    }
  };

  return (
    <SectionPage title={t('settings.notifications')}>
      <Group title={t('settings.notif.browser')} description={t('notif.enableBody')}>
        <Row label={t('settings.notif.browser')} description={perm === 'granted' ? t('settings.notif.browserOn') : perm === 'denied' ? t('notif.denied') : t('settings.notif.browserOff')}>
          {perm === 'default' && (
            <Button size="sm" onClick={async () => setPerm(await Notification.requestPermission())}>
              {t('notif.enable')}
            </Button>
          )}
          {perm === 'granted' && (
            <Button size="sm" variant="ghost" onClick={() => new Notification('PulseGram', { body: t('settings.notif.test'), icon: '/favicon.svg' })}>
              {t('settings.notif.test')}
            </Button>
          )}
        </Row>
        <Row label={t('settings.notif.push')} description={!config?.pushConfigured ? t('settings.notif.pushNotConfigured') : pushOn ? t('settings.notif.pushOn') : undefined}>
          {config?.pushConfigured && !pushOn && perm === 'granted' && (
            <Button size="sm" variant="soft" onClick={() => void enablePush()}>
              {t('settings.notif.pushEnable')}
            </Button>
          )}
          {!config?.pushConfigured && <span className="text-[0.8rem] font-semibold text-ink-3">{t('common.notConfigured')}</span>}
        </Row>
      </Group>
      <Group>
        <Switch checked={n.enabled} onChange={(v) => void save({ notifications: { enabled: v } })} label={t('settings.notif.enabled')} />
        <Switch checked={n.sound} onChange={(v) => { void save({ notifications: { sound: v } }); if (v) playChime(); }} label={t('settings.notif.sound')} disabled={!n.enabled} />
        <Switch checked={n.preview} onChange={(v) => void save({ notifications: { preview: v } })} label={t('settings.notif.preview')} disabled={!n.enabled} />
        <Switch checked={n.lockScreenPreview} onChange={(v) => void save({ notifications: { lockScreenPreview: v } })} label={t('settings.notif.lockScreen')} description={t('settings.notif.lockScreenHint')} disabled={!n.enabled} />
      </Group>
      <Group>
        <Switch checked={n.direct} onChange={(v) => void save({ notifications: { direct: v } })} label={t('settings.notif.direct')} disabled={!n.enabled} />
        <Switch checked={n.groups} onChange={(v) => void save({ notifications: { groups: v } })} label={t('settings.notif.groups')} disabled={!n.enabled} />
        <Switch checked={n.channels} onChange={(v) => void save({ notifications: { channels: v } })} label={t('settings.notif.channels')} disabled={!n.enabled} />
        <Switch checked={n.mentions} onChange={(v) => void save({ notifications: { mentions: v } })} label={t('settings.notif.mentions')} disabled={!n.enabled} />
        <Switch checked={n.calls} onChange={(v) => void save({ notifications: { calls: v } })} label={t('settings.notif.calls')} disabled={!n.enabled} />
      </Group>
      <Group title={t('settings.notif.pause')}>
        <Row label={paused ? t('settings.notif.pausedUntil', { time: `${formatDate(n.pausedUntil!, fmt, false)} ${formatTime(n.pausedUntil!, fmt)}` }) : t('settings.notif.pause')}>
          {paused ? (
            <Button size="sm" variant="soft" onClick={() => void save({ notifications: { pausedUntil: null } })}>
              {t('settings.notif.resume')}
            </Button>
          ) : (
            <div className="flex gap-2">
              <Button size="sm" variant="secondary" onClick={() => void save({ notifications: { pausedUntil: new Date(Date.now() + 3600_000).toISOString() } })}>
                {t('settings.notif.pause1h')}
              </Button>
              <Button size="sm" variant="secondary" onClick={() => void save({ notifications: { pausedUntil: new Date(Date.now() + 8 * 3600_000).toISOString() } })}>
                {t('settings.notif.pause8h')}
              </Button>
            </div>
          )}
        </Row>
      </Group>
    </SectionPage>
  );
}

const ACCENTS = ['#7C4DFF', '#35B6FF', '#FF5C8A', '#1FAE6B', '#F2994A', '#E5484D', '#2CC3B5', '#5B6CFF'];

export function AppearanceSettings() {
  const t = useT();
  const a = usePrefs((s) => s.appearance);
  const save = useSavePrefs();
  return (
    <SectionPage title={t('settings.appearance')}>
      <Group title={t('settings.theme')}>
        <div className="py-3">
          <Segmented
            value={a.theme}
            onChange={(v) => void save({ appearance: { theme: v } })}
            options={[
              { value: 'light', label: t('settings.theme.light'), icon: <Sun size={15} /> },
              { value: 'dark', label: t('settings.theme.dark'), icon: <Moon size={15} /> },
              { value: 'system', label: t('settings.theme.system'), icon: <Monitor size={15} /> },
            ]}
          />
        </div>
      </Group>
      <Group title={t('settings.accent')}>
        <div className="flex flex-wrap items-center gap-2.5 py-3">
          {ACCENTS.map((c) => (
            <button
              key={c}
              type="button"
              aria-label={c}
              aria-pressed={a.accent.toLowerCase() === c.toLowerCase()}
              onClick={() => void save({ appearance: { accent: c } })}
              className="grid size-9 place-items-center rounded-full text-white ring-offset-2 ring-offset-raised transition hover:scale-110"
              style={{ background: c, boxShadow: a.accent.toLowerCase() === c.toLowerCase() ? `0 0 0 2px var(--raised), 0 0 0 4px ${c}` : undefined }}
            >
              {a.accent.toLowerCase() === c.toLowerCase() && <Check size={16} strokeWidth={3} />}
            </button>
          ))}
          <label className="relative grid size-9 cursor-pointer place-items-center overflow-hidden rounded-full border border-dashed border-line-strong text-ink-3" title="Custom">
            <Plus size={16} />
            <input type="color" value={a.accent} onChange={(e) => void save({ appearance: { accent: e.target.value.toUpperCase() } })} className="absolute inset-0 cursor-pointer opacity-0" />
          </label>
        </div>
      </Group>
      <Group>
        <Row label={t('settings.density')}>
          <Segmented value={a.density} onChange={(v) => void save({ appearance: { density: v } })} options={[{ value: 'comfortable', label: t('settings.density.comfortable') }, { value: 'compact', label: t('settings.density.compact') }]} />
        </Row>
        <Row label={t('settings.fontSize')} description={`${Math.round(a.fontScale * 100)}%`}>
          <input type="range" min={0.85} max={1.3} step={0.05} value={a.fontScale} onChange={(e) => void save({ appearance: { fontScale: Number(e.target.value) } })} className="w-44 accent-[var(--accent)]" aria-label={t('settings.fontSize')} />
        </Row>
        <Switch checked={a.reduceMotion} onChange={(v) => void save({ appearance: { reduceMotion: v } })} label={t('settings.reduceMotion')} />
        <Switch checked={a.enterToSend} onChange={(v) => void save({ appearance: { enterToSend: v } })} label={t('settings.enterToSend')} />
      </Group>
    </SectionPage>
  );
}

export function LanguageSettings() {
  const t = useT();
  const a = usePrefs((s) => s.appearance);
  const save = useSavePrefs();
  const sample = new Date();
  return (
    <SectionPage title={t('settings.language')}>
      <Group title={t('settings.languageLabel')}>
        {LANGUAGES.map((l: Language) => (
          <button key={l} type="button" onClick={() => void save({ appearance: { language: l } })} className="flex w-full items-center justify-between py-3 text-left text-[0.95rem] text-ink">
            {LANGUAGE_NAMES[l]}
            {a.language === l && <Check size={18} className="text-accent" />}
          </button>
        ))}
      </Group>
      <Group>
        <Row label={t('settings.timeFormat')} description={formatTime(sample, a)}>
          <Segmented value={a.timeFormat} onChange={(v) => void save({ appearance: { timeFormat: v } })} options={[{ value: '24h', label: '24h' }, { value: '12h', label: '12h' }]} />
        </Row>
        <Row label={t('settings.dateFormat')} description={formatDate(sample, a)}>
          <Segmented value={a.dateFormat} onChange={(v) => void save({ appearance: { dateFormat: v } })} options={[{ value: 'dmy', label: 'DD.MM' }, { value: 'mdy', label: 'MM/DD' }, { value: 'ymd', label: 'YYYY-MM' }]} />
        </Row>
      </Group>
    </SectionPage>
  );
}

function FolderEditor({ folder, onClose }: { folder: FolderDto | null; onClose: () => void }) {
  const t = useT();
  const conversations = useChat((s) => s.conversations);
  const [f, setF] = useState<FolderInput>(
    folder
      ? { name: folder.name, emoji: folder.emoji ?? undefined, includeTypes: folder.includeTypes, includeIds: folder.includeIds, excludeIds: folder.excludeIds, unreadOnly: folder.unreadOnly, excludeMuted: folder.excludeMuted, excludeArchived: folder.excludeArchived }
      : { name: '', includeTypes: ['direct'], includeIds: [], excludeIds: [], unreadOnly: false, excludeMuted: false, excludeArchived: true },
  );
  const [busy, setBusy] = useState(false);
  const chats = sortConversations(Object.values(conversations)).filter((c) => c.type !== 'saved');
  const toggle = (list: 'includeIds' | 'excludeIds', id: string) =>
    setF((x) => ({ ...x, [list]: x[list].includes(id) ? x[list].filter((i) => i !== id) : [...x[list], id], [list === 'includeIds' ? 'excludeIds' : 'includeIds']: x[list === 'includeIds' ? 'excludeIds' : 'includeIds'].filter((i) => i !== id) }));
  return (
    <Modal
      open
      onClose={onClose}
      title={folder ? folder.name : t('settings.folders.create')}
      width={480}
      footer={
        <Button
          loading={busy}
          disabled={!f.name.trim()}
          onClick={async () => {
            setBusy(true);
            try {
              if (folder) await http.put(`/api/folders/${folder.id}`, f);
              else await http.post('/api/folders', f);
              await queryClient.invalidateQueries({ queryKey: ['folders'] });
              onClose();
            } catch (err) {
              toast({ text: errorText(t, err), tone: 'danger' });
            } finally {
              setBusy(false);
            }
          }}
        >
          {t('common.save')}
        </Button>
      }
    >
      <div className="flex flex-col gap-4">
        <div className="flex gap-2">
          <Input wrapClassName="w-20" label="Emoji" value={f.emoji ?? ''} maxLength={4} onChange={(e) => setF({ ...f, emoji: e.target.value || undefined })} />
          <Input wrapClassName="flex-1" label={t('settings.folders.name')} value={f.name} maxLength={32} onChange={(e) => setF({ ...f, name: e.target.value })} data-autofocus />
        </div>
        <div>
          <p className="mb-2 text-[0.82rem] font-semibold text-ink-2">{t('settings.folders.include')}</p>
          <div className="flex flex-wrap gap-3">
            {(['direct', 'group', 'channel'] as const).map((ty) => (
              <Checkbox key={ty} checked={f.includeTypes.includes(ty)} onChange={(v) => setF({ ...f, includeTypes: v ? [...f.includeTypes, ty] : f.includeTypes.filter((x) => x !== ty) })}>
                {t(ty === 'direct' ? 'nav.direct' : ty === 'group' ? 'nav.groups' : 'nav.channels')}
              </Checkbox>
            ))}
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <Checkbox checked={f.unreadOnly} onChange={(v) => setF({ ...f, unreadOnly: v })}>{t('settings.folders.unreadOnly')}</Checkbox>
          <Checkbox checked={f.excludeMuted} onChange={(v) => setF({ ...f, excludeMuted: v })}>{t('settings.folders.excludeMuted')}</Checkbox>
          <Checkbox checked={f.excludeArchived} onChange={(v) => setF({ ...f, excludeArchived: v })}>{t('settings.folders.excludeArchived')}</Checkbox>
        </div>
        <div>
          <p className="mb-1 text-[0.82rem] font-semibold text-ink-2">
            {t('settings.folders.chats')} / {t('settings.folders.exclude')}
          </p>
          <div className="max-h-60 overflow-y-auto rounded-[12px] border border-line">
            {chats.map((c) => (
              <div key={c.id} className="flex items-center gap-2 border-b border-line px-3 py-2 last:border-0">
                <span className="min-w-0 flex-1 truncate text-[0.88rem] text-ink">{c.title}</span>
                <button type="button" onClick={() => toggle('includeIds', c.id)} className={clsx('rounded-full px-2 py-0.5 text-[0.75rem] font-semibold', f.includeIds.includes(c.id) ? 'bg-accent text-white' : 'bg-sunken text-ink-3')}>+</button>
                <button type="button" onClick={() => toggle('excludeIds', c.id)} className={clsx('rounded-full px-2 py-0.5 text-[0.75rem] font-semibold', f.excludeIds.includes(c.id) ? 'bg-danger text-white' : 'bg-sunken text-ink-3')}>−</button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Modal>
  );
}

export function FoldersSettings() {
  const t = useT();
  const q = useQuery({ queryKey: ['folders'], queryFn: () => http.get<FolderDto[]>('/api/folders') });
  const [editing, setEditing] = useState<FolderDto | null | 'new'>(null);
  return (
    <SectionPage title={t('settings.folders')}>
      <p className="text-[0.9rem] text-ink-3">{t('settings.folders.empty')}</p>
      <Group>
        {q.isLoading ? (
          <Spinner className="my-3" />
        ) : (
          q.data?.map((f) => (
            <div key={f.id} className="flex items-center gap-3 py-2.5">
              <span className="text-[1.2rem]">{f.emoji ?? '📁'}</span>
              <span className="flex-1 text-[0.95rem] text-ink">{f.name}</span>
              <IconButton label={t('common.edit')} size={34} onClick={() => setEditing(f)}>
                <Pencil size={16} />
              </IconButton>
              <IconButton
                label={t('common.delete')}
                size={34}
                tone="danger"
                onClick={async () => {
                  await http.del(`/api/folders/${f.id}`);
                  await q.refetch();
                }}
              >
                <Trash2 size={16} />
              </IconButton>
            </div>
          ))
        )}
        <button type="button" onClick={() => setEditing('new')} className="flex w-full items-center gap-3 py-3 text-left text-[0.95rem] font-semibold text-accent">
          <Plus size={18} /> {t('settings.folders.create')}
        </button>
      </Group>
      {editing && <FolderEditor folder={editing === 'new' ? null : editing} onClose={() => setEditing(null)} />}
    </SectionPage>
  );
}

export function ShortcutsSettings() {
  const t = useT();
  const mod = /Mac|iPhone/.test(navigator.platform) ? '⌘' : 'Ctrl';
  const rows: Array<[string[], string]> = [
    [[mod, 'K'], t('settings.shortcuts.search')],
    [['Enter'], t('settings.shortcuts.send')],
    [['Shift', 'Enter'], t('settings.shortcuts.newline')],
    [['↑'], t('settings.shortcuts.editLast')],
    [['Esc'], t('settings.shortcuts.close')],
    [['Alt', '↑ / ↓'], t('settings.shortcuts.nextChat')],
  ];
  return (
    <SectionPage title={t('settings.shortcuts')}>
      <Group>
        {rows.map(([keys, label]) => (
          <Row key={label} label={label}>
            <span className="flex gap-1">
              {keys.map((k) => (
                <Kbd key={k}>{k}</Kbd>
              ))}
            </span>
          </Row>
        ))}
      </Group>
    </SectionPage>
  );
}

export function AboutSettings() {
  const t = useT();
  const config = useAuth((s) => s.config);
  const health = useQuery({ queryKey: ['health'], queryFn: () => http.get<{ status: string; checks: Record<string, string> }>('/api/health') });
  const integrations: Array<[string, boolean | undefined]> = [
    ['Email (SMTP)', config?.emailConfigured],
    ['TURN relay (calls)', config?.turnConfigured],
    ['GIF search', config?.gifConfigured],
    ['Web Push', config?.pushConfigured],
    ['Captcha (Turnstile)', Boolean(config?.captcha.provider)],
    ['End-to-end encryption', false],
  ];
  return (
    <SectionPage title={t('settings.about')}>
      <div className="flex items-center gap-4">
        <Logo size={56} />
        <div>
          <p className="text-[1.2rem] font-extrabold text-ink">PulseGram</p>
          <p className="text-[0.88rem] text-ink-3">
            {t('pages.version', { v: APP_VERSION })} · {t('app.slogan')}
          </p>
        </div>
      </div>
      <Group title={t('pages.status')}>
        {health.isLoading ? (
          <Spinner className="my-3" />
        ) : (
          Object.entries(health.data?.checks ?? {}).map(([k, v]) => (
            <Row key={k} label={k}>
              <span className={clsx('text-[0.85rem] font-semibold', v === 'ok' || v === 'configured' || v === 'local' || v === 's3' ? 'text-success' : v === 'error' ? 'text-danger' : 'text-ink-3')}>{v}</span>
            </Row>
          ))
        )}
      </Group>
      <Group title="Integrations">
        {integrations.map(([k, on]) => (
          <Row key={k} label={k}>
            <span className={clsx('text-[0.85rem] font-semibold', on ? 'text-success' : 'text-ink-3')}>{on ? 'Configured' : t('common.notConfigured')}</span>
          </Row>
        ))}
      </Group>
      <div className="flex flex-wrap gap-x-5 gap-y-2 text-[0.9rem]">
        <Link className="text-accent hover:underline" to="/about">{t('pages.about')}</Link>
        <Link className="text-accent hover:underline" to="/changelog">{t('pages.changelog')}</Link>
        <Link className="text-accent hover:underline" to="/help">{t('pages.help')}</Link>
        <Link className="text-accent hover:underline" to="/privacy">{t('pages.privacy')}</Link>
        <Link className="text-accent hover:underline" to="/terms">{t('pages.terms')}</Link>
        <Link className="text-accent hover:underline" to="/status">{t('pages.status')}</Link>
      </div>
    </SectionPage>
  );
}
