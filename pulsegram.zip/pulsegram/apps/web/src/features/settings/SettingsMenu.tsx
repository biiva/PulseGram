import { clsx } from 'clsx';
import { Bell, ChevronRight, Database, Folder, Info, Keyboard, Languages, LifeBuoy, LogOut, MonitorSmartphone, Palette, Shield, User } from 'lucide-react';
import { NavLink, useNavigate } from 'react-router-dom';
import { Avatar } from '../../components/ui/Avatar';
import { confirmDialog } from '../../components/ui/Modal';
import { useT } from '../../i18n';
import { http } from '../../lib/api';
import { queryClient } from '../../lib/queryClient';
import { realtime } from '../../lib/realtime';
import { useAuth } from '../../stores/auth';
import { useChat } from '../../stores/chat';

export const SECTIONS = [
  { id: 'profile', icon: User, key: 'settings.profile' },
  { id: 'privacy', icon: Shield, key: 'settings.privacy' },
  { id: 'devices', icon: MonitorSmartphone, key: 'settings.devices' },
  { id: 'notifications', icon: Bell, key: 'settings.notifications' },
  { id: 'appearance', icon: Palette, key: 'settings.appearance' },
  { id: 'language', icon: Languages, key: 'settings.language' },
  { id: 'folders', icon: Folder, key: 'settings.folders' },
  { id: 'shortcuts', icon: Keyboard, key: 'settings.shortcuts' },
  { id: 'data', icon: Database, key: 'settings.data' },
  { id: 'about', icon: Info, key: 'settings.about' },
] as const;

export async function logout(nav: (p: string, o?: { replace: boolean }) => void) {
  await http.post('/api/auth/logout').catch(() => {});
  realtime.stop();
  useChat.getState().reset();
  queryClient.clear();
  useAuth.getState().clear();
  nav('/welcome', { replace: true });
}

export function SettingsMenu() {
  const t = useT();
  const nav = useNavigate();
  const me = useAuth((s) => s.me)!;
  return (
    <div className="flex h-full flex-col">
      <header className="px-4 pt-4 pb-2">
        <h1 className="text-[1.35rem] font-extrabold tracking-[-0.02em] text-ink">{t('settings.title')}</h1>
      </header>
      <div className="scroll-y min-h-0 flex-1 px-2 pb-3">
        <NavLink to="/settings/profile" className="mb-2 flex items-center gap-3 rounded-[16px] p-3 hover:bg-sunken">
          <Avatar id={me.id} name={me.displayName} src={me.avatarUrl} size={56} />
          <span className="min-w-0 flex-1">
            <span className="block truncate text-[1.02rem] font-bold text-ink">{me.displayName}</span>
            <span className="block truncate text-[0.85rem] text-ink-3">@{me.username}</span>
          </span>
        </NavLink>
        {SECTIONS.map((s) => (
          <NavLink
            key={s.id}
            to={`/settings/${s.id}`}
            className={({ isActive }) => clsx('flex items-center gap-3.5 rounded-[12px] px-3 py-2.5 text-[0.95rem]', isActive ? 'bg-soft text-accent' : 'text-ink hover:bg-sunken')}
          >
            <s.icon size={20} className="shrink-0 opacity-80" />
            <span className="flex-1">{t(s.key)}</span>
            <ChevronRight size={17} className="text-ink-3 md:hidden" />
          </NavLink>
        ))}
        <NavLink to="/help" className="flex items-center gap-3.5 rounded-[12px] px-3 py-2.5 text-[0.95rem] text-ink hover:bg-sunken">
          <LifeBuoy size={20} className="opacity-80" /> {t('settings.help')}
        </NavLink>
        <button
          type="button"
          className="flex w-full items-center gap-3.5 rounded-[12px] px-3 py-2.5 text-left text-[0.95rem] text-danger hover:bg-danger/10"
          onClick={async () => {
            const r = await confirmDialog({ title: t('auth.logout'), body: t('auth.logoutConfirm'), danger: true, confirmLabel: t('auth.logout') });
            if (r.ok) await logout(nav);
          }}
        >
          <LogOut size={20} /> {t('auth.logout')}
        </button>
      </div>
    </div>
  );
}
