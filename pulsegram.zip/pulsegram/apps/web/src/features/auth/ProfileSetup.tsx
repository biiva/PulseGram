import { Camera } from 'lucide-react';
import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LIMITS, type Me } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { Button } from '../../components/ui/Button';
import { Textarea } from '../../components/ui/Field';
import { useT } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { uploadFile } from '../../lib/upload';
import { useAuth } from '../../stores/auth';
import { AuthLayout } from './AuthLayout';

export function ProfileSetupPage() {
  const t = useT();
  const nav = useNavigate();
  const me = useAuth((s) => s.me)!;
  const setMe = useAuth((s) => s.setMe);
  const [bio, setBio] = useState(me.bio);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const finish = async (skip: boolean) => {
    setBusy(true);
    try {
      const updated = await http.patch<Me>('/api/me/profile', skip ? {} : { bio });
      setMe(updated);
      nav('/chat', { replace: true });
    } catch (err) {
      setError(errorText(t, err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout title={t('auth.setup.title')} subtitle={t('auth.setup.body')}>
      <div className="flex flex-col gap-6">
        <div className="flex items-center gap-5">
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            className="group relative rounded-full"
            aria-label={t('auth.setup.photo')}
          >
            <Avatar id={me.id} name={me.displayName} src={me.avatarUrl} size={88} />
            <span className="absolute inset-0 grid place-items-center rounded-full bg-black/40 text-white opacity-0 transition group-hover:opacity-100 group-focus-visible:opacity-100">
              <Camera size={24} />
            </span>
            {uploading !== null && (
              <span className="absolute inset-0 grid place-items-center rounded-full bg-black/50 text-sm font-semibold text-white">{Math.round(uploading * 100)}%</span>
            )}
          </button>
          <div>
            <p className="text-[1.05rem] font-bold text-ink">{me.displayName}</p>
            <p className="text-[0.9rem] text-ink-3">@{me.username}</p>
            <Button variant="soft" size="sm" className="mt-2" onClick={() => fileRef.current?.click()} icon={<Camera size={15} />}>
              {t('auth.setup.photo')}
            </Button>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/jpeg,image/png,image/webp,image/gif,image/avif"
            hidden
            onChange={async (e) => {
              const f = e.target.files?.[0];
              e.target.value = '';
              if (!f) return;
              setUploading(0);
              setError(null);
              try {
                const h = uploadFile(f, f.name, { url: '/api/me/avatar', method: 'PUT', onProgress: setUploading });
                const updated = (await h.promise) as unknown as Me;
                setMe(updated);
              } catch (err) {
                setError(errorText(t, err));
              } finally {
                setUploading(null);
              }
            }}
          />
        </div>
        <Textarea
          label={t('settings.bio')}
          value={bio}
          maxLength={LIMITS.bio}
          onChange={(e) => setBio(e.target.value)}
          hint={t('settings.bioHint', { n: LIMITS.bio - bio.length })}
        />
        {error && <p role="alert" className="text-[0.88rem] text-danger">{error}</p>}
        <div className="flex gap-3">
          <Button variant="ghost" onClick={() => void finish(true)} disabled={busy}>
            {t('auth.setup.skip')}
          </Button>
          <Button className="flex-1" size="lg" onClick={() => void finish(false)} loading={busy}>
            {t('common.next')}
          </Button>
        </div>
      </div>
    </AuthLayout>
  );
}
