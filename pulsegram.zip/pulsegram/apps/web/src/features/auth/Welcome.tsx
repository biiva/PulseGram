import { Link } from 'react-router-dom';
import { Logo, PulseLine } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { LanguageSwitch } from './LanguageSwitch';

export function WelcomePage() {
  const t = useT();
  return (
    <div className="relative flex min-h-dvh flex-col overflow-hidden bg-[#140f2b] text-white">
      <div className="pointer-events-none absolute -top-32 -right-32 size-[30rem] rounded-full bg-[#7c4dff] opacity-35 blur-[120px]" />
      <div className="pointer-events-none absolute bottom-0 -left-40 size-[26rem] rounded-full bg-[#35b6ff] opacity-20 blur-[120px]" />
      <header className="relative z-10 flex items-center justify-between px-6 py-5 sm:px-10">
        <span className="inline-flex items-center gap-3">
          <Logo size={38} />
          <span className="text-lg font-extrabold tracking-[-0.02em]">PulseGram</span>
        </span>
        <div className="rounded-full bg-white/10 text-white [&_*]:text-white [&_option]:text-black">
          <LanguageSwitch />
        </div>
      </header>

      <main className="relative z-10 mx-auto flex w-full max-w-5xl flex-1 flex-col justify-center px-6 pb-16 sm:px-10">
        <PulseLine className="h-24 w-full sm:h-36" color="#a487ff" />
        <h1 className="mt-10 max-w-[14ch] text-[2.6rem] leading-[1.02] font-extrabold tracking-[-0.035em] sm:text-[4.4rem]">
          {t('auth.welcome.title')}
        </h1>
        <p className="mt-6 max-w-[46ch] text-[1.05rem] leading-relaxed text-white/70 sm:text-lg">{t('auth.welcome.body')}</p>
        <div className="mt-10 flex flex-col gap-3 sm:flex-row">
          <Link
            to="/register"
            className="inline-flex h-13 items-center justify-center rounded-full bg-white px-8 text-[1rem] font-bold text-[#140f2b] transition hover:bg-[#ece6ff]"
          >
            {t('auth.welcome.create')}
          </Link>
          <Link
            to="/login"
            className="inline-flex h-13 items-center justify-center rounded-full border border-white/25 px-8 text-[1rem] font-semibold text-white transition hover:bg-white/10"
          >
            {t('auth.welcome.signin')}
          </Link>
        </div>
      </main>

      <footer className="relative z-10 flex flex-wrap gap-x-6 gap-y-2 px-6 pb-6 text-sm text-white/50 sm:px-10">
        <span>{t('app.slogan')}</span>
        <Link to="/about" className="hover:text-white">{t('pages.about')}</Link>
        <Link to="/terms" className="hover:text-white">{t('pages.terms')}</Link>
        <Link to="/privacy" className="hover:text-white">{t('pages.privacy')}</Link>
      </footer>
    </div>
  );
}
