import type { ReactNode } from 'react';
import { Link } from 'react-router-dom';
import { Logo, PulseLine } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { LanguageSwitch } from './LanguageSwitch';

export function AuthLayout({ title, subtitle, children, footer }: { title: string; subtitle?: ReactNode; children: ReactNode; footer?: ReactNode }) {
  const t = useT();
  return (
    <div className="grid min-h-dvh bg-bg lg:grid-cols-[1.05fr_1fr]">
      <aside className="relative hidden overflow-hidden bg-[#140f2b] text-white lg:flex lg:flex-col lg:justify-between lg:p-12">
        <Link to="/welcome" className="relative z-10 inline-flex items-center gap-3 self-start">
          <Logo size={40} />
          <span className="text-xl font-extrabold tracking-[-0.02em]">PulseGram</span>
        </Link>
        <div className="relative z-10">
          <PulseLine className="mb-10 h-28 w-full" color="#9d7bff" />
          <p className="max-w-[16ch] text-[2.6rem] leading-[1.05] font-extrabold tracking-[-0.03em]">{t('auth.welcome.title')}</p>
          <p className="mt-5 max-w-[42ch] text-[1.02rem] leading-relaxed text-white/65">{t('auth.welcome.body')}</p>
        </div>
        <p className="relative z-10 text-sm text-white/45">{t('app.slogan')}</p>
        <div className="pointer-events-none absolute -right-40 -bottom-40 size-[34rem] rounded-full bg-[#7c4dff] opacity-30 blur-[120px]" />
        <div className="pointer-events-none absolute top-24 -left-24 size-72 rounded-full bg-[#35b6ff] opacity-20 blur-[100px]" />
      </aside>
      <main className="flex flex-col px-5 py-6 sm:px-10">
        <div className="flex items-center justify-between">
          <Link to="/welcome" className="lg:invisible" aria-label="PulseGram">
            <Logo size={34} withText />
          </Link>
          <LanguageSwitch />
        </div>
        <div className="mx-auto flex w-full max-w-[400px] flex-1 flex-col justify-center py-10">
          <h1 className="text-[1.75rem] font-extrabold tracking-[-0.02em] text-ink">{title}</h1>
          {subtitle && <p className="mt-2 text-[0.95rem] leading-relaxed text-ink-3">{subtitle}</p>}
          <div className="mt-8">{children}</div>
          {footer && <div className="mt-8 text-center text-[0.9rem] text-ink-3">{footer}</div>}
        </div>
        <nav className="flex flex-wrap justify-center gap-x-5 gap-y-1 text-[0.8rem] text-ink-3">
          <Link to="/about" className="hover:text-ink">{t('pages.about')}</Link>
          <Link to="/terms" className="hover:text-ink">{t('pages.terms')}</Link>
          <Link to="/privacy" className="hover:text-ink">{t('pages.privacy')}</Link>
          <Link to="/help" className="hover:text-ink">{t('pages.help')}</Link>
        </nav>
      </main>
    </div>
  );
}
