import { CheckCircle2, MailCheck, XCircle } from 'lucide-react';
import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { passwordSchema, type Me } from '@pulsegram/shared';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Field';
import { Spinner } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { errorText, fieldText, http } from '../../lib/api';
import { useAuth } from '../../stores/auth';
import { AuthLayout } from './AuthLayout';
import { PasswordMeter } from './Register';
import { Turnstile } from './Turnstile';

export function ForgotPasswordPage() {
  const t = useT();
  const config = useAuth((s) => s.config);
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [captcha, setCaptcha] = useState<string | undefined>();
  const onToken = useCallback((tok: string | undefined) => setCaptcha(tok), []);

  if (config && !config.emailConfigured) {
    return (
      <AuthLayout title={t('auth.forgot.title')}>
        <p className="rounded-[14px] border border-warning/40 bg-warning/10 p-4 text-[0.92rem] leading-relaxed text-ink-2">{t('auth.emailNotConfigured')}</p>
        <Link to="/login" className="mt-6 inline-block font-semibold text-accent hover:underline">{t('common.back')}</Link>
      </AuthLayout>
    );
  }

  return (
    <AuthLayout title={t('auth.forgot.title')} subtitle={sent ? undefined : t('auth.forgot.body')} footer={<Link to="/login" className="font-semibold text-accent hover:underline">{t('auth.login.submit')}</Link>}>
      {sent ? (
        <div className="flex flex-col items-start gap-4">
          <span className="grid size-12 place-items-center rounded-2xl bg-soft text-accent">
            <MailCheck size={24} />
          </span>
          <p className="text-[0.95rem] leading-relaxed text-ink-2">{t('auth.forgot.sent', { email })}</p>
        </div>
      ) : (
        <form
          className="flex flex-col gap-4"
          onSubmit={async (e) => {
            e.preventDefault();
            setBusy(true);
            setError(null);
            try {
              await http.post('/api/auth/forgot-password', { email, captchaToken: captcha });
              setSent(true);
            } catch (err) {
              setError(errorText(t, err));
            } finally {
              setBusy(false);
            }
          }}
        >
          <Input label={t('auth.field.email')} type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} autoFocus />
          <Turnstile siteKey={config?.captcha.siteKey} onToken={onToken} />
          {error && <p role="alert" className="text-[0.88rem] text-danger">{error}</p>}
          <Button type="submit" size="lg" block loading={busy} disabled={!email}>
            {t('auth.forgot.submit')}
          </Button>
        </form>
      )}
    </AuthLayout>
  );
}

export function ResetPasswordPage() {
  const t = useT();
  const [params] = useSearchParams();
  const token = params.get('token') ?? '';
  const [password, setPassword] = useState('');
  const [repeat, setRepeat] = useState('');
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fieldErr, setFieldErr] = useState<string | undefined>();

  return (
    <AuthLayout title={t('auth.reset.title')}>
      {done ? (
        <div className="flex flex-col items-start gap-4">
          <CheckCircle2 className="text-success" size={32} />
          <p className="text-[0.95rem] text-ink-2">{t('auth.reset.done')}</p>
          <Link to="/login" className="font-semibold text-accent hover:underline">{t('auth.login.submit')}</Link>
        </div>
      ) : (
        <form
          className="flex flex-col gap-4"
          onSubmit={async (e) => {
            e.preventDefault();
            const r = passwordSchema.safeParse(password);
            if (!r.success) return setFieldErr(fieldText(t, r.error.issues[0]?.message));
            if (password !== repeat) return setError(t('auth.password.mismatch'));
            setBusy(true);
            setError(null);
            try {
              await http.post('/api/auth/reset-password', { token, password });
              setDone(true);
            } catch (err) {
              setError(errorText(t, err));
            } finally {
              setBusy(false);
            }
          }}
        >
          <div>
            <Input label={t('auth.field.newPassword')} type="password" autoComplete="new-password" value={password} onChange={(e) => { setPassword(e.target.value); setFieldErr(undefined); }} error={fieldErr} autoFocus />
            <PasswordMeter password={password} />
          </div>
          <Input label={t('auth.field.passwordRepeat')} type="password" autoComplete="new-password" value={repeat} onChange={(e) => setRepeat(e.target.value)} />
          {error && <p role="alert" className="text-[0.88rem] text-danger">{error}</p>}
          <Button type="submit" size="lg" block loading={busy} disabled={!token || !password}>
            {t('auth.reset.submit')}
          </Button>
          {!token && <p className="text-[0.85rem] text-danger">{t('error.token_invalid')}</p>}
        </form>
      )}
    </AuthLayout>
  );
}

export function VerifyEmailPage() {
  const t = useT();
  const nav = useNavigate();
  const [params] = useSearchParams();
  const token = params.get('token') ?? '';
  const status = useAuth((s) => s.status);
  const setMe = useAuth((s) => s.setMe);
  const [state, setState] = useState<'pending' | 'ok' | 'error'>('pending');
  const [error, setError] = useState('');
  const ran = useRef(false);

  useEffect(() => {
    if (ran.current) return;
    ran.current = true;
    http
      .post<{ ok: boolean; me: Me | null }>('/api/auth/verify-email', { token })
      .then((r) => {
        if (r.me) setMe(r.me);
        setState('ok');
      })
      .catch((err) => {
        setError(errorText(t, err));
        setState('error');
      });
  }, [token, setMe, t]);

  return (
    <AuthLayout title={t('auth.verify.title')}>
      {state === 'pending' && <Spinner size={28} className="text-accent" />}
      {state === 'ok' && (
        <div className="flex flex-col items-start gap-4">
          <CheckCircle2 className="text-success" size={36} />
          <p className="text-[1rem] text-ink">{t('auth.verify.ok')}</p>
          <Button onClick={() => nav(status === 'authed' ? '/chat' : '/login')}>{t('auth.verify.continue')}</Button>
        </div>
      )}
      {state === 'error' && (
        <div className="flex flex-col items-start gap-4">
          <XCircle className="text-danger" size={36} />
          <p className="text-[0.95rem] text-ink-2">{error}</p>
          <Link to={status === 'authed' ? '/chat' : '/login'} className="font-semibold text-accent hover:underline">{t('common.back')}</Link>
        </div>
      )}
    </AuthLayout>
  );
}
