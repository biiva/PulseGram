import { Languages } from 'lucide-react';
import { LANGUAGES, type Language } from '@pulsegram/shared';
import { LANGUAGE_NAMES, useLang } from '../../i18n';
import { applyAppearance, usePrefs } from '../../stores/prefs';

/** Pre-login language switch (after login the choice is stored in the account preferences). */
export function LanguageSwitch() {
  const lang = useLang();
  return (
    <label className="inline-flex items-center gap-1.5 rounded-full px-2 py-1 text-[0.85rem] text-ink-3 hover:bg-sunken">
      <Languages size={16} />
      <select
        aria-label="Language"
        className="cursor-pointer bg-transparent outline-none"
        value={lang}
        onChange={(e) => {
          const language = e.target.value as Language;
          usePrefs.getState().setAppearanceLocal({ language, timeFormat: language === 'ru' ? '24h' : '12h', dateFormat: language === 'ru' ? 'dmy' : 'mdy' });
          applyAppearance(usePrefs.getState().appearance);
        }}
      >
        {LANGUAGES.map((l) => (
          <option key={l} value={l}>
            {LANGUAGE_NAMES[l]}
          </option>
        ))}
      </select>
    </label>
  );
}
