import { clsx } from 'clsx';
import { CheckCircle2, XCircle } from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { passwordStrength, registerSchema, USERNAME_RE, type Me, type Preferences } from '@pulsegram/shared';
import { Button } from '../../components/ui/Button';
import { Checkbox, Input } from '../../components/ui/Field';
import { Spinner } from '../../components/ui/misc';
import { useLang, useT } from '../../i18n';
import { ApiError, errorText, fieldText, http } from '../../lib/api';
import { useAuth } from '../../stores/auth';
import { AuthLayout } from './AuthLayout';
import { Turnstile } from './Turnstile';

export function PasswordMeter({ password }: { password: string }) {
  const t = useT();
  if (!password) return null;
  const s = passwordStrength(password);
  const colors = ['bg-danger', 'bg-danger', 'bg-warning', 'bg-success', 'bg-success'];
  return (
    <div className="mt-1.5 flex items-center gap-3" aria-live="polite">
      <div className="flex flex-1 gap-1">
        {[0, 1, 2, 3].map((i) => (
          <span key={i} className={clsx('h-1.5 flex-1 rounded-full transition-colors', i < Math.max(1, s) ? colors[s] : 'bg-line')} />
        ))}
      </div>
      <span className="text-[0.78rem] text-ink-3">{t(`auth.password.strength.${s}` as 'auth.password.strength.0')}</span>
    </div>
  );
}

type UState = 'idle' | 'checking' | 'available' | 'taken' | 'invalid';

export function useUsernameCheck(username: string, current?: string) {
  const [state, setState] = useState<UState>('idle');
  useEffect(() => {
    if (!username || (current && username.toLowerCase() === current.toLowerCase())) {
      setState('idle');
      return;
    }
    if (!USERNAME_RE.test(username)) {
      setState('invalid');
      return;
    }
    setState('checking');
    const ctrl = new AbortController();
    const id = setTimeout(() => {
      http
        .get<{ available: boolean }>(`/api/auth/username-available?username=${encodeURIComponent(username)}`, { signal: ctrl.signal, quiet401: true })
        .then((r) => setState(r.available ? 'available' : 'taken'))
        .catch(() => setState('idle'));
    }, 350);
    return () => {
      clearTimeout(id);
      ctrl.abort();
    };
  }, [username, current]);
  return state;
}

export function UsernameStatus({ state, username }: { state: UState; username: string }) {
  const t = useT();
  if (state === 'checking')
    return (
      <span className="inline-flex items-center gap-1.5 text-ink-3">
        <Spinner size={13} /> {t('auth.username.checking')}
      </span>
    );
  if (state === 'available')
    return (
      <span className="inline-flex items-center gap-1.5 text-success">
        <CheckCircle2 size={14} /> {t('auth.username.available', { u: username })}
      </span>
    );
  if (state === 'taken')
    return (
      <span className="inline-flex items-center gap-1.5 text-danger">
        <XCircle size={14} /> {t('auth.username.taken', { u: username })}
      </span>
    );
  return <>{t('auth.field.usernameHint')}</>;
}

export function RegisterPage() {
  const t = useT();
  const lang = useLang();
  const nav = useNavigate();
  const setSession = useAuth((s) => s.setSession);
  const config = useAuth((s) => s.config);
  const [form, setForm] = useState({ displayName: '', username: '', email: '', password: '', repeat: '', website: '' });
  const [accept, setAccept] = useState(false);
  const [captcha, setCaptcha] = useState<string | undefined>();
  const [errors, setErrors] = useState<Record<string, string | undefined>>({});
  const [formError, setFormError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const uState = useUsernameCheck(form.username);
  const onToken = useCallback((tok: string | undefined) => setCaptcha(tok), []);

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => {
    setForm((f) => ({ ...f, [k]: e.target.value }));
    setErrors((er) => ({ ...er, [k]: undefined }));
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setFormError(null);
    const payload = { displayName: form.displayName, username: form.username, email: form.email, password: form.password, acceptTerms: accept, website: form.website || undefined, captchaToken: captcha, language: lang };
    const parsed = registerSchema.safeParse(payload);
    const errs: Record<string, string | undefined> = {};
    if (!parsed.success) for (const i of parsed.error.issues) errs[String(i.path[0])] ??= fieldText(t, i.message);
    if (form.password !== form.repeat) errs.repeat = t('auth.password.mismatch');
    if (uState === 'taken') errs.username = t('error.username_taken');
    if (Object.values(errs).some(Boolean)) {
      setErrors(errs);
      return;
    }
    setBusy(true);
    try {
      const res = await http.post<{ me: Me; preferences: Preferences }>('/api/auth/register', payload);
      setSession(res.me, res.preferences);
      nav('/setup-profile', { replace: true });
    } catch (err) {
      if (err instanceof ApiError && Object.keys(err.fieldErrors).length) {
        setErrors(Object.fromEntries(Object.entries(err.fieldErrors).map(([k, v]) => [k, fieldText(t, v)])));
      } else setFormError(errorText(t, err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout
      title={t('auth.register.title')}
      subtitle={t('auth.register.subtitle')}
      footer={
        <>
          {t('auth.register.haveAccount')}{' '}
          <Link to="/login" className="font-semibold text-accent hover:underline">
            {t('auth.login.submit')}
          </Link>
        </>
      }
    >
      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        <Input label={t('auth.field.displayName')} autoComplete="name" value={form.displayName} onChange={set('displayName')} error={errors.displayName} maxLength={64} autoFocus />
        <Input
          label={t('auth.field.username')}
          autoComplete="username"
          value={form.username}
          onChange={set('username')}
          leading={<span className="text-[0.95rem]">@</span>}
          error={errors.username}
          hint={<UsernameStatus state={uState} username={form.username} />}
          maxLength={32}
          spellCheck={false}
        />
        <Input label={t('auth.field.email')} type="email" autoComplete="email" value={form.email} onChange={set('email')} error={errors.email} />
        <div>
          <Input label={t('auth.field.password')} type="password" autoComplete="new-password" value={form.password} onChange={set('password')} error={errors.password} />
          <PasswordMeter password={form.password} />
        </div>
        <Input label={t('auth.field.passwordRepeat')} type="password" autoComplete="new-password" value={form.repeat} onChange={set('repeat')} error={errors.repeat} />
        {/* Honeypot — invisible to people, tempting to bots. */}
        <input type="text" name="website" tabIndex={-1} autoComplete="off" value={form.website} onChange={set('website')} className="absolute -left-[9999px] h-0 w-0 opacity-0" aria-hidden="true" />
        <div>
          <Checkbox checked={accept} onChange={(v) => { setAccept(v); setErrors((er) => ({ ...er, acceptTerms: undefined })); }}>
            {(() => {
              const parts = t('auth.register.terms').split(/(\{terms\}|\{privacy\})/);
              return parts.map((p, i) =>
                p === '{terms}' ? (
                  <Link key={i} to="/terms" target="_blank" className="font-medium text-accent hover:underline">{t('auth.register.termsLink')}</Link>
                ) : p === '{privacy}' ? (
                  <Link key={i} to="/privacy" target="_blank" className="font-medium text-accent hover:underline">{t('auth.register.privacyLink')}</Link>
                ) : (
                  <span key={i}>{p}</span>
                ),
              );
            })()}
          </Checkbox>
          {errors.acceptTerms && <p className="mt-1 text-[0.8rem] text-danger">{errors.acceptTerms}</p>}
        </div>
        <Turnstile siteKey={config?.captcha.siteKey} onToken={onToken} />
        {formError && (
          <p role="alert" className="rounded-[12px] bg-danger/10 px-3.5 py-2.5 text-[0.88rem] text-danger">
            {formError}
          </p>
        )}
        <Button type="submit" size="lg" block loading={busy}>
          {t('auth.register.submit')}
        </Button>
      </form>
    </AuthLayout>
  );
}
