import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import type { Me, Preferences } from '@pulsegram/shared';
import { Button } from '../../components/ui/Button';
import { Input } from '../../components/ui/Field';
import { useT } from '../../i18n';
import { ApiError, errorText, http } from '../../lib/api';
import { useAuth } from '../../stores/auth';
import { AuthLayout } from './AuthLayout';

export function LoginPage() {
  const t = useT();
  const nav = useNavigate();
  const loc = useLocation();
  const setSession = useAuth((s) => s.setSession);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await http.post<{ me: Me; preferences: Preferences }>('/api/auth/login', { email, password });
      setSession(res.me, res.preferences);
      const from = (loc.state as { from?: string } | null)?.from;
      nav(from && from.startsWith('/') ? from : '/chat', { replace: true });
    } catch (err) {
      setError(err instanceof ApiError && err.code === 'validation_failed' ? t('error.invalid_credentials') : errorText(t, err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout
      title={t('auth.login.title')}
      subtitle={t('auth.login.subtitle')}
      footer={
        <>
          {t('auth.login.noAccount')}{' '}
          <Link to="/register" className="font-semibold text-accent hover:underline">
            {t('auth.login.createOne')}
          </Link>
        </>
      }
    >
      <form onSubmit={submit} className="flex flex-col gap-4" noValidate>
        <Input label={t('auth.field.email')} type="email" autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} required data-autofocus autoFocus />
        <Input label={t('auth.field.password')} type="password" autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <div className="-mt-1 flex justify-end">
          <Link to="/forgot-password" className="text-[0.85rem] font-medium text-accent hover:underline">
            {t('auth.login.forgot')}
          </Link>
        </div>
        {error && (
          <p role="alert" className="rounded-[12px] bg-danger/10 px-3.5 py-2.5 text-[0.88rem] text-danger">
            {error}
          </p>
        )}
        <Button type="submit" size="lg" block loading={busy} disabled={!email || !password}>
          {t('auth.login.submit')}
        </Button>
      </form>
    </AuthLayout>
  );
}
