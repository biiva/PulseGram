import { useQuery } from '@tanstack/react-query';
import { useVirtualizer } from '@tanstack/react-virtual';
import { clsx } from 'clsx';
import {
  Archive,
  ArchiveRestore,
  Bell,
  BellOff,
  CheckCheck,
  MailOpen,
  MessageSquarePlus,
  Pin,
  PinOff,
  Search,
  Trash2,
  LogOut,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { ConversationDto, FolderDto } from '@pulsegram/shared';
import { Button, IconButton } from '../../components/ui/Button';
import { openMenu, type MenuItem } from '../../components/ui/Menu';
import { confirmDialog } from '../../components/ui/Modal';
import { EmptyState, Skeleton } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { markRead, updateMembership } from '../../lib/chatActions';
import { isMuted, sortConversations, useChat } from '../../stores/chat';
import { toast, useUi, type ChatFilter } from '../../stores/ui';
import { useNewChatMenu } from '../layout/NavRail';
import { ChatListItem } from './ChatListItem';
import { SearchResults } from './SearchResults';

function matchesFilter(c: ConversationDto, f: ChatFilter, folders: FolderDto[]): boolean {
  if (f === 'archive') return Boolean(c.me?.isArchived);
  if (f.startsWith('folder:')) {
    const folder = folders.find((x) => x.id === f.slice(7));
    if (!folder) return !c.me?.isArchived;
    if (folder.excludeIds.includes(c.id)) return false;
    if (folder.includeIds.includes(c.id)) return true;
    if (folder.excludeArchived && c.me?.isArchived) return false;
    if (folder.excludeMuted && isMuted(c)) return false;
    if (folder.unreadOnly && !(c.unreadCount > 0 || c.me?.markedUnread)) return false;
    return c.type !== 'saved' && folder.includeTypes.includes(c.type as 'direct');
  }
  if (c.me?.isArchived) return false;
  if (f === 'all') return true;
  if (f === 'unread') return c.unreadCount > 0 || Boolean(c.me?.markedUnread);
  return c.type === f;
}

export function useConversationMenu() {
  const t = useT();
  const nav = useNavigate();
  return useCallback(
    (e: { clientX?: number; clientY?: number; currentTarget?: EventTarget | null }, c: ConversationDto) => {
      const muted = isMuted(c);
      const run = (p: Promise<unknown>) => p.catch((err: unknown) => toast({ text: errorText(t, err), tone: 'danger' }));
      const mute = (ms: number | 'forever') => run(updateMembership(c.id, { mutedUntil: ms === 'forever' ? 'forever' : new Date(Date.now() + ms).toISOString() }));
      const items: MenuItem[] = [
        c.me?.isPinned
          ? { label: t('chats.unpin'), icon: <PinOff size={17} />, onSelect: () => run(updateMembership(c.id, { isPinned: false })) }
          : { label: t('chats.pin'), icon: <Pin size={17} />, onSelect: () => run(updateMembership(c.id, { isPinned: true })) },
      ];
      if (c.type !== 'saved') {
        items.push(
          c.unreadCount > 0 || c.me?.markedUnread
            ? { label: t('chats.markRead'), icon: <CheckCheck size={17} />, onSelect: () => markRead(c.id, c.lastMessage?.seq ?? c.me?.lastReadSeq ?? 0) }
            : { label: t('chats.markUnread'), icon: <MailOpen size={17} />, onSelect: () => run(updateMembership(c.id, { markUnread: true })) },
          muted
            ? { label: t('chats.unmute'), icon: <Bell size={17} />, onSelect: () => run(updateMembership(c.id, { mutedUntil: null })) }
            : {
                label: t('chats.mute'),
                children: [
                  { label: t('chats.mute1h'), icon: <BellOff size={17} />, onSelect: () => mute(3600_000) },
                  { label: t('chats.mute8h'), icon: <BellOff size={17} />, onSelect: () => mute(8 * 3600_000) },
                  { label: t('chats.mute1d'), icon: <BellOff size={17} />, onSelect: () => mute(86400_000) },
                  { label: t('chats.muteForever'), icon: <BellOff size={17} />, onSelect: () => mute('forever') },
                ],
              },
          c.me?.isArchived
            ? { label: t('chats.unarchive'), icon: <ArchiveRestore size={17} />, onSelect: () => run(updateMembership(c.id, { isArchived: false })) }
            : { label: t('chats.archive'), icon: <Archive size={17} />, onSelect: () => run(updateMembership(c.id, { isArchived: true })) },
          { divider: true, label: '' },
          c.type === 'direct'
            ? {
                label: t('chats.delete'),
                icon: <Trash2 size={17} />,
                danger: true,
                onSelect: async () => {
                  const r = await confirmDialog({ title: t('chats.delete'), body: t('chats.deleteConfirm'), danger: true, confirmLabel: t('common.delete') });
                  if (!r.ok) return;
                  await run(http.post(`/api/conversations/${c.id}/leave`).then(() => useChat.getState().removeConversation(c.id)));
                  nav('/chat');
                },
              }
            : {
                label: t('chats.leave'),
                icon: <LogOut size={17} />,
                danger: true,
                onSelect: async () => {
                  const r = await confirmDialog({ title: t('chats.leave'), body: t('chats.leaveConfirm', { title: c.title }), danger: true, confirmLabel: t('chats.leave') });
                  if (!r.ok) return;
                  await run(http.post(`/api/conversations/${c.id}/leave`).then(() => useChat.getState().removeConversation(c.id)));
                  nav('/chat');
                },
              },
        );
      }
      openMenu(e, items);
    },
    [t, nav],
  );
}

export function ChatListPanel() {
  const t = useT();
  const nav = useNavigate();
  const listLoaded = useChat((s) => s.listLoaded);
  const conversations = useChat((s) => s.conversations);
  const activeId = useChat((s) => s.activeId);
  const connection = useChat((s) => s.connection);
  const filter = useUi((s) => s.filter);
  const setFilter = useUi((s) => s.setFilter);
  const newChat = useNewChatMenu();
  const onContext = useConversationMenu();
  const [q, setQ] = useState('');
  const searchRef = useRef<HTMLInputElement>(null);
  const folders = useQuery({ queryKey: ['folders'], queryFn: () => http.get<FolderDto[]>('/api/folders') });

  const list = useMemo(
    () => sortConversations(Object.values(conversations).filter((c) => matchesFilter(c, filter, folders.data ?? []))),
    [conversations, filter, folders.data],
  );
  const archivedCount = useMemo(() => Object.values(conversations).filter((c) => c.me?.isArchived).length, [conversations]);

  // Ctrl/Cmd+K focuses search; Alt+↑/↓ moves between chats.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        searchRef.current?.focus();
      }
      if (e.altKey && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
        e.preventDefault();
        const i = list.findIndex((c) => c.id === activeId);
        const next = list[Math.max(0, Math.min(list.length - 1, i + (e.key === 'ArrowDown' ? 1 : -1)))];
        if (next) nav(`/chat/${next.id}`);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [list, activeId, nav]);

  const scrollRef = useRef<HTMLDivElement>(null);
  const virtual = useVirtualizer({
    count: list.length,
    getScrollElement: () => scrollRef.current,
    estimateSize: () => (document.documentElement.dataset.density === 'compact' ? 62 : 74),
    overscan: 8,
  });
  const open = useCallback((id: string) => nav(`/chat/${id}`), [nav]);

  const tabs: Array<{ id: ChatFilter; label: string }> = [
    { id: 'all', label: t('chats.allFolder') },
    { id: 'unread', label: t('nav.unread') },
    ...(folders.data ?? []).map((f) => ({ id: `folder:${f.id}` as ChatFilter, label: `${f.emoji ? f.emoji + ' ' : ''}${f.name}` })),
  ];
  const typeTitles: Partial<Record<ChatFilter, string>> = {
    direct: t('nav.direct'),
    group: t('nav.groups'),
    channel: t('nav.channels'),
    archive: t('chats.archived'),
  };

  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center gap-2 px-4 pt-4 pb-2">
        {typeTitles[filter] ? (
          <>
            <IconButton label={t('common.back')} size={34} onClick={() => setFilter('all')}>
              <X size={18} />
            </IconButton>
            <h1 className="flex-1 truncate text-[1.35rem] font-extrabold tracking-[-0.02em] text-ink">{typeTitles[filter]}</h1>
          </>
        ) : (
          <h1 className="flex-1 text-[1.35rem] font-extrabold tracking-[-0.02em] text-ink">
            {connection === 'online' ? t('chats.title') : connection === 'syncing' ? t('chat.updating') : connection === 'offline' ? t('chat.waitingNetwork') : t('chat.connecting')}
          </h1>
        )}
        <IconButton label={t('nav.newMessage')} tone="accent" onClick={newChat}>
          <MessageSquarePlus size={21} />
        </IconButton>
      </header>
      <div className="px-4 pb-2">
        <label className="relative flex items-center">
          <Search size={17} className="pointer-events-none absolute left-3.5 text-ink-3" />
          <input
            ref={searchRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Escape') {
                setQ('');
                searchRef.current?.blur();
              }
            }}
            placeholder={t('chats.searchPlaceholder')}
            aria-label={t('common.search')}
            className="h-10 w-full rounded-full border border-transparent bg-sunken pr-9 pl-10 text-[0.9rem] text-ink outline-none placeholder:text-ink-3 focus:border-accent focus:bg-raised"
          />
          {q && (
            <button type="button" className="absolute right-2 grid size-7 place-items-center rounded-full text-ink-3 hover:bg-line" onClick={() => setQ('')} aria-label={t('search.clear')}>
              <X size={15} />
            </button>
          )}
        </label>
      </div>

      {q.trim() ? (
        <SearchResults q={q.trim()} onDone={() => setQ('')} />
      ) : (
        <>
          {!typeTitles[filter] && (
            <div role="tablist" className="flex gap-1 overflow-x-auto px-3 pb-1 [scrollbar-width:none]">
              {tabs.map((tab) => (
                <button
                  key={tab.id}
                  role="tab"
                  aria-selected={filter === tab.id}
                  onClick={() => setFilter(tab.id)}
                  className={clsx(
                    'shrink-0 rounded-full px-3 py-1.5 text-[0.83rem] font-semibold transition-colors',
                    filter === tab.id ? 'bg-soft text-accent' : 'text-ink-3 hover:bg-sunken hover:text-ink',
                  )}
                >
                  {tab.label}
                </button>
              ))}
              {archivedCount > 0 && (
                <button onClick={() => setFilter('archive')} className="ml-auto flex shrink-0 items-center gap-1 rounded-full px-3 py-1.5 text-[0.83rem] font-semibold text-ink-3 hover:bg-sunken md:hidden">
                  <Archive size={14} /> {archivedCount}
                </button>
              )}
            </div>
          )}
          <div ref={scrollRef} className="scroll-y min-h-0 flex-1 px-2 pb-2">
            {!listLoaded ? (
              <div className="flex flex-col gap-1 p-2">
                {Array.from({ length: 8 }).map((_, i) => (
                  <div key={i} className="flex items-center gap-3 py-2">
                    <Skeleton className="size-12 rounded-full" />
                    <div className="flex-1">
                      <Skeleton className="h-3.5 w-1/2" />
                      <Skeleton className="mt-2 h-3 w-4/5" />
                    </div>
                  </div>
                ))}
              </div>
            ) : list.length === 0 ? (
              <EmptyState
                icon={filter === 'archive' ? <Archive size={24} /> : <MessageSquarePlus size={24} />}
                title={filter === 'all' ? t('chats.empty.title') : t('chats.empty.filter')}
                body={filter === 'all' ? t('chats.empty.body') : filter === 'archive' ? t('chats.empty.archive') : undefined}
                action={
                  filter === 'all' ? (
                    <Button onClick={newChat} icon={<MessageSquarePlus size={17} />}>
                      {t('chat.empty.cta')}
                    </Button>
                  ) : undefined
                }
              />
            ) : (
              <div style={{ height: virtual.getTotalSize(), position: 'relative' }}>
                {virtual.getVirtualItems().map((row) => {
                  const c = list[row.index]!;
                  return (
                    <div key={c.id} data-index={row.index} ref={virtual.measureElement} className="absolute inset-x-0 py-[1px]" style={{ transform: `translateY(${row.start}px)` }}>
                      <ChatListItem c={c} active={c.id === activeId} onOpen={open} onContext={onContext} />
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
