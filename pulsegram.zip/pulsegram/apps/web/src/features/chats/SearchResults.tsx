import { useQuery } from '@tanstack/react-query';
import { History, X } from 'lucide-react';
import { useEffect, useState, type ReactNode } from 'react';
import { useNavigate } from 'react-router-dom';
import type { SearchResults as Results } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { EmptyState, Spinner } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { openDirectWith } from '../../lib/chatActions';
import { formatListTime, presenceText } from '../../lib/format';
import { useChat } from '../../stores/chat';
import { usePrefs } from '../../stores/prefs';
import { toast } from '../../stores/ui';
import { messagePreview } from './ChatListItem';

const HISTORY_KEY = 'pg.searchHistory';

export function useDebounced<T>(value: T, ms = 250): T {
  const [v, setV] = useState(value);
  useEffect(() => {
    const id = setTimeout(() => setV(value), ms);
    return () => clearTimeout(id);
  }, [value, ms]);
  return v;
}

export function Highlight({ text, q }: { text: string; q: string }) {
  if (!q) return <>{text}</>;
  const i = text.toLowerCase().indexOf(q.toLowerCase());
  if (i < 0) return <>{text}</>;
  // Show the match even when it is deep inside a long message.
  const start = Math.max(0, i - 30);
  return (
    <>
      {start > 0 && '…'}
      {text.slice(start, i)}
      <mark className="rounded bg-accent/20 px-0.5 text-inherit">{text.slice(i, i + q.length)}</mark>
      {text.slice(i + q.length)}
    </>
  );
}

function readHistory(): string[] {
  try {
    return JSON.parse(localStorage.getItem(HISTORY_KEY) ?? '[]') as string[];
  } catch {
    return [];
  }
}
function pushHistory(q: string) {
  try {
    const h = [q, ...readHistory().filter((x) => x !== q)].slice(0, 10);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(h));
  } catch {
    /* ignore */
  }
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="mb-2">
      <h3 className="px-3 pt-3 pb-1.5 text-[0.78rem] font-semibold text-ink-3">{title}</h3>
      {children}
    </section>
  );
}

function Row({ children, onClick }: { children: ReactNode; onClick: () => void }) {
  return (
    <button type="button" onClick={onClick} className="flex w-full items-center gap-3 rounded-[14px] px-2.5 py-2 text-left hover:bg-sunken">
      {children}
    </button>
  );
}

export function SearchResults({ q, onDone }: { q: string; onDone: () => void }) {
  const t = useT();
  const nav = useNavigate();
  const fmt = usePrefs((s) => s.appearance);
  const users = useChat((s) => s.users);
  const dq = useDebounced(q);
  const enabled = dq.replace(/^@/, '').length >= 2;
  const res = useQuery({
    queryKey: ['search', dq],
    queryFn: ({ signal }) => http.get<Results>(`/api/search?q=${encodeURIComponent(dq)}`, { signal }),
    enabled,
    staleTime: 10_000,
  });

  const go = (path: string) => {
    pushHistory(q);
    onDone();
    nav(path);
  };

  if (!enabled) {
    const history = readHistory();
    return (
      <div className="scroll-y flex-1 px-2">
        {history.length ? (
          <Section title={t('search.recent')}>
            {history.map((h) => (
              <div key={h} className="flex items-center gap-2 rounded-[12px] px-3 py-2 text-[0.9rem] text-ink-2">
                <History size={16} className="text-ink-3" />
                <span className="flex-1 truncate">{h}</span>
              </div>
            ))}
            <button
              type="button"
              className="mx-3 mt-1 inline-flex items-center gap-1 text-[0.82rem] font-semibold text-accent"
              onClick={() => {
                localStorage.removeItem(HISTORY_KEY);
                onDone();
              }}
            >
              <X size={14} /> {t('search.clear')}
            </button>
          </Section>
        ) : (
          <p className="px-4 py-6 text-center text-[0.88rem] text-ink-3">{t('search.hint')}</p>
        )}
      </div>
    );
  }

  if (res.isLoading)
    return (
      <div className="grid flex-1 place-items-center text-ink-3">
        <Spinner />
      </div>
    );
  if (res.isError) return <p className="px-4 py-6 text-center text-[0.88rem] text-danger">{errorText(t, res.error)}</p>;
  const d = res.data!;
  const empty = !d.users.length && !d.conversations.length && !d.publicConversations.length && !d.messages.length;
  if (empty) return <EmptyState title={t('search.noResults', { q: dq })} />;

  return (
    <div className="scroll-y flex-1 px-2 pb-3">
      {d.conversations.length > 0 && (
        <Section title={t('search.chats')}>
          {d.conversations.map((c) => (
            <Row key={c.id} onClick={() => go(`/chat/${c.id}`)}>
              <Avatar id={c.peer?.id ?? c.id} name={c.type === 'saved' ? t('chats.saved') : c.title} src={c.avatarUrl} size={42} kind={c.type === 'saved' ? 'saved' : c.type === 'direct' ? 'user' : c.type} />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[0.93rem] font-semibold text-ink">
                  <Highlight text={c.type === 'saved' ? t('chats.saved') : c.title} q={dq} />
                </span>
                <span className="block truncate text-[0.82rem] text-ink-3">{c.username ? `@${c.username}` : c.type === 'direct' ? presenceText(c.peer?.presence, fmt, t) : t('common.members', { n: c.memberCount })}</span>
              </span>
            </Row>
          ))}
        </Section>
      )}
      {d.users.length > 0 && (
        <Section title={t('search.people')}>
          {d.users.map((u) => (
            <Row
              key={u.id}
              onClick={async () => {
                try {
                  const c = await openDirectWith(u.id);
                  go(`/chat/${c.id}`);
                } catch (err) {
                  toast({ text: errorText(t, err), tone: 'danger' });
                }
              }}
            >
              <Avatar id={u.id} name={u.displayName} src={u.avatarUrl} size={42} online={u.presence.kind === 'online'} />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[0.93rem] font-semibold text-ink">
                  <Highlight text={u.displayName} q={dq} />
                </span>
                <span className="block truncate text-[0.82rem] text-ink-3">
                  @<Highlight text={u.username} q={dq.replace(/^@/, '')} />
                </span>
              </span>
            </Row>
          ))}
        </Section>
      )}
      {d.publicConversations.length > 0 && (
        <Section title={t('search.public')}>
          {d.publicConversations.map((c) => (
            <Row key={c.id} onClick={() => go(`/chat/${c.id}`)}>
              <Avatar id={c.id} name={c.title} src={c.avatarUrl} size={42} kind={c.type === 'channel' ? 'channel' : 'group'} />
              <span className="min-w-0 flex-1">
                <span className="block truncate text-[0.93rem] font-semibold text-ink">
                  <Highlight text={c.title} q={dq} />
                </span>
                <span className="block truncate text-[0.82rem] text-ink-3">
                  {c.username ? `@${c.username} · ` : ''}
                  {c.type === 'channel' ? t('common.subscribers', { n: c.memberCount }) : t('common.members', { n: c.memberCount })}
                </span>
              </span>
            </Row>
          ))}
        </Section>
      )}
      {d.messages.length > 0 && (
        <Section title={t('search.messages')}>
          {d.messages.map(({ message: m, conversation: c }) => (
            <Row key={m.id} onClick={() => go(`/chat/${c.id}?msg=${m.seq}`)}>
              <Avatar id={c.id} name={c.type === 'saved' ? t('chats.saved') : c.title} src={c.avatarUrl} size={42} kind={c.type === 'saved' ? 'saved' : c.type === 'direct' ? 'user' : c.type} />
              <span className="min-w-0 flex-1">
                <span className="flex items-center gap-2">
                  <span className="min-w-0 flex-1 truncate text-[0.93rem] font-semibold text-ink">{c.type === 'saved' ? t('chats.saved') : c.title}</span>
                  <span className="shrink-0 text-[0.75rem] text-ink-3">{formatListTime(m.createdAt, fmt)}</span>
                </span>
                <span className="block truncate text-[0.84rem] text-ink-3">
                  {c.type === 'group' && m.senderId && users[m.senderId] ? `${users[m.senderId]!.displayName.split(' ')[0]}: ` : ''}
                  <Highlight text={m.text || messagePreview(m, t)} q={dq} />
                </span>
              </span>
            </Row>
          ))}
        </Section>
      )}
    </div>
  );
}
