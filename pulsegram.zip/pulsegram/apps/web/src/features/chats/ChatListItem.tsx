import { clsx } from 'clsx';
import { AtSign, BellOff, Check, CheckCheck, Clock, Megaphone, Pin, Users } from 'lucide-react';
import { memo } from 'react';
import type { ConversationDto, MessageDto } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { Badge } from '../../components/ui/misc';
import { useT, type TFn } from '../../i18n';
import { formatListTime } from '../../lib/format';
import { isMuted, useChat } from '../../stores/chat';
import { usePrefs } from '../../stores/prefs';
import { systemText } from '../chat/systemText';

export function messagePreview(m: MessageDto, t: TFn): string {
  if (m.type === 'system') return '';
  if (m.text) return m.text.replace(/\s+/g, ' ');
  if (m.type === 'voice') return `🎤 ${t('chat.voiceMessage')}`;
  if (m.type === 'sticker') return `${m.sticker?.emoji ?? ''} ${t('chat.sticker')}`;
  if (m.type === 'gif') return t('chat.gif');
  const k = m.attachments[0]?.kind;
  const n = m.attachments.length;
  const label = k === 'image' ? t('chat.photo') : k === 'video' ? t('chat.video') : k === 'audio' ? t('chat.audio') : t('chat.file');
  const icon = k === 'image' ? '🖼' : k === 'video' ? '🎬' : k === 'audio' ? '🎵' : '📎';
  return `${icon} ${n > 1 ? `${label} ×${n}` : k === 'file' ? (m.attachments[0]?.name ?? label) : label}`;
}

function DeliveryTicks({ m, peerReadSeq }: { m: MessageDto; peerReadSeq: number }) {
  if (!m.seq) return <Clock size={14} className="text-ink-3" />;
  return peerReadSeq >= m.seq ? <CheckCheck size={16} className="text-accent" /> : <Check size={16} className="text-ink-3" />;
}

export const ChatListItem = memo(function ChatListItem({
  c,
  active,
  onOpen,
  onContext,
}: {
  c: ConversationDto;
  active: boolean;
  onOpen: (id: string) => void;
  onContext: (e: React.MouseEvent, c: ConversationDto) => void;
}) {
  const t = useT();
  const fmt = usePrefs((s) => s.appearance);
  const myId = useChat((s) => s.myId);
  const presence = useChat((s) => (c.peer ? s.presence[c.peer.id] : undefined));
  const typing = useChat((s) => s.typing[c.id]);
  const sender = useChat((s) => (c.lastMessage?.senderId ? s.users[c.lastMessage.senderId] : undefined));
  const users = useChat((s) => s.users);
  const muted = isMuted(c);
  const last = c.lastMessage;
  const draft = c.me?.draft && !active ? c.me.draft : '';
  const typingIds = Object.entries(typing ?? {}).filter(([, v]) => v.until > Date.now());
  const isSaved = c.type === 'saved';
  const title = isSaved ? t('chats.saved') : c.title || t('chats.deletedAccount');
  const online = (presence ?? c.peer?.presence)?.kind === 'online';
  const unread = c.unreadCount || (c.me?.markedUnread ? 1 : 0);

  let preview: React.ReactNode;
  if (typingIds.length) {
    preview = <span className="text-accent">{c.type === 'direct' ? t('chat.typing') : t('chat.typingName', { name: users[typingIds[0]![0]]?.displayName.split(' ')[0] ?? '…' })}</span>;
  } else if (draft) {
    preview = (
      <>
        <span className="text-danger">{t('chats.draft')} </span>
        {draft}
      </>
    );
  } else if (last) {
    const prefix = last.type === 'system' ? '' : last.senderId === myId && !isSaved ? t('chats.you') : c.type === 'group' && sender ? `${sender.displayName.split(' ')[0]}:` : '';
    preview = (
      <>
        {prefix && <span className="text-ink-2">{prefix} </span>}
        {last.type === 'system' ? systemText(last, users, t, myId) : messagePreview(last, t)}
      </>
    );
  } else {
    preview = isSaved ? t('chats.savedHint') : '';
  }

  return (
    <button
      type="button"
      onClick={() => onOpen(c.id)}
      onContextMenu={(e) => {
        e.preventDefault();
        onContext(e, c);
      }}
      aria-current={active ? 'true' : undefined}
      className={clsx(
        'flex w-full items-center gap-3 rounded-[14px] px-2.5 text-left transition-colors',
        active ? 'bg-accent text-white' : 'hover:bg-sunken',
      )}
      style={{ height: 'var(--row-h)' }}
    >
      <Avatar id={c.peer?.id ?? c.id} name={title} src={c.avatarUrl} size={48} online={online && c.type === 'direct'} kind={isSaved ? 'saved' : c.type === 'direct' ? 'user' : c.type} />
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-1.5">
          {c.type === 'group' && <Users size={14} className={clsx('shrink-0', active ? 'text-white/80' : 'text-ink-3')} />}
          {c.type === 'channel' && <Megaphone size={14} className={clsx('shrink-0', active ? 'text-white/80' : 'text-ink-3')} />}
          <span className={clsx('truncate text-[0.95rem] font-semibold', active ? 'text-white' : 'text-ink')}>{title}</span>
          {muted && <BellOff size={13} className={clsx('shrink-0', active ? 'text-white/70' : 'text-ink-3')} />}
          {c.isDemo && <span className={clsx('shrink-0 rounded px-1 text-[0.62rem] font-semibold', active ? 'bg-white/20' : 'bg-sunken text-ink-3')}>{t('common.demo')}</span>}
          <span className="ml-auto flex shrink-0 items-center gap-1 pl-2">
            {last && last.senderId === myId && last.type !== 'system' && !isSaved && !draft && (
              <span className={active ? '[&_svg]:!text-white' : ''}>
                <DeliveryTicks m={last} peerReadSeq={c.peerReadSeq} />
              </span>
            )}
            <span className={clsx('text-[0.75rem] tabular-nums', active ? 'text-white/80' : unread && !muted ? 'text-accent' : 'text-ink-3')}>
              {formatListTime(c.lastActivityAt, fmt)}
            </span>
          </span>
        </span>
        <span className="mt-0.5 flex items-center gap-2">
          <span className={clsx('min-w-0 flex-1 truncate text-[0.86rem]', active ? 'text-white/85 [&_span]:!text-white/90' : 'text-ink-3')}>{preview}</span>
          {c.unreadMentions > 0 && (
            <span className="grid size-5 shrink-0 place-items-center rounded-full bg-accent text-white">
              <AtSign size={12} />
            </span>
          )}
          {unread > 0 ? (
            <Badge count={c.unreadCount || 1} muted={muted} className={clsx(active && '!bg-white !text-accent')} />
          ) : c.me?.isPinned ? (
            <Pin size={14} className={clsx('shrink-0 rotate-45', active ? 'text-white/70' : 'text-ink-3')} />
          ) : null}
        </span>
      </span>
    </button>
  );
});
