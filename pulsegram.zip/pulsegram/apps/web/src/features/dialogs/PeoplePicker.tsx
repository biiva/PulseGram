import { useQuery } from '@tanstack/react-query';
import { clsx } from 'clsx';
import { Check, Search } from 'lucide-react';
import { useState } from 'react';
import type { UserSummary } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { Spinner } from '../../components/ui/misc';
import { useLang, useT } from '../../i18n';
import { http } from '../../lib/api';
import { presenceText } from '../../lib/format';
import { usePrefs } from '../../stores/prefs';
import { useDebounced } from '../chats/SearchResults';

/** Search people by name/@username; shows contacts when the query is empty. */
export function PeoplePicker({
  multi,
  selected,
  onPick,
  exclude = [],
}: {
  multi?: boolean;
  selected?: string[];
  onPick: (u: UserSummary) => void;
  exclude?: string[];
}) {
  const t = useT();
  const lang = useLang();
  const fmt = usePrefs((s) => s.appearance);
  const [q, setQ] = useState('');
  const dq = useDebounced(q.trim(), 250);
  const contacts = useQuery({ queryKey: ['contacts'], queryFn: () => http.get<UserSummary[]>('/api/contacts') });
  const search = useQuery({
    queryKey: ['user-search', dq],
    queryFn: ({ signal }) => http.get<UserSummary[]>(`/api/users/search?q=${encodeURIComponent(dq)}`, { signal }),
    enabled: dq.replace(/^@/, '').length >= 2,
  });
  const list = (dq.length >= 2 ? search.data : contacts.data)?.filter((u) => !exclude.includes(u.id)) ?? [];
  const loading = dq.length >= 2 ? search.isLoading : contacts.isLoading;
  return (
    <div className="flex flex-col">
      <label className="relative mb-2 flex items-center">
        <Search size={16} className="absolute left-3 text-ink-3" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder={t('new.searchPeople')}
          className="h-10 w-full rounded-full bg-sunken pr-3 pl-9 text-[0.92rem] outline-none focus:ring-2 focus:ring-accent/40"
          data-autofocus
        />
      </label>
      <div className="-mx-2 min-h-40">
        {loading ? (
          <div className="grid h-32 place-items-center text-ink-3">
            <Spinner />
          </div>
        ) : list.length === 0 ? (
          <p className="px-3 py-8 text-center text-[0.88rem] text-ink-3">{dq.length >= 2 ? t('new.noPeople') : t('contacts.empty')}</p>
        ) : (
          list.map((u) => {
            const on = selected?.includes(u.id);
            return (
              <button key={u.id} type="button" onClick={() => onPick(u)} className="flex w-full items-center gap-3 rounded-[12px] px-2 py-2 text-left hover:bg-sunken">
                <Avatar id={u.id} name={u.displayName} src={u.avatarUrl} size={42} online={u.presence.kind === 'online'} />
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[0.93rem] font-semibold text-ink">{u.displayName}</span>
                  <span className="block truncate text-[0.8rem] text-ink-3">
                    @{u.username} · {presenceText(u.presence, { ...fmt, language: lang }, t)}
                  </span>
                </span>
                {multi && (
                  <span className={clsx('grid size-6 place-items-center rounded-full border-2', on ? 'border-accent bg-accent text-white' : 'border-line-strong')}>
                    {on && <Check size={14} strokeWidth={3} />}
                  </span>
                )}
              </button>
            );
          })
        )}
      </div>
    </div>
  );
}
