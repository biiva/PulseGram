import { clsx } from 'clsx';
import { Check, Search } from 'lucide-react';
import { useMemo, useState } from 'react';
import { can } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { Button } from '../../components/ui/Button';
import { Checkbox } from '../../components/ui/Field';
import { Modal } from '../../components/ui/Modal';
import { useT } from '../../i18n';
import { errorText } from '../../lib/api';
import { forwardMessages } from '../../lib/chatActions';
import { sortConversations, useChat } from '../../stores/chat';
import { toast } from '../../stores/ui';

export function ForwardDialog({ messageIds, onClose }: { messageIds: string[]; onClose: () => void }) {
  const t = useT();
  const conversations = useChat((s) => s.conversations);
  const [q, setQ] = useState('');
  const [picked, setPicked] = useState<string[]>([]);
  const [hide, setHide] = useState(false);
  const [busy, setBusy] = useState(false);
  const list = useMemo(
    () =>
      sortConversations(Object.values(conversations)).filter(
        (c) => c.me && can.sendMessage({ type: c.type, role: c.me.role, settings: c.settings }) && (c.type === 'saved' ? t('chats.saved') : c.title).toLowerCase().includes(q.toLowerCase()),
      ),
    [conversations, q, t],
  );
  return (
    <Modal
      open
      onClose={onClose}
      title={t('forward.title')}
      width={440}
      footer={
        <>
          <div className="mr-auto self-center">
            <Checkbox checked={hide} onChange={setHide}>
              {t('forward.hideSender')}
            </Checkbox>
          </div>
          <Button
            disabled={!picked.length}
            loading={busy}
            onClick={async () => {
              setBusy(true);
              try {
                await forwardMessages(messageIds, picked, hide);
                toast(t('forward.done'));
                onClose();
              } catch (err) {
                toast({ text: errorText(t, err), tone: 'danger' });
              } finally {
                setBusy(false);
              }
            }}
          >
            {t('forward.send')}
          </Button>
        </>
      }
    >
      <label className="relative mb-2 flex items-center">
        <Search size={16} className="absolute left-3 text-ink-3" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('common.search')} className="h-10 w-full rounded-full bg-sunken pr-3 pl-9 text-[0.92rem] outline-none" data-autofocus />
      </label>
      <div className="-mx-2">
        {list.map((c) => {
          const on = picked.includes(c.id);
          const title = c.type === 'saved' ? t('chats.saved') : c.title;
          return (
            <button
              key={c.id}
              type="button"
              onClick={() => setPicked((p) => (on ? p.filter((x) => x !== c.id) : p.length >= 20 ? p : [...p, c.id]))}
              className="flex w-full items-center gap-3 rounded-[12px] px-2 py-2 text-left hover:bg-sunken"
            >
              <Avatar id={c.peer?.id ?? c.id} name={title} src={c.avatarUrl} size={40} kind={c.type === 'saved' ? 'saved' : c.type === 'direct' ? 'user' : c.type} />
              <span className="min-w-0 flex-1 truncate text-[0.93rem] font-semibold text-ink">{title}</span>
              <span className={clsx('grid size-6 place-items-center rounded-full border-2', on ? 'border-accent bg-accent text-white' : 'border-line-strong')}>{on && <Check size={14} strokeWidth={3} />}</span>
            </button>
          );
        })}
      </div>
    </Modal>
  );
}
