import { X } from 'lucide-react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CHANNEL_CATEGORIES, createChannelSchema, createGroupSchema, type ConversationDto, type UserSummary } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { Button } from '../../components/ui/Button';
import { Input, Segmented, Select, Textarea } from '../../components/ui/Field';
import { Modal } from '../../components/ui/Modal';
import { useT, type MessageKey } from '../../i18n';
import { ApiError, errorText, fieldText, http } from '../../lib/api';
import { openDirectWith } from '../../lib/chatActions';
import { useChat } from '../../stores/chat';
import { toast } from '../../stores/ui';
import { UsernameStatus, useUsernameCheck } from '../auth/Register';
import { PeoplePicker } from './PeoplePicker';

export function NewMessageDialog({ onClose }: { onClose: () => void }) {
  const t = useT();
  const nav = useNavigate();
  return (
    <Modal open onClose={onClose} title={t('chats.newMessage')} width={440}>
      <PeoplePicker
        onPick={async (u) => {
          try {
            const c = await openDirectWith(u.id);
            onClose();
            nav(`/chat/${c.id}`);
          } catch (err) {
            toast({ text: errorText(t, err), tone: 'danger' });
          }
        }}
      />
    </Modal>
  );
}

function Chips({ users, onRemove }: { users: UserSummary[]; onRemove: (id: string) => void }) {
  if (!users.length) return null;
  return (
    <div className="mb-3 flex flex-wrap gap-1.5">
      {users.map((u) => (
        <span key={u.id} className="inline-flex items-center gap-1.5 rounded-full bg-soft py-0.5 pr-1 pl-0.5 text-[0.82rem] font-medium text-accent">
          <Avatar id={u.id} name={u.displayName} src={u.avatarUrl} size={22} />
          {u.displayName.split(' ')[0]}
          <button type="button" aria-label="Remove" onClick={() => onRemove(u.id)} className="grid size-5 place-items-center rounded-full hover:bg-accent/15">
            <X size={13} />
          </button>
        </span>
      ))}
    </div>
  );
}

function VisibilityFields({
  isPublic,
  setPublic,
  username,
  setUsername,
  error,
}: {
  isPublic: boolean;
  setPublic: (v: boolean) => void;
  username: string;
  setUsername: (v: string) => void;
  error?: string;
}) {
  const t = useT();
  const u = useUsernameCheck(isPublic ? username : '');
  return (
    <div className="flex flex-col gap-3">
      <Segmented
        value={isPublic ? 'public' : 'private'}
        onChange={(v) => setPublic(v === 'public')}
        options={[
          { value: 'private', label: t('new.private') },
          { value: 'public', label: t('new.public') },
        ]}
      />
      <p className="-mt-1 text-[0.82rem] text-ink-3">{isPublic ? t('new.publicHint') : t('new.privateHint')}</p>
      {isPublic && (
        <Input
          label={t('new.publicLink')}
          leading={<span className="text-[0.95rem]">@</span>}
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          error={error}
          hint={<UsernameStatus state={u} username={username} />}
          spellCheck={false}
        />
      )}
    </div>
  );
}

export function NewGroupDialog({ onClose }: { onClose: () => void }) {
  const t = useT();
  const nav = useNavigate();
  const [step, setStep] = useState<1 | 2>(1);
  const [members, setMembers] = useState<UserSummary[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isPublic, setPublic] = useState(false);
  const [username, setUsername] = useState('');
  const [errors, setErrors] = useState<Record<string, string | undefined>>({});
  const [busy, setBusy] = useState(false);

  const create = async () => {
    const input = { title, description, memberIds: members.map((m) => m.id), isPublic, username: isPublic ? username : undefined };
    const r = createGroupSchema.safeParse(input);
    if (!r.success) {
      setErrors(Object.fromEntries(r.error.issues.map((i) => [String(i.path[0]), fieldText(t, i.path[0] === 'title' ? 'required' : i.message)])));
      return;
    }
    setBusy(true);
    try {
      const c = await http.post<ConversationDto & { skippedMembers?: number }>('/api/conversations/group', input);
      useChat.getState().upsertConversation(c);
      if (c.skippedMembers) toast(`${c.skippedMembers} × privacy`);
      onClose();
      nav(`/chat/${c.id}`);
    } catch (err) {
      if (err instanceof ApiError && Object.keys(err.fieldErrors).length) setErrors(Object.fromEntries(Object.entries(err.fieldErrors).map(([k, v]) => [k, fieldText(t, v)])));
      else toast({ text: errorText(t, err), tone: 'danger' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={step === 1 ? t('new.addMembers') : t('chats.newGroup')}
      width={460}
      footer={
        step === 1 ? (
          <>
            <span className="mr-auto self-center text-[0.85rem] text-ink-3">{t('new.selected', { n: members.length })}</span>
            <Button onClick={() => setStep(2)}>{t('common.next')}</Button>
          </>
        ) : (
          <>
            <Button variant="ghost" onClick={() => setStep(1)}>
              {t('common.back')}
            </Button>
            <Button onClick={() => void create()} loading={busy}>
              {t('new.createGroup')}
            </Button>
          </>
        )
      }
    >
      {step === 1 ? (
        <>
          <Chips users={members} onRemove={(id) => setMembers((m) => m.filter((x) => x.id !== id))} />
          <PeoplePicker multi selected={members.map((m) => m.id)} onPick={(u) => setMembers((m) => (m.some((x) => x.id === u.id) ? m.filter((x) => x.id !== u.id) : [...m, u]))} />
        </>
      ) : (
        <div className="flex flex-col gap-4">
          <Input label={t('new.groupTitle')} value={title} onChange={(e) => setTitle(e.target.value)} error={errors.title} maxLength={128} data-autofocus />
          <Textarea label={`${t('new.description')} (${t('common.optional')})`} value={description} onChange={(e) => setDescription(e.target.value)} maxLength={1000} className="min-h-20" />
          <VisibilityFields isPublic={isPublic} setPublic={setPublic} username={username} setUsername={setUsername} error={errors.username} />
        </div>
      )}
    </Modal>
  );
}

export function NewChannelDialog({ onClose }: { onClose: () => void }) {
  const t = useT();
  const nav = useNavigate();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isPublic, setPublic] = useState(true);
  const [username, setUsername] = useState('');
  const [category, setCategory] = useState<(typeof CHANNEL_CATEGORIES)[number]>('other');
  const [errors, setErrors] = useState<Record<string, string | undefined>>({});
  const [busy, setBusy] = useState(false);

  const create = async () => {
    const input = { title, description, isPublic, username: isPublic ? username : undefined, category };
    const r = createChannelSchema.safeParse(input);
    if (!r.success) {
      setErrors(Object.fromEntries(r.error.issues.map((i) => [String(i.path[0]), fieldText(t, i.path[0] === 'title' ? 'required' : i.message)])));
      return;
    }
    if (isPublic && !username) return setErrors({ username: t('error.required') });
    setBusy(true);
    try {
      const c = await http.post<ConversationDto>('/api/conversations/channel', input);
      useChat.getState().upsertConversation(c);
      onClose();
      nav(`/chat/${c.id}`);
    } catch (err) {
      if (err instanceof ApiError && Object.keys(err.fieldErrors).length) setErrors(Object.fromEntries(Object.entries(err.fieldErrors).map(([k, v]) => [k, fieldText(t, v)])));
      else toast({ text: errorText(t, err), tone: 'danger' });
    } finally {
      setBusy(false);
    }
  };

  return (
    <Modal
      open
      onClose={onClose}
      title={t('chats.newChannel')}
      width={460}
      footer={
        <Button onClick={() => void create()} loading={busy}>
          {t('new.createChannel')}
        </Button>
      }
    >
      <div className="flex flex-col gap-4">
        <Input label={t('new.channelTitle')} value={title} onChange={(e) => setTitle(e.target.value)} error={errors.title} maxLength={128} data-autofocus />
        <Textarea label={`${t('new.description')} (${t('common.optional')})`} value={description} onChange={(e) => setDescription(e.target.value)} maxLength={1000} className="min-h-20" />
        <Select
          label={t('new.category')}
          value={category}
          onChange={(e) => setCategory(e.target.value as typeof category)}
          options={CHANNEL_CATEGORIES.map((c) => ({ value: c, label: t(`cat.${c}` as MessageKey) }))}
        />
        <VisibilityFields isPublic={isPublic} setPublic={setPublic} username={username} setUsername={setUsername} error={errors.username} />
      </div>
    </Modal>
  );
}

export function AddMembersDialog({ conversationId, onClose }: { conversationId: string; onClose: () => void }) {
  const t = useT();
  const [members, setMembers] = useState<UserSummary[]>([]);
  const [busy, setBusy] = useState(false);
  return (
    <Modal
      open
      onClose={onClose}
      title={t('info.addMembers')}
      width={460}
      footer={
        <Button
          disabled={!members.length}
          loading={busy}
          onClick={async () => {
            setBusy(true);
            try {
              const r = await http.post<{ added: string[]; skipped: number }>(`/api/conversations/${conversationId}/members`, { userIds: members.map((m) => m.id) });
              toast(`+${r.added.length}`);
              onClose();
            } catch (err) {
              toast({ text: errorText(t, err), tone: 'danger' });
            } finally {
              setBusy(false);
            }
          }}
        >
          {t('common.add')}
        </Button>
      }
    >
      <Chips users={members} onRemove={(id) => setMembers((m) => m.filter((x) => x.id !== id))} />
      <PeoplePicker multi selected={members.map((m) => m.id)} onPick={(u) => setMembers((m) => (m.some((x) => x.id === u.id) ? m.filter((x) => x.id !== u.id) : [...m, u]))} />
    </Modal>
  );
}
