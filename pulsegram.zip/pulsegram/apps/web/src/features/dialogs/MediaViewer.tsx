import { ChevronLeft, ChevronRight, Download, X } from 'lucide-react';
import { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import type { MessageDto } from '@pulsegram/shared';
import { useT } from '../../i18n';
import { formatRelative } from '../../lib/format';
import { useChat } from '../../stores/chat';
import { usePrefs } from '../../stores/prefs';

/** Full-screen viewer for photos and videos with keyboard navigation. */
export function MediaViewer({ items, index, onClose }: { items: MessageDto[]; index: number; onClose: () => void }) {
  const t = useT();
  const fmt = usePrefs((s) => s.appearance);
  const users = useChat((s) => s.users);
  const media = items.flatMap((m) => m.attachments.filter((a) => a.kind === 'image' || a.kind === 'video').map((a) => ({ a, m })));
  const [i, setI] = useState(Math.min(index, media.length - 1));
  const cur = media[i];

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') setI((x) => Math.min(media.length - 1, x + 1));
      if (e.key === 'ArrowLeft') setI((x) => Math.max(0, x - 1));
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [media.length, onClose]);

  if (!cur) return null;
  return createPortal(
    <div className="anim-fade fixed inset-0 z-[80] flex flex-col bg-black/92 text-white" role="dialog" aria-modal="true">
      <div className="flex items-center gap-3 px-4 py-3">
        <div className="min-w-0 flex-1">
          <p className="truncate text-[0.95rem] font-semibold">{users[cur.m.senderId ?? '']?.displayName ?? ''}</p>
          <p className="text-[0.8rem] text-white/60">{formatRelative(cur.m.createdAt, fmt, t)}</p>
        </div>
        <span className="text-[0.85rem] text-white/60 tabular-nums">
          {i + 1} / {media.length}
        </span>
        <a href={`${cur.a.url}?download=1`} download={cur.a.name} className="grid size-10 place-items-center rounded-full hover:bg-white/10" aria-label={t('common.download')}>
          <Download size={20} />
        </a>
        <button type="button" onClick={onClose} className="grid size-10 place-items-center rounded-full hover:bg-white/10" aria-label={t('common.close')}>
          <X size={22} />
        </button>
      </div>
      <div className="relative flex min-h-0 flex-1 items-center justify-center px-2 pb-4" onClick={(e) => e.target === e.currentTarget && onClose()}>
        {cur.a.kind === 'image' ? (
          <img src={cur.a.url} alt={cur.a.name} className="max-h-full max-w-full object-contain select-none" />
        ) : (
          <video key={cur.a.id} src={cur.a.url} controls autoPlay playsInline className="max-h-full max-w-full" />
        )}
        {i > 0 && (
          <button type="button" onClick={() => setI(i - 1)} className="absolute left-3 grid size-12 place-items-center rounded-full bg-white/10 hover:bg-white/20" aria-label="Previous">
            <ChevronLeft size={26} />
          </button>
        )}
        {i < media.length - 1 && (
          <button type="button" onClick={() => setI(i + 1)} className="absolute right-3 grid size-12 place-items-center rounded-full bg-white/10 hover:bg-white/20" aria-label="Next">
            <ChevronRight size={26} />
          </button>
        )}
      </div>
      {cur.m.text && <p className="mx-auto mb-5 max-w-2xl px-4 text-center text-[0.95rem] text-white/85">{cur.m.text}</p>}
    </div>,
    document.body,
  );
}
