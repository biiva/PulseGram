import { useState } from 'react';
import { REPORT_REASONS, type ReportReason } from '@pulsegram/shared';
import { Button } from '../../components/ui/Button';
import { Textarea } from '../../components/ui/Field';
import { Modal } from '../../components/ui/Modal';
import { useT, type MessageKey } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { toast } from '../../stores/ui';

export function ReportDialog({ targetType, targetId, onClose }: { targetType: 'user' | 'message' | 'conversation'; targetId: string; onClose: () => void }) {
  const t = useT();
  const [reason, setReason] = useState<ReportReason>('spam');
  const [details, setDetails] = useState('');
  const [busy, setBusy] = useState(false);
  return (
    <Modal
      open
      onClose={onClose}
      title={t('report.title')}
      width={420}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t('common.cancel')}
          </Button>
          <Button
            variant="danger"
            loading={busy}
            onClick={async () => {
              setBusy(true);
              try {
                await http.post('/api/reports', { targetType, targetId, reason, details: details || undefined });
                toast(t('report.sent'));
                onClose();
              } catch (err) {
                toast({ text: errorText(t, err), tone: 'danger' });
              } finally {
                setBusy(false);
              }
            }}
          >
            {t('report.title')}
          </Button>
        </>
      }
    >
      <fieldset className="flex flex-col gap-1">
        <legend className="mb-2 text-[0.82rem] font-semibold text-ink-2">{t('report.reason')}</legend>
        {REPORT_REASONS.map((r) => (
          <label key={r} className="flex cursor-pointer items-center gap-3 rounded-[10px] px-2 py-2 text-[0.92rem] hover:bg-sunken">
            <input type="radio" name="reason" checked={reason === r} onChange={() => setReason(r)} className="accent-[var(--accent)]" />
            {t(`report.${r}` as MessageKey)}
          </label>
        ))}
      </fieldset>
      <div className="mt-3">
        <Textarea label={`${t('report.details')} (${t('common.optional')})`} value={details} onChange={(e) => setDetails(e.target.value)} maxLength={1000} className="min-h-20" />
      </div>
    </Modal>
  );
}
