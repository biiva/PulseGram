import { useQuery } from '@tanstack/react-query';
import { AtSign, Ban, Calendar, Copy, Mail, MessageCircle, Phone, QrCode, ShieldAlert, UserMinus, UserPlus } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import type { UserProfile } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { Button } from '../../components/ui/Button';
import { confirmDialog, Modal } from '../../components/ui/Modal';
import { Spinner } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { openDirectWith } from '../../lib/chatActions';
import { formatDate, presenceText } from '../../lib/format';
import { queryClient } from '../../lib/queryClient';
import { useAuth } from '../../stores/auth';
import { useChat } from '../../stores/chat';
import { usePrefs } from '../../stores/prefs';
import { toast, useUi } from '../../stores/ui';
import { startCallWithUser } from '../calls/callStore';

function InfoRow({ icon, label, value, onCopy }: { icon: React.ReactNode; label: string; value: string; onCopy?: () => void }) {
  return (
    <div className="flex items-center gap-4 px-1 py-2.5">
      <span className="text-ink-3">{icon}</span>
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[0.93rem] text-ink">{value}</span>
        <span className="block text-[0.78rem] text-ink-3">{label}</span>
      </span>
      {onCopy && (
        <button type="button" onClick={onCopy} className="grid size-8 place-items-center rounded-full text-ink-3 hover:bg-sunken" aria-label="Copy">
          <Copy size={15} />
        </button>
      )}
    </div>
  );
}

export function useUserProfile(userId: string) {
  return useQuery({ queryKey: ['user', userId], queryFn: () => http.get<UserProfile>(`/api/users/${userId}`) });
}

export function ProfileCard({ userId, onNavigate, compact }: { userId: string; onNavigate?: () => void; compact?: boolean }) {
  const t = useT();
  const nav = useNavigate();
  const fmt = usePrefs((s) => s.appearance);
  const meId = useAuth((s) => s.me?.id);
  const livePresence = useChat((s) => s.presence[userId]);
  const open = useUi((s) => s.open);
  const q = useUserProfile(userId);
  const [qr, setQr] = useState(false);
  if (q.isLoading) return <div className="grid h-40 place-items-center text-ink-3"><Spinner /></div>;
  if (q.isError || !q.data) return <p className="p-6 text-center text-danger">{errorText(t, q.error)}</p>;
  const u = q.data;
  const isMe = u.id === meId;
  const link = `${location.origin}/u/${u.username}`;
  const copy = (s: string) => void navigator.clipboard.writeText(s).then(() => toast(t('common.copied')));
  const refresh = () => queryClient.invalidateQueries({ queryKey: ['user', userId] });
  const act = async (fn: () => Promise<unknown>) => {
    try {
      await fn();
      await refresh();
      await queryClient.invalidateQueries({ queryKey: ['contacts'] });
      await queryClient.invalidateQueries({ queryKey: ['blocks'] });
    } catch (err) {
      toast({ text: errorText(t, err), tone: 'danger' });
    }
  };

  return (
    <div>
      <div className="flex flex-col items-center pt-2 text-center">
        <Avatar id={u.id} name={u.displayName} src={u.avatarUrl} size={compact ? 88 : 104} />
        <h2 className="mt-3 text-[1.25rem] font-extrabold tracking-[-0.01em] text-ink">{u.displayName}</h2>
        <p className="text-[0.88rem] text-ink-3">{presenceText(livePresence ?? u.presence, fmt, t)}</p>
        {u.statusText && <p className="mt-1 text-[0.88rem] text-ink-2">{u.statusText}</p>}
        {u.isDemo && <span className="mt-2 rounded bg-sunken px-1.5 text-[0.7rem] font-semibold text-ink-3">{t('common.demo')}</span>}
      </div>
      {!isMe && !u.deleted && (
        <div className="mt-5 grid grid-cols-3 gap-2">
          <Button
            variant="soft"
            className="h-auto flex-col py-2.5"
            icon={<MessageCircle size={20} />}
            disabled={u.blockedViewer}
            onClick={async () => {
              try {
                const c = await openDirectWith(u.id);
                onNavigate?.();
                nav(`/chat/${c.id}`);
              } catch (err) {
                toast({ text: errorText(t, err), tone: 'danger' });
              }
            }}
          >
            {t('info.sendMessage')}
          </Button>
          <Button
            variant="soft"
            className="h-auto flex-col py-2.5"
            icon={<Phone size={20} />}
            disabled={!u.canCall}
            onClick={async () => {
              try {
                await startCallWithUser(u.id, false);
                onNavigate?.();
              } catch (err) {
                toast({ text: errorText(t, err), tone: 'danger' });
              }
            }}
          >
            {t('chat.call')}
          </Button>
          <Button
            variant="soft"
            className="h-auto flex-col py-2.5"
            icon={u.isContact ? <UserMinus size={20} /> : <UserPlus size={20} />}
            onClick={() => void act(() => (u.isContact ? http.del(`/api/contacts/${u.id}`) : http.post('/api/contacts', { userId: u.id })))}
          >
            <span className="text-[0.8rem] leading-tight whitespace-normal">{u.isContact ? t('info.removeContact') : t('info.addContact')}</span>
          </Button>
        </div>
      )}
      <div className="mt-4 divide-y divide-line rounded-[16px] border border-line px-3">
        {u.bio && <p className="px-1 py-3 text-[0.93rem] leading-relaxed whitespace-pre-wrap text-ink">{u.bio}</p>}
        <InfoRow icon={<AtSign size={18} />} label={t('info.username')} value={`@${u.username}`} onCopy={() => copy(link)} />
        {u.phone && <InfoRow icon={<Phone size={18} />} label={t('info.phone')} value={u.phone} onCopy={() => copy(u.phone!)} />}
        {u.email && <InfoRow icon={<Mail size={18} />} label={t('info.email')} value={u.email} onCopy={() => copy(u.email!)} />}
        <InfoRow icon={<Calendar size={18} />} label={t('info.joined', { date: '' }).replace(/\s*$/, '')} value={formatDate(u.createdAt, fmt)} />
        <button type="button" className="flex w-full items-center gap-4 px-1 py-2.5 text-left text-[0.93rem] text-ink hover:text-accent" onClick={() => setQr(true)}>
          <QrCode size={18} className="text-ink-3" /> {t('info.qr')}
        </button>
      </div>
      {u.commonGroups.length > 0 && (
        <div className="mt-4">
          <h3 className="px-1 pb-1.5 text-[0.8rem] font-semibold text-ink-3">{t('info.commonGroups')}</h3>
          {u.commonGroups.map((g) => (
            <button
              key={g.id}
              type="button"
              className="flex w-full items-center gap-3 rounded-[12px] px-1 py-1.5 text-left hover:bg-sunken"
              onClick={() => {
                onNavigate?.();
                nav(`/chat/${g.id}`);
              }}
            >
              <Avatar id={g.id} name={g.title} src={g.avatarUrl} size={36} kind="group" />
              <span className="truncate text-[0.92rem] text-ink">{g.title}</span>
            </button>
          ))}
        </div>
      )}
      {!isMe && !u.deleted && (
        <div className="mt-4 flex flex-col">
          <Button
            variant="ghost"
            className="justify-start !text-danger"
            icon={<Ban size={18} />}
            onClick={async () => {
              if (u.isBlocked) return act(() => http.del(`/api/blocks/${u.id}`));
              const r = await confirmDialog({ title: t('info.block'), body: t('info.blockConfirm', { name: u.displayName }), danger: true, confirmLabel: t('info.block') });
              if (r.ok) await act(() => http.post('/api/blocks', { userId: u.id }));
            }}
          >
            {u.isBlocked ? t('info.unblock') : t('info.block')}
          </Button>
          <Button variant="ghost" className="justify-start !text-danger" icon={<ShieldAlert size={18} />} onClick={() => open({ kind: 'report', targetType: 'user', targetId: u.id })}>
            {t('info.report')}
          </Button>
        </div>
      )}
      <Modal open={qr} onClose={() => setQr(false)} title={t('info.qr')} width={340}>
        <div className="flex flex-col items-center gap-4">
          <div className="rounded-[20px] bg-white p-4">
            <QRCodeSVG value={link} size={220} fgColor="#1A1830" level="M" imageSettings={{ src: '/favicon.svg', height: 40, width: 40, excavate: true }} />
          </div>
          <p className="text-[0.9rem] font-semibold text-ink">@{u.username}</p>
          <Button variant="soft" icon={<Copy size={16} />} onClick={() => copy(link)}>
            {t('chat.copyLink')}
          </Button>
        </div>
      </Modal>
    </div>
  );
}

export function UserDialog({ userId, onClose }: { userId: string; onClose: () => void }) {
  const t = useT();
  return (
    <Modal open onClose={onClose} title={t('info.title')} width={420}>
      <ProfileCard userId={userId} onNavigate={onClose} />
    </Modal>
  );
}
