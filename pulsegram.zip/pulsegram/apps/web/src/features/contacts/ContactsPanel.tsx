import { useQuery } from '@tanstack/react-query';
import { UserPlus, Users } from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type { UserSummary } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { Button, IconButton } from '../../components/ui/Button';
import { EmptyState, Spinner } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { http } from '../../lib/api';
import { presenceText } from '../../lib/format';
import { realtime } from '../../lib/realtime';
import { useChat } from '../../stores/chat';
import { usePrefs } from '../../stores/prefs';
import { useUi } from '../../stores/ui';

export function ContactsPanel() {
  const t = useT();
  const fmt = usePrefs((s) => s.appearance);
  const open = useUi((s) => s.open);
  const presence = useChat((s) => s.presence);
  const [q, setQ] = useState('');
  const contacts = useQuery({ queryKey: ['contacts'], queryFn: () => http.get<UserSummary[]>('/api/contacts') });
  const list = useMemo(() => {
    const s = q.toLowerCase();
    return (contacts.data ?? []).filter((u) => !s || u.displayName.toLowerCase().includes(s) || u.username.toLowerCase().includes(s));
  }, [contacts.data, q]);

  // Live presence for everyone on screen.
  useEffect(() => {
    const ids = (contacts.data ?? []).map((u) => u.id);
    const peers = Object.values(useChat.getState().conversations).map((c) => c.peer?.id).filter((x): x is string => Boolean(x));
    realtime.subscribePresence([...ids, ...peers]);
  }, [contacts.data]);

  const online = list.filter((u) => (presence[u.id] ?? u.presence).kind === 'online');
  const rest = list.filter((u) => (presence[u.id] ?? u.presence).kind !== 'online');

  const row = (u: UserSummary) => (
    <button key={u.id} type="button" onClick={() => open({ kind: 'user', userId: u.id })} className="flex w-full items-center gap-3 rounded-[14px] px-2.5 py-2 text-left hover:bg-sunken">
      <Avatar id={u.id} name={u.displayName} src={u.avatarUrl} size={46} online={(presence[u.id] ?? u.presence).kind === 'online'} />
      <span className="min-w-0 flex-1">
        <span className="block truncate text-[0.95rem] font-semibold text-ink">{u.displayName}</span>
        <span className="block truncate text-[0.82rem] text-ink-3">{presenceText(presence[u.id] ?? u.presence, fmt, t)}</span>
      </span>
    </button>
  );

  return (
    <div className="flex h-full flex-col">
      <header className="flex items-center gap-2 px-4 pt-4 pb-2">
        <h1 className="flex-1 text-[1.35rem] font-extrabold tracking-[-0.02em] text-ink">{t('contacts.title')}</h1>
        <IconButton label={t('contacts.find')} tone="accent" onClick={() => open({ kind: 'new-message' })}>
          <UserPlus size={21} />
        </IconButton>
      </header>
      <div className="px-4 pb-2">
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('common.search')} className="h-10 w-full rounded-full bg-sunken px-4 text-[0.9rem] outline-none focus:ring-2 focus:ring-accent/40" />
      </div>
      <div className="scroll-y min-h-0 flex-1 px-2 pb-2">
        {contacts.isLoading ? (
          <div className="grid h-40 place-items-center text-ink-3"><Spinner /></div>
        ) : !list.length ? (
          <EmptyState icon={<Users size={24} />} title={t('contacts.title')} body={t('contacts.empty')} action={<Button onClick={() => open({ kind: 'new-message' })}>{t('contacts.find')}</Button>} />
        ) : (
          <>
            {online.length > 0 && <h3 className="px-3 pt-2 pb-1 text-[0.78rem] font-semibold text-ink-3">{t('contacts.online')}</h3>}
            {online.map(row)}
            {online.length > 0 && rest.length > 0 && <div className="mx-3 my-2 h-px bg-line" />}
            {rest.map(row)}
          </>
        )}
      </div>
    </div>
  );
}
