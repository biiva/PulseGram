import { create } from 'zustand';
import type { CallDto, CallSignal, ConversationDto } from '@pulsegram/shared';
import { ApiError, http } from '../../lib/api';
import { openDirectWith } from '../../lib/chatActions';
import { queryClient } from '../../lib/queryClient';
import { realtime } from '../../lib/realtime';
import { playChime } from '../../lib/sound';
import { useAuth } from '../../stores/auth';
import { usePrefs } from '../../stores/prefs';

export type CallPhase = 'idle' | 'outgoing' | 'incoming' | 'connecting' | 'connected' | 'reconnecting' | 'ended';
export type CallError = 'permission' | 'failed' | 'failed_nat' | 'busy' | 'rejected' | 'missed' | 'ended' | 'cancelled' | null;

interface CallState {
  call: CallDto | null;
  phase: CallPhase;
  role: 'caller' | 'callee' | null;
  local: MediaStream | null;
  remote: MediaStream | null;
  muted: boolean;
  cameraOn: boolean;
  remoteMedia: { audio: boolean; video: boolean };
  connectedAt: number | null;
  error: CallError;
}

export const useCall = create<CallState>(() => ({
  call: null,
  phase: 'idle',
  role: null,
  local: null,
  remote: null,
  muted: false,
  cameraOn: false,
  remoteMedia: { audio: true, video: true },
  connectedAt: null,
  error: null,
}));

let pc: RTCPeerConnection | null = null;
let pendingIce: RTCIceCandidateInit[] = [];
let ringTimer: ReturnType<typeof setInterval> | null = null;
let iceConfig: { iceServers: RTCIceServer[]; turnConfigured: boolean } | null = null;
let restartTimer: ReturnType<typeof setTimeout> | null = null;

const set = useCall.setState;
const get = useCall.getState;

function stopRing() {
  if (ringTimer) clearInterval(ringTimer);
  ringTimer = null;
}
function startRing() {
  stopRing();
  if (!usePrefs.getState().notifications.calls) return;
  playChime('ring');
  ringTimer = setInterval(() => playChime('ring'), 2200);
}

async function loadIce() {
  iceConfig ??= await http.get<{ iceServers: RTCIceServer[]; turnConfigured: boolean }>('/api/calls/ice-servers');
  return iceConfig;
}

async function getMedia(video: boolean): Promise<MediaStream> {
  if (!navigator.mediaDevices?.getUserMedia) throw new DOMException('unsupported', 'NotSupportedError');
  return navigator.mediaDevices.getUserMedia({
    audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true },
    video: video ? { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'user' } : false,
  });
}

function signal(sig: CallSignal) {
  const call = get().call;
  if (call) realtime.send({ t: 'call:signal', d: { callId: call.id, signal: sig } });
}

function cleanup(error: CallError = null) {
  stopRing();
  if (restartTimer) clearTimeout(restartTimer);
  pc?.close();
  pc = null;
  pendingIce = [];
  get().local?.getTracks().forEach((t) => t.stop());
  set({ phase: error ? 'ended' : 'idle', local: null, remote: null, connectedAt: null, error, role: null, muted: false, cameraOn: false });
  if (error) setTimeout(() => get().phase === 'ended' && set({ phase: 'idle', call: null, error: null }), 2500);
  else set({ call: null });
  void queryClient.invalidateQueries({ queryKey: ['calls'] });
}

async function createPeer() {
  const cfg = await loadIce();
  const peer = new RTCPeerConnection({ iceServers: cfg.iceServers });
  pc = peer;
  const remote = new MediaStream();
  set({ remote });
  for (const track of get().local?.getTracks() ?? []) peer.addTrack(track, get().local!);
  peer.ontrack = (e) => {
    for (const tr of e.streams[0]?.getTracks() ?? [e.track]) if (!remote.getTracks().includes(tr)) remote.addTrack(tr);
    set({ remote: new MediaStream(remote.getTracks()) });
  };
  peer.onicecandidate = (e) => {
    if (e.candidate) signal({ kind: 'ice', candidate: e.candidate.candidate, sdpMid: e.candidate.sdpMid, sdpMLineIndex: e.candidate.sdpMLineIndex });
  };
  peer.onconnectionstatechange = () => {
    const st = peer.connectionState;
    if (st === 'connected') {
      if (restartTimer) clearTimeout(restartTimer);
      set({ phase: 'connected', connectedAt: get().connectedAt ?? Date.now() });
    } else if (st === 'disconnected') {
      set({ phase: 'reconnecting' });
      // Give the network a moment, then try an ICE restart (caller drives renegotiation).
      restartTimer = setTimeout(() => {
        if (peer.connectionState !== 'connected' && get().role === 'caller') void restartIce();
        else if (peer.connectionState !== 'connected') signal({ kind: 'restart' });
      }, 2500);
    } else if (st === 'failed') {
      const nat = !cfg.turnConfigured;
      void hangUp(nat ? 'failed_nat' : 'failed');
    }
  };
  return peer;
}

async function restartIce() {
  if (!pc) return;
  const offer = await pc.createOffer({ iceRestart: true });
  await pc.setLocalDescription(offer);
  signal({ kind: 'offer', sdp: offer.sdp ?? '' });
}

async function flushIce() {
  if (!pc?.remoteDescription) return;
  for (const c of pendingIce) await pc.addIceCandidate(c).catch(() => {});
  pendingIce = [];
}

async function onSignal(sig: CallSignal) {
  if (sig.kind === 'media-state') return set({ remoteMedia: { audio: sig.audio, video: sig.video } });
  if (sig.kind === 'restart') {
    if (get().role === 'caller') await restartIce();
    return;
  }
  if (!pc) return;
  if (sig.kind === 'offer') {
    await pc.setRemoteDescription({ type: 'offer', sdp: sig.sdp });
    await flushIce();
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    signal({ kind: 'answer', sdp: answer.sdp ?? '' });
  } else if (sig.kind === 'answer') {
    await pc.setRemoteDescription({ type: 'answer', sdp: sig.sdp });
    await flushIce();
  } else if (sig.kind === 'ice') {
    const c = { candidate: sig.candidate, sdpMid: sig.sdpMid, sdpMLineIndex: sig.sdpMLineIndex };
    if (pc.remoteDescription) await pc.addIceCandidate(c).catch(() => {});
    else pendingIce.push(c);
  }
}

export async function startCall(conv: ConversationDto, video: boolean) {
  if (get().phase !== 'idle' && get().phase !== 'ended') return;
  let local: MediaStream;
  try {
    local = await getMedia(video);
  } catch {
    set({ phase: 'ended', error: 'permission', cameraOn: video });
    setTimeout(() => set({ phase: 'idle', error: null }), 6000);
    return;
  }
  set({ local, cameraOn: video, muted: false, role: 'caller', phase: 'outgoing', error: null });
  try {
    const call = await http.post<CallDto>('/api/calls', { conversationId: conv.id, video });
    set({ call });
    if (call.status === 'busy') cleanup('busy');
  } catch (err) {
    local.getTracks().forEach((t) => t.stop());
    set({ phase: 'idle', local: null, role: null });
    throw err;
  }
}

export async function startCallWithUser(userId: string, video: boolean) {
  const conv = await openDirectWith(userId);
  await startCall(conv, video);
}

export async function acceptCall() {
  const call = get().call;
  if (!call) return;
  stopRing();
  let local: MediaStream;
  try {
    local = await getMedia(call.video);
  } catch {
    await http.post(`/api/calls/${call.id}/reject`).catch(() => {});
    cleanup('permission');
    return;
  }
  set({ local, cameraOn: call.video, role: 'callee', phase: 'connecting' });
  try {
    await createPeer();
    const updated = await http.post<CallDto>(`/api/calls/${call.id}/accept`);
    set({ call: updated });
  } catch (err) {
    cleanup(err instanceof ApiError && err.code === 'call_not_ringing' ? 'missed' : 'failed');
  }
}

export async function declineCall() {
  const call = get().call;
  if (call) await http.post(`/api/calls/${call.id}/reject`).catch(() => {});
  cleanup();
}

export async function hangUp(error: CallError = null) {
  const call = get().call;
  if (call) await http.post(`/api/calls/${call.id}/end`).catch(() => {});
  cleanup(error);
}

export function toggleMute() {
  const muted = !get().muted;
  get().local?.getAudioTracks().forEach((t) => (t.enabled = !muted));
  set({ muted });
  signal({ kind: 'media-state', audio: !muted, video: get().cameraOn });
}

export function toggleCamera() {
  const on = !get().cameraOn;
  get().local?.getVideoTracks().forEach((t) => (t.enabled = on));
  set({ cameraOn: on });
  signal({ kind: 'media-state', audio: !get().muted, video: on });
}

export async function switchDevice(kind: 'audioinput' | 'videoinput', deviceId: string) {
  const local = get().local;
  if (!local) return;
  const stream = await navigator.mediaDevices.getUserMedia(kind === 'audioinput' ? { audio: { deviceId: { exact: deviceId } } } : { video: { deviceId: { exact: deviceId } } });
  const track = kind === 'audioinput' ? stream.getAudioTracks()[0] : stream.getVideoTracks()[0];
  if (!track) return;
  const old = kind === 'audioinput' ? local.getAudioTracks()[0] : local.getVideoTracks()[0];
  const sender = pc?.getSenders().find((s) => s.track?.kind === track.kind);
  await sender?.replaceTrack(track);
  if (old) {
    local.removeTrack(old);
    old.stop();
  }
  track.enabled = kind === 'audioinput' ? !get().muted : get().cameraOn;
  local.addTrack(track);
  set({ local: new MediaStream(local.getTracks()) });
}

let installed = false;
export function installCallBindings() {
  if (installed) return;
  installed = true;
  realtime.on('call:incoming', ({ call }) => {
    if (get().phase !== 'idle' && get().phase !== 'ended') return; // already in a call; the caller will time out
    set({ call, phase: 'incoming', role: 'callee', error: null });
    startRing();
    if (document.visibilityState !== 'visible' && typeof Notification !== 'undefined' && Notification.permission === 'granted') {
      try {
        new Notification(call.caller.displayName, { body: call.video ? 'Video call' : 'Incoming call', tag: `call:${call.id}`, icon: '/favicon.svg' });
      } catch {
        /* ignore */
      }
    }
  });
  realtime.on('call:updated', ({ call }) => {
    const cur = get().call;
    if (!cur || cur.id !== call.id) return;
    const me = useAuth.getState().me?.id;
    if (call.status === 'accepted') {
      if (get().role === 'caller' && get().phase === 'outgoing') {
        set({ call, phase: 'connecting' });
        void (async () => {
          const peer = await createPeer();
          const offer = await peer.createOffer();
          await peer.setLocalDescription(offer);
          signal({ kind: 'offer', sdp: offer.sdp ?? '' });
        })().catch(() => void hangUp('failed'));
      } else if (get().phase === 'incoming' && call.callee.id === me) {
        // Answered on another of my devices.
        cleanup();
      }
      return;
    }
    if (['rejected', 'missed', 'ended', 'cancelled', 'busy', 'failed'].includes(call.status)) {
      const err: CallError = call.status === 'rejected' && get().role === 'caller' ? 'rejected' : call.status === 'busy' ? 'busy' : call.status === 'missed' && get().role === 'caller' ? 'missed' : get().phase === 'incoming' ? null : 'ended';
      cleanup(err);
    }
  });
  realtime.on('call:signal', ({ callId, signal: sig }) => {
    if (get().call?.id === callId) void onSignal(sig).catch(() => {});
  });
  // Re-attach to a call that is ringing when the app loads (e.g. page refresh).
  realtime.on('session:ready', () => {
    if (get().phase !== 'idle') return;
    void http
      .get<{ call: CallDto | null }>('/api/calls/active')
      .then(({ call }) => {
        if (call && call.status === 'ringing' && call.callee.id === useAuth.getState().me?.id && get().phase === 'idle') {
          set({ call, phase: 'incoming', role: 'callee' });
          startRing();
        }
      })
      .catch(() => {});
  });
}
