import { useQuery } from '@tanstack/react-query';
import { clsx } from 'clsx';
import { Phone, PhoneIncoming, PhoneMissed, PhoneOutgoing, Video } from 'lucide-react';
import type { CallDto } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { IconButton } from '../../components/ui/Button';
import { EmptyState, Spinner } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { formatDuration, formatListTime } from '../../lib/format';
import { useAuth } from '../../stores/auth';
import { usePrefs } from '../../stores/prefs';
import { toast } from '../../stores/ui';
import { startCallWithUser } from './callStore';

export function CallsPanel() {
  const t = useT();
  const fmt = usePrefs((s) => s.appearance);
  const me = useAuth((s) => s.me);
  const turn = useAuth((s) => s.config?.turnConfigured);
  const q = useQuery({ queryKey: ['calls'], queryFn: () => http.get<CallDto[]>('/api/calls') });
  return (
    <div className="flex h-full flex-col">
      <header className="px-4 pt-4 pb-2">
        <h1 className="text-[1.35rem] font-extrabold tracking-[-0.02em] text-ink">{t('calls.title')}</h1>
        {!turn && <p className="mt-1 text-[0.8rem] text-ink-3">{t('calls.turnMissing')}</p>}
      </header>
      <div className="scroll-y min-h-0 flex-1 px-2 pb-2">
        {q.isLoading ? (
          <div className="grid h-40 place-items-center text-ink-3"><Spinner /></div>
        ) : !q.data?.length ? (
          <EmptyState icon={<Phone size={24} />} title={t('calls.title')} body={t('calls.empty')} />
        ) : (
          q.data.map((c) => {
            const outgoing = c.caller.id === me?.id;
            const peer = outgoing ? c.callee : c.caller;
            const missed = !outgoing && (c.status === 'missed' || c.status === 'cancelled');
            const Icon = missed ? PhoneMissed : outgoing ? PhoneOutgoing : PhoneIncoming;
            return (
              <div key={c.id} className="flex items-center gap-3 rounded-[14px] px-2.5 py-2 hover:bg-sunken">
                <Avatar id={peer.id} name={peer.displayName} src={peer.avatarUrl} size={46} />
                <div className="min-w-0 flex-1">
                  <p className={clsx('truncate text-[0.95rem] font-semibold', missed ? 'text-danger' : 'text-ink')}>{peer.displayName}</p>
                  <p className="flex items-center gap-1.5 text-[0.82rem] text-ink-3">
                    <Icon size={14} className={missed ? 'text-danger' : 'text-success'} />
                    {outgoing ? t('calls.outgoingLabel') : t('calls.incomingLabel')}
                    {c.video && <Video size={13} />}
                    · {formatListTime(c.createdAt, fmt)}
                    {c.durationSec !== null && ` · ${formatDuration(c.durationSec * 1000)}`}
                  </p>
                </div>
                <IconButton
                  label={t('calls.callBack')}
                  tone="accent"
                  onClick={() => void startCallWithUser(peer.id, c.video).catch((err: unknown) => toast({ text: errorText(t, err), tone: 'danger' }))}
                >
                  {c.video ? <Video size={20} /> : <Phone size={20} />}
                </IconButton>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
