import { clsx } from 'clsx';
import { Mic, MicOff, Phone, PhoneOff, Settings2, Video, VideoOff } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Avatar } from '../../components/ui/Avatar';
import { Modal } from '../../components/ui/Modal';
import { Select } from '../../components/ui/Field';
import { useT } from '../../i18n';
import { formatDuration } from '../../lib/format';
import { useAuth } from '../../stores/auth';
import { acceptCall, declineCall, hangUp, installCallBindings, switchDevice, toggleCamera, toggleMute, useCall } from './callStore';

function VideoEl({ stream, muted, mirrored, className }: { stream: MediaStream | null; muted?: boolean; mirrored?: boolean; className?: string }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    if (ref.current && ref.current.srcObject !== stream) ref.current.srcObject = stream;
  }, [stream]);
  return <video ref={ref} autoPlay playsInline muted={muted} className={clsx(className, mirrored && '-scale-x-100')} />;
}

function AudioEl({ stream }: { stream: MediaStream | null }) {
  const ref = useRef<HTMLAudioElement>(null);
  useEffect(() => {
    if (ref.current && ref.current.srcObject !== stream) ref.current.srcObject = stream;
  }, [stream]);
  return <audio ref={ref} autoPlay />;
}

function Timer({ since }: { since: number }) {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);
  return <span className="tabular-nums">{formatDuration(now - since)}</span>;
}

function RoundButton({ label, onClick, tone = 'neutral', children }: { label: string; onClick: () => void; tone?: 'neutral' | 'danger' | 'success' | 'active'; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={label}
      title={label}
      className={clsx(
        'grid size-14 place-items-center rounded-full transition active:scale-95',
        tone === 'danger' ? 'bg-danger text-white hover:brightness-110' : tone === 'success' ? 'bg-success text-white hover:brightness-110' : tone === 'active' ? 'bg-white text-[#140f2b]' : 'bg-white/15 text-white hover:bg-white/25',
      )}
    >
      {children}
    </button>
  );
}

function DevicesDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const t = useT();
  const [devices, setDevices] = useState<MediaDeviceInfo[]>([]);
  useEffect(() => {
    if (open) void navigator.mediaDevices?.enumerateDevices().then(setDevices);
  }, [open]);
  const mics = devices.filter((d) => d.kind === 'audioinput');
  const cams = devices.filter((d) => d.kind === 'videoinput');
  return (
    <Modal open={open} onClose={onClose} title={t('calls.devices')} width={400}>
      <div className="flex flex-col gap-4">
        {mics.length > 0 && <Select label={t('calls.microphone')} options={mics.map((d, i) => ({ value: d.deviceId, label: d.label || `Mic ${i + 1}` }))} onChange={(e) => void switchDevice('audioinput', e.target.value)} />}
        {cams.length > 0 && <Select label={t('calls.camera')} options={cams.map((d, i) => ({ value: d.deviceId, label: d.label || `Camera ${i + 1}` }))} onChange={(e) => void switchDevice('videoinput', e.target.value)} />}
      </div>
    </Modal>
  );
}

/** Full-screen call UI. Only shows "connected" once WebRTC actually reports a connection. */
export function CallOverlay() {
  const t = useT();
  const s = useCall();
  const me = useAuth((x) => x.me);
  const turnConfigured = useAuth((x) => x.config?.turnConfigured);
  const [devicesOpen, setDevicesOpen] = useState(false);
  useEffect(() => installCallBindings(), []);

  if (s.phase === 'idle') return null;
  if (s.phase === 'ended' && !s.call) {
    // Permission error before a call record exists.
    return createPortal(
      <div className="anim-pop fixed inset-x-4 top-4 z-[90] mx-auto max-w-md rounded-[16px] bg-[#140f2b] p-4 text-[0.9rem] text-white shadow-pop">
        {t('calls.permissionDenied', { cam: s.cameraOn ? ' / camera' : '' })}
      </div>,
      document.body,
    );
  }
  const call = s.call;
  if (!call) return null;
  const peer = call.caller.id === me?.id ? call.callee : call.caller;
  const showVideo = call.video && (s.phase === 'connected' || s.phase === 'reconnecting');
  const statusText =
    s.phase === 'incoming'
      ? call.video
        ? t('calls.incomingVideo')
        : t('calls.incoming')
      : s.phase === 'outgoing'
        ? t('calls.outgoing')
        : s.phase === 'connecting'
          ? t('calls.connecting')
          : s.phase === 'reconnecting'
            ? t('calls.reconnecting')
            : s.phase === 'ended'
              ? s.error === 'busy'
                ? t('calls.busy')
                : s.error === 'rejected'
                  ? t('calls.rejected')
                  : s.error === 'missed'
                    ? t('calls.missed')
                    : s.error === 'failed_nat'
                      ? t('calls.failedNat')
                      : s.error === 'failed'
                        ? t('calls.failed')
                        : s.error === 'permission'
                          ? t('calls.permissionDenied', { cam: call.video ? ' / camera' : '' })
                          : t('calls.ended')
              : null;

  return createPortal(
    <div className="anim-fade fixed inset-0 z-[90] flex flex-col bg-[#140f2b] text-white" role="dialog" aria-modal="true" aria-label={statusText ?? peer.displayName}>
      <AudioEl stream={call.video ? null : s.remote} />
      {showVideo && <VideoEl stream={s.remote} className="absolute inset-0 size-full object-cover" />}
      {!showVideo && (
        <>
          <div className="pointer-events-none absolute -top-40 left-1/2 size-[36rem] -translate-x-1/2 rounded-full bg-[#7c4dff] opacity-30 blur-[140px]" />
          <div className="pointer-events-none absolute bottom-0 left-0 size-80 rounded-full bg-[#35b6ff] opacity-15 blur-[120px]" />
        </>
      )}
      <div className="relative z-10 flex flex-1 flex-col items-center justify-center px-6 text-center">
        {!showVideo && (
          <span className={clsx('rounded-full', (s.phase === 'incoming' || s.phase === 'outgoing') && 'beat')}>
            <Avatar id={peer.id} name={peer.displayName} src={peer.avatarUrl} size={128} />
          </span>
        )}
        <h2 className={clsx('mt-6 text-[1.7rem] font-extrabold tracking-[-0.02em]', showVideo && 'drop-shadow-lg')}>{peer.displayName}</h2>
        <p className="mt-2 max-w-sm text-[1rem] text-white/70">
          {s.phase === 'connected' && s.connectedAt ? <Timer since={s.connectedAt} /> : statusText}
        </p>
        {s.phase === 'connected' && !s.remoteMedia.audio && <p className="mt-2 inline-flex items-center gap-1 text-[0.85rem] text-white/60"><MicOff size={14} /> muted</p>}
        {(s.phase === 'outgoing' || s.phase === 'connecting') && !turnConfigured && <p className="mt-4 max-w-xs text-[0.78rem] text-white/45">{t('calls.turnMissing')}</p>}
      </div>
      {call.video && s.local && s.phase !== 'incoming' && (
        <VideoEl stream={s.local} muted mirrored className="absolute top-4 right-4 z-10 aspect-[3/4] w-28 rounded-[16px] border border-white/20 object-cover shadow-pop sm:w-40" />
      )}
      <div className="pb-safe relative z-10 flex items-center justify-center gap-4 px-6 pt-4 pb-10">
        {s.phase === 'incoming' ? (
          <>
            <div className="flex flex-col items-center gap-2">
              <RoundButton label={t('calls.decline')} tone="danger" onClick={() => void declineCall()}>
                <PhoneOff size={24} />
              </RoundButton>
              <span className="text-[0.8rem] text-white/70">{t('calls.decline')}</span>
            </div>
            <div className="w-16" />
            <div className="flex flex-col items-center gap-2">
              <RoundButton label={t('calls.accept')} tone="success" onClick={() => void acceptCall()}>
                {call.video ? <Video size={24} /> : <Phone size={24} />}
              </RoundButton>
              <span className="text-[0.8rem] text-white/70">{t('calls.accept')}</span>
            </div>
          </>
        ) : s.phase === 'ended' ? null : (
          <>
            <RoundButton label={s.muted ? t('calls.unmute') : t('calls.mute')} tone={s.muted ? 'active' : 'neutral'} onClick={toggleMute}>
              {s.muted ? <MicOff size={22} /> : <Mic size={22} />}
            </RoundButton>
            {call.video && (
              <RoundButton label={s.cameraOn ? t('calls.cameraOff') : t('calls.cameraOn')} tone={!s.cameraOn ? 'active' : 'neutral'} onClick={toggleCamera}>
                {s.cameraOn ? <Video size={22} /> : <VideoOff size={22} />}
              </RoundButton>
            )}
            <RoundButton label={t('calls.devices')} onClick={() => setDevicesOpen(true)}>
              <Settings2 size={22} />
            </RoundButton>
            <RoundButton label={t('calls.end')} tone="danger" onClick={() => void hangUp()}>
              <PhoneOff size={24} />
            </RoundButton>
          </>
        )}
      </div>
      <DevicesDialog open={devicesOpen} onClose={() => setDevicesOpen(false)} />
    </div>,
    document.body,
  );
}
