import { useInfiniteQuery } from '@tanstack/react-query';
import { clsx } from 'clsx';
import { Link2, Play } from 'lucide-react';
import { useState } from 'react';
import { extractLinks, type MessageDto } from '@pulsegram/shared';
import { Spinner } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { http } from '../../lib/api';
import { formatDuration } from '../../lib/format';
import { useUi } from '../../stores/ui';
import { FileCard, VoicePlayer } from '../chat/Attachments';

type Kind = 'media' | 'file' | 'link' | 'voice';

export function SharedMedia({ conversationId, onJump }: { conversationId: string; onJump: (m: MessageDto) => void }) {
  const t = useT();
  const [kind, setKind] = useState<Kind>('media');
  const open = useUi((s) => s.open);
  const q = useInfiniteQuery({
    queryKey: ['media', conversationId, kind],
    initialPageParam: 0,
    queryFn: ({ pageParam }) => http.get<{ items: MessageDto[]; hasMore: boolean }>(`/api/conversations/${conversationId}/media?kind=${kind}${pageParam ? `&before=${pageParam}` : ''}`),
    getNextPageParam: (last) => (last.hasMore ? last.items[last.items.length - 1]?.seq : undefined),
  });
  const items = q.data?.pages.flatMap((p) => p.items) ?? [];
  const tabs: Array<{ id: Kind; label: string }> = [
    { id: 'media', label: t('info.media') },
    { id: 'file', label: t('info.files') },
    { id: 'link', label: t('info.links') },
    { id: 'voice', label: t('info.voice') },
  ];
  return (
    <div>
      <div role="tablist" className="sticky top-0 z-[1] flex border-b border-line bg-bg">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            role="tab"
            aria-selected={kind === tab.id}
            onClick={() => setKind(tab.id)}
            className={clsx('flex-1 border-b-2 py-2.5 text-[0.85rem] font-semibold', kind === tab.id ? 'border-accent text-accent' : 'border-transparent text-ink-3 hover:text-ink')}
          >
            {tab.label}
          </button>
        ))}
      </div>
      {q.isLoading ? (
        <div className="grid h-32 place-items-center text-ink-3"><Spinner /></div>
      ) : items.length === 0 ? (
        <p className="p-8 text-center text-[0.88rem] text-ink-3">{t('info.noMedia')}</p>
      ) : kind === 'media' ? (
        <div className="grid grid-cols-3 gap-0.5 p-0.5">
          {items.flatMap((m) =>
            m.attachments
              .filter((a) => a.kind === 'image' || a.kind === 'video')
              .map((a) => (
                <button key={a.id} type="button" className="relative aspect-square overflow-hidden bg-sunken" onClick={() => open({ kind: 'media', items, index: items.slice(0, items.indexOf(m)).reduce((n, x) => n + x.attachments.filter((y) => y.kind === 'image' || y.kind === 'video').length, 0) + m.attachments.filter((y) => y.kind === 'image' || y.kind === 'video').indexOf(a) })}>
                  {a.thumbUrl ? <img src={a.thumbUrl} alt="" loading="lazy" className="size-full object-cover" /> : <span className="grid size-full place-items-center bg-ink/70" />}
                  {a.kind === 'video' && (
                    <span className="absolute bottom-1 left-1 flex items-center gap-0.5 rounded bg-black/55 px-1 text-[0.68rem] text-white">
                      <Play size={10} fill="currentColor" /> {formatDuration(a.durationMs)}
                    </span>
                  )}
                </button>
              )),
          )}
        </div>
      ) : kind === 'link' ? (
        <ul className="p-2">
          {items.flatMap((m) =>
            extractLinks(m.text).map((l, i) => (
              <li key={`${m.id}-${i}`} className="flex items-start gap-3 rounded-[12px] p-2 hover:bg-sunken">
                <span className="grid size-10 shrink-0 place-items-center rounded-[10px] bg-soft text-accent"><Link2 size={18} /></span>
                <span className="min-w-0 flex-1">
                  <a href={l} target="_blank" rel="noopener noreferrer nofollow" className="block truncate text-[0.88rem] font-semibold text-accent hover:underline">{new URL(l).hostname}</a>
                  <button type="button" onClick={() => onJump(m)} className="block w-full truncate text-left text-[0.8rem] text-ink-3">{l}</button>
                </span>
              </li>
            )),
          )}
        </ul>
      ) : (
        <ul className="p-2">
          {items.flatMap((m) =>
            m.attachments
              .filter((a) => (kind === 'voice' ? a.kind === 'voice' : a.kind === 'file' || a.kind === 'audio'))
              .map((a) => (
                <li key={a.id} className="rounded-[12px] px-2 hover:bg-sunken" onDoubleClick={() => onJump(m)}>
                  {a.kind === 'voice' ? <VoicePlayer a={a} out={false} /> : <FileCard a={a} out={false} />}
                </li>
              )),
          )}
        </ul>
      )}
      {q.hasNextPage && (
        <button type="button" className="w-full py-3 text-[0.85rem] font-semibold text-accent" onClick={() => void q.fetchNextPage()} disabled={q.isFetchingNextPage}>
          {q.isFetchingNextPage ? <Spinner size={16} /> : t('common.more')}
        </button>
      )}
    </div>
  );
}
