import { useQuery } from '@tanstack/react-query';
import { clsx } from 'clsx';
import {
  ArrowLeft,
  Bell,
  Camera,
  ClipboardList,
  Copy,
  Link2,
  LogOut,
  MoreVertical,
  Pencil,
  ShieldCheck,
  SlidersHorizontal,
  Trash2,
  UserPlus,
  X,
} from 'lucide-react';
import { useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { can, CHANNEL_CATEGORIES, type AuditLogDto, type ConversationDto, type InviteDto, type MemberDto, type MessageDto } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { Button, IconButton } from '../../components/ui/Button';
import { Input, Select, Switch, Textarea } from '../../components/ui/Field';
import { openMenu, type MenuItem } from '../../components/ui/Menu';
import { confirmDialog } from '../../components/ui/Modal';
import { Spinner } from '../../components/ui/misc';
import { useT, type MessageKey } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { updateMembership } from '../../lib/chatActions';
import { formatDate, formatRelative, presenceText } from '../../lib/format';
import { queryClient } from '../../lib/queryClient';
import { uploadFile } from '../../lib/upload';
import { useAuth } from '../../stores/auth';
import { isMuted, useChat } from '../../stores/chat';
import { usePrefs } from '../../stores/prefs';
import { toast, useUi } from '../../stores/ui';
import { ProfileCard } from '../dialogs/ProfileCard';
import { SharedMedia } from './SharedMedia';

type View = 'main' | 'edit' | 'permissions' | 'invites' | 'audit';

function Header({ title, onBack, onClose }: { title: string; onBack?: () => void; onClose: () => void }) {
  const t = useT();
  return (
    <div className="flex h-16 shrink-0 items-center gap-2 border-b border-line px-3">
      {onBack ? (
        <IconButton label={t('common.back')} onClick={onBack}>
          <ArrowLeft size={20} />
        </IconButton>
      ) : (
        <IconButton label={t('common.close')} onClick={onClose}>
          <X size={20} />
        </IconButton>
      )}
      <h2 className="flex-1 truncate text-[1.05rem] font-bold text-ink">{title}</h2>
    </div>
  );
}

function MemberRow({ m, conv, onOpen }: { m: MemberDto; conv: ConversationDto; onOpen: () => void }) {
  const t = useT();
  const fmt = usePrefs((s) => s.appearance);
  const meId = useAuth((s) => s.me?.id);
  const pc = conv.me ? { type: conv.type, role: conv.me.role, settings: conv.settings } : null;
  const actions: MenuItem[] = [];
  const run = (p: Promise<unknown>) =>
    p.then(() => queryClient.invalidateQueries({ queryKey: ['members', conv.id] })).catch((err: unknown) => toast({ text: errorText(t, err), tone: 'danger' }));
  if (pc && m.user.id !== meId) {
    const setRole = (role: 'admin' | 'moderator' | 'member') => run(http.patch(`/api/conversations/${conv.id}/members/${m.user.id}`, { role }));
    if (m.role !== 'admin' && can.changeRole(pc, m.role, 'admin')) actions.push({ label: t('info.makeAdmin'), onSelect: () => setRole('admin') });
    if (conv.type === 'group' && m.role !== 'moderator' && can.changeRole(pc, m.role, 'moderator')) actions.push({ label: t('info.makeModerator'), onSelect: () => setRole('moderator') });
    if (m.role !== 'member' && can.changeRole(pc, m.role, 'member')) actions.push({ label: t('info.makeMember'), onSelect: () => setRole('member') });
    if (can.transferOwnership(pc))
      actions.push({
        label: t('info.transfer'),
        onSelect: async () => {
          const r = await confirmDialog({ title: t('info.transfer'), body: t('info.transferConfirm', { name: m.user.displayName }), danger: true, input: { label: t('auth.field.password'), type: 'password' }, confirmLabel: t('info.transfer') });
          if (r.ok) run(http.post(`/api/conversations/${conv.id}/transfer-ownership`, { userId: m.user.id, password: r.value }));
        },
      });
    if (can.kick(pc, m.role))
      actions.push({
        label: t('info.kick'),
        danger: true,
        onSelect: async () => {
          const r = await confirmDialog({ title: t('info.kick'), body: t('info.kickConfirm', { name: m.user.displayName }), danger: true, confirmLabel: t('common.remove') });
          if (r.ok) run(http.del(`/api/conversations/${conv.id}/members/${m.user.id}`));
        },
      });
  }
  const roleLabel = m.role === 'member' ? '' : t(`info.role.${m.role}` as MessageKey);
  return (
    <div className="flex items-center gap-3 rounded-[12px] px-2 py-1.5 hover:bg-sunken">
      <button type="button" className="flex min-w-0 flex-1 items-center gap-3 text-left" onClick={onOpen}>
        <Avatar id={m.user.id} name={m.user.displayName} src={m.user.avatarUrl} size={40} online={m.user.presence.kind === 'online'} />
        <span className="min-w-0 flex-1">
          <span className="block truncate text-[0.92rem] font-semibold text-ink">{m.user.displayName}</span>
          <span className="block truncate text-[0.78rem] text-ink-3">{presenceText(m.user.presence, fmt, t)}</span>
        </span>
      </button>
      {roleLabel && <span className="text-[0.75rem] font-semibold text-accent">{roleLabel}</span>}
      {actions.length > 0 && (
        <IconButton label={t('common.more')} size={32} onClick={(e) => openMenu(e, actions)}>
          <MoreVertical size={16} />
        </IconButton>
      )}
    </div>
  );
}

function Members({ conv }: { conv: ConversationDto }) {
  const t = useT();
  const open = useUi((s) => s.open);
  const [q, setQ] = useState('');
  const members = useQuery({
    queryKey: ['members', conv.id, q],
    queryFn: () => http.get<{ items: MemberDto[]; hasMore: boolean }>(`/api/conversations/${conv.id}/members?q=${encodeURIComponent(q)}&limit=200`),
  });
  const pc = conv.me ? { type: conv.type, role: conv.me.role, settings: conv.settings } : null;
  const isAdminView = conv.type !== 'channel' || (pc && can.editInfo(pc));
  return (
    <div className="px-2 py-3">
      <div className="flex items-center justify-between px-2 pb-2">
        <h3 className="text-[0.82rem] font-semibold text-ink-3">{conv.type === 'channel' ? t('common.subscribers', { n: conv.memberCount }) : t('common.members', { n: conv.memberCount })}</h3>
        {pc && can.invite(pc) && (
          <Button size="sm" variant="ghost" icon={<UserPlus size={16} />} onClick={() => open({ kind: 'add-members', conversationId: conv.id })}>
            {t('common.add')}
          </Button>
        )}
      </div>
      {!isAdminView && <p className="px-2 pb-2 text-[0.8rem] text-ink-3">{t('info.subscribersHidden')}</p>}
      {conv.memberCount > 20 && isAdminView && (
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder={t('common.search')} className="mx-2 mb-2 h-9 w-[calc(100%-1rem)] rounded-full bg-sunken px-4 text-[0.88rem] outline-none" />
      )}
      {members.isLoading ? <Spinner className="m-4 text-ink-3" /> : members.data?.items.map((m) => <MemberRow key={m.user.id} m={m} conv={conv} onOpen={() => open({ kind: 'user', userId: m.user.id })} />)}
    </div>
  );
}

function EditInfo({ conv, onDone }: { conv: ConversationDto; onDone: () => void }) {
  const t = useT();
  const [title, setTitle] = useState(conv.title);
  const [description, setDescription] = useState(conv.description);
  const [isPublic, setPublic] = useState(conv.isPublic);
  const [username, setUsername] = useState(conv.username ?? '');
  const [category, setCategory] = useState(conv.category ?? 'other');
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const file = useRef<HTMLInputElement>(null);
  return (
    <div className="flex flex-col gap-4 p-5">
      <div className="flex items-center gap-4">
        <button type="button" className="group relative rounded-full" onClick={() => file.current?.click()} aria-label={t('info.setPhoto')}>
          <Avatar id={conv.id} name={conv.title} src={conv.avatarUrl} size={72} kind={conv.type === 'channel' ? 'channel' : 'group'} />
          <span className="absolute inset-0 grid place-items-center rounded-full bg-black/40 text-white opacity-0 group-hover:opacity-100">{uploading ? <Spinner /> : <Camera size={22} />}</span>
        </button>
        <div className="flex flex-col gap-1">
          <Button size="sm" variant="soft" onClick={() => file.current?.click()}>
            {t('info.setPhoto')}
          </Button>
          {conv.avatarUrl && (
            <Button size="sm" variant="ghost" onClick={() => void http.del(`/api/conversations/${conv.id}/avatar`).catch((err: unknown) => toast({ text: errorText(t, err), tone: 'danger' }))}>
              {t('info.removePhoto')}
            </Button>
          )}
        </div>
        <input
          ref={file}
          type="file"
          hidden
          accept="image/*"
          onChange={async (e) => {
            const f = e.target.files?.[0];
            e.target.value = '';
            if (!f) return;
            setUploading(true);
            try {
              await uploadFile(f, f.name, { url: `/api/conversations/${conv.id}/avatar`, method: 'PUT' }).promise;
            } catch (err) {
              toast({ text: errorText(t, err), tone: 'danger' });
            } finally {
              setUploading(false);
            }
          }}
        />
      </div>
      <Input label={conv.type === 'channel' ? t('new.channelTitle') : t('new.groupTitle')} value={title} onChange={(e) => setTitle(e.target.value)} maxLength={128} />
      <Textarea label={t('new.description')} value={description} onChange={(e) => setDescription(e.target.value)} maxLength={1000} />
      {conv.type === 'channel' && (
        <Select label={t('new.category')} value={category} onChange={(e) => setCategory(e.target.value as typeof category)} options={CHANNEL_CATEGORIES.map((c) => ({ value: c, label: t(`cat.${c}` as MessageKey) }))} />
      )}
      <Switch checked={isPublic} onChange={setPublic} label={t('new.public')} description={isPublic ? t('new.publicHint') : t('new.privateHint')} />
      {isPublic && <Input label={t('new.publicLink')} leading={<span>@</span>} value={username} onChange={(e) => setUsername(e.target.value)} spellCheck={false} />}
      <Button
        loading={busy}
        onClick={async () => {
          setBusy(true);
          try {
            const c = await http.patch<ConversationDto>(`/api/conversations/${conv.id}`, {
              title,
              description,
              isPublic,
              username: isPublic ? username : null,
              ...(conv.type === 'channel' ? { category } : {}),
            });
            useChat.getState().upsertConversation(c);
            toast(t('common.saved'));
            onDone();
          } catch (err) {
            toast({ text: errorText(t, err), tone: 'danger' });
          } finally {
            setBusy(false);
          }
        }}
      >
        {t('common.save')}
      </Button>
    </div>
  );
}

function Permissions({ conv }: { conv: ConversationDto }) {
  const t = useT();
  const s = conv.settings;
  const conversations = useChat((st) => st.conversations);
  const groups = useMemo(() => Object.values(conversations).filter((c) => c.type === 'group' && c.me && ['owner', 'admin'].includes(c.me.role)), [conversations]);
  const save = async (patch: Partial<ConversationDto['settings']> | { discussionGroupId: string | null }) => {
    try {
      const body = 'discussionGroupId' in patch ? patch : { settings: patch };
      const c = await http.patch<ConversationDto>(`/api/conversations/${conv.id}`, body);
      useChat.getState().upsertConversation(c);
    } catch (err) {
      toast({ text: errorText(t, err), tone: 'danger' });
    }
  };
  return (
    <div className="flex flex-col divide-y divide-line px-5 py-2">
      {conv.type === 'group' && (
        <>
          <Switch checked={s.membersCanSend} onChange={(v) => void save({ membersCanSend: v })} label={t('info.membersCanSend')} />
          <Switch checked={s.membersCanSendMedia} onChange={(v) => void save({ membersCanSendMedia: v })} label={t('info.membersCanSendMedia')} />
          <Switch checked={s.membersCanInvite} onChange={(v) => void save({ membersCanInvite: v })} label={t('info.membersCanInvite')} />
          <Switch checked={s.membersCanPin} onChange={(v) => void save({ membersCanPin: v })} label={t('info.membersCanPin')} />
          <Switch checked={s.historyVisibleToNewMembers} onChange={(v) => void save({ historyVisibleToNewMembers: v })} label={t('info.historyVisible')} />
          <div className="py-3">
            <Select
              label={t('info.slowMode')}
              value={String(s.slowModeSeconds)}
              onChange={(e) => void save({ slowModeSeconds: Number(e.target.value) })}
              options={[0, 10, 30, 60, 300, 900, 3600].map((n) => ({ value: String(n), label: n === 0 ? t('info.slowOff') : n < 60 ? `${n}s` : `${n / 60}m` }))}
            />
          </div>
        </>
      )}
      <Switch checked={s.reactionsEnabled} onChange={(v) => void save({ reactionsEnabled: v })} label={t('info.reactions')} />
      {conv.type === 'channel' && (
        <>
          <Switch checked={s.signPosts} onChange={(v) => void save({ signPosts: v })} label={t('info.signPosts')} />
          <div className="py-3">
            <Select
              label={t('info.discussionGroup')}
              value={conv.discussionGroupId ?? ''}
              onChange={(e) => void save({ discussionGroupId: e.target.value || null })}
              options={[{ value: '', label: t('info.discussionNone') }, ...groups.map((g) => ({ value: g.id, label: g.title }))]}
            />
          </div>
        </>
      )}
    </div>
  );
}

function Invites({ conv }: { conv: ConversationDto }) {
  const t = useT();
  const fmt = usePrefs((s) => s.appearance);
  const q = useQuery({ queryKey: ['invites', conv.id], queryFn: () => http.get<InviteDto[]>(`/api/conversations/${conv.id}/invites`) });
  const [expires, setExpires] = useState('');
  const [maxUses, setMaxUses] = useState('');
  const refresh = () => queryClient.invalidateQueries({ queryKey: ['invites', conv.id] });
  return (
    <div className="flex flex-col gap-4 p-5">
      <div className="grid grid-cols-2 gap-2">
        <Select label={t('info.expires', { date: '' }).replace(/\s*$/, '')} value={expires} onChange={(e) => setExpires(e.target.value)} options={[{ value: '', label: t('info.noExpiry') }, { value: '1', label: '1h' }, { value: '24', label: '24h' }, { value: '168', label: '7d' }]} />
        <Select label="Max" value={maxUses} onChange={(e) => setMaxUses(e.target.value)} options={[{ value: '', label: '∞' }, ...[1, 10, 50, 100].map((n) => ({ value: String(n), label: String(n) }))]} />
      </div>
      <Button
        icon={<Link2 size={17} />}
        onClick={async () => {
          try {
            await http.post(`/api/conversations/${conv.id}/invites`, { expiresInHours: expires ? Number(expires) : null, maxUses: maxUses ? Number(maxUses) : null });
            await refresh();
          } catch (err) {
            toast({ text: errorText(t, err), tone: 'danger' });
          }
        }}
      >
        {t('info.createLink')}
      </Button>
      <ul className="flex flex-col gap-2">
        {q.data?.map((i) => (
          <li key={i.id} className={clsx('rounded-[14px] border border-line p-3', i.revokedAt && 'opacity-55')}>
            <p className="truncate font-mono text-[0.8rem] text-ink">{i.url}</p>
            <p className="mt-1 text-[0.75rem] text-ink-3">
              {t('info.uses', { n: i.uses })}
              {i.maxUses ? ` / ${i.maxUses}` : ''} · {i.revokedAt ? t('info.revoked') : i.expiresAt ? t('info.expires', { date: formatDate(i.expiresAt, fmt) }) : t('info.noExpiry')}
            </p>
            {!i.revokedAt && (
              <div className="mt-2 flex gap-2">
                <Button size="sm" variant="soft" icon={<Copy size={14} />} onClick={() => void navigator.clipboard.writeText(i.url).then(() => toast(t('common.copied')))}>
                  {t('common.copy')}
                </Button>
                <Button size="sm" variant="ghost" className="!text-danger" onClick={() => void http.del(`/api/conversations/${conv.id}/invites/${i.id}`).then(refresh)}>
                  {t('info.revoke')}
                </Button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

function Audit({ conv }: { conv: ConversationDto }) {
  const t = useT();
  const fmt = usePrefs((s) => s.appearance);
  const q = useQuery({ queryKey: ['audit', conv.id], queryFn: () => http.get<AuditLogDto[]>(`/api/conversations/${conv.id}/audit-log`) });
  if (q.isLoading) return <Spinner className="m-6 text-ink-3" />;
  return (
    <ul className="divide-y divide-line px-5">
      {q.data?.map((a) => (
        <li key={a.id} className="py-2.5">
          <p className="text-[0.88rem] text-ink">
            <span className="font-semibold">{a.actor?.displayName ?? '—'}</span> · <span className="font-mono text-[0.8rem] text-ink-2">{a.action}</span>
            {a.targetUser && <> → {a.targetUser.displayName}</>}
          </p>
          <p className="text-[0.75rem] text-ink-3">{formatRelative(a.createdAt, fmt, t)}</p>
        </li>
      ))}
    </ul>
  );
}

export function InfoPanel({ conv, onClose, onJump }: { conv: ConversationDto; onClose: () => void; onJump: (m: MessageDto) => void }) {
  const t = useT();
  const nav = useNavigate();
  const [view, setView] = useState<View>('main');
  const pc = conv.me ? { type: conv.type, role: conv.me.role, settings: conv.settings } : null;
  const isAdmin = pc ? can.editInfo(pc) : false;
  const muted = isMuted(conv);

  const titles: Record<View, string> = {
    main: t('info.title'),
    edit: t('info.edit'),
    permissions: t('info.permissions'),
    invites: t('info.inviteLinks'),
    audit: t('info.auditLog'),
  };

  return (
    <aside className="anim-slide fixed inset-0 z-40 flex w-full flex-col border-l border-line bg-bg lg:static lg:z-auto lg:w-[360px] lg:shrink-0">
      <Header title={titles[view]} onClose={onClose} onBack={view === 'main' ? undefined : () => setView('main')} />
      <div className="scroll-y min-h-0 flex-1">
        {view === 'edit' && <EditInfo conv={conv} onDone={() => setView('main')} />}
        {view === 'permissions' && <Permissions conv={conv} />}
        {view === 'invites' && <Invites conv={conv} />}
        {view === 'audit' && <Audit conv={conv} />}
        {view === 'main' && (
          <>
            {conv.type === 'direct' && conv.peer ? (
              <div className="p-5">
                <ProfileCard userId={conv.peer.id} compact />
              </div>
            ) : conv.type === 'saved' ? (
              <div className="p-5 text-center">
                <Avatar id={conv.id} name="" kind="saved" size={88} className="mx-auto" />
                <h2 className="mt-3 text-[1.2rem] font-extrabold text-ink">{t('chats.saved')}</h2>
                <p className="mt-1 text-[0.88rem] text-ink-3">{t('chats.savedHint')}</p>
              </div>
            ) : (
              <div className="p-5">
                <div className="flex flex-col items-center text-center">
                  <Avatar id={conv.id} name={conv.title} src={conv.avatarUrl} size={96} kind={conv.type === 'channel' ? 'channel' : 'group'} />
                  <h2 className="mt-3 text-[1.25rem] font-extrabold text-ink">{conv.title}</h2>
                  <p className="text-[0.88rem] text-ink-3">
                    {conv.type === 'channel' ? t('common.subscribers', { n: conv.memberCount }) : t('common.members', { n: conv.memberCount })} · {conv.isPublic ? t('info.publicChat') : t('info.privateChat')}
                  </p>
                  {conv.isDemo && <span className="mt-2 rounded bg-sunken px-1.5 text-[0.7rem] font-semibold text-ink-3">{t('common.demo')}</span>}
                </div>
                {conv.description && <p className="mt-4 text-[0.92rem] leading-relaxed whitespace-pre-wrap text-ink">{conv.description}</p>}
                {conv.username && (
                  <button
                    type="button"
                    className="mt-3 flex w-full items-center gap-3 rounded-[12px] px-1 py-2 text-left hover:bg-sunken"
                    onClick={() => void navigator.clipboard.writeText(`${location.origin}/u/${conv.username}`).then(() => toast(t('common.copied')))}
                  >
                    <Link2 size={18} className="text-ink-3" />
                    <span className="flex-1 truncate text-[0.92rem] text-accent">{location.host}/u/{conv.username}</span>
                    <Copy size={15} className="text-ink-3" />
                  </button>
                )}
                {conv.linkedChannelId && (
                  <Button variant="soft" size="sm" className="mt-2" onClick={() => nav(`/chat/${conv.linkedChannelId}`)}>
                    {t('nav.channels')}
                  </Button>
                )}
                {conv.type === 'channel' && conv.discussionGroupId && (
                  <Button variant="soft" size="sm" className="mt-2" onClick={() => nav(`/chat/${conv.discussionGroupId}`)}>
                    {t('chat.discussion')}
                  </Button>
                )}
              </div>
            )}

            {conv.me && conv.type !== 'saved' && (
              <div className="border-t border-line px-5">
                <Switch
                  checked={!muted}
                  onChange={(v) => void updateMembership(conv.id, { mutedUntil: v ? null : 'forever' }).catch((err: unknown) => toast({ text: errorText(t, err), tone: 'danger' }))}
                  label={
                    <span className="flex items-center gap-2">
                      <Bell size={17} className="text-ink-3" /> {t('info.notifications')}
                    </span>
                  }
                />
              </div>
            )}

            {isAdmin && (
              <div className="flex flex-col border-t border-line px-3 py-2">
                {[
                  { v: 'edit' as View, icon: Pencil, label: t('info.edit') },
                  { v: 'permissions' as View, icon: SlidersHorizontal, label: t('info.permissions') },
                  { v: 'invites' as View, icon: Link2, label: t('info.inviteLinks') },
                  { v: 'audit' as View, icon: ClipboardList, label: t('info.auditLog') },
                ].map((x) => (
                  <button key={x.v} type="button" onClick={() => setView(x.v)} className="flex items-center gap-4 rounded-[12px] px-2 py-2.5 text-left text-[0.93rem] text-ink hover:bg-sunken">
                    <x.icon size={18} className="text-ink-3" /> {x.label}
                  </button>
                ))}
              </div>
            )}

            {(conv.type === 'group' || conv.type === 'channel') && conv.me && (
              <div className="border-t border-line">
                <Members conv={conv} />
              </div>
            )}

            {conv.me && (
              <div className="border-t border-line">
                <SharedMedia conversationId={conv.id} onJump={onJump} />
              </div>
            )}

            {(conv.type === 'group' || conv.type === 'channel') && conv.me && (
              <div className="flex flex-col border-t border-line p-3">
                <Button
                  variant="ghost"
                  className="justify-start !text-danger"
                  icon={<LogOut size={18} />}
                  onClick={async () => {
                    const r = await confirmDialog({ title: t('chats.leave'), body: t('chats.leaveConfirm', { title: conv.title }), danger: true, confirmLabel: t('chats.leave') });
                    if (!r.ok) return;
                    try {
                      await http.post(`/api/conversations/${conv.id}/leave`);
                      useChat.getState().removeConversation(conv.id);
                      onClose();
                      nav('/chat');
                    } catch (err) {
                      toast({ text: errorText(t, err), tone: 'danger' });
                    }
                  }}
                >
                  {t('info.leave')}
                </Button>
                {pc && can.deleteConversation(pc) && (
                  <Button
                    variant="ghost"
                    className="justify-start !text-danger"
                    icon={<Trash2 size={18} />}
                    onClick={async () => {
                      const r = await confirmDialog({ title: t('info.deleteChat'), body: t('info.deleteChatConfirm', { title: conv.title }), danger: true, confirmLabel: t('common.delete') });
                      if (!r.ok) return;
                      try {
                        await http.del(`/api/conversations/${conv.id}`);
                        useChat.getState().removeConversation(conv.id);
                        onClose();
                        nav('/chat');
                      } catch (err) {
                        toast({ text: errorText(t, err), tone: 'danger' });
                      }
                    }}
                  >
                    {t('info.deleteChat')}
                  </Button>
                )}
                {pc && can.editInfo(pc) && (
                  <p className="mt-2 flex items-center gap-1.5 px-2 text-[0.75rem] text-ink-3">
                    <ShieldCheck size={13} /> {t(`info.role.${conv.me.role}` as MessageKey)}
                  </p>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </aside>
  );
}
