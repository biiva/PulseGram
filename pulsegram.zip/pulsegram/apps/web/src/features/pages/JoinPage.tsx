import { useQuery } from '@tanstack/react-query';
import { Link2Off } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import type { ConversationDto, InvitePreview, UserProfile } from '@pulsegram/shared';
import { Avatar } from '../../components/ui/Avatar';
import { Button } from '../../components/ui/Button';
import { EmptyState, Spinner } from '../../components/ui/misc';
import { useT } from '../../i18n';
import { errorText, http } from '../../lib/api';
import { openDirectWith } from '../../lib/chatActions';
import { useChat } from '../../stores/chat';
import { toast } from '../../stores/ui';

export function JoinPage() {
  const t = useT();
  const { token = '' } = useParams();
  const nav = useNavigate();
  const [busy, setBusy] = useState(false);
  const q = useQuery({ queryKey: ['invite', token], queryFn: () => http.get<InvitePreview>(`/api/invites/${token}`), retry: false });
  if (q.isLoading) return <div className="grid h-full w-full place-items-center text-ink-3"><Spinner /></div>;
  if (q.isError || !q.data)
    return (
      <div className="grid h-full w-full place-items-center">
        <EmptyState icon={<Link2Off size={24} />} title={t('join.invalid')} action={<Button onClick={() => nav('/chat')}>{t('pages.goHome')}</Button>} />
      </div>
    );
  const c = q.data.conversation;
  return (
    <div className="chat-wallpaper grid h-full w-full place-items-center p-6">
      <div className="flex w-full max-w-sm flex-col items-center rounded-[24px] bg-raised p-8 text-center shadow-2">
        <p className="mb-5 text-[0.85rem] font-semibold text-ink-3">{t('join.title')}</p>
        <Avatar id={c.id} name={c.title} src={c.avatarUrl} size={96} kind={c.type === 'channel' ? 'channel' : 'group'} />
        <h1 className="mt-4 text-[1.35rem] font-extrabold text-ink">{c.title}</h1>
        <p className="text-[0.88rem] text-ink-3">{c.type === 'channel' ? t('common.subscribers', { n: c.memberCount }) : t('common.members', { n: c.memberCount })}</p>
        {c.description && <p className="mt-3 line-clamp-4 text-[0.9rem] text-ink-2">{c.description}</p>}
        <Button
          size="lg"
          className="mt-6 w-full"
          loading={busy}
          onClick={async () => {
            if (q.data!.alreadyMember) return nav(`/chat/${c.id}`);
            setBusy(true);
            try {
              const conv = await http.post<ConversationDto>(`/api/invites/${token}/join`);
              useChat.getState().upsertConversation(conv);
              nav(`/chat/${conv.id}`, { replace: true });
            } catch (err) {
              toast({ text: errorText(t, err), tone: 'danger' });
            } finally {
              setBusy(false);
            }
          }}
        >
          {q.data.alreadyMember ? t('join.open') : t('join.join')}
        </Button>
      </div>
    </div>
  );
}

/** /u/:username — opens a person's chat or a public group/channel. */
export function UserLinkPage() {
  const t = useT();
  const { username = '' } = useParams();
  const nav = useNavigate();
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let alive = true;
    http
      .get<{ kind: 'user'; profile: UserProfile } | { kind: 'conversation'; conversationId: string }>(`/api/users/by-username/${encodeURIComponent(username)}`)
      .then(async (r) => {
        if (!alive) return;
        if (r.kind === 'conversation') nav(`/chat/${r.conversationId}`, { replace: true });
        else {
          const c = await openDirectWith(r.profile.id);
          nav(`/chat/${c.id}`, { replace: true });
        }
      })
      .catch((err: unknown) => alive && setError(errorText(t, err)));
    return () => {
      alive = false;
    };
  }, [username, nav, t]);
  return <div className="grid h-full w-full place-items-center text-ink-3">{error ? <EmptyState title={error} action={<Button onClick={() => nav('/chat')}>{t('pages.goHome')}</Button>} /> : <Spinner />}</div>;
}
