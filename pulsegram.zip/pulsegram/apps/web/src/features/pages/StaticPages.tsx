import { useQuery } from '@tanstack/react-query';
import { ArrowLeft } from 'lucide-react';
import type { ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { APP_VERSION } from '@pulsegram/shared';
import { Logo } from '../../components/ui/misc';
import { useLang, useT } from '../../i18n';
import { http } from '../../lib/api';
import { useAuth } from '../../stores/auth';

type Page = 'about' | 'help' | 'privacy' | 'terms' | 'changelog' | 'status';

const H = ({ children }: { children: ReactNode }) => <h2 className="mt-8 mb-2 text-[1.15rem] font-bold text-ink">{children}</h2>;
const P = ({ children }: { children: ReactNode }) => <p className="mb-3 text-[0.97rem] leading-relaxed text-ink-2">{children}</p>;
const L = ({ items }: { items: ReactNode[] }) => (
  <ul className="mb-3 list-disc space-y-1.5 pl-5 text-[0.97rem] leading-relaxed text-ink-2">
    {items.map((i, k) => (
      <li key={k}>{i}</li>
    ))}
  </ul>
);

const CONTENT: Record<Page, Record<'en' | 'ru', () => ReactNode>> = {
  about: {
    en: () => (
      <>
        <P>PulseGram is a messenger for personal chats, groups, channels, file sharing and calls. It is built to be fast, private by default, and honest about what it does.</P>
        <H>What PulseGram does today</H>
        <L items={['Real-time personal and group chats synced across your devices', 'Channels with subscriber-only posting rules and real view counts', 'Photos, videos, voice messages and documents up to the server’s upload limit', 'One-to-one voice and video calls over WebRTC', 'Privacy controls for last seen, profile photo, phone, calls and group invites']} />
        <H>What it does not do (yet)</H>
        <P>Messages are encrypted in transit when the server uses HTTPS, and stored on the server. End-to-end encryption is not implemented. Group calls are not available yet.</P>
      </>
    ),
    ru: () => (
      <>
        <P>PulseGram — мессенджер для личных чатов, групп, каналов, обмена файлами и звонков. Он быстрый, приватный по умолчанию и честно говорит о том, что умеет.</P>
        <H>Что PulseGram умеет сейчас</H>
        <L items={['Личные и групповые чаты в реальном времени с синхронизацией между устройствами', 'Каналы с правилами публикации и настоящими счётчиками просмотров', 'Фото, видео, голосовые сообщения и документы в пределах лимита сервера', 'Аудио- и видеозвонки один на один через WebRTC', 'Настройки приватности: время входа, фото, телефон, звонки и приглашения в группы']} />
        <H>Чего пока нет</H>
        <P>Сообщения шифруются при передаче, если сервер работает по HTTPS, и хранятся на сервере. Сквозное шифрование не реализовано. Групповых звонков пока нет.</P>
      </>
    ),
  },
  help: {
    en: () => (
      <>
        <H>Starting a chat</H>
        <P>Use the pencil button or press Ctrl/⌘+K and type a name or @username. Open the person and send a message — the chat appears for them once the first message arrives.</P>
        <H>Groups and channels</H>
        <P>Create a group to talk with several people, or a channel to broadcast. Admins can change permissions, create invite links, set slow mode and see recent admin actions in the chat info panel.</P>
        <H>Files and voice</H>
        <P>Drag files into a chat, paste images, or use the paperclip. Images are re-encoded to remove location metadata; tick “Send without compression” to send the original as a document. Hold nothing — click the microphone to record a voice message and click send when done.</P>
        <H>Security</H>
        <P>Review signed-in devices under Settings → Devices and sign out anything you do not recognise. Changing your password signs out every other device.</P>
        <H>Calls do not connect</H>
        <P>Calls between different networks need a TURN relay server. If your server administrator has not configured one, calls only work when both devices can reach each other directly.</P>
      </>
    ),
    ru: () => (
      <>
        <H>Как начать чат</H>
        <P>Нажмите кнопку с карандашом или Ctrl/⌘+K и введите имя или @username. Откройте человека и отправьте сообщение — чат появится у собеседника после первого сообщения.</P>
        <H>Группы и каналы</H>
        <P>Создайте группу для общения нескольких людей или канал для публикаций. Администраторы меняют разрешения, создают пригласительные ссылки, включают медленный режим и видят журнал действий в панели информации.</P>
        <H>Файлы и голосовые</H>
        <P>Перетащите файлы в чат, вставьте изображение или нажмите скрепку. Фото пересжимаются, чтобы удалить данные о местоположении; отметьте «Отправить без сжатия», чтобы отправить оригинал документом. Нажмите на микрофон, чтобы записать голосовое, и на кнопку отправки, чтобы его отправить.</P>
        <H>Безопасность</H>
        <P>Проверяйте активные устройства в «Настройки → Устройства» и завершайте незнакомые сеансы. Смена пароля завершает все остальные сеансы.</P>
        <H>Звонок не соединяется</H>
        <P>Для звонков между разными сетями нужен TURN-сервер. Если администратор его не настроил, звонки работают только при прямой связи между устройствами.</P>
      </>
    ),
  },
  privacy: {
    en: () => (
      <>
        <P>This policy describes how a PulseGram server operated by your provider handles your data. The operator of this server is responsible for it.</P>
        <H>Data we store</H>
        <L items={['Account: email, username, display name, password hash (Argon2id — never the password itself)', 'Profile details you choose to add: photo, bio, phone, status', 'Messages, reactions, read positions and files you send, so they sync across devices', 'Signed-in devices: browser name, IP address and last activity', 'Security logs of sign-ins, password changes and moderation actions (no message contents)']} />
        <H>What we do not do</H>
        <P>We do not sell data and do not show ads. Message contents are not written to server logs.</P>
        <H>Your controls</H>
        <P>You can export your data and delete your account from Settings → Data &amp; account. Deleting your account erases your profile; messages you sent remain in other people’s chats attributed to “Deleted account”.</P>
        <H>Encryption</H>
        <P>Traffic is encrypted with TLS when the server is deployed with HTTPS. Messages are stored on the server without end-to-end encryption.</P>
      </>
    ),
    ru: () => (
      <>
        <P>Эта политика описывает, как сервер PulseGram, которым управляет ваш провайдер, обращается с данными. Ответственность за сервер несёт его оператор.</P>
        <H>Какие данные хранятся</H>
        <L items={['Аккаунт: email, имя пользователя, отображаемое имя, хеш пароля (Argon2id — сам пароль не хранится)', 'Данные профиля, которые вы добавили: фото, описание, телефон, статус', 'Сообщения, реакции, отметки прочтения и файлы — для синхронизации между устройствами', 'Устройства: название браузера, IP-адрес и время последней активности', 'Журнал безопасности: входы, смены пароля, действия модераторов (без текста сообщений)']} />
        <H>Чего мы не делаем</H>
        <P>Мы не продаём данные и не показываем рекламу. Текст сообщений не записывается в журналы сервера.</P>
        <H>Ваши возможности</H>
        <P>Экспорт данных и удаление аккаунта доступны в «Настройки → Данные и аккаунт». После удаления профиль стирается; отправленные вами сообщения остаются у собеседников от «Удалённого аккаунта».</P>
        <H>Шифрование</H>
        <P>Трафик шифруется TLS, если сервер развёрнут с HTTPS. Сообщения хранятся на сервере без сквозного шифрования.</P>
      </>
    ),
  },
  terms: {
    en: () => (
      <>
        <P>By creating an account you agree to use PulseGram lawfully and respectfully.</P>
        <L items={['Do not send spam, malware, or content that is illegal where you or the recipient live.', 'Do not harass, threaten or impersonate other people.', 'Do not attempt to access other people’s accounts or chats, or to disrupt the service.', 'Public channels and groups must follow these rules; admins are responsible for moderating them.', 'The operator may suspend accounts that break these rules, and may act on user reports.']} />
        <P>The service is provided “as is”. The operator may change these terms; continued use means you accept the updated terms.</P>
      </>
    ),
    ru: () => (
      <>
        <P>Создавая аккаунт, вы соглашаетесь использовать PulseGram законно и уважительно.</P>
        <L items={['Не рассылайте спам, вредоносные файлы и контент, незаконный в вашей стране или стране получателя.', 'Не преследуйте, не угрожайте и не выдавайте себя за других людей.', 'Не пытайтесь получить доступ к чужим аккаунтам и чатам или нарушить работу сервиса.', 'Публичные каналы и группы обязаны соблюдать эти правила; модерация — обязанность их администраторов.', 'Оператор может заблокировать аккаунты, нарушающие правила, и реагирует на жалобы пользователей.']} />
        <P>Сервис предоставляется «как есть». Оператор может менять условия; продолжая пользоваться сервисом, вы принимаете обновлённые условия.</P>
      </>
    ),
  },
  changelog: {
    en: () => (
      <>
        <H>0.1.0 — first release</H>
        <L items={['Registration with email confirmation, password reset, device management', 'Personal chats, groups with roles and permissions, channels with view counts', 'Replies, edits, deletions, reactions, pins, forwarding, drafts, read receipts', 'Photos, videos, voice messages, documents, stickers, optional GIF search', 'One-to-one WebRTC calls, chat folders, archive, saved messages, global search', 'Light/dark themes, custom accent, English and Russian']} />
      </>
    ),
    ru: () => (
      <>
        <H>0.1.0 — первый выпуск</H>
        <L items={['Регистрация с подтверждением email, сброс пароля, управление устройствами', 'Личные чаты, группы с ролями и разрешениями, каналы со счётчиком просмотров', 'Ответы, редактирование, удаление, реакции, закрепление, пересылка, черновики, отметки прочтения', 'Фото, видео, голосовые, документы, стикеры, поиск GIF (если настроен)', 'Звонки один на один через WebRTC, папки, архив, избранное, глобальный поиск', 'Светлая и тёмная темы, свой цвет акцента, английский и русский языки']} />
      </>
    ),
  },
  status: { en: () => <StatusBody />, ru: () => <StatusBody /> },
};

function StatusBody() {
  const q = useQuery({
    queryKey: ['health'],
    queryFn: () => http.get<{ status: string; version: string; uptimeSec: number; checks: Record<string, string> }>('/api/health'),
    refetchInterval: 30_000,
  });
  if (q.isLoading) return <P>…</P>;
  if (q.isError) return <P>The API is not reachable right now.</P>;
  const d = q.data!;
  return (
    <>
      <p className={`mb-4 text-[1.1rem] font-bold ${d.status === 'ok' ? 'text-success' : 'text-warning'}`}>{d.status === 'ok' ? 'All systems operational' : 'Degraded'}</p>
      <table className="w-full text-left text-[0.95rem]">
        <tbody>
          {Object.entries(d.checks).map(([k, v]) => (
            <tr key={k} className="border-b border-line">
              <td className="py-2 text-ink-2">{k}</td>
              <td className="py-2 font-semibold text-ink">{v}</td>
            </tr>
          ))}
          <tr>
            <td className="py-2 text-ink-2">uptime</td>
            <td className="py-2 font-semibold text-ink">{Math.round(d.uptimeSec / 60)} min</td>
          </tr>
        </tbody>
      </table>
    </>
  );
}

const TITLES: Record<Page, 'pages.about' | 'pages.help' | 'pages.privacy' | 'pages.terms' | 'pages.changelog' | 'pages.status'> = {
  about: 'pages.about',
  help: 'pages.help',
  privacy: 'pages.privacy',
  terms: 'pages.terms',
  changelog: 'pages.changelog',
  status: 'pages.status',
};

export function StaticPage({ page }: { page: Page }) {
  const t = useT();
  const lang = useLang();
  const nav = useNavigate();
  const authed = useAuth((s) => s.status === 'authed');
  return (
    <div className="min-h-dvh bg-bg">
      <header className="sticky top-0 z-10 flex items-center gap-3 border-b border-line bg-bg/95 px-4 py-3 backdrop-blur">
        <button type="button" onClick={() => (window.history.length > 1 ? nav(-1) : nav(authed ? '/chat' : '/welcome'))} className="grid size-10 place-items-center rounded-full text-ink-2 hover:bg-sunken" aria-label={t('common.back')}>
          <ArrowLeft size={20} />
        </button>
        <Link to={authed ? '/chat' : '/welcome'}>
          <Logo size={30} withText />
        </Link>
      </header>
      <main className="mx-auto max-w-[68ch] px-5 py-10">
        <h1 className="text-[2rem] font-extrabold tracking-[-0.02em] text-ink">{t(TITLES[page])}</h1>
        <p className="mt-1 mb-6 text-[0.85rem] text-ink-3">{t('pages.version', { v: APP_VERSION })}</p>
        {CONTENT[page][lang]()}
      </main>
    </div>
  );
}
