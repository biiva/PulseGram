// PulseGram service worker: Web Push notifications only (no offline caching of private data).
self.addEventListener('push', (event) => {
  let data = { title: 'PulseGram', body: 'New message', url: '/chat' };
  try { data = Object.assign(data, event.data ? event.data.json() : {}); } catch (e) {}
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      // Skip the system notification when a PulseGram window is focused — the app shows its own.
      if (list.some((c) => c.focused)) return;
      return self.registration.showNotification(data.title, { body: data.body, tag: data.tag, icon: '/favicon.svg', data: { url: data.url } });
    }),
  );
});
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || '/chat';
  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
      for (const c of list) { if ('focus' in c) { c.navigate(url); return c.focus(); } }
      return self.clients.openWindow(url);
    }),
  );
});
