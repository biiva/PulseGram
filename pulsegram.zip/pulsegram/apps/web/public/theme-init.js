// Apply the stored theme before first paint (external file so a strict CSP can forbid inline scripts).
try {
  var t = localStorage.getItem('pg.theme') || 'system';
  var dark = t === 'dark' || (t === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
  document.documentElement.dataset.theme = dark ? 'dark' : 'light';
  var a = localStorage.getItem('pg.accent');
  if (a && /^#[0-9a-fA-F]{6}$/.test(a)) document.documentElement.style.setProperty('--accent', a);
  var d = localStorage.getItem('pg.density');
  if (d) document.documentElement.dataset.density = d;
} catch (e) {}
