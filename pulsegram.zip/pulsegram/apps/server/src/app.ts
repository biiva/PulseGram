import fs from 'node:fs';
import path from 'node:path';
import Fastify, { type FastifyInstance } from 'fastify';
import cookie from '@fastify/cookie';
import helmet from '@fastify/helmet';
import multipart from '@fastify/multipart';
import websocket from '@fastify/websocket';
import { Redis } from 'ioredis';
import type { AppConfig } from './config';
import type { AppContext } from './context';
import { createDb } from './db/client';
import { AppError } from './lib/errors';
import { MemoryRateLimiter, RedisRateLimiter } from './lib/rateLimit';
import { registerAuthRoutes } from './modules/auth/routes';
import { resolveSessionToken, SESSION_COOKIE } from './modules/auth/session';
import { expireStaleCalls } from './modules/calls/service';
import { registerConversationRoutes } from './modules/conversations/routes';
import { registerFileRoutes } from './modules/files/routes';
import { registerMiscRoutes } from './modules/misc/routes';
import { registerSearchRoutes } from './modules/search/routes';
import { ensureBuiltinStickers } from './modules/stickers/builtin';
import { registerUserRoutes } from './modules/users/routes';
import { allowedOrigins, installPresence, registerGateway } from './realtime/gateway';
import { RealtimeHub } from './realtime/hub';
import { LocalBroker, MemoryPresenceStore, RedisBroker, RedisPresenceStore } from './services/broker';
import { createMailer } from './services/mailer';
import { createPushService } from './services/push';
import { createStorage } from './services/storage';

export interface BuiltApp {
  app: FastifyInstance;
  ctx: AppContext;
  close: () => Promise<void>;
}

/** Fields that must never reach the logs. */
const REDACT = [
  'req.headers.cookie',
  'req.headers.authorization',
  'req.headers["x-csrf-token"]',
  'res.headers["set-cookie"]',
  '*.password',
  '*.currentPassword',
  '*.newPassword',
  '*.token',
  '*.text',
];

export async function buildApp(config: AppConfig): Promise<BuiltApp> {
  const app = Fastify({
    logger:
      config.LOG_LEVEL === 'silent'
        ? false
        : {
            level: config.LOG_LEVEL,
            redact: { paths: REDACT, censor: '[redacted]' },
            transport: !config.isProd && !config.isTest ? { target: 'pino-pretty', options: { translateTime: 'HH:MM:ss', ignore: 'pid,hostname' } } : undefined,
          },
    trustProxy: config.TRUST_PROXY,
    bodyLimit: 1024 * 1024,
  });

  const { db, pool } = createDb(config.DATABASE_URL, config.DATABASE_POOL_MAX);
  const redis = config.REDIS_URL ? new Redis(config.REDIS_URL, { maxRetriesPerRequest: 2, lazyConnect: false }) : null;
  const redisSub = config.REDIS_URL ? new Redis(config.REDIS_URL) : null;
  const broker = redis && redisSub ? new RedisBroker(redis, redisSub) : new LocalBroker();
  const presence = redis ? new RedisPresenceStore(redis) : new MemoryPresenceStore();
  const hub = new RealtimeHub(broker, presence);

  const ctx: AppContext = {
    config,
    db,
    redis,
    log: app.log,
    limiter: redis ? new RedisRateLimiter(redis) : new MemoryRateLimiter(),
    mailer: createMailer(config, app.log),
    storage: createStorage(config),
    broker,
    presence,
    hub,
    push: await createPushService(config, db, app.log),
  };
  installPresence(ctx);

  await app.register(cookie);
  await app.register(helmet, {
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", 'https://challenges.cloudflare.com'],
        styleSrc: ["'self'", "'unsafe-inline'"],
        fontSrc: ["'self'", 'data:'],
        imgSrc: ["'self'", 'data:', 'blob:', 'https://media.tenor.com', 'https://*.giphy.com'],
        mediaSrc: ["'self'", 'blob:'],
        connectSrc: ["'self'", 'ws:', 'wss:'],
        frameSrc: ['https://challenges.cloudflare.com'],
        objectSrc: ["'none'"],
        baseUri: ["'self'"],
        frameAncestors: ["'none'"],
        formAction: ["'self'"],
        // Only force https sub-resources when the app is actually served over https.
        upgradeInsecureRequests: config.cookieSecure ? [] : null,
      },
    },
    crossOriginEmbedderPolicy: false,
    crossOriginResourcePolicy: { policy: 'same-origin' },
  });
  await app.register(multipart, { limits: { fileSize: config.maxUploadBytes, files: 1, fields: 10 } });
  await app.register(websocket, { options: { maxPayload: 64 * 1024 } });

  app.decorateRequest('auth', null);

  // Resolve the session for API requests; origin-check state-changing requests (CSRF defence in depth).
  const origins = allowedOrigins(ctx);
  app.addHook('onRequest', async (req) => {
    if (!req.url.startsWith('/api/')) return;
    if (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'OPTIONS') {
      const origin = req.headers.origin;
      if (origin && !origins.has(origin)) throw new AppError(403, 'origin_not_allowed', 'Cross-site request blocked');
    }
    req.auth = await resolveSessionToken(ctx, req.cookies[SESSION_COOKIE]);
  });

  app.setErrorHandler((err, req, reply) => {
    if (err instanceof AppError) {
      if (err.status === 429) {
        const retry = (err.details as { retryAfterSec?: number } | undefined)?.retryAfterSec;
        if (retry) reply.header('Retry-After', String(retry));
      }
      return reply.code(err.status).send({ error: { code: err.code, message: err.message, details: err.details } });
    }
    const e = err as { statusCode?: number; code?: string; message?: string };
    if (e.code === 'FST_REQ_FILE_TOO_LARGE' || e.statusCode === 413) {
      return reply.code(413).send({ error: { code: 'payload_too_large', message: 'File is too large' } });
    }
    if (e.statusCode && e.statusCode >= 400 && e.statusCode < 500) {
      return reply.code(e.statusCode).send({ error: { code: e.code?.toLowerCase() ?? 'bad_request', message: e.message ?? 'Bad request' } });
    }
    req.log.error({ err }, 'unhandled error');
    return reply.code(500).send({ error: { code: 'internal', message: 'Something went wrong on our side' } });
  });

  app.setNotFoundHandler((req, reply) => {
    if (req.url.startsWith('/api/') || req.url.startsWith('/ws')) {
      return reply.code(404).send({ error: { code: 'not_found', message: 'Not found' } });
    }
    if (webIndex) return reply.type('text/html').header('Cache-Control', 'no-cache').send(webIndex);
    return reply.code(404).send({ error: { code: 'not_found', message: 'Not found' } });
  });

  await registerAuthRoutes(app, ctx);
  await registerUserRoutes(app, ctx);
  await registerConversationRoutes(app, ctx);
  await registerFileRoutes(app, ctx);
  await registerSearchRoutes(app, ctx);
  await registerMiscRoutes(app, ctx);
  await registerGateway(app, ctx);

  // Optional: serve the built SPA from the same origin (single-process deployment).
  let webIndex: string | null = null;
  if (config.SERVE_WEB_DIST) {
    const dist = path.resolve(config.SERVE_WEB_DIST);
    const indexFile = path.join(dist, 'index.html');
    if (fs.existsSync(indexFile)) {
      webIndex = fs.readFileSync(indexFile, 'utf8');
      const fastifyStatic = (await import('@fastify/static')).default;
      await app.register(fastifyStatic, {
        root: dist,
        wildcard: false,
        index: false,
        setHeaders(res, filePath) {
          res.header('Cache-Control', filePath.includes(`${path.sep}assets${path.sep}`) ? 'public, max-age=31536000, immutable' : 'no-cache');
        },
      });
      app.get('/', (_req, reply) => reply.type('text/html').header('Cache-Control', 'no-cache').send(webIndex));
    } else {
      app.log.warn(`SERVE_WEB_DIST=${dist} has no index.html — run "npm run build" first`);
    }
  }

  await ensureBuiltinStickers(ctx);
  await expireStaleCalls(ctx).catch(() => {});

  const close = async () => {
    hub.closeAll(4503, 'server shutting down');
    await app.close();
    await broker.close();
    await pool.end();
    redis?.disconnect();
    redisSub?.disconnect();
  };
  return { app, ctx, close };
}
