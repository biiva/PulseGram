import type { Redis } from 'ioredis';

/**
 * Cross-instance fan-out. With a single server process the LocalBroker is enough; when
 * REDIS_URL is configured every instance subscribes to one channel so events reach users
 * connected to any instance.
 */
export type BrokerMessage =
  | { kind: 'users'; userIds: string[]; frame: string; exceptSessionId?: string; onlySessionId?: string }
  | { kind: 'presence'; userId: string }
  | { kind: 'revoke-session'; sessionId: string }
  | { kind: 'revoke-user'; userId: string; exceptSessionId?: string };

export interface Broker {
  publish(msg: BrokerMessage): Promise<void>;
  onMessage(handler: (msg: BrokerMessage) => void): void;
  close(): Promise<void>;
}

export class LocalBroker implements Broker {
  private handlers: Array<(msg: BrokerMessage) => void> = [];
  async publish(msg: BrokerMessage) {
    for (const h of this.handlers) h(msg);
  }
  onMessage(handler: (msg: BrokerMessage) => void) {
    this.handlers.push(handler);
  }
  async close() {}
}

const CHANNEL = 'pulsegram:events';

export class RedisBroker implements Broker {
  private handlers: Array<(msg: BrokerMessage) => void> = [];

  constructor(
    private pub: Redis,
    private sub: Redis,
  ) {
    void this.sub.subscribe(CHANNEL);
    this.sub.on('message', (_channel: string, raw: string) => {
      let msg: BrokerMessage;
      try {
        msg = JSON.parse(raw) as BrokerMessage;
      } catch {
        return;
      }
      for (const h of this.handlers) h(msg);
    });
  }

  async publish(msg: BrokerMessage) {
    await this.pub.publish(CHANNEL, JSON.stringify(msg));
  }

  onMessage(handler: (msg: BrokerMessage) => void) {
    this.handlers.push(handler);
  }

  async close() {
    await this.sub.quit().catch(() => {});
  }
}

/** Tracks how many live connections each user has, across instances when Redis is available. */
export interface PresenceStore {
  connect(userId: string): Promise<number>;
  disconnect(userId: string): Promise<number>;
  onlineSet(userIds: string[]): Promise<Set<string>>;
}

export class MemoryPresenceStore implements PresenceStore {
  private counts = new Map<string, number>();
  async connect(userId: string) {
    const n = (this.counts.get(userId) ?? 0) + 1;
    this.counts.set(userId, n);
    return n;
  }
  async disconnect(userId: string) {
    const n = Math.max(0, (this.counts.get(userId) ?? 0) - 1);
    if (n === 0) this.counts.delete(userId);
    else this.counts.set(userId, n);
    return n;
  }
  async onlineSet(userIds: string[]) {
    return new Set(userIds.filter((id) => (this.counts.get(id) ?? 0) > 0));
  }
}

export class RedisPresenceStore implements PresenceStore {
  constructor(private redis: Redis) {}
  async connect(userId: string) {
    const n = await this.redis.hincrby('presence:conns', userId, 1);
    return n;
  }
  async disconnect(userId: string) {
    const n = await this.redis.hincrby('presence:conns', userId, -1);
    if (n <= 0) await this.redis.hdel('presence:conns', userId);
    return Math.max(0, n);
  }
  async onlineSet(userIds: string[]) {
    if (userIds.length === 0) return new Set<string>();
    const vals = await this.redis.hmget('presence:conns', ...userIds);
    return new Set(userIds.filter((_, i) => Number(vals[i] ?? 0) > 0));
  }
}
