import fs from 'node:fs/promises';
import path from 'node:path';
import nodemailer, { type Transporter } from 'nodemailer';
import type { FastifyBaseLogger } from 'fastify';
import type { AppConfig } from '../config';

export interface MailMessage {
  to: string;
  subject: string;
  text: string;
  html: string;
}

export interface Mailer {
  readonly configured: boolean;
  send(msg: MailMessage): Promise<void>;
  /** Only populated in test mode — lets integration tests read verification links. */
  readonly outbox: MailMessage[];
}

/**
 * Real SMTP delivery when SMTP_* is configured.
 * In development (DEV_MAILBOX=true, never in production) mail is written to ./data/dev-mailbox
 * and the server log so you can click verification links locally. In tests it is captured in memory.
 * Without either, `configured` is false and the UI tells the user email is not set up.
 */
export function createMailer(config: AppConfig, log: FastifyBaseLogger): Mailer {
  const outbox: MailMessage[] = [];

  if (config.isTest) {
    return {
      configured: true,
      outbox,
      async send(msg) {
        outbox.push(msg);
      },
    };
  }

  let transport: Transporter | null = null;
  if (config.SMTP_HOST) {
    transport = nodemailer.createTransport({
      host: config.SMTP_HOST,
      port: config.SMTP_PORT,
      secure: config.SMTP_SECURE,
      auth: config.SMTP_USER ? { user: config.SMTP_USER, pass: config.SMTP_PASS } : undefined,
    });
  }

  return {
    configured: config.emailConfigured,
    outbox,
    async send(msg) {
      if (transport) {
        await transport.sendMail({ from: config.MAIL_FROM, to: msg.to, subject: msg.subject, text: msg.text, html: msg.html });
        log.info({ subject: msg.subject }, 'mail sent');
        return;
      }
      if (config.DEV_MAILBOX && !config.isProd) {
        const dir = path.resolve('data/dev-mailbox');
        await fs.mkdir(dir, { recursive: true });
        const file = path.join(dir, `${new Date().toISOString().replace(/[:.]/g, '-')}.txt`);
        await fs.writeFile(file, `To: ${msg.to}\nSubject: ${msg.subject}\n\n${msg.text}\n`);
        log.warn(`[DEV MAILBOX] "${msg.subject}" → ${file}\n${msg.text}`);
        return;
      }
      throw new Error('Email is not configured');
    },
  };
}

type Lang = 'en' | 'ru';

const T = {
  verify: {
    en: {
      subject: 'Confirm your PulseGram email',
      intro: 'Welcome to PulseGram! Confirm your email address to finish setting up your account.',
      cta: 'Confirm email',
      outro: 'This link expires in 24 hours. If you did not create an account, ignore this email.',
    },
    ru: {
      subject: 'Подтвердите email в PulseGram',
      intro: 'Добро пожаловать в PulseGram! Подтвердите адрес электронной почты, чтобы завершить настройку аккаунта.',
      cta: 'Подтвердить email',
      outro: 'Ссылка действует 24 часа. Если вы не создавали аккаунт, просто проигнорируйте это письмо.',
    },
  },
  reset: {
    en: {
      subject: 'Reset your PulseGram password',
      intro: 'Someone requested a password reset for your PulseGram account.',
      cta: 'Choose a new password',
      outro: 'This link expires in 1 hour and works once. If it was not you, you can safely ignore this email — your password stays the same.',
    },
    ru: {
      subject: 'Сброс пароля PulseGram',
      intro: 'Кто-то запросил сброс пароля для вашего аккаунта PulseGram.',
      cta: 'Задать новый пароль',
      outro: 'Ссылка действует 1 час и срабатывает один раз. Если это были не вы — просто проигнорируйте письмо, пароль останется прежним.',
    },
  },
} as const;

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]!);
}

export function buildEmail(kind: keyof typeof T, lang: Lang, name: string, link: string): Omit<MailMessage, 'to'> {
  const t = T[kind][lang];
  const greeting = lang === 'ru' ? `Привет, ${name}!` : `Hi ${name},`;
  const text = `${greeting}\n\n${t.intro}\n\n${t.cta}: ${link}\n\n${t.outro}\n\n— PulseGram`;
  const html = `<!doctype html><html><body style="margin:0;background:#f4f2fb;font-family:Inter,Segoe UI,Arial,sans-serif;color:#1b1d26">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr><td align="center" style="padding:40px 16px">
<table role="presentation" width="100%" style="max-width:480px;background:#fff;border-radius:20px;padding:32px;box-shadow:0 4px 24px rgba(124,77,255,.08)">
<tr><td style="font-size:20px;font-weight:700;color:#7C4DFF;padding-bottom:20px">● PulseGram</td></tr>
<tr><td style="font-size:16px;line-height:1.55;padding-bottom:12px">${escapeHtml(greeting)}</td></tr>
<tr><td style="font-size:15px;line-height:1.55;color:#454857;padding-bottom:24px">${escapeHtml(t.intro)}</td></tr>
<tr><td style="padding-bottom:24px"><a href="${escapeHtml(link)}" style="display:inline-block;background:#7C4DFF;color:#fff;text-decoration:none;font-weight:600;padding:12px 22px;border-radius:12px">${escapeHtml(t.cta)}</a></td></tr>
<tr><td style="font-size:13px;line-height:1.5;color:#7b7e8c">${escapeHtml(t.outro)}</td></tr>
</table></td></tr></table></body></html>`;
  return { subject: t.subject, text, html };
}
