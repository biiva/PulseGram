import fs from 'node:fs';
import fsp from 'node:fs/promises';
import path from 'node:path';
import { Readable } from 'node:stream';
import type { AppConfig } from '../config';

export interface StoredObject {
  stream: Readable;
  size: number;
}

/**
 * Object storage abstraction. Objects are private: they are never exposed by a public
 * static route — every download goes through an authorised API endpoint.
 */
export interface Storage {
  readonly driver: 'local' | 's3';
  put(key: string, body: Buffer, contentType: string): Promise<void>;
  get(key: string, range?: { start: number; end: number }): Promise<StoredObject>;
  stat(key: string): Promise<{ size: number }>;
  delete(key: string): Promise<void>;
}

class LocalStorage implements Storage {
  readonly driver = 'local' as const;
  constructor(private root: string) {}

  private resolve(key: string) {
    const p = path.resolve(this.root, key);
    if (!p.startsWith(path.resolve(this.root) + path.sep)) throw new Error('Invalid storage key');
    return p;
  }

  async put(key: string, body: Buffer) {
    const p = this.resolve(key);
    await fsp.mkdir(path.dirname(p), { recursive: true });
    await fsp.writeFile(p, body, { mode: 0o600 });
  }

  async stat(key: string) {
    const st = await fsp.stat(this.resolve(key));
    return { size: st.size };
  }

  async get(key: string, range?: { start: number; end: number }) {
    const p = this.resolve(key);
    const st = await fsp.stat(p);
    const stream = fs.createReadStream(p, range ? { start: range.start, end: range.end } : undefined);
    return { stream, size: range ? range.end - range.start + 1 : st.size };
  }

  async delete(key: string) {
    await fsp.rm(this.resolve(key), { force: true });
  }
}

class S3Storage implements Storage {
  readonly driver = 's3' as const;
  private clientPromise: Promise<import('@aws-sdk/client-s3').S3Client>;

  constructor(private config: AppConfig) {
    this.clientPromise = import('@aws-sdk/client-s3').then(
      ({ S3Client }) =>
        new S3Client({
          region: config.S3_REGION,
          endpoint: config.S3_ENDPOINT,
          forcePathStyle: config.S3_FORCE_PATH_STYLE,
          credentials:
            config.S3_ACCESS_KEY_ID && config.S3_SECRET_ACCESS_KEY
              ? { accessKeyId: config.S3_ACCESS_KEY_ID, secretAccessKey: config.S3_SECRET_ACCESS_KEY }
              : undefined,
        }),
    );
  }

  async put(key: string, body: Buffer, contentType: string) {
    const { PutObjectCommand } = await import('@aws-sdk/client-s3');
    const client = await this.clientPromise;
    await client.send(
      new PutObjectCommand({ Bucket: this.config.S3_BUCKET, Key: key, Body: body, ContentType: contentType, ACL: 'private' }),
    );
  }

  async stat(key: string) {
    const { HeadObjectCommand } = await import('@aws-sdk/client-s3');
    const client = await this.clientPromise;
    const r = await client.send(new HeadObjectCommand({ Bucket: this.config.S3_BUCKET, Key: key }));
    return { size: Number(r.ContentLength ?? 0) };
  }

  async get(key: string, range?: { start: number; end: number }) {
    const { GetObjectCommand } = await import('@aws-sdk/client-s3');
    const client = await this.clientPromise;
    const r = await client.send(
      new GetObjectCommand({
        Bucket: this.config.S3_BUCKET,
        Key: key,
        Range: range ? `bytes=${range.start}-${range.end}` : undefined,
      }),
    );
    return { stream: r.Body as Readable, size: Number(r.ContentLength ?? 0) };
  }

  async delete(key: string) {
    const { DeleteObjectCommand } = await import('@aws-sdk/client-s3');
    const client = await this.clientPromise;
    await client.send(new DeleteObjectCommand({ Bucket: this.config.S3_BUCKET, Key: key }));
  }
}

export function createStorage(config: AppConfig): Storage {
  if (config.STORAGE_DRIVER === 's3') {
    if (!config.S3_BUCKET) throw new Error('STORAGE_DRIVER=s3 requires S3_BUCKET');
    return new S3Storage(config);
  }
  if (config.isProd) {
    // Allowed (e.g. single-node deploys with a mounted volume), but worth a loud warning.
    console.warn('[storage] Using local disk storage in production. Mount STORAGE_LOCAL_DIR on a persistent volume or switch to S3.');
  }
  return new LocalStorage(path.resolve(config.STORAGE_LOCAL_DIR));
}
