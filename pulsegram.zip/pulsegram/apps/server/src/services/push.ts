import { eq, inArray } from 'drizzle-orm';
import type { FastifyBaseLogger } from 'fastify';
import type { AppConfig } from '../config';
import type { Database } from '../db/client';
import { pushSubscriptions } from '../db/schema';

export interface PushPayload {
  title: string;
  body: string;
  tag?: string;
  url?: string;
}

export interface PushService {
  readonly configured: boolean;
  sendToUser(userId: string, payload: PushPayload): Promise<void>;
}

/**
 * Web Push (VAPID). Only active when VAPID keys are configured, and only ever sends to
 * subscriptions the user explicitly created from the browser.
 */
export async function createPushService(config: AppConfig, db: Database, log: FastifyBaseLogger): Promise<PushService> {
  if (!config.pushConfigured) {
    return { configured: false, async sendToUser() {} };
  }
  const webpush = (await import('web-push')).default;
  webpush.setVapidDetails(config.VAPID_SUBJECT, config.VAPID_PUBLIC_KEY!, config.VAPID_PRIVATE_KEY!);
  return {
    configured: true,
    async sendToUser(userId, payload) {
      const subs = await db.select().from(pushSubscriptions).where(eq(pushSubscriptions.userId, userId));
      const dead: string[] = [];
      await Promise.all(
        subs.map(async (s) => {
          try {
            await webpush.sendNotification(
              { endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
              JSON.stringify(payload),
              { TTL: 60 * 60 },
            );
          } catch (err: unknown) {
            const status = (err as { statusCode?: number }).statusCode;
            if (status === 404 || status === 410) dead.push(s.id);
            else log.warn({ status }, 'push delivery failed');
          }
        }),
      );
      if (dead.length) await db.delete(pushSubscriptions).where(inArray(pushSubscriptions.id, dead));
    },
  };
}
