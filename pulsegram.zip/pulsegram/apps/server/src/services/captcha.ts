import type { AppConfig } from '../config';
import { errors } from '../lib/errors';

/**
 * Cloudflare Turnstile verification. Active only when TURNSTILE_* keys are set; otherwise
 * registration relies on the honeypot field + per-IP rate limits (documented limitation).
 */
export async function verifyCaptcha(config: AppConfig, token: string | undefined, ip: string): Promise<void> {
  if (!config.captchaConfigured) return;
  if (!token) throw errors.badRequest('captcha_required', 'Please complete the human verification');
  const body = new URLSearchParams({ secret: config.TURNSTILE_SECRET_KEY!, response: token, remoteip: ip });
  const res = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body });
  const json = (await res.json().catch(() => ({}))) as { success?: boolean };
  if (!json.success) throw errors.badRequest('captcha_failed', 'Human verification failed, please try again');
}
