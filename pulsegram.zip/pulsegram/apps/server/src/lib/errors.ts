export class AppError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
    message?: string,
    public readonly details?: unknown,
  ) {
    super(message ?? code);
  }
}

export const errors = {
  badRequest: (code = 'bad_request', message?: string, details?: unknown) => new AppError(400, code, message, details),
  unauthorized: (code = 'unauthorized', message = 'Authentication required') => new AppError(401, code, message),
  forbidden: (code = 'forbidden', message = 'You do not have permission to do this') => new AppError(403, code, message),
  notFound: (code = 'not_found', message = 'Not found') => new AppError(404, code, message),
  conflict: (code = 'conflict', message?: string) => new AppError(409, code, message),
  tooLarge: (message = 'Payload too large') => new AppError(413, 'payload_too_large', message),
  unsupported: (message = 'Unsupported media type') => new AppError(415, 'unsupported_media_type', message),
  tooMany: (retryAfterSec: number) => new AppError(429, 'rate_limited', 'Too many requests, slow down', { retryAfterSec }),
  notConfigured: (feature: string) =>
    new AppError(503, 'not_configured', `${feature} is not configured on this server`, { feature }),
};

/** Postgres error code, unwrapping driver/ORM wrappers (e.g. 23505 = unique violation). */
export function pgCode(err: unknown): string | undefined {
  let e: unknown = err;
  for (let i = 0; i < 4 && e; i++) {
    const code = (e as { code?: unknown }).code;
    if (typeof code === 'string' && /^[0-9A-Z]{5}$/.test(code)) return code;
    e = (e as { cause?: unknown }).cause;
  }
  return undefined;
}
