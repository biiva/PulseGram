import type { Redis } from 'ioredis';
import { errors } from './errors';

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  retryAfterSec: number;
}

export interface RateLimiter {
  /** Count one hit for `key` within a fixed window. */
  hit(key: string, limit: number, windowSec: number): Promise<RateLimitResult>;
  /** Inspect the current window without counting a hit. */
  peek(key: string, limit: number): Promise<RateLimitResult>;
  reset(key: string): Promise<void>;
}

export class MemoryRateLimiter implements RateLimiter {
  private buckets = new Map<string, { count: number; resetAt: number }>();
  private timer: NodeJS.Timeout;

  constructor() {
    this.timer = setInterval(() => this.sweep(), 60_000);
    this.timer.unref();
  }

  async hit(key: string, limit: number, windowSec: number): Promise<RateLimitResult> {
    const now = Date.now();
    let b = this.buckets.get(key);
    if (!b || b.resetAt <= now) {
      b = { count: 0, resetAt: now + windowSec * 1000 };
      this.buckets.set(key, b);
    }
    b.count++;
    const allowed = b.count <= limit;
    return { allowed, remaining: Math.max(0, limit - b.count), retryAfterSec: Math.ceil((b.resetAt - now) / 1000) };
  }

  async peek(key: string, limit: number): Promise<RateLimitResult> {
    const now = Date.now();
    const b = this.buckets.get(key);
    if (!b || b.resetAt <= now) return { allowed: true, remaining: limit, retryAfterSec: 0 };
    return { allowed: b.count < limit, remaining: Math.max(0, limit - b.count), retryAfterSec: Math.ceil((b.resetAt - now) / 1000) };
  }

  async reset(key: string): Promise<void> {
    this.buckets.delete(key);
  }

  private sweep() {
    const now = Date.now();
    for (const [k, b] of this.buckets) if (b.resetAt <= now) this.buckets.delete(k);
  }
}

export class RedisRateLimiter implements RateLimiter {
  constructor(private redis: Redis) {}

  async hit(key: string, limit: number, windowSec: number): Promise<RateLimitResult> {
    const k = `rl:${key}`;
    const res = await this.redis.multi().incr(k).pttl(k).exec();
    const count = Number(res?.[0]?.[1] ?? 1);
    let ttl = Number(res?.[1]?.[1] ?? -1);
    if (ttl < 0) {
      await this.redis.pexpire(k, windowSec * 1000);
      ttl = windowSec * 1000;
    }
    return { allowed: count <= limit, remaining: Math.max(0, limit - count), retryAfterSec: Math.ceil(ttl / 1000) };
  }

  async peek(key: string, limit: number): Promise<RateLimitResult> {
    const k = `rl:${key}`;
    const [count, ttl] = await Promise.all([this.redis.get(k), this.redis.pttl(k)]);
    const n = Number(count ?? 0);
    return { allowed: n < limit, remaining: Math.max(0, limit - n), retryAfterSec: Math.max(0, Math.ceil(ttl / 1000)) };
  }

  async reset(key: string): Promise<void> {
    await this.redis.del(`rl:${key}`);
  }
}

/** Throws a 429 AppError when the limit is exceeded. */
export async function enforce(limiter: RateLimiter, key: string, limit: number, windowSec: number): Promise<void> {
  const r = await limiter.hit(key, limit, windowSec);
  if (!r.allowed) throw errors.tooMany(r.retryAfterSec);
}
