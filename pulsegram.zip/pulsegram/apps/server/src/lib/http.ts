import type { z } from 'zod';
import { errors } from './errors';

/** Validate untrusted input; throws a 400 with field-level issues. */
export function parse<S extends z.ZodType>(schema: S, data: unknown): z.output<S> {
  const r = schema.safeParse(data);
  if (!r.success) {
    const issues = r.error.issues.map((i) => ({ path: i.path.join('.'), code: i.message }));
    throw errors.badRequest('validation_failed', 'Some fields are invalid', issues);
  }
  return r.data;
}

export const isUuid = (s: unknown): s is string =>
  typeof s === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(s);

export function uuidParam(params: unknown, key = 'id'): string {
  const v = (params as Record<string, unknown>)[key];
  if (!isUuid(v)) throw errors.notFound();
  return v;
}
