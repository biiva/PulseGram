import type { FastifyBaseLogger } from 'fastify';
import type { Redis } from 'ioredis';
import type { AppConfig } from './config';
import type { Database } from './db/client';
import type { RateLimiter } from './lib/rateLimit';
import type { Mailer } from './services/mailer';
import type { Storage } from './services/storage';
import type { Broker, PresenceStore } from './services/broker';
import type { RealtimeHub } from './realtime/hub';
import type { PushService } from './services/push';

export interface AppContext {
  config: AppConfig;
  db: Database;
  redis: Redis | null;
  log: FastifyBaseLogger;
  limiter: RateLimiter;
  mailer: Mailer;
  storage: Storage;
  broker: Broker;
  presence: PresenceStore;
  hub: RealtimeHub;
  push: PushService;
}
