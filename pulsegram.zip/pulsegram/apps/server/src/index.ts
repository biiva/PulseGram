import { buildApp } from './app';
import { loadConfig } from './config';
import { runMigrations } from './db/migrate';

async function main() {
  const config = loadConfig();
  if (process.env.MIGRATE_ON_START !== 'false') {
    await runMigrations(config.DATABASE_URL);
  }
  const { app, close } = await buildApp(config);
  await app.listen({ host: config.HOST, port: config.PORT });
  app.log.info(`PulseGram API ready on http://${config.HOST}:${config.PORT} (app: ${config.APP_URL})`);

  let shuttingDown = false;
  const shutdown = async (signal: string) => {
    if (shuttingDown) return;
    shuttingDown = true;
    app.log.info(`${signal} received, shutting down`);
    const force = setTimeout(() => process.exit(1), 10_000);
    force.unref();
    try {
      await close();
      process.exit(0);
    } catch (err) {
      app.log.error({ err }, 'shutdown failed');
      process.exit(1);
    }
  };
  process.on('SIGTERM', () => void shutdown('SIGTERM'));
  process.on('SIGINT', () => void shutdown('SIGINT'));
}

main().catch((err: unknown) => {
  console.error(err);
  process.exit(1);
});
