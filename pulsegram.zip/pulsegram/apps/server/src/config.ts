import { z } from 'zod';

const bool = z
  .enum(['true', 'false', '1', '0', ''])
  .optional()
  .transform((v) => v === 'true' || v === '1');

const optionalStr = z
  .string()
  .optional()
  .transform((v) => (v && v.trim() ? v.trim() : undefined));

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'production', 'test']).default('development'),
  HOST: z.string().default('0.0.0.0'),
  PORT: z.coerce.number().int().default(4000),
  /** Public origin of the web app, used in emails and invite links and for CORS/CSRF origin checks. */
  APP_URL: z.string().url().default('http://localhost:5173'),
  DATABASE_URL: z.string().min(1).default('postgres://postgres:postgres@127.0.0.1:5432/pulsegram'),
  DATABASE_POOL_MAX: z.coerce.number().int().min(1).max(200).default(10),
  REDIS_URL: optionalStr,
  /** Secret used to sign CSRF tokens and file URLs. Must be long and random in production. */
  APP_SECRET: z.string().min(16).default('dev-only-insecure-secret-change-me'),
  SESSION_TTL_DAYS: z.coerce.number().int().min(1).max(365).default(30),
  TRUST_PROXY: bool,
  LOG_LEVEL: z.enum(['fatal', 'error', 'warn', 'info', 'debug', 'trace', 'silent']).default('info'),

  REQUIRE_EMAIL_VERIFICATION: bool,
  SMTP_HOST: optionalStr,
  SMTP_PORT: z.coerce.number().int().default(587),
  SMTP_SECURE: bool,
  SMTP_USER: optionalStr,
  SMTP_PASS: optionalStr,
  MAIL_FROM: z.string().default('PulseGram <no-reply@pulsegram.local>'),
  /** Development only: write outgoing mail to the server log + data/dev-mailbox instead of sending. */
  DEV_MAILBOX: bool,

  TURNSTILE_SITE_KEY: optionalStr,
  TURNSTILE_SECRET_KEY: optionalStr,

  STORAGE_DRIVER: z.enum(['local', 's3']).default('local'),
  STORAGE_LOCAL_DIR: z.string().default('./data/uploads'),
  S3_BUCKET: optionalStr,
  S3_REGION: z.string().default('us-east-1'),
  S3_ENDPOINT: optionalStr,
  S3_ACCESS_KEY_ID: optionalStr,
  S3_SECRET_ACCESS_KEY: optionalStr,
  S3_FORCE_PATH_STYLE: bool,
  MAX_UPLOAD_MB: z.coerce.number().int().min(1).max(4096).default(50),

  STUN_URLS: z.string().default('stun:stun.l.google.com:19302'),
  TURN_URLS: optionalStr,
  TURN_USERNAME: optionalStr,
  TURN_CREDENTIAL: optionalStr,
  /** coturn "use-auth-secret" shared secret; when set, short-lived TURN credentials are minted per user. */
  TURN_SECRET: optionalStr,

  GIF_PROVIDER: z.enum(['tenor', 'giphy', '']).optional(),
  GIF_API_KEY: optionalStr,

  VAPID_PUBLIC_KEY: optionalStr,
  VAPID_PRIVATE_KEY: optionalStr,
  VAPID_SUBJECT: z.string().default('mailto:admin@pulsegram.local'),

  GOOGLE_CLIENT_ID: optionalStr,
  GOOGLE_CLIENT_SECRET: optionalStr,

  /** Serve the built web app from the API server (single-process production deploy). */
  SERVE_WEB_DIST: optionalStr,
});

export type AppConfig = z.infer<typeof envSchema> & {
  isProd: boolean;
  isTest: boolean;
  emailConfigured: boolean;
  turnConfigured: boolean;
  gifConfigured: boolean;
  pushConfigured: boolean;
  captchaConfigured: boolean;
  maxUploadBytes: number;
  cookieSecure: boolean;
};

export function loadConfig(env: NodeJS.ProcessEnv = process.env): AppConfig {
  const parsed = envSchema.safeParse(env);
  if (!parsed.success) {
    const issues = parsed.error.issues.map((i) => `  ${i.path.join('.')}: ${i.message}`).join('\n');
    throw new Error(`Invalid environment configuration:\n${issues}`);
  }
  const c = parsed.data;
  const isProd = c.NODE_ENV === 'production';
  if (isProd) {
    if (c.APP_SECRET.startsWith('dev-only') || c.APP_SECRET.length < 32) {
      throw new Error('APP_SECRET must be set to a random value of at least 32 characters in production.');
    }
    if (c.DEV_MAILBOX) throw new Error('DEV_MAILBOX must not be enabled in production.');
  }
  return {
    ...c,
    isProd,
    isTest: c.NODE_ENV === 'test',
    emailConfigured: Boolean(c.SMTP_HOST) || (c.DEV_MAILBOX && !isProd),
    turnConfigured: Boolean(c.TURN_URLS && ((c.TURN_USERNAME && c.TURN_CREDENTIAL) || c.TURN_SECRET)),
    gifConfigured: Boolean(c.GIF_PROVIDER && c.GIF_API_KEY),
    pushConfigured: Boolean(c.VAPID_PUBLIC_KEY && c.VAPID_PRIVATE_KEY),
    captchaConfigured: Boolean(c.TURNSTILE_SITE_KEY && c.TURNSTILE_SECRET_KEY),
    maxUploadBytes: c.MAX_UPLOAD_MB * 1024 * 1024,
    cookieSecure: c.APP_URL.startsWith('https://'),
  };
}
