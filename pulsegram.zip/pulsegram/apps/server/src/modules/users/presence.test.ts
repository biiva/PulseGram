import { describe, expect, it } from 'vitest';
import { presenceView } from './serialize';

const now = new Date('2026-06-01T12:00:00Z');
const base = {
  online: false,
  presenceMode: 'auto' as const,
  lastSeenAt: new Date('2026-06-01T11:00:00Z'),
  privacy: { online: 'everybody' as const, lastSeen: 'everybody' as const },
  isSelf: false,
  viewerIsContact: false,
  blocked: false,
  now,
};

describe('presenceView', () => {
  it('shows online and exact last seen when allowed', () => {
    expect(presenceView({ ...base, online: true })).toEqual({ kind: 'online', dnd: false });
    expect(presenceView(base)).toEqual({ kind: 'last_seen', at: '2026-06-01T11:00:00.000Z' });
  });

  it('only approximates when last seen is hidden', () => {
    expect(presenceView({ ...base, privacy: { online: 'everybody', lastSeen: 'nobody' } })).toEqual({ kind: 'recently' });
    const old = { ...base, lastSeenAt: new Date('2026-05-28T12:00:00Z'), privacy: { online: 'nobody' as const, lastSeen: 'nobody' as const } };
    expect(presenceView(old)).toEqual({ kind: 'within_week' });
  });

  it('honors contacts-only audiences', () => {
    const p = { ...base, online: true, privacy: { online: 'contacts' as const, lastSeen: 'contacts' as const } };
    expect(presenceView(p).kind).toBe('recently');
    expect(presenceView({ ...p, viewerIsContact: true }).kind).toBe('online');
  });

  it('invisible users never appear online to others, but do to themselves', () => {
    expect(presenceView({ ...base, online: true, presenceMode: 'invisible' }).kind).toBe('recently');
    expect(presenceView({ ...base, online: true, presenceMode: 'invisible', isSelf: true }).kind).toBe('online');
  });

  it('reveals nothing to blocked viewers', () => {
    expect(presenceView({ ...base, online: true, blocked: true })).toEqual({ kind: 'long_ago' });
  });

  it('flags do-not-disturb', () => {
    expect(presenceView({ ...base, online: true, presenceMode: 'dnd' })).toEqual({ kind: 'online', dnd: true });
  });
});
