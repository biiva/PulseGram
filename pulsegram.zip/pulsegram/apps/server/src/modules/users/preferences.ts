import { eq, inArray } from 'drizzle-orm';
import type {
  AppearanceSettings,
  Language,
  NotificationSettings,
  Preferences,
  PrivacySettings,
  UpdatePreferencesInput,
} from '@pulsegram/shared';
import type { DbOrTx } from '../../db/client';
import { userPreferences } from '../../db/schema';

export const DEFAULT_PRIVACY: PrivacySettings = {
  lastSeen: 'everybody',
  online: 'everybody',
  avatar: 'everybody',
  phone: 'contacts',
  groupInvites: 'everybody',
  calls: 'everybody',
};

export const DEFAULT_NOTIFICATIONS: NotificationSettings = {
  enabled: true,
  sound: true,
  preview: true,
  lockScreenPreview: false,
  direct: true,
  groups: true,
  channels: false,
  mentions: true,
  calls: true,
  pausedUntil: null,
};

export function defaultAppearance(language: Language = 'en'): AppearanceSettings {
  return {
    theme: 'system',
    accent: '#7C4DFF',
    density: 'comfortable',
    fontScale: 1,
    language,
    timeFormat: language === 'ru' ? '24h' : '12h',
    dateFormat: language === 'ru' ? 'dmy' : 'mdy',
    enterToSend: true,
    reduceMotion: false,
  };
}

export async function createDefaultPreferences(db: DbOrTx, userId: string, language: Language = 'en') {
  await db
    .insert(userPreferences)
    .values({ userId, privacy: DEFAULT_PRIVACY, notifications: DEFAULT_NOTIFICATIONS, appearance: defaultAppearance(language) })
    .onConflictDoNothing();
}

export async function getPreferences(db: DbOrTx, userId: string): Promise<Preferences> {
  const [row] = await db.select().from(userPreferences).where(eq(userPreferences.userId, userId));
  return {
    privacy: { ...DEFAULT_PRIVACY, ...row?.privacy },
    notifications: { ...DEFAULT_NOTIFICATIONS, ...row?.notifications },
    appearance: { ...defaultAppearance(), ...row?.appearance },
  };
}

export async function getPrivacyMap(db: DbOrTx, userIds: string[]): Promise<Map<string, PrivacySettings>> {
  const map = new Map<string, PrivacySettings>();
  if (userIds.length === 0) return map;
  const rows = await db
    .select({ userId: userPreferences.userId, privacy: userPreferences.privacy })
    .from(userPreferences)
    .where(inArray(userPreferences.userId, userIds));
  for (const id of userIds) map.set(id, DEFAULT_PRIVACY);
  for (const r of rows) map.set(r.userId, { ...DEFAULT_PRIVACY, ...r.privacy });
  return map;
}

export async function getNotificationPrefsMap(db: DbOrTx, userIds: string[]) {
  const map = new Map<string, NotificationSettings>();
  if (userIds.length === 0) return map;
  const rows = await db
    .select({ userId: userPreferences.userId, n: userPreferences.notifications, a: userPreferences.appearance })
    .from(userPreferences)
    .where(inArray(userPreferences.userId, userIds));
  for (const r of rows) map.set(r.userId, { ...DEFAULT_NOTIFICATIONS, ...r.n });
  return map;
}

export async function updatePreferences(db: DbOrTx, userId: string, patch: UpdatePreferencesInput): Promise<Preferences> {
  const current = await getPreferences(db, userId);
  const next: Preferences = {
    privacy: { ...current.privacy, ...patch.privacy },
    notifications: { ...current.notifications, ...patch.notifications },
    appearance: { ...current.appearance, ...patch.appearance },
  };
  await db
    .insert(userPreferences)
    .values({ userId, ...next, updatedAt: new Date() })
    .onConflictDoUpdate({ target: userPreferences.userId, set: { ...next, updatedAt: new Date() } });
  return next;
}
