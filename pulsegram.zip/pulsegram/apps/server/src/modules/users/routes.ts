import { and, asc, desc, eq, inArray, isNull, ne, or, sql } from 'drizzle-orm';
import type { FastifyInstance } from 'fastify';
import {
  deleteAccountSchema,
  reportSchema,
  updatePreferencesSchema,
  updateProfileSchema,
  type UserProfile,
} from '@pulsegram/shared';
import type { AppContext } from '../../context';
import {
  blockedUsers,
  chatFolders,
  contacts,
  conversationMembers,
  conversations,
  messages,
  pushSubscriptions,
  reports,
  sessions,
  userPreferences,
  users,
} from '../../db/schema';
import { hashPassword, randomToken, verifyPassword } from '../../lib/crypto';
import { AppError, errors } from '../../lib/errors';
import { parse, uuidParam } from '../../lib/http';
import { enforce } from '../../lib/rateLimit';
import { audit } from '../audit/service';
import { isUsernameTaken } from '../auth/routes';
import { clearSessionCookies, requireAuth } from '../auth/session';
import { directKey } from '../conversations/access';
import { leaveConversation } from '../conversations/service';
import { readSingleUpload } from '../files/routes';
import { storeUpload } from '../files/service';
import { toMe } from './me';
import { getPreferences, getPrivacyMap, updatePreferences } from './preferences';
import { audienceAllows, loadRelations, loadUserSummaries } from './serialize';

export async function registerUserRoutes(app: FastifyInstance, ctx: AppContext) {
  const auth = { preHandler: requireAuth(ctx) };

  app.get('/api/users/search', auth, async (req) => {
    await enforce(ctx.limiter, `usearch:${req.auth!.userId}`, 120, 60);
    const q = String((req.query as { q?: string }).q ?? '')
      .trim()
      .replace(/^@/, '')
      .toLowerCase()
      .slice(0, 64);
    if (q.length < 2) return [];
    const like = `%${q.replace(/[%_\\]/g, '\\$&')}%`;
    const rows = await ctx.db
      .select({ id: users.id })
      .from(users)
      .where(
        and(
          isNull(users.deletedAt),
          ne(users.id, req.auth!.userId),
          or(sql`lower(${users.username}) LIKE ${like}`, sql`lower(${users.displayName}) LIKE ${like}`),
        ),
      )
      .orderBy(sql`CASE WHEN lower(${users.username}) = ${q} THEN 0 WHEN lower(${users.username}) LIKE ${q + '%'} THEN 1 ELSE 2 END`, asc(users.username))
      .limit(25);
    const sums = await loadUserSummaries(ctx, req.auth!.userId, rows.map((r) => r.id));
    return rows.map((r) => sums.get(r.id)!).filter(Boolean);
  });

  async function profile(viewerId: string, targetId: string): Promise<UserProfile> {
    const [u] = await ctx.db.select().from(users).where(eq(users.id, targetId));
    if (!u) throw errors.notFound('user_not_found', 'User not found');
    const [sum, rel, privacy] = await Promise.all([
      loadUserSummaries(ctx, viewerId, [targetId]),
      loadRelations(ctx.db, viewerId, [targetId]),
      getPrivacyMap(ctx.db, [targetId]),
    ]);
    const p = privacy.get(targetId)!;
    const isSelf = viewerId === targetId;
    const viewerIsContact = rel.viewerIsContactOf.has(targetId);
    const blockedViewer = rel.blockedViewer.has(targetId);
    const common = isSelf
      ? []
      : await ctx.db.execute<{ id: string; title: string; avatar_file_id: string | null }>(sql`
          SELECT c.id, c.title, c.avatar_file_id FROM conversations c
          JOIN conversation_members a ON a.conversation_id = c.id AND a.user_id = ${viewerId}
          JOIN conversation_members b ON b.conversation_id = c.id AND b.user_id = ${targetId}
          WHERE c.type = 'group' AND c.deleted_at IS NULL
          ORDER BY c.last_activity_at DESC LIMIT 20`);
    return {
      ...sum.get(targetId)!,
      bio: u.deletedAt || blockedViewer ? '' : u.bio,
      phone: u.phone && (isSelf || (!blockedViewer && audienceAllows(p.phone, viewerIsContact))) ? u.phone : null,
      email: u.publicEmail && !u.deletedAt && !blockedViewer ? u.email : null,
      createdAt: u.createdAt.toISOString(),
      isContact: rel.viewerContacts.has(targetId),
      isBlocked: rel.blockedByViewer.has(targetId),
      blockedViewer,
      commonGroups: (Array.isArray(common) ? common : common.rows).map((c) => ({
        id: c.id,
        title: c.title,
        avatarUrl: c.avatar_file_id ? `/api/files/${c.avatar_file_id}` : null,
      })),
      canCall: !isSelf && !u.deletedAt && !rel.blockedEither.has(targetId) && audienceAllows(p.calls, viewerIsContact),
      canInviteToGroups: !isSelf && !rel.blockedEither.has(targetId) && audienceAllows(p.groupInvites, viewerIsContact),
    };
  }

  /** Batch summaries (e.g. senders shown in a group chat). Presence/avatars are privacy-filtered per viewer. */
  app.get('/api/users', auth, async (req) => {
    const raw = String((req.query as { ids?: string }).ids ?? '');
    const ids = [...new Set(raw.split(',').filter((s) => /^[0-9a-f-]{36}$/i.test(s)))].slice(0, 200);
    const sums = await loadUserSummaries(ctx, req.auth!.userId, ids);
    return [...sums.values()];
  });

  app.get('/api/users/:id', auth, async (req) => profile(req.auth!.userId, uuidParam(req.params)));

  app.get('/api/users/by-username/:username', auth, async (req) => {
    const name = String((req.params as { username: string }).username).replace(/^@/, '').toLowerCase();
    const [u] = await ctx.db
      .select({ id: users.id })
      .from(users)
      .where(and(sql`lower(${users.username}) = ${name}`, isNull(users.deletedAt)));
    if (u) return { kind: 'user', profile: await profile(req.auth!.userId, u.id) };
    const [c] = await ctx.db
      .select({ id: conversations.id })
      .from(conversations)
      .where(and(sql`lower(${conversations.username}) = ${name}`, eq(conversations.isPublic, true), isNull(conversations.deletedAt)));
    if (c) return { kind: 'conversation', conversationId: c.id };
    throw errors.notFound('not_found', 'Nobody uses this username');
  });

  // ── Me ──
  app.patch('/api/me/profile', auth, async (req) => {
    const input = parse(updateProfileSchema, req.body);
    const me = req.auth!.user;
    if (input.username && input.username.toLowerCase() !== me.username.toLowerCase()) {
      await enforce(ctx.limiter, `uname-change:${me.id}`, 10, 86400);
      if (await isUsernameTaken(ctx, input.username, me.id)) {
        throw new AppError(409, 'username_taken', 'This username is already taken', [{ path: 'username', code: 'username_taken' }]);
      }
    }
    const [u] = await ctx.db
      .update(users)
      .set({
        ...input,
        phone: input.phone === '' ? null : input.phone,
        profileCompleted: true,
        updatedAt: new Date(),
      })
      .where(eq(users.id, me.id))
      .returning();
    if (input.presenceMode !== undefined && input.presenceMode !== me.presenceMode) await ctx.hub.presenceChanged(me.id);
    await ctx.hub.emit(await relatedUserIds(ctx, me.id), 'user:updated', { userId: me.id });
    return toMe(u!);
  });

  app.put('/api/me/avatar', auth, async (req) => {
    await enforce(ctx.limiter, `avatar:${req.auth!.userId}`, 20, 3600);
    const { buf, filename } = await readSingleUpload(req, 15 * 1024 * 1024);
    const f = await storeUpload(ctx, req.auth!.userId, buf, filename, { purpose: 'avatar' });
    const [u] = await ctx.db.update(users).set({ avatarFileId: f.id, updatedAt: new Date() }).where(eq(users.id, req.auth!.userId)).returning();
    await ctx.hub.emit(await relatedUserIds(ctx, req.auth!.userId), 'user:updated', { userId: req.auth!.userId });
    return toMe(u!);
  });

  app.delete('/api/me/avatar', auth, async (req) => {
    const [u] = await ctx.db.update(users).set({ avatarFileId: null, updatedAt: new Date() }).where(eq(users.id, req.auth!.userId)).returning();
    await ctx.hub.emit(await relatedUserIds(ctx, req.auth!.userId), 'user:updated', { userId: req.auth!.userId });
    return toMe(u!);
  });

  app.get('/api/me/preferences', auth, async (req) => getPreferences(ctx.db, req.auth!.userId));

  app.patch('/api/me/preferences', auth, async (req) => {
    const input = parse(updatePreferencesSchema, req.body);
    const prefs = await updatePreferences(ctx.db, req.auth!.userId, input);
    if (input.privacy) {
      await ctx.hub.presenceChanged(req.auth!.userId);
      await audit(ctx, { actorId: req.auth!.userId, action: 'privacy.updated', data: { fields: Object.keys(input.privacy) } });
    }
    return prefs;
  });

  // ── Contacts ──
  app.get('/api/contacts', auth, async (req) => {
    const rows = await ctx.db
      .select({ id: contacts.contactId })
      .from(contacts)
      .innerJoin(users, eq(users.id, contacts.contactId))
      .where(and(eq(contacts.ownerId, req.auth!.userId), isNull(users.deletedAt)))
      .orderBy(asc(users.displayName));
    const sums = await loadUserSummaries(ctx, req.auth!.userId, rows.map((r) => r.id));
    return rows.map((r) => sums.get(r.id)!).filter(Boolean);
  });

  app.post('/api/contacts', auth, async (req) => {
    const { userId } = req.body as { userId?: string };
    const id = uuidParam({ id: userId });
    if (id === req.auth!.userId) throw errors.badRequest('cannot_add_self');
    const [u] = await ctx.db.select({ id: users.id }).from(users).where(and(eq(users.id, id), isNull(users.deletedAt)));
    if (!u) throw errors.notFound('user_not_found', 'User not found');
    await ctx.db.insert(contacts).values({ ownerId: req.auth!.userId, contactId: id }).onConflictDoNothing();
    // Adding a contact may change what that person can see of *us*? No — only what we allow them; but it changes their view of our presence.
    await ctx.hub.presenceChanged(req.auth!.userId);
    return { ok: true };
  });

  app.delete('/api/contacts/:id', auth, async (req) => {
    const id = uuidParam(req.params);
    await ctx.db.delete(contacts).where(and(eq(contacts.ownerId, req.auth!.userId), eq(contacts.contactId, id)));
    await ctx.hub.presenceChanged(req.auth!.userId);
    return { ok: true };
  });

  // ── Blocks ──
  app.get('/api/blocks', auth, async (req) => {
    const rows = await ctx.db
      .select({ id: blockedUsers.blockedId })
      .from(blockedUsers)
      .where(eq(blockedUsers.blockerId, req.auth!.userId))
      .orderBy(desc(blockedUsers.createdAt));
    const sums = await loadUserSummaries(ctx, req.auth!.userId, rows.map((r) => r.id));
    return rows.map((r) => sums.get(r.id)!).filter(Boolean);
  });

  app.post('/api/blocks', auth, async (req) => {
    const { userId } = req.body as { userId?: string };
    const id = uuidParam({ id: userId });
    if (id === req.auth!.userId) throw errors.badRequest('cannot_block_self');
    const [u] = await ctx.db.select({ id: users.id }).from(users).where(eq(users.id, id));
    if (!u) throw errors.notFound('user_not_found', 'User not found');
    await ctx.db.insert(blockedUsers).values({ blockerId: req.auth!.userId, blockedId: id }).onConflictDoNothing();
    await audit(ctx, { actorId: req.auth!.userId, targetUserId: id, action: 'user.blocked' });
    await ctx.hub.presenceChanged(req.auth!.userId);
    // Let the blocked user's open direct chat refresh its state (they will now fail to send).
    const [dm] = await ctx.db.select({ id: conversations.id }).from(conversations).where(eq(conversations.directKey, directKey(req.auth!.userId, id)));
    if (dm) await ctx.hub.emit([req.auth!.userId, id], 'user:updated', { userId: req.auth!.userId });
    return { ok: true };
  });

  app.delete('/api/blocks/:id', auth, async (req) => {
    const id = uuidParam(req.params);
    await ctx.db.delete(blockedUsers).where(and(eq(blockedUsers.blockerId, req.auth!.userId), eq(blockedUsers.blockedId, id)));
    await audit(ctx, { actorId: req.auth!.userId, targetUserId: id, action: 'user.unblocked' });
    await ctx.hub.presenceChanged(req.auth!.userId);
    await ctx.hub.emit([req.auth!.userId, id], 'user:updated', { userId: req.auth!.userId });
    return { ok: true };
  });

  // ── Reports ──
  app.post('/api/reports', auth, async (req) => {
    await enforce(ctx.limiter, `report:${req.auth!.userId}`, 20, 3600);
    const input = parse(reportSchema, req.body);
    await ctx.db.insert(reports).values({ reporterId: req.auth!.userId, ...input, details: input.details ?? '' });
    await audit(ctx, { actorId: req.auth!.userId, action: 'report.created', data: { targetType: input.targetType, targetId: input.targetId, reason: input.reason } });
    return { ok: true };
  });

  // ── Data export (GDPR-style) ──
  app.get('/api/me/export', auth, async (req, reply) => {
    await enforce(ctx.limiter, `export:${req.auth!.userId}`, 5, 3600);
    const uid = req.auth!.userId;
    const [prefs, contactRows, blockRows, sessionRows, convRows, msgRows] = await Promise.all([
      getPreferences(ctx.db, uid),
      ctx.db.select({ username: users.username, displayName: users.displayName }).from(contacts).innerJoin(users, eq(users.id, contacts.contactId)).where(eq(contacts.ownerId, uid)),
      ctx.db.select({ username: users.username }).from(blockedUsers).innerJoin(users, eq(users.id, blockedUsers.blockedId)).where(eq(blockedUsers.blockerId, uid)),
      ctx.db.select({ deviceName: sessions.deviceName, createdAt: sessions.createdAt, lastActiveAt: sessions.lastActiveAt, ip: sessions.ip }).from(sessions).where(eq(sessions.userId, uid)),
      ctx.db
        .select({ id: conversations.id, type: conversations.type, title: conversations.title, role: conversationMembers.role, joinedAt: conversationMembers.joinedAt })
        .from(conversationMembers)
        .innerJoin(conversations, eq(conversations.id, conversationMembers.conversationId))
        .where(eq(conversationMembers.userId, uid)),
      ctx.db
        .select({ id: messages.id, conversationId: messages.conversationId, type: messages.type, text: messages.text, createdAt: messages.createdAt, editedAt: messages.editedAt })
        .from(messages)
        .where(and(eq(messages.senderId, uid), isNull(messages.deletedAt)))
        .orderBy(asc(messages.seq))
        .limit(100_000),
    ]);
    const data = {
      exportedAt: new Date().toISOString(),
      account: toMe(req.auth!.user),
      preferences: prefs,
      contacts: contactRows,
      blocked: blockRows,
      sessions: sessionRows,
      conversations: convRows,
      messagesSent: msgRows,
    };
    await audit(ctx, { actorId: uid, action: 'account.exported', ip: req.ip });
    reply
      .header('Content-Type', 'application/json; charset=utf-8')
      .header('Content-Disposition', `attachment; filename="pulsegram-export-${req.auth!.user.username}.json"`);
    return JSON.stringify(data, null, 2);
  });

  // ── Account deletion ──
  app.post('/api/me/delete', auth, async (req, reply) => {
    await enforce(ctx.limiter, `delacct:${req.auth!.userId}`, 5, 3600);
    const input = parse(deleteAccountSchema, req.body);
    if (!(await verifyPassword(req.auth!.user.passwordHash, input.password))) {
      throw errors.badRequest('invalid_password', 'Password is incorrect', [{ path: 'password', code: 'invalid_password' }]);
    }
    const uid = req.auth!.userId;
    // Leave groups/channels first (hands ownership over or deletes empty chats).
    const memberships = await ctx.db
      .select({ id: conversationMembers.conversationId, type: conversations.type })
      .from(conversationMembers)
      .innerJoin(conversations, eq(conversations.id, conversationMembers.conversationId))
      .where(and(eq(conversationMembers.userId, uid), inArray(conversations.type, ['group', 'channel'])));
    for (const m of memberships) await leaveConversation(ctx, req.auth!, m.id).catch(() => {});
    const short = uid.slice(0, 8);
    await ctx.db.transaction(async (tx) => {
      await tx
        .update(users)
        .set({
          deletedAt: new Date(),
          email: `deleted+${uid}@deleted.invalid`,
          username: `deleted_${short}${randomToken(3).replace(/[^a-zA-Z0-9]/g, '')}`,
          displayName: 'Deleted account',
          bio: '',
          phone: null,
          statusText: '',
          avatarFileId: null,
          passwordHash: await hashPassword(randomToken(32)),
        })
        .where(eq(users.id, uid));
      await tx.delete(sessions).where(eq(sessions.userId, uid));
      await tx.delete(contacts).where(or(eq(contacts.ownerId, uid), eq(contacts.contactId, uid)));
      await tx.delete(blockedUsers).where(eq(blockedUsers.blockerId, uid));
      await tx.delete(pushSubscriptions).where(eq(pushSubscriptions.userId, uid));
      await tx.delete(chatFolders).where(eq(chatFolders.userId, uid));
      await tx.delete(userPreferences).where(eq(userPreferences.userId, uid));
      await tx.update(conversations).set({ deletedAt: new Date() }).where(eq(conversations.directKey, `saved:${uid}`));
    });
    await audit(ctx, { actorId: uid, action: 'account.deleted', ip: req.ip });
    await ctx.hub.revokeUser(uid);
    clearSessionCookies(ctx, reply);
    return { ok: true };
  });
}

/** People who may have this user on screen: direct-chat peers and contacts-of. */
export async function relatedUserIds(ctx: AppContext, userId: string): Promise<string[]> {
  const rows = await ctx.db.execute<{ id: string }>(sql`
    SELECT DISTINCT cm2.user_id AS id FROM conversation_members cm
    JOIN conversations c ON c.id = cm.conversation_id AND c.type IN ('direct','group')
    JOIN conversation_members cm2 ON cm2.conversation_id = cm.conversation_id
    WHERE cm.user_id = ${userId} AND c.member_count <= 500
    UNION SELECT owner_id AS id FROM contacts WHERE contact_id = ${userId}
    LIMIT 5000`);
  return rows.rows.map((r) => r.id);
}
