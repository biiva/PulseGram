import { and, eq, inArray, or } from 'drizzle-orm';
import type { PresenceMode, PresenceView, PrivacyAudience, PrivacySettings, UserSummary } from '@pulsegram/shared';
import type { AppContext } from '../../context';
import type { DbOrTx } from '../../db/client';
import { blockedUsers, contacts, users } from '../../db/schema';
import { getPrivacyMap } from './preferences';

export function fileUrl(fileId: string | null | undefined): string | null {
  return fileId ? `/api/files/${fileId}` : null;
}

export interface PresenceInput {
  online: boolean;
  presenceMode: PresenceMode;
  lastSeenAt: Date | null;
  privacy: Pick<PrivacySettings, 'online' | 'lastSeen'>;
  isSelf: boolean;
  /** The viewer is in the target's contact list. */
  viewerIsContact: boolean;
  blocked: boolean;
  deleted?: boolean;
  now?: Date;
}

export function audienceAllows(aud: PrivacyAudience, viewerIsContact: boolean): boolean {
  return aud === 'everybody' || (aud === 'contacts' && viewerIsContact);
}

/** Presence as a particular viewer is allowed to see it. Pure — unit tested. */
export function presenceView(p: PresenceInput): PresenceView {
  const now = p.now ?? new Date();
  if (p.deleted) return { kind: 'long_ago' };
  if (p.blocked) return { kind: 'long_ago' };
  const invisible = p.presenceMode === 'invisible';
  if (p.isSelf) {
    return p.online ? { kind: 'online', dnd: p.presenceMode === 'dnd' } : { kind: 'last_seen', at: (p.lastSeenAt ?? now).toISOString() };
  }
  if (p.online && !invisible && audienceAllows(p.privacy.online, p.viewerIsContact)) {
    return { kind: 'online', dnd: p.presenceMode === 'dnd' };
  }
  const effectiveLastSeen = p.online && !invisible ? now : p.lastSeenAt;
  if (!invisible && !p.online && effectiveLastSeen && audienceAllows(p.privacy.lastSeen, p.viewerIsContact)) {
    return { kind: 'last_seen', at: effectiveLastSeen.toISOString() };
  }
  // Approximate only — never the exact time.
  const ref = p.online ? now : p.lastSeenAt;
  if (!ref) return { kind: 'long_ago' };
  const ageDays = (now.getTime() - ref.getTime()) / 86_400_000;
  if (ageDays <= 3) return { kind: 'recently' };
  if (ageDays <= 7) return { kind: 'within_week' };
  if (ageDays <= 30) return { kind: 'within_month' };
  return { kind: 'long_ago' };
}

export interface Relations {
  /** target ids that have the viewer in their contacts */
  viewerIsContactOf: Set<string>;
  /** ids the viewer has as contacts */
  viewerContacts: Set<string>;
  /** ids blocked by viewer, or that blocked the viewer */
  blockedEither: Set<string>;
  blockedByViewer: Set<string>;
  blockedViewer: Set<string>;
}

export async function loadRelations(db: DbOrTx, viewerId: string, ids: string[]): Promise<Relations> {
  const r: Relations = {
    viewerIsContactOf: new Set(),
    viewerContacts: new Set(),
    blockedEither: new Set(),
    blockedByViewer: new Set(),
    blockedViewer: new Set(),
  };
  if (ids.length === 0) return r;
  const [cRows, bRows] = await Promise.all([
    db
      .select()
      .from(contacts)
      .where(
        or(
          and(inArray(contacts.ownerId, ids), eq(contacts.contactId, viewerId)),
          and(eq(contacts.ownerId, viewerId), inArray(contacts.contactId, ids)),
        ),
      ),
    db
      .select()
      .from(blockedUsers)
      .where(
        or(
          and(inArray(blockedUsers.blockerId, ids), eq(blockedUsers.blockedId, viewerId)),
          and(eq(blockedUsers.blockerId, viewerId), inArray(blockedUsers.blockedId, ids)),
        ),
      ),
  ]);
  for (const c of cRows) {
    if (c.contactId === viewerId) r.viewerIsContactOf.add(c.ownerId);
    if (c.ownerId === viewerId) r.viewerContacts.add(c.contactId);
  }
  for (const b of bRows) {
    if (b.blockerId === viewerId) {
      r.blockedByViewer.add(b.blockedId);
      r.blockedEither.add(b.blockedId);
    } else {
      r.blockedViewer.add(b.blockerId);
      r.blockedEither.add(b.blockerId);
    }
  }
  return r;
}

export type UserRow = typeof users.$inferSelect;

export async function loadUserSummaries(
  ctx: Pick<AppContext, 'db' | 'presence'>,
  viewerId: string,
  ids: Iterable<string>,
  db: DbOrTx = ctx.db,
): Promise<Map<string, UserSummary>> {
  const unique = [...new Set(ids)].filter(Boolean);
  const out = new Map<string, UserSummary>();
  if (unique.length === 0) return out;
  const [rows, privacy, rel, online] = await Promise.all([
    db.select().from(users).where(inArray(users.id, unique)),
    getPrivacyMap(db, unique),
    loadRelations(db, viewerId, unique),
    ctx.presence.onlineSet(unique),
  ]);
  for (const u of rows) out.set(u.id, toSummary(u, viewerId, privacy.get(u.id)!, rel, online.has(u.id)));
  return out;
}

export function toSummary(u: UserRow, viewerId: string, privacy: PrivacySettings, rel: Relations, online: boolean): UserSummary {
  const isSelf = u.id === viewerId;
  const deleted = Boolean(u.deletedAt);
  const viewerIsContact = rel.viewerIsContactOf.has(u.id);
  const blocked = rel.blockedViewer.has(u.id); // the target blocked the viewer → hide their details
  const showAvatar = isSelf || (!blocked && audienceAllows(privacy.avatar, viewerIsContact));
  return {
    id: u.id,
    username: u.username,
    displayName: deleted ? 'Deleted account' : u.displayName,
    avatarUrl: deleted || !showAvatar ? null : fileUrl(u.avatarFileId),
    presence: presenceView({
      online,
      presenceMode: u.presenceMode,
      lastSeenAt: u.lastSeenAt,
      privacy,
      isSelf,
      viewerIsContact,
      blocked,
      deleted,
    }),
    statusText: deleted || blocked ? '' : u.statusText,
    isDemo: u.isDemo || undefined,
    deleted: deleted || undefined,
  };
}
