import type { Me } from '@pulsegram/shared';
import type { users } from '../../db/schema';
import { fileUrl } from './serialize';

export function toMe(u: typeof users.$inferSelect): Me {
  return {
    id: u.id,
    email: u.email,
    emailVerified: Boolean(u.emailVerifiedAt),
    username: u.username,
    displayName: u.displayName,
    avatarUrl: fileUrl(u.avatarFileId),
    bio: u.bio,
    phone: u.phone,
    publicEmail: u.publicEmail,
    statusText: u.statusText,
    presenceMode: u.presenceMode,
    createdAt: u.createdAt.toISOString(),
    profileCompleted: u.profileCompleted,
    isDemo: u.isDemo,
  };
}
