import { and, desc, eq, inArray, lt } from 'drizzle-orm';
import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import type { AppContext } from '../../context';
import { files, messageAttachments, messages } from '../../db/schema';
import { errors } from '../../lib/errors';
import { uuidParam } from '../../lib/http';
import { enforce } from '../../lib/rateLimit';
import { requireAuth } from '../auth/session';
import { requireReadable } from '../conversations/access';
import { visibleTo } from '../messages/service';
import { attachmentDto, toMessageDtos } from '../messages/serialize';
import { canAccessFile, storeUpload } from './service';

export async function readSingleUpload(req: FastifyRequest, maxBytes: number) {
  const part = await req.file({ limits: { fileSize: maxBytes, files: 1 } });
  if (!part) throw errors.badRequest('file_missing', 'No file was uploaded');
  let buf: Buffer;
  try {
    buf = await part.toBuffer();
  } catch (err: unknown) {
    if ((err as { code?: string }).code === 'FST_REQ_FILE_TOO_LARGE') throw errors.tooLarge();
    throw err;
  }
  if (part.file.truncated) throw errors.tooLarge();
  return { buf, filename: part.filename };
}

const INLINE_PREFIXES = ['image/', 'video/', 'audio/'];

async function sendStored(ctx: AppContext, req: FastifyRequest, reply: FastifyReply, key: string, mime: string, name: string, size: number) {
  const download = (req.query as { download?: string }).download === '1';
  const inline = !download && INLINE_PREFIXES.some((p) => mime.startsWith(p));
  reply
    .header('Content-Type', mime === 'text/plain' ? 'text/plain; charset=utf-8' : mime)
    .header('X-Content-Type-Options', 'nosniff')
    .header('Content-Security-Policy', "default-src 'none'; sandbox")
    .header('Cross-Origin-Resource-Policy', 'same-origin')
    .header('Cache-Control', 'private, max-age=86400, immutable')
    .header('Accept-Ranges', 'bytes')
    .header('Content-Disposition', `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(name)}`);

  const range = req.headers.range;
  const m = typeof range === 'string' ? /^bytes=(\d*)-(\d*)$/.exec(range) : null;
  if (m && size > 0) {
    let start = m[1] ? Number(m[1]) : NaN;
    let end = m[2] ? Number(m[2]) : NaN;
    if (Number.isNaN(start)) {
      start = Math.max(0, size - end);
      end = size - 1;
    } else if (Number.isNaN(end) || end >= size) end = size - 1;
    if (start > end || start >= size) {
      reply.code(416).header('Content-Range', `bytes */${size}`);
      return reply.send();
    }
    const obj = await ctx.storage.get(key, { start, end });
    reply.code(206).header('Content-Range', `bytes ${start}-${end}/${size}`).header('Content-Length', String(end - start + 1));
    return reply.send(obj.stream);
  }
  const obj = await ctx.storage.get(key);
  reply.header('Content-Length', String(obj.size));
  return reply.send(obj.stream);
}

export async function registerFileRoutes(app: FastifyInstance, ctx: AppContext) {
  const auth = { preHandler: requireAuth(ctx) };

  app.post('/api/files', auth, async (req, reply) => {
    await enforce(ctx.limiter, `upload:${req.auth!.userId}`, ctx.config.isTest ? 10_000 : 60, 300);
    const as = (req.query as { as?: string }).as;
    const { buf, filename } = await readSingleUpload(req, ctx.config.maxUploadBytes);
    const row = await storeUpload(ctx, req.auth!.userId, buf, filename, {
      purpose: 'attachment',
      as: as === 'voice' || as === 'file' ? as : 'auto',
    });
    reply.code(201);
    return attachmentDto(row);
  });

  app.get('/api/files/:id', auth, async (req, reply) => {
    const id = uuidParam(req.params);
    const [file] = await ctx.db.select().from(files).where(eq(files.id, id));
    if (!file || !(await canAccessFile(ctx, req.auth!.userId, file))) throw errors.notFound('file_not_found', 'File not found');
    return sendStored(ctx, req, reply, file.storageKey, file.mime, file.name, file.size);
  });

  app.get('/api/files/:id/thumb', auth, async (req, reply) => {
    const id = uuidParam(req.params);
    const [file] = await ctx.db.select().from(files).where(eq(files.id, id));
    if (!file?.thumbKey || !(await canAccessFile(ctx, req.auth!.userId, file))) throw errors.notFound('file_not_found', 'File not found');
    const st = await ctx.storage.stat(file.thumbKey);
    return sendStored(ctx, req, reply, file.thumbKey, 'image/webp', 'thumb.webp', st.size);
  });

  /** Shared media / files / links of a chat (for the info panel). */
  app.get('/api/conversations/:id/media', auth, async (req) => {
    const convId = uuidParam(req.params);
    const q = req.query as { kind?: string; before?: string; limit?: string };
    const kind = q.kind ?? 'image';
    const limit = Math.min(60, Math.max(1, Number(q.limit ?? 30)));
    const before = q.before ? Number(q.before) : undefined;
    const { conv, member } = await requireReadable(ctx.db, req.auth!.userId, convId);
    const base = and(eq(messages.conversationId, conv.id), visibleTo(req.auth!.userId, member), before ? lt(messages.seq, before) : undefined);
    let rows;
    if (kind === 'link') {
      rows = await ctx.db.select().from(messages).where(and(base, eq(messages.hasLink, true))).orderBy(desc(messages.seq)).limit(limit + 1);
    } else {
      const kinds = kind === 'media' ? ['image', 'video'] : [kind];
      const allowed = ['image', 'video', 'audio', 'voice', 'file'];
      if (!kinds.every((k) => allowed.includes(k))) throw errors.badRequest('invalid_kind');
      rows = await ctx.db
        .selectDistinct({ m: messages })
        .from(messages)
        .innerJoin(messageAttachments, eq(messageAttachments.messageId, messages.id))
        .innerJoin(files, eq(files.id, messageAttachments.fileId))
        .where(and(base, inArray(files.kind, kinds as Array<'image'>)))
        .orderBy(desc(messages.seq))
        .limit(limit + 1)
        .then((r) => r.map((x) => x.m));
    }
    const items = await toMessageDtos(ctx.db, rows.slice(0, limit), req.auth!.userId, { channel: conv.type === 'channel' });
    return { items, hasMore: rows.length > limit };
  });

}
