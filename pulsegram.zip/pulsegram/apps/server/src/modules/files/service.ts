import { randomUUID } from 'node:crypto';
import path from 'node:path';
import { and, eq, gt, isNull, or, sql } from 'drizzle-orm';
import { fileTypeFromBuffer } from 'file-type';
import sharp from 'sharp';
import type { AttachmentKind } from '@pulsegram/shared';
import type { AppContext } from '../../context';
import { conversationMembers, conversations, files, messageAttachments, messages, users } from '../../db/schema';
import { sha256 } from '../../lib/crypto';
import { AppError, errors } from '../../lib/errors';
import { audioWaveform, probeMedia, videoPoster } from './media';

/** Types are detected from file content (magic bytes) — the client-sent MIME type is ignored. */
const IMAGE = new Set(['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/avif']);
const VIDEO = new Set(['video/mp4', 'video/webm', 'video/quicktime', 'video/x-matroska']);
const AUDIO = new Set(['audio/mpeg', 'audio/ogg', 'audio/opus', 'audio/wav', 'audio/x-wav', 'audio/mp4', 'audio/x-m4a', 'audio/aac', 'audio/flac', 'audio/x-flac', 'audio/webm']);
const DOCS = new Set([
  'application/pdf',
  'application/zip',
  'application/x-7z-compressed',
  'application/x-rar-compressed',
  'application/vnd.rar',
  'application/gzip',
  'application/x-tar',
  'application/x-bzip2',
  'application/x-xz',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'application/vnd.oasis.opendocument.text',
  'application/vnd.oasis.opendocument.spreadsheet',
  'application/vnd.oasis.opendocument.presentation',
  'application/msword',
  'application/vnd.ms-excel',
  'application/vnd.ms-powerpoint',
  'application/x-cfb',
  'application/epub+zip',
  'application/rtf',
  'image/vnd.adobe.photoshop',
  'image/heic',
  'image/heif',
  'image/bmp',
  'image/tiff',
]);
/** Plain-text formats have no magic bytes; accepted only for these extensions and only if the bytes are valid UTF-8 text. */
const TEXT_EXT = new Set([
  'txt', 'md', 'csv', 'tsv', 'json', 'log', 'xml', 'yaml', 'yml', 'toml', 'ini', 'conf', 'sql',
  'js', 'mjs', 'cjs', 'ts', 'tsx', 'jsx', 'py', 'rb', 'go', 'rs', 'java', 'kt', 'c', 'h', 'cpp', 'hpp', 'cs', 'php', 'sh', 'swift', 'lua', 'css', 'scss',
]);

export interface UploadOptions {
  purpose: 'attachment' | 'avatar';
  /** voice → treat as a voice message; file → send images/videos uncompressed as documents */
  as?: 'auto' | 'voice' | 'file';
}

function sanitizeName(name: string): string {
  // eslint-disable-next-line no-control-regex -- stripping control characters is the point
  const base = path.basename(name || 'file').replace(/[\u0000-\u001f\u007f<>:"/\\|?*]+/g, '_').trim();
  return (base || 'file').slice(0, 200);
}

function looksLikeUtf8Text(buf: Buffer): boolean {
  const sample = buf.subarray(0, 64 * 1024);
  if (sample.includes(0)) return false;
  try {
    new TextDecoder('utf-8', { fatal: true }).decode(sample.length === buf.length ? sample : sample.subarray(0, sample.length - 4));
    return true;
  } catch {
    return false;
  }
}

export async function storeUpload(ctx: AppContext, ownerId: string, buf: Buffer, originalName: string, opts: UploadOptions) {
  if (buf.length === 0) throw errors.badRequest('file_empty', 'The file is empty');
  if (buf.length > ctx.config.maxUploadBytes) throw errors.tooLarge(`Files up to ${ctx.config.MAX_UPLOAD_MB} MB are allowed`);
  const name = sanitizeName(originalName);
  const ext = path.extname(name).slice(1).toLowerCase();
  const detected = await fileTypeFromBuffer(buf);
  let mime = detected?.mime as string | undefined;

  if (opts.purpose === 'avatar') {
    if (!mime || !IMAGE.has(mime)) throw errors.unsupported('Avatars must be JPEG, PNG, GIF, WebP or AVIF images');
    const out = await sharp(buf, { limitInputPixels: 64_000_000 })
      .rotate()
      .resize(512, 512, { fit: 'cover', position: 'attention' })
      .webp({ quality: 88 })
      .toBuffer()
      .catch(() => {
        throw errors.unsupported('This image could not be processed');
      });
    return persist(ctx, ownerId, out, { name: 'avatar.webp', mime: 'image/webp', kind: 'image', width: 512, height: 512, purpose: 'avatar' });
  }

  if (!mime) {
    if (TEXT_EXT.has(ext) && looksLikeUtf8Text(buf)) mime = 'text/plain';
    else throw errors.unsupported('This file type is not allowed');
  }

  if (opts.as === 'voice') {
    const isAudioContainer = AUDIO.has(mime) || mime === 'video/webm' || mime === 'video/mp4';
    if (!isAudioContainer) throw errors.unsupported('Voice messages must be audio');
    const probe = await probeMedia(buf, detected?.ext ?? 'webm');
    if (probe?.hasVideo) throw errors.unsupported('Voice messages must be audio');
    const decoded = await audioWaveform(buf, detected?.ext ?? 'webm');
    const voiceMime = mime === 'video/webm' ? 'audio/webm' : mime === 'video/mp4' ? 'audio/mp4' : mime;
    return persist(ctx, ownerId, buf, {
      name: `voice.${detected?.ext ?? 'webm'}`,
      mime: voiceMime,
      kind: 'voice',
      durationMs: probe?.durationMs ?? decoded?.durationMs ?? null,
      waveform: decoded?.waveform ?? null,
      purpose: 'attachment',
    });
  }

  if (IMAGE.has(mime) && opts.as !== 'file') {
    return processImage(ctx, ownerId, buf, name, mime).catch((err: unknown) => {
      if (err instanceof AppError) throw err;
      throw errors.unsupported('This image could not be processed');
    });
  }

  if ((VIDEO.has(mime) || mime === 'video/webm') && opts.as !== 'file') {
    const probe = await probeMedia(buf, detected?.ext ?? 'mp4');
    if (probe && !probe.hasVideo && probe.hasAudio) {
      return persist(ctx, ownerId, buf, { name, mime: mime.replace('video/', 'audio/'), kind: 'audio', durationMs: probe.durationMs, purpose: 'attachment' });
    }
    const poster = await videoPoster(buf, detected?.ext ?? 'mp4');
    const thumb = poster ? await sharp(poster).webp({ quality: 75 }).toBuffer().catch(() => null) : null;
    return persist(ctx, ownerId, buf, {
      name,
      mime,
      kind: 'video',
      width: probe?.width ?? null,
      height: probe?.height ?? null,
      durationMs: probe?.durationMs ?? null,
      thumb,
      purpose: 'attachment',
    });
  }

  if (AUDIO.has(mime) && opts.as !== 'file') {
    const probe = await probeMedia(buf, detected?.ext ?? 'mp3');
    return persist(ctx, ownerId, buf, { name, mime, kind: 'audio', durationMs: probe?.durationMs ?? null, purpose: 'attachment' });
  }

  if (DOCS.has(mime) || mime === 'text/plain' || IMAGE.has(mime) || VIDEO.has(mime) || AUDIO.has(mime)) {
    return persist(ctx, ownerId, buf, { name, mime, kind: 'file', purpose: 'attachment' });
  }
  throw errors.unsupported('This file type is not allowed');
}

async function processImage(ctx: AppContext, ownerId: string, buf: Buffer, name: string, mime: string) {
  const kind: AttachmentKind = 'image';
  const img = sharp(buf, { limitInputPixels: 100_000_000, animated: mime === 'image/gif' });
  const meta = await img.metadata().catch(() => null);
  if (!meta?.width || !meta.height) throw errors.unsupported('This image could not be read');
  let body = buf;
  let width = meta.width;
  let height = meta.pageHeight ?? meta.height;
  if (mime !== 'image/gif') {
    // Re-encode: applies EXIF orientation, strips metadata (e.g. GPS location), bounds the size.
    const res = await sharp(buf, { limitInputPixels: 100_000_000 })
      .rotate()
      .resize(4096, 4096, { fit: 'inside', withoutEnlargement: true })
      .toFormat(mime === 'image/png' ? 'png' : mime === 'image/avif' ? 'avif' : mime === 'image/webp' ? 'webp' : 'jpeg', { quality: 90 })
      .toBuffer({ resolveWithObject: true });
    body = res.data;
    width = res.info.width;
    height = res.info.height;
  }
  const thumb = await sharp(buf, { limitInputPixels: 100_000_000 })
    .rotate()
    .resize(480, 480, { fit: 'inside', withoutEnlargement: true })
    .webp({ quality: 75 })
    .toBuffer()
    .catch(() => null);
  return persist(ctx, ownerId, body, { name, mime, kind, width, height, thumb, purpose: 'attachment' });
}

async function persist(
  ctx: AppContext,
  ownerId: string,
  body: Buffer,
  meta: {
    name: string;
    mime: string;
    kind: AttachmentKind;
    width?: number | null;
    height?: number | null;
    durationMs?: number | null;
    waveform?: number[] | null;
    thumb?: Buffer | null;
    purpose: 'attachment' | 'avatar';
  },
) {
  const id = randomUUID();
  const day = new Date().toISOString().slice(0, 10);
  const key = `${meta.purpose}/${day}/${id}`;
  await ctx.storage.put(key, body, meta.mime);
  let thumbKey: string | null = null;
  if (meta.thumb) {
    thumbKey = `${key}.thumb.webp`;
    await ctx.storage.put(thumbKey, meta.thumb, 'image/webp');
  }
  const [row] = await ctx.db
    .insert(files)
    .values({
      id,
      ownerId,
      storageKey: key,
      thumbKey,
      kind: meta.kind,
      mime: meta.mime,
      size: body.length,
      name: meta.name,
      width: meta.width ?? null,
      height: meta.height ?? null,
      durationMs: meta.durationMs ?? null,
      waveform: meta.waveform ?? null,
      purpose: meta.purpose,
      sha256: sha256(body),
    })
    .returning();
  return row!;
}

/**
 * Authorisation for downloads: owner; avatars (any signed-in user); or the file is attached to a
 * non-deleted message the viewer can see (member beyond hidden history, or a public chat preview).
 */
export async function canAccessFile(ctx: AppContext, userId: string, file: typeof files.$inferSelect): Promise<boolean> {
  if (file.ownerId === userId) return true;
  if (file.purpose === 'avatar') {
    // Avatars must still be in use by someone (prevents reading replaced/removed avatars by id).
    const [u] = await ctx.db.select({ id: users.id }).from(users).where(eq(users.avatarFileId, file.id)).limit(1);
    if (u) return true;
    const [c] = await ctx.db.select({ id: conversations.id }).from(conversations).where(eq(conversations.avatarFileId, file.id)).limit(1);
    return Boolean(c);
  }
  const [row] = await ctx.db
    .select({ id: messages.id })
    .from(messageAttachments)
    .innerJoin(messages, eq(messages.id, messageAttachments.messageId))
    .innerJoin(conversations, eq(conversations.id, messages.conversationId))
    .leftJoin(
      conversationMembers,
      and(eq(conversationMembers.conversationId, messages.conversationId), eq(conversationMembers.userId, userId)),
    )
    .where(
      and(
        eq(messageAttachments.fileId, file.id),
        isNull(messages.deletedAt),
        isNull(conversations.deletedAt),
        or(
          and(sql`${conversationMembers.userId} IS NOT NULL`, gt(messages.seq, conversationMembers.hiddenBeforeSeq)),
          and(eq(conversations.isPublic, true), sql`${conversations.type} IN ('group','channel')`),
        ),
      ),
    )
    .limit(1);
  return Boolean(row);
}
