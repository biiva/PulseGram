import { execFile } from 'node:child_process';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import { randomUUID } from 'node:crypto';

const run = promisify(execFile);

let ffmpegAvailable: boolean | null = null;
export async function hasFfmpeg(): Promise<boolean> {
  if (ffmpegAvailable !== null) return ffmpegAvailable;
  try {
    await run('ffprobe', ['-version'], { timeout: 5000 });
    await run('ffmpeg', ['-version'], { timeout: 5000 });
    ffmpegAvailable = true;
  } catch {
    ffmpegAvailable = false;
  }
  return ffmpegAvailable;
}

async function withTempFile<T>(buf: Buffer, ext: string, fn: (p: string) => Promise<T>): Promise<T> {
  const dir = await fs.mkdtemp(path.join(os.tmpdir(), 'pg-media-'));
  const p = path.join(dir, `${randomUUID()}.${ext.replace(/[^a-z0-9]/gi, '') || 'bin'}`);
  try {
    await fs.writeFile(p, buf);
    return await fn(p);
  } finally {
    await fs.rm(dir, { recursive: true, force: true });
  }
}

export interface ProbeResult {
  durationMs: number | null;
  width: number | null;
  height: number | null;
  hasVideo: boolean;
  hasAudio: boolean;
}

/** Server-side media probing (never trust client-provided duration or dimensions). */
export async function probeMedia(buf: Buffer, ext: string): Promise<ProbeResult | null> {
  if (!(await hasFfmpeg())) return null;
  return withTempFile(buf, ext, async (p) => {
    try {
      const { stdout } = await run(
        'ffprobe',
        ['-v', 'error', '-print_format', 'json', '-show_format', '-show_streams', p],
        { timeout: 15000, maxBuffer: 4 * 1024 * 1024 },
      );
      const info = JSON.parse(stdout) as {
        format?: { duration?: string };
        streams?: Array<{ codec_type?: string; width?: number; height?: number; duration?: string; tags?: { rotate?: string }; side_data_list?: Array<{ rotation?: number }> }>;
      };
      const v = info.streams?.find((s) => s.codec_type === 'video');
      const a = info.streams?.find((s) => s.codec_type === 'audio');
      let durationSec = Number(info.format?.duration ?? v?.duration ?? a?.duration);
      if (!Number.isFinite(durationSec)) durationSec = NaN;
      const rot = Math.abs(Number(v?.tags?.rotate ?? v?.side_data_list?.find((s) => s.rotation !== undefined)?.rotation ?? 0));
      const swap = rot === 90 || rot === 270;
      return {
        durationMs: Number.isFinite(durationSec) ? Math.round(durationSec * 1000) : null,
        width: v ? ((swap ? v.height : v.width) ?? null) : null,
        height: v ? ((swap ? v.width : v.height) ?? null) : null,
        hasVideo: Boolean(v),
        hasAudio: Boolean(a),
      };
    } catch {
      return null;
    }
  });
}

/** Extract a poster frame (JPEG) from a video. */
export async function videoPoster(buf: Buffer, ext: string): Promise<Buffer | null> {
  if (!(await hasFfmpeg())) return null;
  return withTempFile(buf, ext, async (p) => {
    const out = `${p}.jpg`;
    try {
      await run('ffmpeg', ['-v', 'error', '-y', '-ss', '0.5', '-i', p, '-frames:v', '1', '-vf', 'scale=640:-2', out], { timeout: 20000 });
      return await fs.readFile(out);
    } catch {
      try {
        await run('ffmpeg', ['-v', 'error', '-y', '-i', p, '-frames:v', '1', '-vf', 'scale=640:-2', out], { timeout: 20000 });
        return await fs.readFile(out);
      } catch {
        return null;
      }
    }
  });
}

/**
 * Decode audio to 8 kHz mono PCM: yields a coarse waveform (64 samples, 0..1) and the exact
 * duration — browser-recorded WebM often has no duration header, so probing alone is not enough.
 */
export async function audioWaveform(buf: Buffer, ext: string, samples = 64): Promise<{ waveform: number[]; durationMs: number } | null> {
  if (!(await hasFfmpeg())) return null;
  return withTempFile(buf, ext, async (p) => {
    try {
      const { stdout } = await run('ffmpeg', ['-v', 'error', '-i', p, '-ac', '1', '-ar', '8000', '-f', 's16le', '-'], {
        timeout: 20000,
        encoding: 'buffer',
        maxBuffer: 64 * 1024 * 1024,
      });
      const pcm = stdout as unknown as Buffer;
      const n = Math.floor(pcm.length / 2);
      if (n === 0) return null;
      const bucket = Math.max(1, Math.floor(n / samples));
      const out: number[] = [];
      for (let i = 0; i < samples; i++) {
        let peak = 0;
        for (let j = i * bucket; j < Math.min(n, (i + 1) * bucket); j++) peak = Math.max(peak, Math.abs(pcm.readInt16LE(j * 2)));
        out.push(peak / 32768);
      }
      const max = Math.max(...out, 0.01);
      return { waveform: out.map((v) => Math.round((v / max) * 100) / 100), durationMs: Math.round((n / 8000) * 1000) };
    } catch {
      return null;
    }
  });
}
