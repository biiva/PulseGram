import { and, eq, gt, isNull } from 'drizzle-orm';
import type { FastifyReply, FastifyRequest } from 'fastify';
import type { AppContext } from '../../context';
import { sessions, users } from '../../db/schema';
import { errors } from '../../lib/errors';
import { hmac, randomToken, safeEqual, sha256 } from '../../lib/crypto';

export const SESSION_COOKIE = 'pg_session';
export const CSRF_COOKIE = 'pg_csrf';
export const CSRF_HEADER = 'x-csrf-token';

export interface AuthState {
  userId: string;
  sessionId: string;
  user: typeof users.$inferSelect;
}

declare module 'fastify' {
  interface FastifyRequest {
    auth: AuthState | null;
  }
}

export function csrfTokenFor(ctx: AppContext, sessionId: string): string {
  return hmac(ctx.config.APP_SECRET, `csrf:${sessionId}`);
}

function describeDevice(ua: string): string {
  const browser = /Edg\//.test(ua)
    ? 'Edge'
    : /OPR\//.test(ua)
      ? 'Opera'
      : /Firefox\//.test(ua)
        ? 'Firefox'
        : /Chrome\//.test(ua)
          ? 'Chrome'
          : /Safari\//.test(ua)
            ? 'Safari'
            : 'Browser';
  const os = /Windows/.test(ua)
    ? 'Windows'
    : /Android/.test(ua)
      ? 'Android'
      : /iPhone|iPad|iOS/.test(ua)
        ? 'iOS'
        : /Mac OS X/.test(ua)
          ? 'macOS'
          : /Linux/.test(ua)
            ? 'Linux'
            : '';
  return os ? `${browser} on ${os}` : browser;
}

export async function createSession(
  ctx: AppContext,
  req: FastifyRequest,
  reply: FastifyReply,
  userId: string,
  deviceName?: string,
): Promise<string> {
  const token = randomToken(32);
  const ua = String(req.headers['user-agent'] ?? '').slice(0, 512);
  const expiresAt = new Date(Date.now() + ctx.config.SESSION_TTL_DAYS * 86_400_000);
  const [row] = await ctx.db
    .insert(sessions)
    .values({
      userId,
      tokenHash: sha256(token),
      userAgent: ua,
      deviceName: (deviceName?.trim() || describeDevice(ua)).slice(0, 64),
      ip: req.ip,
      expiresAt,
    })
    .returning({ id: sessions.id });
  setSessionCookies(ctx, reply, token, row!.id, expiresAt);
  return row!.id;
}

export function setSessionCookies(ctx: AppContext, reply: FastifyReply, token: string, sessionId: string, expiresAt: Date) {
  const base = { path: '/', sameSite: 'lax' as const, secure: ctx.config.cookieSecure, expires: expiresAt };
  reply.setCookie(SESSION_COOKIE, token, { ...base, httpOnly: true });
  // Readable by the SPA so it can echo it in the X-CSRF-Token header (double-submit, bound to the session).
  reply.setCookie(CSRF_COOKIE, csrfTokenFor(ctx, sessionId), { ...base, httpOnly: false });
}

export function clearSessionCookies(ctx: AppContext, reply: FastifyReply) {
  const base = { path: '/', sameSite: 'lax' as const, secure: ctx.config.cookieSecure };
  reply.clearCookie(SESSION_COOKIE, base);
  reply.clearCookie(CSRF_COOKIE, base);
}

const TOUCH_INTERVAL_MS = 5 * 60 * 1000;

export async function resolveSessionToken(ctx: AppContext, token: string | undefined): Promise<AuthState | null> {
  if (!token || token.length > 128) return null;
  const now = new Date();
  const [row] = await ctx.db
    .select({ s: sessions, u: users })
    .from(sessions)
    .innerJoin(users, eq(users.id, sessions.userId))
    .where(and(eq(sessions.tokenHash, sha256(token)), isNull(sessions.revokedAt), gt(sessions.expiresAt, now), isNull(users.deletedAt)))
    .limit(1);
  if (!row) return null;
  if (now.getTime() - row.s.lastActiveAt.getTime() > TOUCH_INTERVAL_MS) {
    await ctx.db.update(sessions).set({ lastActiveAt: now }).where(eq(sessions.id, row.s.id));
  }
  return { userId: row.u.id, sessionId: row.s.id, user: row.u };
}

/** preHandler: requires a valid session; for state-changing methods also validates the CSRF token. */
export function requireAuth(ctx: AppContext) {
  return async (req: FastifyRequest) => {
    if (!req.auth) throw errors.unauthorized();
    if (req.method !== 'GET' && req.method !== 'HEAD' && req.method !== 'OPTIONS') {
      const header = req.headers[CSRF_HEADER];
      const expected = csrfTokenFor(ctx, req.auth.sessionId);
      if (typeof header !== 'string' || !safeEqual(header, expected)) {
        throw errors.forbidden('csrf_invalid', 'Security token missing or invalid. Reload the page and try again.');
      }
    }
  };
}
