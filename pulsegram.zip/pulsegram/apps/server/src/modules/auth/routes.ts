import { and, desc, eq, gt, isNull, ne, sql } from 'drizzle-orm';
import type { FastifyInstance, FastifyRequest } from 'fastify';
import {
  changePasswordSchema,
  forgotPasswordSchema,
  loginSchema,
  registerSchema,
  resetPasswordSchema,
  tokenSchema,
  usernameSchema,
  DEFAULT_GROUP_SETTINGS,
  type Language,
  type SessionInfo,
} from '@pulsegram/shared';
import type { AppContext } from '../../context';
import { authTokens, conversationMembers, conversations, sessions, users } from '../../db/schema';
import { burnPasswordCheck, hashPassword, randomToken, sha256, verifyPassword } from '../../lib/crypto';
import { AppError, errors, pgCode } from '../../lib/errors';
import { parse, uuidParam } from '../../lib/http';
import { enforce } from '../../lib/rateLimit';
import { verifyCaptcha } from '../../services/captcha';
import { buildEmail } from '../../services/mailer';
import { audit } from '../audit/service';
import { createDefaultPreferences, getPreferences } from '../users/preferences';
import { toMe } from '../users/me';
import { clearSessionCookies, createSession, requireAuth } from './session';

const VERIFY_TTL_MS = 24 * 3600_000;
const RESET_TTL_MS = 3600_000;

function langOf(req: FastifyRequest, fallback?: Language): Language {
  if (fallback) return fallback;
  return /^ru\b/i.test(String(req.headers['accept-language'] ?? '')) ? 'ru' : 'en';
}

async function isUsernameTaken(ctx: AppContext, username: string, exceptUserId?: string): Promise<boolean> {
  const lower = username.toLowerCase();
  const [u] = await ctx.db
    .select({ id: users.id })
    .from(users)
    .where(and(sql`lower(${users.username}) = ${lower}`, exceptUserId ? ne(users.id, exceptUserId) : undefined))
    .limit(1);
  if (u) return true;
  const [c] = await ctx.db
    .select({ id: conversations.id })
    .from(conversations)
    .where(sql`lower(${conversations.username}) = ${lower}`)
    .limit(1);
  return Boolean(c);
}
export { isUsernameTaken };

export async function issueAuthToken(ctx: AppContext, userId: string, purpose: 'email_verify' | 'password_reset') {
  const token = randomToken(32);
  // Invalidate any earlier unused token of the same purpose.
  await ctx.db
    .update(authTokens)
    .set({ usedAt: new Date() })
    .where(and(eq(authTokens.userId, userId), eq(authTokens.purpose, purpose), isNull(authTokens.usedAt)));
  await ctx.db.insert(authTokens).values({
    userId,
    purpose,
    tokenHash: sha256(token),
    expiresAt: new Date(Date.now() + (purpose === 'email_verify' ? VERIFY_TTL_MS : RESET_TTL_MS)),
  });
  return token;
}

async function consumeAuthToken(ctx: AppContext, token: string, purpose: 'email_verify' | 'password_reset') {
  const [row] = await ctx.db
    .update(authTokens)
    .set({ usedAt: new Date() })
    .where(
      and(
        eq(authTokens.tokenHash, sha256(token)),
        eq(authTokens.purpose, purpose),
        isNull(authTokens.usedAt),
        gt(authTokens.expiresAt, new Date()),
      ),
    )
    .returning({ userId: authTokens.userId });
  if (!row) throw errors.badRequest('token_invalid', 'This link is invalid or has expired');
  return row.userId;
}

export async function sendVerificationEmail(ctx: AppContext, user: typeof users.$inferSelect, lang: Language) {
  if (!ctx.mailer.configured) return false;
  const token = await issueAuthToken(ctx, user.id, 'email_verify');
  const link = `${ctx.config.APP_URL}/verify-email?token=${encodeURIComponent(token)}`;
  await ctx.mailer.send({ to: user.email, ...buildEmail('verify', lang, user.displayName, link) });
  return true;
}

export async function registerAuthRoutes(app: FastifyInstance, ctx: AppContext) {
  const auth = { preHandler: requireAuth(ctx) };

  app.get('/api/auth/username-available', async (req) => {
    await enforce(ctx.limiter, `uname:${req.ip}`, 60, 60);
    const q = req.query as { username?: string };
    const r = usernameSchema.safeParse(q.username ?? '');
    if (!r.success) return { available: false, reason: 'invalid' };
    const taken = await isUsernameTaken(ctx, r.data, req.auth?.userId);
    return { available: !taken, reason: taken ? 'taken' : null };
  });

  app.post('/api/auth/register', async (req, reply) => {
    await enforce(ctx.limiter, `register:ip:${req.ip}`, ctx.config.isProd ? 5 : 1000, 3600);
    const input = parse(registerSchema, req.body);
    await verifyCaptcha(ctx.config, input.captchaToken, req.ip);

    if (await isUsernameTaken(ctx, input.username)) {
      throw new AppError(409, 'username_taken', 'This username is already taken', [{ path: 'username', code: 'username_taken' }]);
    }
    const [existingEmail] = await ctx.db
      .select({ id: users.id })
      .from(users)
      .where(sql`lower(${users.email}) = ${input.email}`)
      .limit(1);
    if (existingEmail) {
      // Registration necessarily reveals that an email is in use; it is rate limited per IP above.
      throw new AppError(409, 'email_taken', 'An account with this email already exists', [{ path: 'email', code: 'email_taken' }]);
    }

    const passwordHash = await hashPassword(input.password);
    const lang = langOf(req, input.language);
    let user: typeof users.$inferSelect;
    try {
      user = await ctx.db.transaction(async (tx) => {
        const [u] = await tx
          .insert(users)
          .values({ email: input.email, username: input.username, displayName: input.displayName, passwordHash })
          .returning();
        await createDefaultPreferences(tx, u!.id, lang);
        // Personal "Saved messages" space — private to its owner.
        const [saved] = await tx
          .insert(conversations)
          .values({ type: 'saved', directKey: `saved:${u!.id}`, settings: DEFAULT_GROUP_SETTINGS, memberCount: 1, createdById: u!.id })
          .returning({ id: conversations.id });
        await tx.insert(conversationMembers).values({ conversationId: saved!.id, userId: u!.id, role: 'owner' });
        return u!;
      });
    } catch (err: unknown) {
      if (pgCode(err) === '23505') throw errors.conflict('already_exists', 'Username or email already in use');
      throw err;
    }

    await audit(ctx, { actorId: user.id, action: 'account.registered', ip: req.ip });
    let verificationSent = false;
    try {
      verificationSent = await sendVerificationEmail(ctx, user, lang);
    } catch (err) {
      req.log.error({ err }, 'failed to send verification email');
    }
    await createSession(ctx, req, reply, user.id);
    reply.code(201);
    return { me: toMe(user), preferences: await getPreferences(ctx.db, user.id), verificationSent };
  });

  app.post('/api/auth/login', async (req, reply) => {
    const input = parse(loginSchema, req.body);
    await enforce(ctx.limiter, `login:ip:${req.ip}`, ctx.config.isTest ? 1000 : 30, 15 * 60);
    const emailKey = `login:email:${input.email}`;
    const lock = await ctx.limiter.peek(emailKey, 8);
    if (!lock.allowed) throw errors.tooMany(lock.retryAfterSec);

    const [user] = await ctx.db
      .select()
      .from(users)
      .where(and(sql`lower(${users.email}) = ${input.email}`, isNull(users.deletedAt)))
      .limit(1);
    const ok = user ? await verifyPassword(user.passwordHash, input.password) : (await burnPasswordCheck(input.password), false);
    if (!ok || !user) {
      // Count failures per account to slow down targeted guessing (window resets after 15 minutes).
      await ctx.limiter.hit(emailKey, 8, 15 * 60);
      throw errors.unauthorized('invalid_credentials', 'Incorrect email or password');
    }
    await ctx.limiter.reset(emailKey);
    await createSession(ctx, req, reply, user.id, input.deviceName);
    await audit(ctx, { actorId: user.id, action: 'account.login', ip: req.ip });
    return { me: toMe(user), preferences: await getPreferences(ctx.db, user.id) };
  });

  app.post('/api/auth/logout', auth, async (req, reply) => {
    await ctx.db.update(sessions).set({ revokedAt: new Date() }).where(eq(sessions.id, req.auth!.sessionId));
    await ctx.hub.revokeSession(req.auth!.sessionId);
    clearSessionCookies(ctx, reply);
    return { ok: true };
  });

  app.get('/api/auth/me', async (req) => {
    if (!req.auth) throw errors.unauthorized();
    return { me: toMe(req.auth.user), preferences: await getPreferences(ctx.db, req.auth.userId) };
  });

  app.post('/api/auth/verify-email', async (req) => {
    await enforce(ctx.limiter, `verify:ip:${req.ip}`, 30, 3600);
    const { token } = parse(tokenSchema, req.body);
    const userId = await consumeAuthToken(ctx, token, 'email_verify');
    const [u] = await ctx.db.update(users).set({ emailVerifiedAt: new Date() }).where(eq(users.id, userId)).returning();
    await audit(ctx, { actorId: userId, action: 'account.email_verified', ip: req.ip });
    return { ok: true, me: req.auth?.userId === userId && u ? toMe(u) : null };
  });

  app.post('/api/auth/resend-verification', auth, async (req) => {
    await enforce(ctx.limiter, `resend:${req.auth!.userId}`, 3, 3600);
    if (req.auth!.user.emailVerifiedAt) return { ok: true, alreadyVerified: true };
    if (!ctx.mailer.configured) throw errors.notConfigured('Email delivery');
    const prefs = await getPreferences(ctx.db, req.auth!.userId);
    await sendVerificationEmail(ctx, req.auth!.user, prefs.appearance.language);
    return { ok: true };
  });

  app.post('/api/auth/forgot-password', async (req) => {
    const input = parse(forgotPasswordSchema, req.body);
    await enforce(ctx.limiter, `forgot:ip:${req.ip}`, ctx.config.isTest ? 1000 : 10, 3600);
    await verifyCaptcha(ctx.config, input.captchaToken, req.ip);
    if (!ctx.mailer.configured) throw errors.notConfigured('Email delivery');
    // Same response whether or not the account exists (no account enumeration).
    const perEmail = await ctx.limiter.hit(`forgot:email:${input.email}`, 3, 3600);
    if (perEmail.allowed) {
      const [user] = await ctx.db
        .select()
        .from(users)
        .where(and(sql`lower(${users.email}) = ${input.email}`, isNull(users.deletedAt)))
        .limit(1);
      if (user) {
        const prefs = await getPreferences(ctx.db, user.id);
        const token = await issueAuthToken(ctx, user.id, 'password_reset');
        const link = `${ctx.config.APP_URL}/reset-password?token=${encodeURIComponent(token)}`;
        ctx.mailer
          .send({ to: user.email, ...buildEmail('reset', prefs.appearance.language, user.displayName, link) })
          .catch((err: unknown) => req.log.error({ err }, 'failed to send reset email'));
      } else {
        await burnPasswordCheck('x'); // keep timing similar
      }
    }
    return { ok: true };
  });

  app.post('/api/auth/reset-password', async (req) => {
    await enforce(ctx.limiter, `reset:ip:${req.ip}`, 20, 3600);
    const input = parse(resetPasswordSchema, req.body);
    const userId = await consumeAuthToken(ctx, input.token, 'password_reset');
    const passwordHash = await hashPassword(input.password);
    await ctx.db.transaction(async (tx) => {
      // Proving control of the inbox also verifies the email.
      await tx
        .update(users)
        .set({ passwordHash, emailVerifiedAt: sql`coalesce(${users.emailVerifiedAt}, now())`, updatedAt: new Date() })
        .where(eq(users.id, userId));
      await tx.update(sessions).set({ revokedAt: new Date() }).where(and(eq(sessions.userId, userId), isNull(sessions.revokedAt)));
    });
    await ctx.hub.revokeUser(userId);
    await audit(ctx, { actorId: userId, action: 'account.password_reset', ip: req.ip });
    return { ok: true };
  });

  app.post('/api/auth/change-password', auth, async (req) => {
    await enforce(ctx.limiter, `chpw:${req.auth!.userId}`, 10, 3600);
    const input = parse(changePasswordSchema, req.body);
    if (!(await verifyPassword(req.auth!.user.passwordHash, input.currentPassword))) {
      throw errors.badRequest('invalid_password', 'Current password is incorrect', [{ path: 'currentPassword', code: 'invalid_password' }]);
    }
    await ctx.db.update(users).set({ passwordHash: await hashPassword(input.newPassword), updatedAt: new Date() }).where(eq(users.id, req.auth!.userId));
    await ctx.db
      .update(sessions)
      .set({ revokedAt: new Date() })
      .where(and(eq(sessions.userId, req.auth!.userId), ne(sessions.id, req.auth!.sessionId), isNull(sessions.revokedAt)));
    await ctx.hub.revokeUser(req.auth!.userId, req.auth!.sessionId);
    await audit(ctx, { actorId: req.auth!.userId, action: 'account.password_changed', ip: req.ip });
    return { ok: true };
  });

  // ── Sessions / devices ──
  app.get('/api/sessions', auth, async (req): Promise<SessionInfo[]> => {
    const rows = await ctx.db
      .select()
      .from(sessions)
      .where(and(eq(sessions.userId, req.auth!.userId), isNull(sessions.revokedAt), gt(sessions.expiresAt, new Date())))
      .orderBy(desc(sessions.lastActiveAt));
    return rows.map((s) => ({
      id: s.id,
      deviceName: s.deviceName,
      userAgent: s.userAgent,
      ip: s.ip,
      createdAt: s.createdAt.toISOString(),
      lastActiveAt: s.lastActiveAt.toISOString(),
      current: s.id === req.auth!.sessionId,
    }));
  });

  app.delete('/api/sessions/:id', auth, async (req) => {
    const id = uuidParam(req.params);
    const [row] = await ctx.db
      .update(sessions)
      .set({ revokedAt: new Date() })
      .where(and(eq(sessions.id, id), eq(sessions.userId, req.auth!.userId), isNull(sessions.revokedAt)))
      .returning({ id: sessions.id });
    if (!row) throw errors.notFound();
    await ctx.hub.revokeSession(id);
    await audit(ctx, { actorId: req.auth!.userId, action: 'session.revoked', ip: req.ip, data: { sessionId: id } });
    return { ok: true };
  });

  app.post('/api/sessions/revoke-others', auth, async (req) => {
    const rows = await ctx.db
      .update(sessions)
      .set({ revokedAt: new Date() })
      .where(and(eq(sessions.userId, req.auth!.userId), ne(sessions.id, req.auth!.sessionId), isNull(sessions.revokedAt)))
      .returning({ id: sessions.id });
    await ctx.hub.revokeUser(req.auth!.userId, req.auth!.sessionId);
    await audit(ctx, { actorId: req.auth!.userId, action: 'session.revoked_others', ip: req.ip, data: { count: rows.length } });
    return { ok: true, revoked: rows.length };
  });
}
