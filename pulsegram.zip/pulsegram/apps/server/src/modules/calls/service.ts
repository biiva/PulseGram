import { createHmac } from 'node:crypto';
import { and, desc, eq, inArray, lt, or } from 'drizzle-orm';
import type { CallDto, CallSignal } from '@pulsegram/shared';
import type { AppContext } from '../../context';
import { calls } from '../../db/schema';
import { errors } from '../../lib/errors';
import { enforce } from '../../lib/rateLimit';
import type { AuthState } from '../auth/session';
import { directPeerId, isBlockedEitherWay, requireMember } from '../conversations/access';
import { notify } from '../notifications/service';
import { getPrivacyMap } from '../users/preferences';
import { audienceAllows, loadRelations, loadUserSummaries } from '../users/serialize';

const RING_TIMEOUT_MS = 45_000;
const ACTIVE = ['ringing', 'accepted'] as const;
type CallRow = typeof calls.$inferSelect;

export async function callDto(ctx: AppContext, viewerId: string, c: CallRow): Promise<CallDto> {
  const sums = await loadUserSummaries(ctx, viewerId, [c.callerId, c.calleeId]);
  return {
    id: c.id,
    conversationId: c.conversationId,
    caller: sums.get(c.callerId)!,
    callee: sums.get(c.calleeId)!,
    video: c.video,
    status: c.status,
    createdAt: c.createdAt.toISOString(),
    answeredAt: c.answeredAt?.toISOString() ?? null,
    endedAt: c.endedAt?.toISOString() ?? null,
    durationSec: c.answeredAt && c.endedAt ? Math.round((c.endedAt.getTime() - c.answeredAt.getTime()) / 1000) : null,
  };
}

async function broadcast(ctx: AppContext, c: CallRow) {
  for (const uid of [c.callerId, c.calleeId]) {
    await ctx.hub.emit([uid], 'call:updated', { call: await callDto(ctx, uid, c) });
  }
}

/** Mark calls stuck in "ringing" (e.g. after a server restart) as missed. */
export async function expireStaleCalls(ctx: AppContext) {
  const cutoff = new Date(Date.now() - RING_TIMEOUT_MS - 5000);
  await ctx.db
    .update(calls)
    .set({ status: 'missed', endedAt: new Date() })
    .where(and(eq(calls.status, 'ringing'), lt(calls.createdAt, cutoff)));
  // Accepted calls older than 6h without an end are certainly over.
  await ctx.db
    .update(calls)
    .set({ status: 'ended', endedAt: new Date() })
    .where(and(eq(calls.status, 'accepted'), lt(calls.createdAt, new Date(Date.now() - 6 * 3600_000))));
}

export async function startCall(ctx: AppContext, auth: AuthState, conversationId: string, video: boolean) {
  await enforce(ctx.limiter, `call:${auth.userId}`, ctx.config.isTest ? 10_000 : 20, 600);
  const { conv } = await requireMember(ctx.db, auth.userId, conversationId);
  if (conv.type !== 'direct') {
    throw errors.badRequest('group_calls_unsupported', 'Group calls are not available yet');
  }
  const peerId = await directPeerId(ctx.db, conv.id, auth.userId);
  if (!peerId) throw errors.notFound();
  if (await isBlockedEitherWay(ctx.db, auth.userId, peerId)) throw errors.forbidden('blocked', 'You cannot call this user');
  const [privacy, rel] = await Promise.all([getPrivacyMap(ctx.db, [peerId]), loadRelations(ctx.db, auth.userId, [peerId])]);
  if (!audienceAllows(privacy.get(peerId)!.calls, rel.viewerIsContactOf.has(peerId))) {
    throw errors.forbidden('calls_restricted', 'This user does not accept calls from you');
  }
  await expireStaleCalls(ctx);
  const busy = await ctx.db
    .select({ id: calls.id })
    .from(calls)
    .where(
      and(
        inArray(calls.status, [...ACTIVE]),
        or(eq(calls.callerId, peerId), eq(calls.calleeId, peerId), eq(calls.callerId, auth.userId), eq(calls.calleeId, auth.userId)),
      ),
    )
    .limit(1);
  const [row] = await ctx.db
    .insert(calls)
    .values({
      conversationId: conv.id,
      callerId: auth.userId,
      calleeId: peerId,
      video,
      status: busy.length ? 'busy' : 'ringing',
      callerSessionId: auth.sessionId,
      endedAt: busy.length ? new Date() : null,
    })
    .returning();
  const c = row!;
  if (c.status === 'busy') return callDto(ctx, auth.userId, c);

  await ctx.hub.emit([peerId], 'call:incoming', { call: await callDto(ctx, peerId, c) });
  await ctx.hub.emit([auth.userId], 'call:updated', { call: await callDto(ctx, auth.userId, c) }, { exceptSessionId: auth.sessionId });
  const offline = !(await ctx.presence.onlineSet([peerId])).has(peerId);
  if (offline) await ctx.push.sendToUser(peerId, { title: auth.user.displayName, body: video ? 'Incoming video call' : 'Incoming call', tag: `call:${c.id}`, url: `/chat/${conv.id}` });

  setTimeout(() => {
    void (async () => {
      const [updated] = await ctx.db
        .update(calls)
        .set({ status: 'missed', endedAt: new Date() })
        .where(and(eq(calls.id, c.id), eq(calls.status, 'ringing')))
        .returning();
      if (updated) {
        await broadcast(ctx, updated);
        await notify(ctx, [
          { userId: peerId, type: 'call', title: `Missed ${video ? 'video ' : ''}call from ${auth.user.displayName}`, conversationId: conv.id, actorId: auth.userId },
        ]);
      }
    })().catch((err: unknown) => ctx.log.error({ err }, 'call timeout handler failed'));
  }, RING_TIMEOUT_MS).unref();

  return callDto(ctx, auth.userId, c);
}

async function loadCall(ctx: AppContext, userId: string, callId: string) {
  const [c] = await ctx.db.select().from(calls).where(eq(calls.id, callId));
  if (!c || (c.callerId !== userId && c.calleeId !== userId)) throw errors.notFound('call_not_found', 'Call not found');
  return c;
}

export async function answerCall(ctx: AppContext, auth: AuthState, callId: string, action: 'accept' | 'reject' | 'end') {
  const c = await loadCall(ctx, auth.userId, callId);
  let next: Partial<CallRow>;
  if (action === 'accept') {
    if (c.calleeId !== auth.userId) throw errors.forbidden();
    if (c.status !== 'ringing') throw errors.conflict('call_not_ringing', 'This call is no longer ringing');
    next = { status: 'accepted', answeredAt: new Date(), calleeSessionId: auth.sessionId };
  } else if (action === 'reject') {
    if (c.status !== 'ringing') return callDto(ctx, auth.userId, c);
    next = { status: c.calleeId === auth.userId ? 'rejected' : 'cancelled', endedAt: new Date() };
  } else {
    if (c.status === 'ringing') next = { status: c.callerId === auth.userId ? 'cancelled' : 'rejected', endedAt: new Date() };
    else if (c.status === 'accepted') next = { status: 'ended', endedAt: new Date() };
    else return callDto(ctx, auth.userId, c);
  }
  const [updated] = await ctx.db
    .update(calls)
    .set(next)
    .where(and(eq(calls.id, c.id), eq(calls.status, c.status)))
    .returning();
  if (!updated) throw errors.conflict('call_state_changed', 'Call state changed, try again');
  await broadcast(ctx, updated);
  if (updated.status === 'cancelled') {
    await notify(ctx, [
      { userId: updated.calleeId, type: 'call', title: `Missed ${updated.video ? 'video ' : ''}call from ${auth.user.displayName}`, conversationId: updated.conversationId, actorId: auth.userId },
    ]);
  }
  return callDto(ctx, auth.userId, updated);
}

/** Relay an SDP/ICE signal to the other device in an active call. */
export async function relaySignal(ctx: AppContext, userId: string, sessionId: string, callId: string, signal: CallSignal) {
  const [c] = await ctx.db.select().from(calls).where(eq(calls.id, callId));
  if (!c || !['accepted', 'ringing'].includes(c.status)) throw errors.notFound('call_not_found', 'Call is not active');
  let toUser: string;
  let toSession: string | null;
  if (c.callerId === userId && c.callerSessionId === sessionId) {
    toUser = c.calleeId;
    toSession = c.calleeSessionId;
  } else if (c.calleeId === userId && c.calleeSessionId === sessionId) {
    toUser = c.callerId;
    toSession = c.callerSessionId;
  } else {
    throw errors.forbidden('not_call_device', 'This device is not part of the call');
  }
  if (!toSession) throw errors.conflict('call_not_accepted', 'Call has not been accepted yet');
  await ctx.hub.emitToSession(toUser, toSession, 'call:signal', { callId, fromUserId: userId, signal });
}

export async function listCalls(ctx: AppContext, userId: string) {
  await expireStaleCalls(ctx);
  const rows = await ctx.db
    .select()
    .from(calls)
    .where(or(eq(calls.callerId, userId), eq(calls.calleeId, userId)))
    .orderBy(desc(calls.createdAt))
    .limit(100);
  const ids = [...new Set(rows.flatMap((r) => [r.callerId, r.calleeId]))];
  const sums = await loadUserSummaries(ctx, userId, ids);
  return rows.map((c) => ({
    id: c.id,
    conversationId: c.conversationId,
    caller: sums.get(c.callerId)!,
    callee: sums.get(c.calleeId)!,
    video: c.video,
    status: c.status,
    createdAt: c.createdAt.toISOString(),
    answeredAt: c.answeredAt?.toISOString() ?? null,
    endedAt: c.endedAt?.toISOString() ?? null,
    durationSec: c.answeredAt && c.endedAt ? Math.round((c.endedAt.getTime() - c.answeredAt.getTime()) / 1000) : null,
  }));
}

export async function activeCall(ctx: AppContext, userId: string) {
  await expireStaleCalls(ctx);
  const [c] = await ctx.db
    .select()
    .from(calls)
    .where(and(inArray(calls.status, [...ACTIVE]), or(eq(calls.callerId, userId), eq(calls.calleeId, userId))))
    .orderBy(desc(calls.createdAt))
    .limit(1);
  return c ? callDto(ctx, userId, c) : null;
}

export function iceServers(ctx: AppContext, userId: string) {
  const servers: Array<{ urls: string[]; username?: string; credential?: string }> = [];
  const stun = ctx.config.STUN_URLS.split(',').map((s) => s.trim()).filter(Boolean);
  if (stun.length) servers.push({ urls: stun });
  if (ctx.config.TURN_URLS) {
    const urls = ctx.config.TURN_URLS.split(',').map((s) => s.trim()).filter(Boolean);
    if (ctx.config.TURN_SECRET) {
      // coturn REST API credentials (use-auth-secret), valid for 12 hours.
      const username = `${Math.floor(Date.now() / 1000) + 12 * 3600}:${userId}`;
      const credential = createHmac('sha1', ctx.config.TURN_SECRET).update(username).digest('base64');
      servers.push({ urls, username, credential });
    } else if (ctx.config.TURN_USERNAME && ctx.config.TURN_CREDENTIAL) {
      servers.push({ urls, username: ctx.config.TURN_USERNAME, credential: ctx.config.TURN_CREDENTIAL });
    }
  }
  return { iceServers: servers, turnConfigured: ctx.config.turnConfigured };
}

