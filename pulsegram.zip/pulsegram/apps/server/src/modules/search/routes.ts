import { and, asc, desc, eq, exists, gt, gte, inArray, isNull, lt, lte, ne, notExists, or, sql } from 'drizzle-orm';
import type { FastifyInstance } from 'fastify';
import { searchQuerySchema, type SearchResults, type SyncResponse } from '@pulsegram/shared';
import { z } from 'zod';
import type { AppContext } from '../../context';
import {
  conversationMembers,
  conversations,
  files,
  hiddenMessages,
  messageAttachments,
  messages,
  users,
} from '../../db/schema';
import { parse } from '../../lib/http';
import { enforce } from '../../lib/rateLimit';
import { requireAuth } from '../auth/session';
import { requireReadable } from '../conversations/access';
import { toConversationDtos } from '../conversations/serialize';
import { listConversations } from '../conversations/service';
import { toMessageDtos } from '../messages/serialize';
import { loadUserSummaries } from '../users/serialize';

function likeTerm(q: string) {
  return `%${q.toLowerCase().replace(/[%_\\]/g, '\\$&')}%`;
}

export async function registerSearchRoutes(app: FastifyInstance, ctx: AppContext) {
  const auth = { preHandler: requireAuth(ctx) };

  app.get('/api/search', auth, async (req): Promise<SearchResults> => {
    await enforce(ctx.limiter, `search:${req.auth!.userId}`, ctx.config.isTest ? 10_000 : 90, 60);
    const q = parse(searchQuerySchema, req.query);
    const uid = req.auth!.userId;
    const term = q.q.replace(/^@/, '');
    const like = likeTerm(term);
    const empty: SearchResults = { users: [], conversations: [], publicConversations: [], messages: [] };

    // Message filter shared by global and in-chat search. Only chats the user is a member of,
    // and only history visible to them — never other people's private conversations.
    const msgWhere = and(
      isNull(messages.deletedAt),
      ne(messages.type, 'system'),
      term ? sql`lower(${messages.text}) LIKE ${like}` : undefined,
      q.senderId ? eq(messages.senderId, q.senderId) : undefined,
      q.from ? gte(messages.createdAt, new Date(q.from)) : undefined,
      q.to ? lte(messages.createdAt, new Date(q.to)) : undefined,
      q.before ? lt(messages.seq, q.before) : undefined,
      q.type === 'link' ? eq(messages.hasLink, true) : undefined,
      q.type === 'text' ? eq(messages.type, 'text') : undefined,
      q.type && !['link', 'text'].includes(q.type)
        ? exists(
            ctx.db
              .select({ x: sql`1` })
              .from(messageAttachments)
              .innerJoin(files, eq(files.id, messageAttachments.fileId))
              .where(and(eq(messageAttachments.messageId, messages.id), eq(files.kind, q.type as 'image'))),
          )
        : undefined,
      notExists(
        ctx.db
          .select({ x: sql`1` })
          .from(hiddenMessages)
          .where(and(eq(hiddenMessages.messageId, messages.id), eq(hiddenMessages.userId, uid))),
      ),
    );
    const hasFilter = Boolean(term || q.senderId || q.type || q.from || q.to);

    if (q.conversationId) {
      const { conv, member } = await requireReadable(ctx.db, uid, q.conversationId);
      if (!hasFilter) return empty;
      const rows = await ctx.db
        .select()
        .from(messages)
        .where(and(msgWhere, eq(messages.conversationId, conv.id), member ? gt(messages.seq, member.hiddenBeforeSeq) : undefined))
        .orderBy(desc(messages.seq))
        .limit(q.limit);
      const dtos = await toMessageDtos(ctx.db, rows, uid, { channel: conv.type === 'channel' });
      return {
        ...empty,
        messages: dtos.map((m) => ({ message: m, conversation: { id: conv.id, title: conv.title, type: conv.type, avatarUrl: null } })),
      };
    }

    if (!hasFilter || (term && term.length < 2 && !q.type)) return empty;

    const [userRows, msgRows, publicRows] = await Promise.all([
      term
        ? ctx.db
            .select({ id: users.id })
            .from(users)
            .where(
              and(
                isNull(users.deletedAt),
                ne(users.id, uid),
                or(sql`lower(${users.username}) LIKE ${like}`, sql`lower(${users.displayName}) LIKE ${like}`),
              ),
            )
            .orderBy(sql`CASE WHEN lower(${users.username}) = ${term.toLowerCase()} THEN 0 ELSE 1 END`, asc(users.username))
            .limit(8)
        : Promise.resolve([]),
      ctx.db
        .select({ m: messages })
        .from(messages)
        .innerJoin(
          conversationMembers,
          and(eq(conversationMembers.conversationId, messages.conversationId), eq(conversationMembers.userId, uid)),
        )
        .innerJoin(conversations, and(eq(conversations.id, messages.conversationId), isNull(conversations.deletedAt)))
        .where(and(msgWhere, gt(messages.seq, conversationMembers.hiddenBeforeSeq)))
        .orderBy(desc(messages.seq))
        .limit(q.limit),
      term
        ? ctx.db
            .select()
            .from(conversations)
            .where(
              and(
                eq(conversations.isPublic, true),
                isNull(conversations.deletedAt),
                inArray(conversations.type, ['group', 'channel']),
                or(sql`lower(${conversations.title}) LIKE ${like}`, sql`lower(${conversations.username}) LIKE ${like}`),
                notExists(
                  ctx.db
                    .select({ x: sql`1` })
                    .from(conversationMembers)
                    .where(and(eq(conversationMembers.conversationId, conversations.id), eq(conversationMembers.userId, uid))),
                ),
              ),
            )
            .orderBy(desc(conversations.memberCount))
            .limit(8)
        : Promise.resolve([]),
    ]);

    const mine = term ? await listConversations(ctx, uid) : [];
    const lowerTerm = term.toLowerCase();
    const myMatches = mine
      .filter((c) => c.title.toLowerCase().includes(lowerTerm) || (c.username ?? '').toLowerCase().includes(lowerTerm))
      .slice(0, 10);

    const userSums = await loadUserSummaries(ctx, uid, userRows.map((r) => r.id));
    const convIds = [...new Set(msgRows.map((r) => r.m.conversationId))];
    const convDtos = convIds.length
      ? await toConversationDtos(ctx, uid, await ctx.db.select().from(conversations).where(inArray(conversations.id, convIds)))
      : [];
    const convBy = new Map(convDtos.map((c) => [c.id, c]));
    const msgDtos = await toMessageDtos(ctx.db, msgRows.map((r) => r.m), uid);
    return {
      users: userRows.map((r) => userSums.get(r.id)!).filter(Boolean),
      conversations: myMatches,
      publicConversations: await toConversationDtos(ctx, uid, publicRows),
      messages: msgDtos.flatMap((m) => {
        const c = convBy.get(m.conversationId);
        return c ? [{ message: m, conversation: { id: c.id, title: c.title, type: c.type, avatarUrl: c.avatarUrl } }] : [];
      }),
    };
  });

  /**
   * Recovery after reconnect: everything that changed since `since` (server time from the last
   * event the client saw). The conversation list is returned in full so removals are detectable.
   */
  app.get('/api/sync', auth, async (req): Promise<SyncResponse> => {
    const { since } = parse(z.object({ since: z.iso.datetime() }), req.query);
    const uid = req.auth!.userId;
    const serverTime = new Date().toISOString();
    const sinceDate = new Date(new Date(since).getTime() - 2000); // small overlap for clock edges; client dedups
    const LIMIT = 500;
    const rows = await ctx.db
      .select({ m: messages, conv: conversations })
      .from(messages)
      .innerJoin(conversationMembers, and(eq(conversationMembers.conversationId, messages.conversationId), eq(conversationMembers.userId, uid)))
      .innerJoin(conversations, eq(conversations.id, messages.conversationId))
      .where(and(gt(messages.updatedAt, sinceDate), gt(messages.seq, conversationMembers.hiddenBeforeSeq)))
      .orderBy(asc(messages.updatedAt))
      .limit(LIMIT + 1);
    const truncated = rows.length > LIMIT;
    const page = rows.slice(0, LIMIT).map((r) => r.m);
    const hidden = page.length
      ? await ctx.db
          .select({ id: hiddenMessages.messageId })
          .from(hiddenMessages)
          .where(and(eq(hiddenMessages.userId, uid), inArray(hiddenMessages.messageId, page.map((m) => m.id))))
      : [];
    const hiddenIds = new Set(hidden.map((h) => h.id));
    const dtos = await toMessageDtos(ctx.db, page, uid);
    return {
      serverTime,
      conversations: await listConversations(ctx, uid),
      // Messages the user deleted "for me" are replayed as deleted so every device drops them.
      messages: dtos.map((d) => (hiddenIds.has(d.id) ? { ...d, deletedAt: d.deletedAt ?? serverTime, text: '', attachments: [] } : d)),
      truncated,
    };
  });
}
