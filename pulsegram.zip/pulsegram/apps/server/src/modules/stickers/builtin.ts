import { eq } from 'drizzle-orm';
import type { AppContext } from '../../context';
import { stickers, stickerSets } from '../../db/schema';

/**
 * PulseGram ships one original sticker pack ("Pip", the pulse mascot). The SVG assets live in
 * apps/web/public/stickers/pip and are part of the product, not demo data.
 */
export const BUILTIN_PACKS = [
  {
    name: 'pip',
    title: 'Pip the Pulse',
    stickers: [
      { file: 'hi', emoji: '👋' },
      { file: 'love', emoji: '❤️' },
      { file: 'laugh', emoji: '😂' },
      { file: 'wow', emoji: '😮' },
      { file: 'sad', emoji: '😢' },
      { file: 'angry', emoji: '😠' },
      { file: 'cool', emoji: '😎' },
      { file: 'party', emoji: '🎉' },
      { file: 'thumbs', emoji: '👍' },
      { file: 'sleep', emoji: '😴' },
      { file: 'think', emoji: '🤔' },
      { file: 'coffee', emoji: '☕' },
    ],
  },
] as const;

export async function ensureBuiltinStickers(ctx: Pick<AppContext, 'db'>) {
  for (const pack of BUILTIN_PACKS) {
    let [set] = await ctx.db.select().from(stickerSets).where(eq(stickerSets.name, pack.name));
    if (!set) {
      [set] = await ctx.db.insert(stickerSets).values({ name: pack.name, title: pack.title }).onConflictDoNothing().returning();
      if (!set) [set] = await ctx.db.select().from(stickerSets).where(eq(stickerSets.name, pack.name));
    }
    const existing = await ctx.db.select({ assetPath: stickers.assetPath }).from(stickers).where(eq(stickers.setId, set!.id));
    const have = new Set(existing.map((e) => e.assetPath));
    const missing = pack.stickers
      .map((s, position) => ({ setId: set!.id, emoji: s.emoji, assetPath: `/stickers/${pack.name}/${s.file}.svg`, animated: true, position }))
      .filter((s) => !have.has(s.assetPath));
    if (missing.length) await ctx.db.insert(stickers).values(missing);
  }
}
