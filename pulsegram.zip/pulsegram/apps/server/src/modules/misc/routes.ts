import { and, asc, desc, eq, inArray, isNull, sql } from 'drizzle-orm';
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import {
  APP_VERSION,
  folderSchema,
  pushSubscriptionSchema,
  startCallSchema,
  type FolderDto,
  type GifDto,
  type NotificationDto,
  type PublicConfig,
  type StickerSetDto,
} from '@pulsegram/shared';
import type { AppContext } from '../../context';
import { chatFolders, favoriteStickers, notifications, pushSubscriptions, stickers, stickerSets } from '../../db/schema';
import { errors } from '../../lib/errors';
import { parse, uuidParam } from '../../lib/http';
import { enforce } from '../../lib/rateLimit';
import { requireAuth } from '../auth/session';
import { activeCall, answerCall, iceServers, listCalls, startCall } from '../calls/service';
import { stickerDto } from '../messages/serialize';
import { markNotificationsRead } from '../notifications/service';
import { loadUserSummaries } from '../users/serialize';

export async function registerMiscRoutes(app: FastifyInstance, ctx: AppContext) {
  const auth = { preHandler: requireAuth(ctx) };

  // ── System ──
  app.get('/api/health', async () => {
    const started = Date.now();
    let db = 'ok';
    try {
      await ctx.db.execute(sql`SELECT 1`);
    } catch {
      db = 'error';
    }
    let redis: string = ctx.redis ? 'ok' : 'not_configured';
    if (ctx.redis) {
      try {
        await ctx.redis.ping();
      } catch {
        redis = 'error';
      }
    }
    const healthy = db === 'ok' && redis !== 'error';
    return {
      status: healthy ? 'ok' : 'degraded',
      version: APP_VERSION,
      checks: { database: db, redis, storage: ctx.storage.driver, email: ctx.mailer.configured ? 'configured' : 'not_configured' },
      connections: ctx.hub.localConnectionCount(),
      uptimeSec: Math.round(process.uptime()),
      latencyMs: Date.now() - started,
    };
  });

  app.get('/api/config', async (): Promise<PublicConfig> => ({
    appVersion: APP_VERSION,
    emailConfigured: ctx.mailer.configured,
    emailVerificationRequired: ctx.config.REQUIRE_EMAIL_VERIFICATION && ctx.mailer.configured,
    smsConfigured: false,
    oauth: { google: false },
    captcha: { provider: ctx.config.captchaConfigured ? 'turnstile' : null, siteKey: ctx.config.TURNSTILE_SITE_KEY ?? null },
    turnConfigured: ctx.config.turnConfigured,
    gifConfigured: ctx.config.gifConfigured,
    pushConfigured: ctx.config.pushConfigured,
    vapidPublicKey: ctx.config.VAPID_PUBLIC_KEY ?? null,
    storage: ctx.storage.driver,
    maxUploadBytes: ctx.config.maxUploadBytes,
    e2ee: false,
    isProduction: ctx.config.isProd,
  }));

  // ── Calls ──
  app.get('/api/calls', auth, async (req) => listCalls(ctx, req.auth!.userId));
  app.get('/api/calls/active', auth, async (req) => ({ call: await activeCall(ctx, req.auth!.userId) }));
  app.get('/api/calls/ice-servers', auth, async (req) => iceServers(ctx, req.auth!.userId));
  app.post('/api/calls', auth, async (req) => {
    const input = parse(startCallSchema, req.body);
    return startCall(ctx, req.auth!, input.conversationId, input.video);
  });
  app.post('/api/calls/:id/:action', auth, async (req) => {
    const action = (req.params as { action: string }).action;
    if (action !== 'accept' && action !== 'reject' && action !== 'end') throw errors.notFound();
    return answerCall(ctx, req.auth!, uuidParam(req.params), action);
  });

  // ── Notifications ──
  app.get('/api/notifications', auth, async (req): Promise<{ items: NotificationDto[]; unread: number }> => {
    const rows = await ctx.db
      .select()
      .from(notifications)
      .where(eq(notifications.userId, req.auth!.userId))
      .orderBy(desc(notifications.createdAt))
      .limit(100);
    const [unread] = await ctx.db
      .select({ n: sql<number>`count(*)::int` })
      .from(notifications)
      .where(and(eq(notifications.userId, req.auth!.userId), isNull(notifications.readAt)));
    const actors = await loadUserSummaries(ctx, req.auth!.userId, rows.map((r) => r.actorId).filter((x): x is string => Boolean(x)));
    return {
      unread: unread?.n ?? 0,
      items: rows.map((r) => ({
        id: r.id,
        type: r.type as NotificationDto['type'],
        title: r.title,
        body: r.body,
        conversationId: r.conversationId,
        messageId: r.messageId,
        actor: r.actorId ? (actors.get(r.actorId) ?? null) : null,
        readAt: r.readAt?.toISOString() ?? null,
        createdAt: r.createdAt.toISOString(),
      })),
    };
  });

  app.post('/api/notifications/read', auth, async (req) => {
    const { ids } = parse(z.object({ ids: z.array(z.uuid()).max(200).optional() }), req.body ?? {});
    await markNotificationsRead(ctx, req.auth!.userId, ids);
    return { ok: true };
  });

  app.delete('/api/notifications', auth, async (req) => {
    await ctx.db.delete(notifications).where(eq(notifications.userId, req.auth!.userId));
    return { ok: true };
  });

  // ── Web push ──
  app.post('/api/push/subscribe', auth, async (req) => {
    if (!ctx.push.configured) throw errors.notConfigured('Push notifications');
    const sub = parse(pushSubscriptionSchema, req.body);
    await ctx.db
      .insert(pushSubscriptions)
      .values({ userId: req.auth!.userId, sessionId: req.auth!.sessionId, endpoint: sub.endpoint, p256dh: sub.keys.p256dh, auth: sub.keys.auth })
      .onConflictDoUpdate({
        target: pushSubscriptions.endpoint,
        set: { userId: req.auth!.userId, sessionId: req.auth!.sessionId, p256dh: sub.keys.p256dh, auth: sub.keys.auth },
      });
    return { ok: true };
  });

  app.post('/api/push/unsubscribe', auth, async (req) => {
    const { endpoint } = parse(z.object({ endpoint: z.url() }), req.body);
    await ctx.db.delete(pushSubscriptions).where(and(eq(pushSubscriptions.endpoint, endpoint), eq(pushSubscriptions.userId, req.auth!.userId)));
    return { ok: true };
  });

  // ── Folders ──
  const folderDto = (f: typeof chatFolders.$inferSelect): FolderDto => ({
    id: f.id,
    name: f.name,
    emoji: f.emoji,
    includeTypes: f.includeTypes,
    includeIds: f.includeIds,
    excludeIds: f.excludeIds,
    unreadOnly: f.unreadOnly,
    excludeMuted: f.excludeMuted,
    excludeArchived: f.excludeArchived,
    position: f.position,
  });

  app.get('/api/folders', auth, async (req) => {
    const rows = await ctx.db.select().from(chatFolders).where(eq(chatFolders.userId, req.auth!.userId)).orderBy(asc(chatFolders.position));
    return rows.map(folderDto);
  });

  app.post('/api/folders', auth, async (req) => {
    const input = parse(folderSchema, req.body);
    const existing = await ctx.db.select({ id: chatFolders.id }).from(chatFolders).where(eq(chatFolders.userId, req.auth!.userId));
    if (existing.length >= 20) throw errors.badRequest('too_many_folders', 'You can have up to 20 folders');
    const [row] = await ctx.db
      .insert(chatFolders)
      .values({ ...input, emoji: input.emoji ?? null, userId: req.auth!.userId, position: existing.length })
      .returning();
    return folderDto(row!);
  });

  app.put('/api/folders/:id', auth, async (req) => {
    const input = parse(folderSchema, req.body);
    const [row] = await ctx.db
      .update(chatFolders)
      .set({ ...input, emoji: input.emoji ?? null })
      .where(and(eq(chatFolders.id, uuidParam(req.params)), eq(chatFolders.userId, req.auth!.userId)))
      .returning();
    if (!row) throw errors.notFound();
    return folderDto(row);
  });

  app.post('/api/folders/order', auth, async (req) => {
    const { ids } = parse(z.object({ ids: z.array(z.uuid()).max(20) }), req.body);
    await ctx.db.transaction(async (tx) => {
      for (const [i, id] of ids.entries()) {
        await tx.update(chatFolders).set({ position: i }).where(and(eq(chatFolders.id, id), eq(chatFolders.userId, req.auth!.userId)));
      }
    });
    return { ok: true };
  });

  app.delete('/api/folders/:id', auth, async (req) => {
    await ctx.db.delete(chatFolders).where(and(eq(chatFolders.id, uuidParam(req.params)), eq(chatFolders.userId, req.auth!.userId)));
    return { ok: true };
  });

  // ── Stickers ──
  app.get('/api/stickers', auth, async (req): Promise<{ sets: StickerSetDto[]; favorites: string[] }> => {
    const sets = await ctx.db.select().from(stickerSets).orderBy(asc(stickerSets.createdAt));
    const items = sets.length
      ? await ctx.db.select().from(stickers).where(inArray(stickers.setId, sets.map((s) => s.id))).orderBy(asc(stickers.position))
      : [];
    const favs = await ctx.db
      .select({ id: favoriteStickers.stickerId })
      .from(favoriteStickers)
      .where(eq(favoriteStickers.userId, req.auth!.userId))
      .orderBy(desc(favoriteStickers.addedAt));
    return {
      sets: sets.map((s) => ({
        id: s.id,
        name: s.name,
        title: s.title,
        isDemo: s.isDemo,
        stickers: items.filter((i) => i.setId === s.id).map(stickerDto),
      })),
      favorites: favs.map((f) => f.id),
    };
  });

  app.post('/api/stickers/:id/favorite', auth, async (req) => {
    const id = uuidParam(req.params);
    const [s] = await ctx.db.select({ id: stickers.id }).from(stickers).where(eq(stickers.id, id));
    if (!s) throw errors.notFound();
    await ctx.db.insert(favoriteStickers).values({ userId: req.auth!.userId, stickerId: id }).onConflictDoNothing();
    return { ok: true };
  });

  app.delete('/api/stickers/:id/favorite', auth, async (req) => {
    await ctx.db.delete(favoriteStickers).where(and(eq(favoriteStickers.userId, req.auth!.userId), eq(favoriteStickers.stickerId, uuidParam(req.params))));
    return { ok: true };
  });

  // ── GIF search (server-side proxy: the API key never reaches the browser) ──
  app.get('/api/gifs', auth, async (req): Promise<{ items: GifDto[] }> => {
    if (!ctx.config.gifConfigured) throw errors.notConfigured('GIF search');
    await enforce(ctx.limiter, `gif:${req.auth!.userId}`, 60, 60);
    const q = String((req.query as { q?: string }).q ?? '').trim().slice(0, 100);
    const key = ctx.config.GIF_API_KEY!;
    if (ctx.config.GIF_PROVIDER === 'tenor') {
      const url = new URL(q ? 'https://tenor.googleapis.com/v2/search' : 'https://tenor.googleapis.com/v2/featured');
      url.search = new URLSearchParams({ key, q, limit: '24', media_filter: 'gif,tinygif', contentfilter: 'medium', client_key: 'pulsegram' }).toString();
      const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
      if (!res.ok) throw errors.badRequest('gif_provider_error', 'GIF provider request failed');
      const json = (await res.json()) as { results?: Array<{ content_description?: string; media_formats?: Record<string, { url: string; dims: [number, number] }> }> };
      return {
        items: (json.results ?? []).flatMap((r) => {
          const g = r.media_formats?.gif;
          const t = r.media_formats?.tinygif ?? g;
          return g && t ? [{ url: g.url, previewUrl: t.url, width: g.dims[0], height: g.dims[1], title: r.content_description }] : [];
        }),
      };
    }
    const url = new URL(q ? 'https://api.giphy.com/v1/gifs/search' : 'https://api.giphy.com/v1/gifs/trending');
    url.search = new URLSearchParams({ api_key: key, q, limit: '24', rating: 'pg-13' }).toString();
    const res = await fetch(url, { signal: AbortSignal.timeout(8000) });
    if (!res.ok) throw errors.badRequest('gif_provider_error', 'GIF provider request failed');
    const json = (await res.json()) as { data?: Array<{ title?: string; images?: Record<string, { url: string; width: string; height: string }> }> };
    return {
      items: (json.data ?? []).flatMap((d) => {
        const g = d.images?.original;
        const p = d.images?.fixed_width ?? g;
        return g && p ? [{ url: g.url, previewUrl: p.url, width: Number(g.width), height: Number(g.height), title: d.title }] : [];
      }),
    };
  });
}
