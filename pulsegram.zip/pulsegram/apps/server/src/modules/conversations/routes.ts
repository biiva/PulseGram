import { and, asc, eq } from 'drizzle-orm';
import type { FastifyInstance } from 'fastify';
import { z } from 'zod';
import {
  addMembersSchema,
  CHANNEL_CATEGORIES,
  createChannelSchema,
  createGroupSchema,
  createInviteSchema,
  deleteMessagesSchema,
  editMessageSchema,
  forwardSchema,
  historyQuerySchema,
  memberRoleUpdateSchema,
  reactionSchema,
  readSchema,
  sendMessageSchema,
  updateConversationSchema,
  updateMembershipSchema,
} from '@pulsegram/shared';
import type { AppContext } from '../../context';
import { errors } from '../../lib/errors';
import { parse, uuidParam } from '../../lib/http';
import { requireAuth } from '../auth/session';
import { messagePins, messages } from '../../db/schema';
import { toMessageDtos } from '../messages/serialize';
import { requireReadable } from './access';
import { readSingleUpload } from '../files/routes';
import { storeUpload } from '../files/service';
import {
  deleteMessages,
  editMessage,
  forwardMessages,
  getHistory,
  markRead,
  messageReadBy,
  recordViews,
  sendMessage,
  setPinned,
  toggleReaction,
  visibleTo,
} from '../messages/service';
import {
  addMembers,
  auditLog,
  clearHistory,
  changeRole,
  createChannel,
  createGroup,
  createInvite,
  deleteConversation,
  explorePublic,
  getConversation,
  joinByInvite,
  joinPublic,
  kickMember,
  leaveConversation,
  listConversations,
  listInvites,
  listMembers,
  openDirect,
  previewInvite,
  revokeInvite,
  setConversationAvatar,
  transferOwnership,
  updateConversation,
  updateMembership,
} from './service';

export async function registerConversationRoutes(app: FastifyInstance, ctx: AppContext) {
  const auth = { preHandler: requireAuth(ctx) };
  const A = (req: { auth: import('../auth/session').AuthState | null }) => req.auth!;

  app.get('/api/conversations', auth, async (req) => listConversations(ctx, A(req).userId));

  app.post('/api/conversations/direct', auth, async (req) => {
    const { userId } = parse(z.object({ userId: z.uuid() }), req.body);
    return openDirect(ctx, A(req), userId);
  });

  app.post('/api/conversations/group', auth, async (req, reply) => {
    const dto = await createGroup(ctx, A(req), parse(createGroupSchema, req.body));
    reply.code(201);
    return dto;
  });

  app.post('/api/conversations/channel', auth, async (req, reply) => {
    const dto = await createChannel(ctx, A(req), parse(createChannelSchema, req.body));
    reply.code(201);
    return dto;
  });

  app.get('/api/conversations/:id', auth, async (req) => getConversation(ctx, A(req).userId, uuidParam(req.params)));

  app.patch('/api/conversations/:id', auth, async (req) =>
    updateConversation(ctx, A(req), uuidParam(req.params), parse(updateConversationSchema, req.body)),
  );

  app.put('/api/conversations/:id/avatar', auth, async (req) => {
    const id = uuidParam(req.params);
    const { buf, filename } = await readSingleUpload(req, 15 * 1024 * 1024);
    const f = await storeUpload(ctx, A(req).userId, buf, filename, { purpose: 'avatar' });
    return setConversationAvatar(ctx, A(req), id, f.id);
  });

  app.delete('/api/conversations/:id/avatar', auth, async (req) => setConversationAvatar(ctx, A(req), uuidParam(req.params), null));

  app.patch('/api/conversations/:id/me', auth, async (req) =>
    updateMembership(ctx, A(req), uuidParam(req.params), parse(updateMembershipSchema, req.body)),
  );

  app.post('/api/conversations/:id/clear', auth, async (req) => clearHistory(ctx, A(req), uuidParam(req.params)));
  app.post('/api/conversations/:id/leave', auth, async (req) => leaveConversation(ctx, A(req), uuidParam(req.params)));
  app.delete('/api/conversations/:id', auth, async (req) => deleteConversation(ctx, A(req), uuidParam(req.params)));
  app.post('/api/conversations/:id/join', auth, async (req) => joinPublic(ctx, A(req), uuidParam(req.params)));

  app.post('/api/conversations/:id/read', auth, async (req) => {
    const { seq } = parse(readSchema, req.body);
    return markRead(ctx, A(req), uuidParam(req.params), seq);
  });

  app.post('/api/conversations/:id/views', auth, async (req) => {
    const { messageIds } = parse(z.object({ messageIds: z.array(z.uuid()).min(1).max(100) }), req.body);
    return recordViews(ctx, A(req).userId, uuidParam(req.params), messageIds);
  });

  // ── Members ──
  app.get('/api/conversations/:id/members', auth, async (req) => {
    const q = parse(
      z.object({ q: z.string().max(64).default(''), limit: z.coerce.number().int().min(1).max(200).default(100), offset: z.coerce.number().int().min(0).default(0) }),
      req.query,
    );
    return listMembers(ctx, A(req).userId, uuidParam(req.params), q.q, q.limit, q.offset);
  });

  app.post('/api/conversations/:id/members', auth, async (req) =>
    addMembers(ctx, A(req), uuidParam(req.params), parse(addMembersSchema, req.body).userIds),
  );

  app.delete('/api/conversations/:id/members/:userId', auth, async (req) =>
    kickMember(ctx, A(req), uuidParam(req.params), uuidParam(req.params, 'userId')),
  );

  app.patch('/api/conversations/:id/members/:userId', auth, async (req) =>
    changeRole(ctx, A(req), uuidParam(req.params), uuidParam(req.params, 'userId'), parse(memberRoleUpdateSchema, req.body).role),
  );

  app.post('/api/conversations/:id/transfer-ownership', auth, async (req) => {
    const b = parse(z.object({ userId: z.uuid(), password: z.string().min(1).max(256) }), req.body);
    return transferOwnership(ctx, A(req), uuidParam(req.params), b.userId, b.password);
  });

  app.get('/api/conversations/:id/audit-log', auth, async (req) => auditLog(ctx, A(req), uuidParam(req.params)));

  // ── Invites ──
  app.get('/api/conversations/:id/invites', auth, async (req) => listInvites(ctx, A(req), uuidParam(req.params)));
  app.post('/api/conversations/:id/invites', auth, async (req) =>
    createInvite(ctx, A(req), uuidParam(req.params), parse(createInviteSchema, req.body ?? {})),
  );
  app.delete('/api/conversations/:id/invites/:inviteId', auth, async (req) =>
    revokeInvite(ctx, A(req), uuidParam(req.params), uuidParam(req.params, 'inviteId')),
  );
  app.get('/api/invites/:token', auth, async (req) => {
    const token = String((req.params as { token: string }).token);
    if (!/^[A-Za-z0-9_-]{8,64}$/.test(token)) throw errors.notFound('invite_invalid', 'This invite link is invalid');
    return previewInvite(ctx, A(req).userId, token);
  });
  app.post('/api/invites/:token/join', auth, async (req) => {
    const token = String((req.params as { token: string }).token);
    if (!/^[A-Za-z0-9_-]{8,64}$/.test(token)) throw errors.notFound('invite_invalid', 'This invite link is invalid');
    return joinByInvite(ctx, A(req), token);
  });

  app.get('/api/explore', auth, async (req) => {
    const q = parse(
      z.object({
        q: z.string().max(100).default(''),
        type: z.enum(['channel', 'group']).optional(),
        category: z.enum(CHANNEL_CATEGORIES).optional(),
      }),
      req.query,
    );
    return explorePublic(ctx, A(req).userId, q.q, q.type, q.category);
  });

  // ── Messages ──
  app.get('/api/conversations/:id/messages', auth, async (req) => {
    const q = parse(historyQuerySchema, req.query);
    return getHistory(ctx, A(req).userId, uuidParam(req.params), q);
  });

  app.post('/api/conversations/:id/messages', auth, async (req, reply) => {
    const input = parse(sendMessageSchema, req.body);
    const r = await sendMessage(ctx, A(req), uuidParam(req.params), input);
    reply.code(r.duplicate ? 200 : 201);
    return r.message;
  });

  app.patch('/api/messages/:id', auth, async (req) => editMessage(ctx, A(req), uuidParam(req.params), parse(editMessageSchema, req.body).text));

  app.delete('/api/messages/:id', auth, async (req) => {
    const forEveryone = (req.query as { forEveryone?: string }).forEveryone === 'true';
    return deleteMessages(ctx, A(req), [uuidParam(req.params)], forEveryone);
  });

  app.post('/api/messages/delete', auth, async (req) => {
    const input = parse(deleteMessagesSchema, req.body);
    return deleteMessages(ctx, A(req), input.messageIds, input.forEveryone);
  });

  app.post('/api/messages/:id/reactions', auth, async (req) =>
    toggleReaction(ctx, A(req), uuidParam(req.params), parse(reactionSchema, req.body).emoji),
  );

  app.post('/api/messages/:id/pin', auth, async (req) => setPinned(ctx, A(req), uuidParam(req.params), true));
  app.delete('/api/messages/:id/pin', auth, async (req) => setPinned(ctx, A(req), uuidParam(req.params), false));

  app.get('/api/conversations/:id/pins', auth, async (req) => {
    const id = uuidParam(req.params);
    const { conv, member } = await requireReadable(ctx.db, A(req).userId, id);
    const rows = await ctx.db
      .select({ m: messages })
      .from(messagePins)
      .innerJoin(messages, eq(messages.id, messagePins.messageId))
      .where(and(eq(messagePins.conversationId, conv.id), visibleTo(A(req).userId, member)))
      .orderBy(asc(messagePins.pinnedAt));
    return toMessageDtos(ctx.db, rows.map((r) => r.m), A(req).userId, { channel: conv.type === 'channel' });
  });

  app.get('/api/messages/:id/read-by', auth, async (req) => messageReadBy(ctx, A(req).userId, uuidParam(req.params)));

  app.post('/api/messages/forward', auth, async (req) => forwardMessages(ctx, A(req), parse(forwardSchema, req.body)));

}
