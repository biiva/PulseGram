import { and, asc, eq, inArray, ne, sql } from 'drizzle-orm';
import type { ChannelCategory, ConversationDto, ConversationMembership, MessageDto } from '@pulsegram/shared';
import type { AppContext } from '../../context';
import type { DbOrTx } from '../../db/client';
import { conversationMembers, conversations, messagePins, messages } from '../../db/schema';
import { fileUrl, loadUserSummaries } from '../users/serialize';
import { toMessageDtos } from '../messages/serialize';
import { settingsOf, type ConversationRow, type MemberRow } from './access';

export function uuidArray(ids: string[]) {
  return sql`${sql.param(ids)}::uuid[]`;
}

export function membershipDto(m: MemberRow): ConversationMembership {
  return {
    role: m.role,
    isPinned: m.isPinned,
    pinnedAt: m.pinnedAt?.toISOString() ?? null,
    isArchived: m.isArchived,
    mutedUntil: m.mutedUntil?.toISOString() ?? null,
    draft: m.draft,
    draftUpdatedAt: m.draftUpdatedAt?.toISOString() ?? null,
    lastReadSeq: m.lastReadSeq,
    markedUnread: m.markedUnread,
    joinedAt: m.joinedAt.toISOString(),
  };
}

/**
 * Builds ConversationDtos for one viewer. Batched: a fixed number of queries for any number of chats.
 * Pass `memberRows` when already loaded; non-members (public preview) get `me: null`.
 */
export async function toConversationDtos(
  ctx: Pick<AppContext, 'db' | 'presence'>,
  viewerId: string,
  convs: ConversationRow[],
  memberRows?: Map<string, MemberRow>,
  db: DbOrTx = ctx.db,
): Promise<ConversationDto[]> {
  if (convs.length === 0) return [];
  const ids = convs.map((c) => c.id);

  const members =
    memberRows ??
    new Map(
      (
        await db
          .select()
          .from(conversationMembers)
          .where(and(eq(conversationMembers.userId, viewerId), inArray(conversationMembers.conversationId, ids)))
      ).map((m) => [m.conversationId, m]),
    );

  const directIds = convs.filter((c) => c.type === 'direct').map((c) => c.id);
  const peerReadIds = convs.filter((c) => c.type === 'direct' || c.type === 'group').map((c) => c.id);

  const [lastIdsRes, unreadRes, peers, peerRead, pins, linked] = await Promise.all([
    db.execute<{ conversation_id: string; id: string }>(sql`
      SELECT c.id AS conversation_id, lm.id
      FROM unnest(${uuidArray(ids)}) AS c(id)
      LEFT JOIN conversation_members cm ON cm.conversation_id = c.id AND cm.user_id = ${viewerId}
      JOIN LATERAL (
        SELECT m.id FROM messages m
        WHERE m.conversation_id = c.id
          AND m.deleted_at IS NULL
          AND m.seq > coalesce(cm.hidden_before_seq, 0)
          AND NOT EXISTS (SELECT 1 FROM hidden_messages h WHERE h.message_id = m.id AND h.user_id = ${viewerId})
        ORDER BY m.seq DESC
        LIMIT 1
      ) lm ON true`),
    db.execute<{ conversation_id: string; unread: number; mentions: number }>(sql`
      SELECT cm.conversation_id,
        count(m.id)::int AS unread,
        count(m.id) FILTER (WHERE m.mentions @> jsonb_build_array(${viewerId}::text))::int AS mentions
      FROM conversation_members cm
      JOIN messages m ON m.conversation_id = cm.conversation_id
        AND m.seq > greatest(cm.last_read_seq, cm.hidden_before_seq)
        AND m.deleted_at IS NULL
        AND m.type <> 'system'
        AND m.sender_id IS DISTINCT FROM cm.user_id
      WHERE cm.user_id = ${viewerId} AND cm.conversation_id = ANY(${uuidArray(ids)})
      GROUP BY cm.conversation_id`),
    directIds.length
      ? db
          .select({ conversationId: conversationMembers.conversationId, userId: conversationMembers.userId })
          .from(conversationMembers)
          .where(and(inArray(conversationMembers.conversationId, directIds), ne(conversationMembers.userId, viewerId)))
      : Promise.resolve([]),
    peerReadIds.length
      ? db
          .select({ conversationId: conversationMembers.conversationId, seq: sql<number>`max(${conversationMembers.lastReadSeq})` })
          .from(conversationMembers)
          .where(and(inArray(conversationMembers.conversationId, peerReadIds), ne(conversationMembers.userId, viewerId)))
          .groupBy(conversationMembers.conversationId)
      : Promise.resolve([]),
    db
      .select({ conversationId: messagePins.conversationId, messageId: messagePins.messageId })
      .from(messagePins)
      .innerJoin(messages, eq(messages.id, messagePins.messageId))
      .where(and(inArray(messagePins.conversationId, ids), sql`${messages.deletedAt} IS NULL`))
      .orderBy(asc(messagePins.pinnedAt)),
    db
      .select({ id: conversations.id, discussionGroupId: conversations.discussionGroupId })
      .from(conversations)
      .where(and(inArray(conversations.discussionGroupId, ids), sql`${conversations.deletedAt} IS NULL`)),
  ]);

  const lastIds = lastIdsRes.rows.map((r) => r.id);
  const lastRows = lastIds.length ? await db.select().from(messages).where(inArray(messages.id, lastIds)) : [];
  const channelIds = new Set(convs.filter((c) => c.type === 'channel').map((c) => c.id));
  const lastDtos = await toMessageDtos(db, lastRows, viewerId);
  // Channel view counts are not needed for the chat list preview.
  const lastBy = new Map<string, MessageDto>(lastDtos.map((m) => [m.conversationId, { ...m, views: channelIds.has(m.conversationId) ? m.views : null }]));
  const unreadBy = new Map(unreadRes.rows.map((r) => [r.conversation_id, r]));
  const peerBy = new Map(peers.map((p) => [p.conversationId, p.userId]));
  const peerReadBy = new Map(peerRead.map((p) => [p.conversationId, Number(p.seq ?? 0)]));
  const pinsBy = new Map<string, string[]>();
  for (const p of pins) pinsBy.set(p.conversationId, [...(pinsBy.get(p.conversationId) ?? []), p.messageId]);
  const linkedBy = new Map(linked.map((l) => [l.discussionGroupId!, l.id]));

  const peerSummaries = await loadUserSummaries(ctx, viewerId, peerBy.values(), db);

  return convs.map((c) => {
    const me = members.get(c.id) ?? null;
    const last = lastBy.get(c.id) ?? null;
    const peer = c.type === 'direct' ? (peerSummaries.get(peerBy.get(c.id) ?? '') ?? null) : null;
    const unread = unreadBy.get(c.id);
    const isSaved = c.type === 'saved';
    return {
      id: c.id,
      type: c.type,
      title: c.type === 'direct' ? (peer?.displayName ?? 'Deleted account') : c.title,
      description: c.description,
      username: c.type === 'direct' ? (peer?.username ?? null) : c.username,
      avatarUrl: c.type === 'direct' ? (peer?.avatarUrl ?? null) : fileUrl(c.avatarFileId),
      isPublic: c.isPublic,
      category: (c.category as ChannelCategory | null) ?? null,
      settings: settingsOf(c),
      memberCount: c.memberCount,
      createdAt: c.createdAt.toISOString(),
      lastMessage: last,
      lastActivityAt: (me?.draftUpdatedAt && me.draft && me.draftUpdatedAt > c.lastActivityAt ? me.draftUpdatedAt : c.lastActivityAt).toISOString(),
      unreadCount: isSaved ? 0 : (unread?.unread ?? 0),
      unreadMentions: unread?.mentions ?? 0,
      peerReadSeq: isSaved ? Number.MAX_SAFE_INTEGER : (peerReadBy.get(c.id) ?? 0),
      peer,
      me: me ? membershipDto(me) : null,
      pinnedMessageIds: pinsBy.get(c.id) ?? [],
      discussionGroupId: c.discussionGroupId,
      linkedChannelId: linkedBy.get(c.id) ?? null,
      isDemo: c.isDemo,
    };
  });
}

export async function conversationDtoFor(
  ctx: Pick<AppContext, 'db' | 'presence'>,
  viewerId: string,
  conv: ConversationRow,
  member?: MemberRow | null,
): Promise<ConversationDto> {
  const map = member ? new Map([[conv.id, member]]) : member === null ? new Map<string, MemberRow>() : undefined;
  const [dto] = await toConversationDtos(ctx, viewerId, [conv], map);
  return dto!;
}
