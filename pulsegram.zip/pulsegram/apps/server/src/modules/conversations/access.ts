import { and, eq, isNull, or } from 'drizzle-orm';
import { DEFAULT_GROUP_SETTINGS, type GroupSettings, type PermissionContext } from '@pulsegram/shared';
import type { DbOrTx } from '../../db/client';
import { blockedUsers, conversationMembers, conversations } from '../../db/schema';
import { errors } from '../../lib/errors';

export type ConversationRow = typeof conversations.$inferSelect;
export type MemberRow = typeof conversationMembers.$inferSelect;

export interface Access {
  conv: ConversationRow;
  member: MemberRow;
}

export function settingsOf(conv: ConversationRow): GroupSettings {
  return { ...DEFAULT_GROUP_SETTINGS, ...conv.settings };
}

export function permCtx(conv: ConversationRow, member: MemberRow): PermissionContext {
  return { type: conv.type, role: member.role, settings: settingsOf(conv) };
}

export async function loadConversation(db: DbOrTx, conversationId: string): Promise<ConversationRow | null> {
  const [conv] = await db
    .select()
    .from(conversations)
    .where(and(eq(conversations.id, conversationId), isNull(conversations.deletedAt)))
    .limit(1);
  return conv ?? null;
}

/**
 * Loads the conversation and the caller's membership. Non-members get a 404 (not 403) so the
 * API never confirms the existence of private conversations (IDOR protection).
 */
export async function requireMember(db: DbOrTx, userId: string, conversationId: string): Promise<Access> {
  const [row] = await db
    .select({ conv: conversations, member: conversationMembers })
    .from(conversationMembers)
    .innerJoin(conversations, eq(conversations.id, conversationMembers.conversationId))
    .where(
      and(eq(conversationMembers.conversationId, conversationId), eq(conversationMembers.userId, userId), isNull(conversations.deletedAt)),
    )
    .limit(1);
  if (!row) throw errors.notFound('conversation_not_found', 'Chat not found');
  return row;
}

/** For public groups/channels a non-member may read (preview) without joining. */
export async function requireReadable(
  db: DbOrTx,
  userId: string,
  conversationId: string,
): Promise<{ conv: ConversationRow; member: MemberRow | null }> {
  const [row] = await db
    .select({ conv: conversations, member: conversationMembers })
    .from(conversations)
    .leftJoin(
      conversationMembers,
      and(eq(conversationMembers.conversationId, conversations.id), eq(conversationMembers.userId, userId)),
    )
    .where(and(eq(conversations.id, conversationId), isNull(conversations.deletedAt)))
    .limit(1);
  if (!row) throw errors.notFound('conversation_not_found', 'Chat not found');
  if (!row.member && !(row.conv.isPublic && (row.conv.type === 'group' || row.conv.type === 'channel'))) {
    throw errors.notFound('conversation_not_found', 'Chat not found');
  }
  return row;
}

export async function directPeerId(db: DbOrTx, conversationId: string, userId: string): Promise<string | null> {
  const rows = await db
    .select({ userId: conversationMembers.userId })
    .from(conversationMembers)
    .where(eq(conversationMembers.conversationId, conversationId));
  return rows.find((r) => r.userId !== userId)?.userId ?? null;
}

export async function isBlockedEitherWay(db: DbOrTx, a: string, b: string): Promise<boolean> {
  const [row] = await db
    .select({ x: blockedUsers.blockerId })
    .from(blockedUsers)
    .where(
      or(
        and(eq(blockedUsers.blockerId, a), eq(blockedUsers.blockedId, b)),
        and(eq(blockedUsers.blockerId, b), eq(blockedUsers.blockedId, a)),
      ),
    )
    .limit(1);
  return Boolean(row);
}

export async function memberIds(db: DbOrTx, conversationId: string): Promise<string[]> {
  const rows = await db
    .select({ userId: conversationMembers.userId })
    .from(conversationMembers)
    .where(eq(conversationMembers.conversationId, conversationId));
  return rows.map((r) => r.userId);
}

export function directKey(a: string, b: string) {
  return a < b ? `dm:${a}:${b}` : `dm:${b}:${a}`;
}
