import { and, asc, desc, eq, gt, inArray, isNull, ne, or, sql } from 'drizzle-orm';
import {
  can,
  DEFAULT_CHANNEL_SETTINGS,
  DEFAULT_GROUP_SETTINGS,
  LIMITS,
  type AuditLogDto,
  type ConversationDto,
  type CreateChannelInput,
  type CreateGroupInput,
  type InviteDto,
  type InvitePreview,
  type MemberDto,
  type MemberRole,
  type UpdateConversationInput,
  type UpdateMembershipInput,
} from '@pulsegram/shared';
import type { AppContext } from '../../context';
import { auditLogs, conversationMembers, conversations, groupInvites, messages, users } from '../../db/schema';
import { randomToken } from '../../lib/crypto';
import { AppError, errors } from '../../lib/errors';
import { enforce } from '../../lib/rateLimit';
import { audit } from '../audit/service';
import type { AuthState } from '../auth/session';
import { postSystemMessage, requireVerifiedIfNeeded } from '../messages/service';
import { notify } from '../notifications/service';
import { audienceAllows, loadRelations, loadUserSummaries } from '../users/serialize';
import { getPrivacyMap } from '../users/preferences';
import {
  directKey,
  isBlockedEitherWay,
  loadConversation,
  memberIds,
  permCtx,
  requireMember,
  requireReadable,
  settingsOf,
  type ConversationRow,
  type MemberRow,
} from './access';
import { conversationDtoFor, membershipDto, toConversationDtos } from './serialize';

export async function listConversations(ctx: AppContext, userId: string): Promise<ConversationDto[]> {
  const rows = await ctx.db
    .select({ conv: conversations, member: conversationMembers })
    .from(conversationMembers)
    .innerJoin(conversations, eq(conversations.id, conversationMembers.conversationId))
    .where(and(eq(conversationMembers.userId, userId), eq(conversationMembers.hidden, false), isNull(conversations.deletedAt)))
    .orderBy(desc(conversations.lastActivityAt))
    .limit(2000);
  const dtos = await toConversationDtos(
    ctx,
    userId,
    rows.map((r) => r.conv),
    new Map(rows.map((r) => [r.conv.id, r.member])),
  );
  // Empty direct chats someone else opened with you stay hidden until a first message arrives.
  return dtos.filter((d) => !(d.type === 'direct' && !d.lastMessage && d.me && rows.find((r) => r.conv.id === d.id)?.conv.createdById !== userId));
}

export async function getConversation(ctx: AppContext, userId: string, conversationId: string): Promise<ConversationDto> {
  const { conv, member } = await requireReadable(ctx.db, userId, conversationId);
  return conversationDtoFor(ctx, userId, conv, member);
}

async function emitNewConversation(ctx: AppContext, conv: ConversationRow, userIds: string[]) {
  for (const uid of userIds) {
    const [member] = await ctx.db
      .select()
      .from(conversationMembers)
      .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, uid)));
    if (!member) continue;
    const dto = await conversationDtoFor(ctx, uid, conv, member);
    await ctx.hub.emit([uid], 'conversation:new', { conversation: dto });
  }
}

async function emitPatch(ctx: AppContext, conv: ConversationRow) {
  const [fresh] = await ctx.db.select().from(conversations).where(eq(conversations.id, conv.id));
  if (!fresh) return;
  await ctx.hub.emit(await memberIds(ctx.db, conv.id), 'conversation:updated', {
    conversationId: conv.id,
    patch: {
      title: fresh.title,
      description: fresh.description,
      username: fresh.username,
      avatarUrl: fresh.avatarFileId ? `/api/files/${fresh.avatarFileId}` : null,
      isPublic: fresh.isPublic,
      category: (fresh.category as ConversationDto['category']) ?? null,
      settings: settingsOf(fresh),
      memberCount: fresh.memberCount,
      discussionGroupId: fresh.discussionGroupId,
    },
  });
}

export async function openDirect(ctx: AppContext, auth: AuthState, peerId: string): Promise<ConversationDto> {
  requireVerifiedIfNeeded(ctx, auth);
  if (peerId === auth.userId) {
    const [saved] = await ctx.db.select().from(conversations).where(eq(conversations.directKey, `saved:${auth.userId}`));
    if (!saved) throw errors.notFound();
    return getConversation(ctx, auth.userId, saved.id);
  }
  const [peer] = await ctx.db.select().from(users).where(and(eq(users.id, peerId), isNull(users.deletedAt)));
  if (!peer) throw errors.notFound('user_not_found', 'User not found');
  const key = directKey(auth.userId, peerId);
  const [existing] = await ctx.db.select().from(conversations).where(eq(conversations.directKey, key));
  if (existing) {
    await ctx.db
      .update(conversationMembers)
      .set({ hidden: false })
      .where(and(eq(conversationMembers.conversationId, existing.id), eq(conversationMembers.userId, auth.userId)));
    return getConversation(ctx, auth.userId, existing.id);
  }
  if (await isBlockedEitherWay(ctx.db, auth.userId, peerId)) throw errors.forbidden('blocked', 'You cannot message this user');
  await enforce(ctx.limiter, `newdm:${auth.userId}`, ctx.config.isTest ? 10_000 : 30, 3600);
  const conv = await ctx.db.transaction(async (tx) => {
    const [c] = await tx
      .insert(conversations)
      .values({ type: 'direct', directKey: key, settings: DEFAULT_GROUP_SETTINGS, memberCount: 2, createdById: auth.userId })
      .onConflictDoNothing()
      .returning();
    if (!c) {
      const [again] = await tx.select().from(conversations).where(eq(conversations.directKey, key));
      return again!;
    }
    await tx.insert(conversationMembers).values([
      { conversationId: c.id, userId: auth.userId, role: 'member' },
      { conversationId: c.id, userId: peerId, role: 'member' },
    ]);
    return c;
  });
  return getConversation(ctx, auth.userId, conv.id);
}

async function canInviteUsers(ctx: AppContext, inviterId: string, ids: string[]): Promise<string[]> {
  if (ids.length === 0) return [];
  const [privacy, rel, existing] = await Promise.all([
    getPrivacyMap(ctx.db, ids),
    loadRelations(ctx.db, inviterId, ids),
    ctx.db.select({ id: users.id }).from(users).where(and(inArray(users.id, ids), isNull(users.deletedAt))),
  ]);
  const exist = new Set(existing.map((e) => e.id));
  return ids.filter(
    (id) =>
      exist.has(id) &&
      !rel.blockedEither.has(id) &&
      audienceAllows(privacy.get(id)!.groupInvites, rel.viewerIsContactOf.has(id)),
  );
}

async function assertUsernameFree(ctx: AppContext, username: string | null | undefined, exceptConvId?: string) {
  if (!username) return;
  const lower = username.toLowerCase();
  const [u] = await ctx.db.select({ id: users.id }).from(users).where(sql`lower(${users.username}) = ${lower}`).limit(1);
  const [c] = await ctx.db
    .select({ id: conversations.id })
    .from(conversations)
    .where(and(sql`lower(${conversations.username}) = ${lower}`, exceptConvId ? ne(conversations.id, exceptConvId) : undefined))
    .limit(1);
  if (u || c) throw new AppError(409, 'username_taken', 'This public link is already taken', [{ path: 'username', code: 'username_taken' }]);
}

export async function createGroup(ctx: AppContext, auth: AuthState, input: CreateGroupInput): Promise<ConversationDto> {
  requireVerifiedIfNeeded(ctx, auth);
  await enforce(ctx.limiter, `newgroup:${auth.userId}`, ctx.config.isTest ? 10_000 : 20, 3600);
  if (input.isPublic && !input.username) throw errors.badRequest('username_required', 'Public groups need a public link');
  await assertUsernameFree(ctx, input.isPublic ? input.username : null);
  const wanted = [...new Set(input.memberIds.filter((id) => id !== auth.userId))];
  const allowed = await canInviteUsers(ctx, auth.userId, wanted);
  const conv = await ctx.db.transaction(async (tx) => {
    const [c] = await tx
      .insert(conversations)
      .values({
        type: 'group',
        title: input.title,
        description: input.description ?? '',
        isPublic: input.isPublic,
        username: input.isPublic ? input.username : null,
        settings: DEFAULT_GROUP_SETTINGS,
        memberCount: 1 + allowed.length,
        createdById: auth.userId,
      })
      .returning();
    await tx.insert(conversationMembers).values([
      { conversationId: c!.id, userId: auth.userId, role: 'owner' as const },
      ...allowed.map((uid) => ({ conversationId: c!.id, userId: uid, role: 'member' as const, invitedById: auth.userId })),
    ]);
    return c!;
  });
  await audit(ctx, { actorId: auth.userId, conversationId: conv.id, action: 'group.created' });
  await postSystemMessage(ctx, conv, auth.userId, { action: 'group_created', title: conv.title });
  await emitNewConversation(ctx, conv, allowed);
  await notify(
    ctx,
    allowed.map((uid) => ({
      userId: uid,
      type: 'invite',
      title: `${auth.user.displayName} added you to ${conv.title}`,
      conversationId: conv.id,
      actorId: auth.userId,
    })),
  );
  const dto = await getConversation(ctx, auth.userId, conv.id);
  return { ...dto, ...(wanted.length !== allowed.length ? { skippedMembers: wanted.length - allowed.length } : {}) };
}

export async function createChannel(ctx: AppContext, auth: AuthState, input: CreateChannelInput): Promise<ConversationDto> {
  requireVerifiedIfNeeded(ctx, auth);
  await enforce(ctx.limiter, `newchannel:${auth.userId}`, ctx.config.isTest ? 10_000 : 10, 3600);
  if (input.isPublic && !input.username) throw errors.badRequest('username_required', 'Public channels need a public link');
  await assertUsernameFree(ctx, input.isPublic ? input.username : null);
  const conv = await ctx.db.transaction(async (tx) => {
    const [c] = await tx
      .insert(conversations)
      .values({
        type: 'channel',
        title: input.title,
        description: input.description ?? '',
        isPublic: input.isPublic,
        username: input.isPublic ? input.username : null,
        category: input.category,
        settings: DEFAULT_CHANNEL_SETTINGS,
        memberCount: 1,
        createdById: auth.userId,
      })
      .returning();
    await tx.insert(conversationMembers).values({ conversationId: c!.id, userId: auth.userId, role: 'owner' });
    return c!;
  });
  await audit(ctx, { actorId: auth.userId, conversationId: conv.id, action: 'channel.created' });
  await postSystemMessage(ctx, conv, auth.userId, { action: 'channel_created', title: conv.title });
  return getConversation(ctx, auth.userId, conv.id);
}

export async function updateConversation(ctx: AppContext, auth: AuthState, conversationId: string, input: UpdateConversationInput) {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  if (!can.editInfo(permCtx(conv, member))) throw errors.forbidden('cannot_edit', 'Only admins can change chat info');
  const patch: Partial<typeof conversations.$inferInsert> = { updatedAt: new Date() };
  const changes: string[] = [];
  if (input.title !== undefined && input.title !== conv.title) {
    patch.title = input.title;
    changes.push('title');
  }
  if (input.description !== undefined) patch.description = input.description;
  if (input.category !== undefined && conv.type === 'channel') patch.category = input.category;
  const nextPublic = input.isPublic ?? conv.isPublic;
  const nextUsername = input.username !== undefined ? input.username : conv.username;
  if (nextPublic && !nextUsername) throw errors.badRequest('username_required', 'Public chats need a public link');
  if (input.username !== undefined && input.username !== conv.username) await assertUsernameFree(ctx, input.username, conv.id);
  patch.isPublic = nextPublic;
  patch.username = nextPublic ? nextUsername : null;
  if (input.settings) {
    // Only the owner may change permissions that affect other admins' powers; admins may tweak member rights.
    patch.settings = { ...settingsOf(conv), ...input.settings };
    changes.push('settings');
  }
  if (input.discussionGroupId !== undefined) {
    if (conv.type !== 'channel') throw errors.badRequest('not_channel');
    if (input.discussionGroupId) {
      const g = await requireMember(ctx.db, auth.userId, input.discussionGroupId);
      if (g.conv.type !== 'group' || !can.editInfo(permCtx(g.conv, g.member))) {
        throw errors.forbidden('cannot_link', 'You must be an admin of the discussion group');
      }
    }
    patch.discussionGroupId = input.discussionGroupId;
  }
  await ctx.db.update(conversations).set(patch).where(eq(conversations.id, conv.id));
  await audit(ctx, { actorId: auth.userId, conversationId: conv.id, action: 'chat.updated', data: { fields: Object.keys(input) } });
  if (changes.includes('title')) await postSystemMessage(ctx, conv, auth.userId, { action: 'title_changed', title: input.title });
  await emitPatch(ctx, conv);
  return getConversation(ctx, auth.userId, conv.id);
}

export async function setConversationAvatar(ctx: AppContext, auth: AuthState, conversationId: string, fileId: string | null) {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  if (!can.editInfo(permCtx(conv, member))) throw errors.forbidden('cannot_edit');
  await ctx.db.update(conversations).set({ avatarFileId: fileId, updatedAt: new Date() }).where(eq(conversations.id, conv.id));
  await audit(ctx, { actorId: auth.userId, conversationId: conv.id, action: 'chat.avatar_changed' });
  await emitPatch(ctx, conv);
  return getConversation(ctx, auth.userId, conv.id);
}

export async function updateMembership(ctx: AppContext, auth: AuthState, conversationId: string, input: UpdateMembershipInput) {
  const { conv } = await requireMember(ctx.db, auth.userId, conversationId);
  const patch: Partial<MemberRow> = {};
  if (input.isPinned !== undefined) {
    patch.isPinned = input.isPinned;
    patch.pinnedAt = input.isPinned ? new Date() : null;
  }
  if (input.isArchived !== undefined) patch.isArchived = input.isArchived;
  if (input.mutedUntil !== undefined) {
    patch.mutedUntil = input.mutedUntil === null ? null : input.mutedUntil === 'forever' ? new Date('9999-12-31T00:00:00Z') : new Date(input.mutedUntil);
  }
  if (input.draft !== undefined) {
    patch.draft = input.draft;
    patch.draftUpdatedAt = input.draft ? new Date() : null;
  }
  if (input.markUnread !== undefined) patch.markedUnread = input.markUnread;
  const [m] = await ctx.db
    .update(conversationMembers)
    .set(patch)
    .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, auth.userId)))
    .returning();
  const me = membershipDto(m!);
  await ctx.hub.emit([auth.userId], 'conversation:membership', { conversationId: conv.id, me }, { exceptSessionId: auth.sessionId });
  return me;
}

export async function listMembers(ctx: AppContext, userId: string, conversationId: string, q: string, limit: number, offset: number) {
  const { conv, member } = await requireReadable(ctx.db, userId, conversationId);
  // Channel subscriber lists are visible to admins only.
  if (conv.type === 'channel' && (!member || !can.editInfo(permCtx(conv, member)))) {
    const admins = await ctx.db
      .select({ m: conversationMembers })
      .from(conversationMembers)
      .where(and(eq(conversationMembers.conversationId, conv.id), inArray(conversationMembers.role, ['owner', 'admin'])));
    const sums = await loadUserSummaries(ctx, userId, admins.map((a) => a.m.userId));
    return {
      items: admins.flatMap((a) => (sums.get(a.m.userId) ? [{ user: sums.get(a.m.userId)!, role: a.m.role, joinedAt: a.m.joinedAt.toISOString() }] : [])),
      hasMore: false,
    };
  }
  const rows = await ctx.db
    .select({ m: conversationMembers })
    .from(conversationMembers)
    .innerJoin(users, eq(users.id, conversationMembers.userId))
    .where(
      and(
        eq(conversationMembers.conversationId, conv.id),
        q ? or(sql`lower(${users.username}) LIKE ${'%' + q.toLowerCase() + '%'}`, sql`lower(${users.displayName}) LIKE ${'%' + q.toLowerCase() + '%'}`) : undefined,
      ),
    )
    .orderBy(sql`CASE ${conversationMembers.role} WHEN 'owner' THEN 0 WHEN 'admin' THEN 1 WHEN 'moderator' THEN 2 ELSE 3 END`, asc(users.displayName))
    .limit(limit + 1)
    .offset(offset);
  const sums = await loadUserSummaries(ctx, userId, rows.map((r) => r.m.userId));
  const items: MemberDto[] = rows.slice(0, limit).flatMap((r) => {
    const u = sums.get(r.m.userId);
    return u ? [{ user: u, role: r.m.role, joinedAt: r.m.joinedAt.toISOString() }] : [];
  });
  return { items, hasMore: rows.length > limit };
}

async function addMemberRows(ctx: AppContext, conv: ConversationRow, userIds: string[], inviterId: string | null, role: MemberRole = 'member') {
  if (userIds.length === 0) return [];
  const settings = settingsOf(conv);
  const hiddenBefore = conv.type === 'group' && !settings.historyVisibleToNewMembers ? conv.lastMessageSeq : 0;
  const added = await ctx.db.transaction(async (tx) => {
    const rows = await tx
      .insert(conversationMembers)
      .values(
        userIds.map((uid) => ({
          conversationId: conv.id,
          userId: uid,
          role,
          invitedById: inviterId,
          hiddenBeforeSeq: hiddenBefore,
          lastReadSeq: conv.type === 'channel' ? conv.lastMessageSeq : hiddenBefore,
        })),
      )
      .onConflictDoNothing()
      .returning({ userId: conversationMembers.userId });
    if (rows.length) {
      const [{ n } = { n: 0 }] = await tx
        .select({ n: sql<number>`count(*)::int` })
        .from(conversationMembers)
        .where(eq(conversationMembers.conversationId, conv.id));
      if (n > LIMITS.maxGroupMembers && conv.type === 'group') throw errors.forbidden('group_full', 'This group is full');
      await tx.update(conversations).set({ memberCount: n }).where(eq(conversations.id, conv.id));
    }
    return rows.map((r) => r.userId);
  });
  return added;
}

export async function addMembers(ctx: AppContext, auth: AuthState, conversationId: string, userIds: string[]) {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  if (!can.invite(permCtx(conv, member))) throw errors.forbidden('cannot_invite', 'You cannot add members here');
  await enforce(ctx.limiter, `addmembers:${auth.userId}`, ctx.config.isTest ? 10_000 : 200, 3600);
  const allowed = await canInviteUsers(ctx, auth.userId, [...new Set(userIds)].filter((id) => id !== auth.userId));
  const added = await addMemberRows(ctx, conv, allowed, auth.userId);
  if (added.length) {
    const [fresh] = await ctx.db.select().from(conversations).where(eq(conversations.id, conv.id));
    await audit(ctx, { actorId: auth.userId, conversationId: conv.id, action: 'member.added', data: { userIds: added } });
    if (conv.type === 'group') await postSystemMessage(ctx, fresh!, auth.userId, { action: 'members_added', userIds: added });
    await emitNewConversation(ctx, fresh!, added);
    await emitPatch(ctx, fresh!);
    await notify(
      ctx,
      added.map((uid) => ({
        userId: uid,
        type: 'invite',
        title: `${auth.user.displayName} added you to ${conv.title}`,
        conversationId: conv.id,
        actorId: auth.userId,
      })),
    );
  }
  return { added, skipped: userIds.length - added.length };
}

async function removeMember(ctx: AppContext, conv: ConversationRow, userId: string, reason: 'left' | 'kicked') {
  await ctx.db.transaction(async (tx) => {
    await tx.delete(conversationMembers).where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, userId)));
    const [{ n } = { n: 0 }] = await tx
      .select({ n: sql<number>`count(*)::int` })
      .from(conversationMembers)
      .where(eq(conversationMembers.conversationId, conv.id));
    await tx.update(conversations).set({ memberCount: n }).where(eq(conversations.id, conv.id));
  });
  await ctx.hub.emit([userId], 'conversation:removed', { conversationId: conv.id, reason });
}

export async function kickMember(ctx: AppContext, auth: AuthState, conversationId: string, targetId: string) {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  if (targetId === auth.userId) throw errors.badRequest('use_leave', 'Use leave instead');
  const [target] = await ctx.db
    .select()
    .from(conversationMembers)
    .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, targetId)));
  if (!target) throw errors.notFound('member_not_found', 'Member not found');
  if (!can.kick(permCtx(conv, member), target.role)) throw errors.forbidden('cannot_kick', 'You cannot remove this member');
  await removeMember(ctx, conv, targetId, 'kicked');
  // Kicked members can not rejoin through old invite links they may have; admins can re-add them explicitly.
  await audit(ctx, { actorId: auth.userId, conversationId: conv.id, targetUserId: targetId, action: 'member.removed' });
  const [fresh] = await ctx.db.select().from(conversations).where(eq(conversations.id, conv.id));
  if (conv.type === 'group') await postSystemMessage(ctx, fresh!, auth.userId, { action: 'member_removed', userId: targetId });
  await emitPatch(ctx, fresh!);
  await notify(ctx, [{ userId: targetId, type: 'admin', title: `You were removed from ${conv.title}`, actorId: auth.userId }]);
  return { ok: true };
}

export async function leaveConversation(ctx: AppContext, auth: AuthState, conversationId: string) {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  if (conv.type === 'saved') throw errors.badRequest('cannot_leave_saved');
  if (conv.type === 'direct') {
    // "Delete chat for me": hide it and clear history for this user only.
    await ctx.db
      .update(conversationMembers)
      .set({ hidden: true, hiddenBeforeSeq: conv.lastMessageSeq, lastReadSeq: conv.lastMessageSeq, isPinned: false, draft: '' })
      .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, auth.userId)));
    await ctx.hub.emit([auth.userId], 'conversation:removed', { conversationId: conv.id, reason: 'left' });
    return { ok: true };
  }
  if (member.role === 'owner') {
    // Pass ownership to the most senior remaining member, or delete an empty chat.
    const [heir] = await ctx.db
      .select()
      .from(conversationMembers)
      .where(and(eq(conversationMembers.conversationId, conv.id), ne(conversationMembers.userId, auth.userId)))
      .orderBy(sql`CASE ${conversationMembers.role} WHEN 'admin' THEN 0 WHEN 'moderator' THEN 1 ELSE 2 END`, asc(conversationMembers.joinedAt))
      .limit(1);
    if (!heir) {
      await ctx.db.update(conversations).set({ deletedAt: new Date() }).where(eq(conversations.id, conv.id));
      await audit(ctx, { actorId: auth.userId, conversationId: conv.id, action: 'chat.deleted', data: { reason: 'last_member_left' } });
      await ctx.hub.emit([auth.userId], 'conversation:removed', { conversationId: conv.id, reason: 'deleted' });
      return { ok: true };
    }
    await ctx.db
      .update(conversationMembers)
      .set({ role: 'owner' })
      .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, heir.userId)));
    await audit(ctx, { actorId: auth.userId, conversationId: conv.id, targetUserId: heir.userId, action: 'owner.transferred', data: { reason: 'owner_left' } });
  }
  await removeMember(ctx, conv, auth.userId, 'left');
  await audit(ctx, { actorId: auth.userId, conversationId: conv.id, action: 'member.left' });
  const [fresh] = await ctx.db.select().from(conversations).where(eq(conversations.id, conv.id));
  if (conv.type === 'group') await postSystemMessage(ctx, fresh!, auth.userId, { action: 'member_left' });
  await emitPatch(ctx, fresh!);
  return { ok: true };
}

/** "Clear history for me" — hides all current messages for this user only. */
export async function clearHistory(ctx: AppContext, auth: AuthState, conversationId: string) {
  const { conv } = await requireMember(ctx.db, auth.userId, conversationId);
  const [m] = await ctx.db
    .update(conversationMembers)
    .set({ hiddenBeforeSeq: conv.lastMessageSeq, lastReadSeq: sql`greatest(${conversationMembers.lastReadSeq}, ${conv.lastMessageSeq})` })
    .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, auth.userId)))
    .returning();
  await ctx.hub.emit([auth.userId], 'conversation:membership', { conversationId: conv.id, me: membershipDto(m!) });
  return getConversation(ctx, auth.userId, conv.id);
}

export async function deleteConversation(ctx: AppContext, auth: AuthState, conversationId: string) {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  if (!can.deleteConversation(permCtx(conv, member))) throw errors.forbidden('cannot_delete_chat', 'Only the owner can delete this chat');
  const ids = await memberIds(ctx.db, conv.id);
  await ctx.db.update(conversations).set({ deletedAt: new Date(), username: null }).where(eq(conversations.id, conv.id));
  await ctx.db.update(groupInvites).set({ revokedAt: new Date() }).where(and(eq(groupInvites.conversationId, conv.id), isNull(groupInvites.revokedAt)));
  await audit(ctx, { actorId: auth.userId, conversationId: conv.id, action: 'chat.deleted' });
  await ctx.hub.emit(ids, 'conversation:removed', { conversationId: conv.id, reason: 'deleted' });
  return { ok: true };
}

export async function changeRole(ctx: AppContext, auth: AuthState, conversationId: string, targetId: string, role: Exclude<MemberRole, 'owner'>) {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  const [target] = await ctx.db
    .select()
    .from(conversationMembers)
    .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, targetId)));
  if (!target) throw errors.notFound('member_not_found', 'Member not found');
  if (targetId === auth.userId) throw errors.forbidden('cannot_change_own_role', 'You cannot change your own role');
  if (!can.changeRole(permCtx(conv, member), target.role, role)) throw errors.forbidden('cannot_change_role', 'You cannot assign this role');
  if (conv.type === 'channel' && role === 'moderator') throw errors.badRequest('invalid_role', 'Channels have admins and subscribers only');
  await ctx.db
    .update(conversationMembers)
    .set({ role })
    .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, targetId)));
  await audit(ctx, { actorId: auth.userId, conversationId: conv.id, targetUserId: targetId, action: 'member.role_changed', data: { from: target.role, to: role } });
  const [updated] = await ctx.db
    .select()
    .from(conversationMembers)
    .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, targetId)));
  await ctx.hub.emit([targetId], 'conversation:membership', { conversationId: conv.id, me: membershipDto(updated!) });
  await notify(ctx, [
    { userId: targetId, type: 'admin', title: `Your role in ${conv.title || 'a chat'} is now ${role}`, conversationId: conv.id, actorId: auth.userId },
  ]);
  return { ok: true };
}

export async function transferOwnership(ctx: AppContext, auth: AuthState, conversationId: string, targetId: string, password: string) {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  if (!can.transferOwnership(permCtx(conv, member))) throw errors.forbidden('not_owner', 'Only the owner can transfer ownership');
  const { verifyPassword } = await import('../../lib/crypto');
  if (!(await verifyPassword(auth.user.passwordHash, password))) throw errors.badRequest('invalid_password', 'Password is incorrect');
  const [target] = await ctx.db
    .select()
    .from(conversationMembers)
    .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, targetId)));
  if (!target || targetId === auth.userId) throw errors.notFound('member_not_found', 'Member not found');
  await ctx.db.transaction(async (tx) => {
    await tx
      .update(conversationMembers)
      .set({ role: 'owner' })
      .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, targetId)));
    await tx
      .update(conversationMembers)
      .set({ role: 'admin' })
      .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, auth.userId)));
  });
  await audit(ctx, { actorId: auth.userId, conversationId: conv.id, targetUserId: targetId, action: 'owner.transferred' });
  for (const uid of [targetId, auth.userId]) {
    const [m] = await ctx.db
      .select()
      .from(conversationMembers)
      .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, uid)));
    await ctx.hub.emit([uid], 'conversation:membership', { conversationId: conv.id, me: membershipDto(m!) });
  }
  await postSystemMessage(ctx, conv, auth.userId, { action: 'owner_transferred', userId: targetId });
  return { ok: true };
}

// ── Invites ───────────────────────────────────────────────────────────────

function inviteDto(ctx: AppContext, i: typeof groupInvites.$inferSelect): InviteDto {
  return {
    id: i.id,
    token: i.token,
    url: `${ctx.config.APP_URL}/join/${i.token}`,
    createdAt: i.createdAt.toISOString(),
    expiresAt: i.expiresAt?.toISOString() ?? null,
    maxUses: i.maxUses,
    uses: i.uses,
    revokedAt: i.revokedAt?.toISOString() ?? null,
    createdBy: i.createdById ?? '',
  };
}

export async function listInvites(ctx: AppContext, auth: AuthState, conversationId: string) {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  if (!can.manageInviteLinks(permCtx(conv, member))) throw errors.forbidden();
  const rows = await ctx.db.select().from(groupInvites).where(eq(groupInvites.conversationId, conv.id)).orderBy(desc(groupInvites.createdAt)).limit(100);
  return rows.map((r) => inviteDto(ctx, r));
}

export async function createInvite(ctx: AppContext, auth: AuthState, conversationId: string, input: { expiresInHours: number | null; maxUses: number | null }) {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  if (!can.manageInviteLinks(permCtx(conv, member))) throw errors.forbidden('cannot_manage_invites', 'Only admins can create invite links');
  const [row] = await ctx.db
    .insert(groupInvites)
    .values({
      conversationId: conv.id,
      token: randomToken(12),
      createdById: auth.userId,
      expiresAt: input.expiresInHours ? new Date(Date.now() + input.expiresInHours * 3600_000) : null,
      maxUses: input.maxUses,
    })
    .returning();
  await audit(ctx, { actorId: auth.userId, conversationId: conv.id, action: 'invite.created', data: { inviteId: row!.id } });
  return inviteDto(ctx, row!);
}

export async function revokeInvite(ctx: AppContext, auth: AuthState, conversationId: string, inviteId: string) {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  if (!can.manageInviteLinks(permCtx(conv, member))) throw errors.forbidden();
  const [row] = await ctx.db
    .update(groupInvites)
    .set({ revokedAt: new Date() })
    .where(and(eq(groupInvites.id, inviteId), eq(groupInvites.conversationId, conv.id), isNull(groupInvites.revokedAt)))
    .returning();
  if (!row) throw errors.notFound();
  await audit(ctx, { actorId: auth.userId, conversationId: conv.id, action: 'invite.revoked', data: { inviteId } });
  return inviteDto(ctx, row);
}

async function validInvite(ctx: AppContext, token: string) {
  const [inv] = await ctx.db
    .select({ inv: groupInvites, conv: conversations })
    .from(groupInvites)
    .innerJoin(conversations, eq(conversations.id, groupInvites.conversationId))
    .where(and(eq(groupInvites.token, token), isNull(groupInvites.revokedAt), isNull(conversations.deletedAt)))
    .limit(1);
  if (!inv) throw errors.notFound('invite_invalid', 'This invite link is invalid or was revoked');
  if (inv.inv.expiresAt && inv.inv.expiresAt < new Date()) throw errors.notFound('invite_expired', 'This invite link has expired');
  if (inv.inv.maxUses !== null && inv.inv.uses >= inv.inv.maxUses) throw errors.notFound('invite_exhausted', 'This invite link has reached its limit');
  return inv;
}

export async function previewInvite(ctx: AppContext, userId: string, token: string): Promise<InvitePreview> {
  await enforce(ctx.limiter, `invprev:${userId}`, 60, 60);
  const { conv } = await validInvite(ctx, token);
  const [m] = await ctx.db
    .select()
    .from(conversationMembers)
    .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, userId)));
  return {
    conversation: {
      id: conv.id,
      type: conv.type,
      title: conv.title,
      description: conv.description,
      avatarUrl: conv.avatarFileId ? `/api/files/${conv.avatarFileId}` : null,
      memberCount: conv.memberCount,
    },
    alreadyMember: Boolean(m),
  };
}

async function joinConv(ctx: AppContext, auth: AuthState, conv: ConversationRow, via: string) {
  const added = await addMemberRows(ctx, conv, [auth.userId], null);
  if (added.length === 0) return getConversation(ctx, auth.userId, conv.id);
  const [fresh] = await ctx.db.select().from(conversations).where(eq(conversations.id, conv.id));
  await audit(ctx, { actorId: auth.userId, conversationId: conv.id, action: 'member.joined', data: { via } });
  if (conv.type === 'group') await postSystemMessage(ctx, fresh!, auth.userId, { action: 'member_joined' });
  await emitPatch(ctx, fresh!);
  const dto = await getConversation(ctx, auth.userId, conv.id);
  await ctx.hub.emit([auth.userId], 'conversation:new', { conversation: dto }, { exceptSessionId: auth.sessionId });
  return dto;
}

export async function joinByInvite(ctx: AppContext, auth: AuthState, token: string) {
  requireVerifiedIfNeeded(ctx, auth);
  await enforce(ctx.limiter, `join:${auth.userId}`, ctx.config.isTest ? 10_000 : 30, 3600);
  const { inv, conv } = await validInvite(ctx, token);
  const [already] = await ctx.db
    .select()
    .from(conversationMembers)
    .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, auth.userId)));
  if (already) return getConversation(ctx, auth.userId, conv.id);
  // Atomically consume one use (guards maxUses under concurrency).
  const [bumped] = await ctx.db
    .update(groupInvites)
    .set({ uses: sql`${groupInvites.uses} + 1` })
    .where(and(eq(groupInvites.id, inv.id), or(isNull(groupInvites.maxUses), gt(groupInvites.maxUses, groupInvites.uses))))
    .returning();
  if (!bumped) throw errors.notFound('invite_exhausted', 'This invite link has reached its limit');
  return joinConv(ctx, auth, conv, 'invite');
}

export async function joinPublic(ctx: AppContext, auth: AuthState, conversationId: string) {
  requireVerifiedIfNeeded(ctx, auth);
  await enforce(ctx.limiter, `join:${auth.userId}`, ctx.config.isTest ? 10_000 : 30, 3600);
  const conv = await loadConversation(ctx.db, conversationId);
  if (!conv || !conv.isPublic || (conv.type !== 'group' && conv.type !== 'channel')) throw errors.notFound('conversation_not_found', 'Chat not found');
  return joinConv(ctx, auth, conv, 'public');
}

export async function auditLog(ctx: AppContext, auth: AuthState, conversationId: string): Promise<AuditLogDto[]> {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  if (!can.viewAuditLog(permCtx(conv, member))) throw errors.forbidden();
  const rows = await ctx.db
    .select()
    .from(auditLogs)
    .where(eq(auditLogs.conversationId, conv.id))
    .orderBy(desc(auditLogs.createdAt))
    .limit(200);
  const ids = rows.flatMap((r) => [r.actorId, r.targetUserId]).filter((x): x is string => Boolean(x));
  const sums = await loadUserSummaries(ctx, auth.userId, ids);
  return rows.map((r) => ({
    id: r.id,
    action: r.action,
    actor: r.actorId ? (sums.get(r.actorId) ?? null) : null,
    targetUser: r.targetUserId ? (sums.get(r.targetUserId) ?? null) : null,
    data: r.data,
    createdAt: r.createdAt.toISOString(),
  }));
}

export async function explorePublic(ctx: AppContext, userId: string, q: string, type: 'channel' | 'group' | undefined, category: string | undefined) {
  const term = q.trim().toLowerCase();
  const rows = await ctx.db
    .select()
    .from(conversations)
    .where(
      and(
        eq(conversations.isPublic, true),
        isNull(conversations.deletedAt),
        type ? eq(conversations.type, type) : inArray(conversations.type, ['channel', 'group']),
        category ? eq(conversations.category, category) : undefined,
        term
          ? or(
              sql`lower(${conversations.title}) LIKE ${'%' + term + '%'}`,
              sql`lower(${conversations.username}) LIKE ${'%' + term + '%'}`,
              sql`lower(${conversations.description}) LIKE ${'%' + term + '%'}`,
            )
          : undefined,
      ),
    )
    .orderBy(desc(conversations.memberCount), desc(conversations.lastActivityAt))
    .limit(50);
  return toConversationDtos(ctx, userId, rows);
}

export async function sharedMediaStats(ctx: AppContext, userId: string, conversationId: string) {
  const { conv } = await requireMember(ctx.db, userId, conversationId);
  const [row] = await ctx.db
    .select({ n: sql<number>`count(*)::int` })
    .from(messages)
    .where(and(eq(messages.conversationId, conv.id), isNull(messages.deletedAt)));
  return { messages: row?.n ?? 0 };
}
