import { and, eq, inArray, isNull, sql } from 'drizzle-orm';
import type { NotificationDto } from '@pulsegram/shared';
import type { AppContext } from '../../context';
import { conversationMembers, notifications, pushSubscriptions } from '../../db/schema';
import { getNotificationPrefsMap } from '../users/preferences';
import { loadUserSummaries } from '../users/serialize';

export type NotificationType = NotificationDto['type'];

export interface NewNotification {
  userId: string;
  type: NotificationType;
  title: string;
  body?: string;
  conversationId?: string | null;
  messageId?: string | null;
  actorId?: string | null;
}

export async function notify(ctx: AppContext, items: NewNotification[]): Promise<void> {
  if (items.length === 0) return;
  const rows = await ctx.db
    .insert(notifications)
    .values(
      items.map((n) => ({
        userId: n.userId,
        type: n.type,
        title: n.title.slice(0, 200),
        body: (n.body ?? '').slice(0, 300),
        conversationId: n.conversationId ?? null,
        messageId: n.messageId ?? null,
        actorId: n.actorId ?? null,
      })),
    )
    .returning();
  const actorIds = [...new Set(rows.map((r) => r.actorId).filter((x): x is string => Boolean(x)))];
  for (const r of rows) {
    const actors = actorIds.length ? await loadUserSummaries(ctx, r.userId, actorIds) : new Map();
    const dto: NotificationDto = {
      id: r.id,
      type: r.type as NotificationType,
      title: r.title,
      body: r.body,
      conversationId: r.conversationId,
      messageId: r.messageId,
      actor: r.actorId ? (actors.get(r.actorId) ?? null) : null,
      readAt: null,
      createdAt: r.createdAt.toISOString(),
    };
    await ctx.hub.emit([r.userId], 'notification:new', { notification: dto });
  }
}

/**
 * Web push for users with no open connection. Honors per-user notification preferences,
 * per-chat mute and the "pause all" setting. Only users with a registered push subscription
 * are considered, so this stays cheap for large channels.
 */
export async function pushNewMessage(
  ctx: AppContext,
  conv: { id: string; type: 'direct' | 'group' | 'channel' | 'saved'; title: string },
  senderId: string,
  senderName: string,
  text: string,
  mentionedIds: string[],
) {
  if (!ctx.push.configured || conv.type === 'saved') return;
  const candidates = await ctx.db
    .selectDistinct({ userId: conversationMembers.userId, mutedUntil: conversationMembers.mutedUntil })
    .from(conversationMembers)
    .innerJoin(pushSubscriptions, eq(pushSubscriptions.userId, conversationMembers.userId))
    .where(and(eq(conversationMembers.conversationId, conv.id), sql`${conversationMembers.userId} <> ${senderId}`));
  if (candidates.length === 0) return;
  const online = await ctx.presence.onlineSet(candidates.map((c) => c.userId));
  const prefs = await getNotificationPrefsMap(ctx.db, candidates.map((c) => c.userId));
  const now = new Date();
  for (const c of candidates) {
    if (online.has(c.userId)) continue;
    const p = prefs.get(c.userId);
    if (!p || !p.enabled) continue;
    if (p.pausedUntil && new Date(p.pausedUntil) > now) continue;
    const mentioned = mentionedIds.includes(c.userId);
    if (c.mutedUntil && c.mutedUntil > now && !mentioned) continue;
    const typeAllowed = conv.type === 'direct' ? p.direct : conv.type === 'group' ? p.groups || (mentioned && p.mentions) : p.channels;
    if (!typeAllowed) continue;
    const title = conv.type === 'direct' ? senderName : conv.title;
    const body = p.preview && p.lockScreenPreview ? (conv.type === 'group' ? `${senderName}: ${text}` : text) : 'New message';
    await ctx.push.sendToUser(c.userId, { title, body: body.slice(0, 180), tag: conv.id, url: `/chat/${conv.id}` });
  }
}

export async function markNotificationsRead(ctx: AppContext, userId: string, ids?: string[], conversationId?: string) {
  await ctx.db
    .update(notifications)
    .set({ readAt: new Date() })
    .where(
      and(
        eq(notifications.userId, userId),
        isNull(notifications.readAt),
        ids ? inArray(notifications.id, ids) : undefined,
        conversationId ? eq(notifications.conversationId, conversationId) : undefined,
      ),
    );
}
