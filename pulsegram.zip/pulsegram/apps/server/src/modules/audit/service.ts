import type { AppContext } from '../../context';
import type { DbOrTx } from '../../db/client';
import { auditLogs } from '../../db/schema';

export interface AuditEntry {
  actorId: string | null;
  action: string;
  conversationId?: string | null;
  targetUserId?: string | null;
  data?: Record<string, unknown>;
  ip?: string | null;
}

/**
 * Records security and moderation events. Never pass passwords, tokens or message contents here.
 */
export async function audit(ctx: Pick<AppContext, 'db' | 'log'>, e: AuditEntry, db: DbOrTx = ctx.db): Promise<void> {
  try {
    await db.insert(auditLogs).values({
      actorId: e.actorId,
      action: e.action,
      conversationId: e.conversationId ?? null,
      targetUserId: e.targetUserId ?? null,
      data: e.data ?? {},
      ip: e.ip ?? null,
    });
  } catch (err) {
    ctx.log.error({ err, action: e.action }, 'failed to write audit log');
  }
}
