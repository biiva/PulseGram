import { asc, count, eq, inArray } from 'drizzle-orm';
import type { AttachmentDto, MessageDto, ReactionSummary, ReplyPreview, StickerDto } from '@pulsegram/shared';
import type { DbOrTx } from '../../db/client';
import { files, messageAttachments, messageReactions, messages, messageViews, stickers, users } from '../../db/schema';

export type MessageRow = typeof messages.$inferSelect;
export type FileRow = typeof files.$inferSelect;

export function attachmentDto(f: FileRow): AttachmentDto {
  return {
    id: f.id,
    kind: f.kind,
    mime: f.mime,
    size: f.size,
    name: f.name,
    url: `/api/files/${f.id}`,
    thumbUrl: f.thumbKey ? `/api/files/${f.id}/thumb` : null,
    width: f.width,
    height: f.height,
    durationMs: f.durationMs,
    waveform: f.waveform ?? null,
  };
}

export function stickerDto(s: typeof stickers.$inferSelect): StickerDto {
  return { id: s.id, setId: s.setId, emoji: s.emoji, url: s.assetPath, animated: s.animated };
}

export function summarizeReactions(
  rows: Array<{ emoji: string; userId: string; createdAt: Date }>,
  viewerId: string | null,
): ReactionSummary[] {
  const by = new Map<string, { count: number; mine: boolean; users: Array<{ id: string; at: number }>; first: number }>();
  for (const r of rows) {
    let e = by.get(r.emoji);
    if (!e) by.set(r.emoji, (e = { count: 0, mine: false, users: [], first: r.createdAt.getTime() }));
    e.count++;
    if (r.userId === viewerId) e.mine = true;
    e.users.push({ id: r.userId, at: r.createdAt.getTime() });
    e.first = Math.min(e.first, r.createdAt.getTime());
  }
  return [...by.entries()]
    .sort((a, b) => b[1].count - a[1].count || a[1].first - b[1].first)
    .map(([emoji, e]) => ({
      emoji,
      count: e.count,
      mine: e.mine,
      userIds: e.users
        .sort((a, b) => b.at - a.at)
        .slice(0, 3)
        .map((u) => u.id),
    }));
}

export function previewText(m: Pick<MessageRow, 'type' | 'text'>): string {
  return m.text.slice(0, 200);
}

/**
 * Batch-serializes message rows. One query per related table regardless of page size.
 * `viewerId` is only used for the `mine` flag on reactions (null → all false, for fan-out payloads).
 */
export async function toMessageDtos(
  db: DbOrTx,
  rows: MessageRow[],
  viewerId: string | null,
  opts: { channel?: boolean } = {},
): Promise<MessageDto[]> {
  if (rows.length === 0) return [];
  const ids = rows.map((r) => r.id);
  const replyIds = [...new Set(rows.map((r) => r.replyToId).filter((x): x is string => Boolean(x)))];
  const stickerIds = [...new Set(rows.map((r) => r.stickerId).filter((x): x is string => Boolean(x)))];

  const [att, reacts, replies, stk, views] = await Promise.all([
    db
      .select({ messageId: messageAttachments.messageId, file: files })
      .from(messageAttachments)
      .innerJoin(files, eq(files.id, messageAttachments.fileId))
      .where(inArray(messageAttachments.messageId, ids))
      .orderBy(asc(messageAttachments.position)),
    db
      .select({ messageId: messageReactions.messageId, emoji: messageReactions.emoji, userId: messageReactions.userId, createdAt: messageReactions.createdAt })
      .from(messageReactions)
      .where(inArray(messageReactions.messageId, ids)),
    replyIds.length
      ? db
          .select({ m: messages, senderName: users.displayName })
          .from(messages)
          .leftJoin(users, eq(users.id, messages.senderId))
          .where(inArray(messages.id, replyIds))
      : Promise.resolve([]),
    stickerIds.length ? db.select().from(stickers).where(inArray(stickers.id, stickerIds)) : Promise.resolve([]),
    opts.channel
      ? db
          .select({ messageId: messageViews.messageId, n: count() })
          .from(messageViews)
          .where(inArray(messageViews.messageId, ids))
          .groupBy(messageViews.messageId)
      : Promise.resolve([]),
  ]);

  const attBy = new Map<string, AttachmentDto[]>();
  for (const a of att) {
    const list = attBy.get(a.messageId) ?? [];
    list.push(attachmentDto(a.file));
    attBy.set(a.messageId, list);
  }
  const reactBy = new Map<string, Array<{ emoji: string; userId: string; createdAt: Date }>>();
  for (const r of reacts) {
    const list = reactBy.get(r.messageId) ?? [];
    list.push(r);
    reactBy.set(r.messageId, list);
  }
  const replyBy = new Map<string, ReplyPreview>();
  for (const r of replies) {
    replyBy.set(r.m.id, {
      id: r.m.id,
      seq: r.m.seq,
      senderId: r.m.senderId,
      senderName: r.senderName ?? '',
      text: r.m.deletedAt ? '' : previewText(r.m),
      type: r.m.type,
      deleted: Boolean(r.m.deletedAt),
    });
  }
  const stickerBy = new Map(stk.map((s) => [s.id, stickerDto(s)]));
  const viewsBy = new Map(views.map((v) => [v.messageId, Number(v.n)]));

  return rows.map((m) => toMessageDto(m, {
    attachments: attBy.get(m.id) ?? [],
    reactions: summarizeReactions(reactBy.get(m.id) ?? [], viewerId),
    replyTo: m.replyToId ? (replyBy.get(m.replyToId) ?? null) : null,
    sticker: m.stickerId ? (stickerBy.get(m.stickerId) ?? null) : null,
    views: opts.channel ? (viewsBy.get(m.id) ?? 0) : null,
  }));
}

export function toMessageDto(
  m: MessageRow,
  extra: Pick<MessageDto, 'attachments' | 'reactions' | 'replyTo' | 'sticker' | 'views'>,
): MessageDto {
  const deleted = Boolean(m.deletedAt);
  return {
    id: m.id,
    seq: m.seq,
    conversationId: m.conversationId,
    senderId: m.senderId,
    clientId: m.clientId,
    type: m.type,
    text: deleted ? '' : m.text,
    createdAt: m.createdAt.toISOString(),
    editedAt: m.editedAt?.toISOString() ?? null,
    deletedAt: m.deletedAt?.toISOString() ?? null,
    replyTo: deleted ? null : extra.replyTo,
    forward: deleted ? null : (m.forward ?? null),
    attachments: deleted ? [] : extra.attachments,
    sticker: deleted ? null : extra.sticker,
    gif: deleted ? null : (m.gif ?? null),
    reactions: deleted ? [] : extra.reactions,
    views: extra.views,
    system: m.system ?? null,
    mentions: m.mentions ?? [],
    signature: m.signature,
  };
}
