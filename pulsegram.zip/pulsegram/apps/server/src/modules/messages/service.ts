import { and, asc, desc, eq, gt, inArray, isNull, lt, lte, notExists, sql } from 'drizzle-orm';
import {
  can,
  EDIT_WINDOW_MS,
  extractLinks,
  extractMentions,
  LIMITS,
  sendMessageSchema,
  type MessageDto,
  type MessageType,
} from '@pulsegram/shared';
import type { z } from 'zod';
import type { AppContext } from '../../context';
import type { DbOrTx, Tx } from '../../db/client';
import {
  conversationMembers,
  conversations,
  files,
  hiddenMessages,
  messageAttachments,
  messagePins,
  messageReactions,
  messages,
  messageViews,
  stickers,
  users,
} from '../../db/schema';
import { AppError, errors, pgCode } from '../../lib/errors';
import { enforce } from '../../lib/rateLimit';
import type { AuthState } from '../auth/session';
import {
  isBlockedEitherWay,
  memberIds,
  permCtx,
  requireMember,
  requireReadable,
  type ConversationRow,
  type MemberRow,
} from '../conversations/access';
import { notify, pushNewMessage, markNotificationsRead } from '../notifications/service';
import { summarizeReactions, toMessageDtos, type MessageRow } from './serialize';

type SendInput = z.output<typeof sendMessageSchema>;

const GIF_HOSTS = [/^media\d*\.tenor\.com$/, /^media\d*\.giphy\.com$/, /^i\.giphy\.com$/, /^c\.tenor\.com$/];

/** Visible-to-viewer predicate for history queries. */
export function visibleTo(viewerId: string, member: MemberRow | null) {
  return and(
    isNull(messages.deletedAt),
    member ? gt(messages.seq, member.hiddenBeforeSeq) : undefined,
    notExists(
      sql`(SELECT 1 FROM ${hiddenMessages} WHERE ${hiddenMessages.messageId} = ${messages.id} AND ${hiddenMessages.userId} = ${viewerId})`,
    ),
  );
}

export function requireVerifiedIfNeeded(ctx: AppContext, auth: AuthState) {
  if (ctx.config.REQUIRE_EMAIL_VERIFICATION && ctx.mailer.configured && !auth.user.emailVerifiedAt) {
    throw errors.forbidden('email_unverified', 'Confirm your email address to start chatting');
  }
}

async function assertCanPost(ctx: AppContext, conv: ConversationRow, member: MemberRow, userId: string, media: boolean) {
  const pc = permCtx(conv, member);
  if (!can.sendMessage(pc)) throw errors.forbidden('cannot_send', 'You cannot send messages here');
  if (media && !can.sendMedia(pc)) throw errors.forbidden('cannot_send_media', 'Sending media is restricted in this chat');
  if (conv.type === 'direct') {
    const peer = (await memberIds(ctx.db, conv.id)).find((id) => id !== userId);
    if (!peer) throw errors.forbidden('peer_gone', 'This user is no longer available');
    if (await isBlockedEitherWay(ctx.db, userId, peer)) throw errors.forbidden('blocked', 'You cannot message this user');
    const [p] = await ctx.db.select({ deletedAt: users.deletedAt }).from(users).where(eq(users.id, peer));
    if (p?.deletedAt) throw errors.forbidden('peer_gone', 'This account was deleted');
  }
  const slow = pc.settings.slowModeSeconds;
  if (conv.type === 'group' && slow > 0 && !can.bypassSlowMode(pc) && member.lastPostAt) {
    const wait = member.lastPostAt.getTime() + slow * 1000 - Date.now();
    if (wait > 0) throw new AppError(429, 'slow_mode', 'Slow mode is on', { retryAfterSec: Math.ceil(wait / 1000) });
  }
}

/** Insert a message inside a transaction and bump conversation/member state. */
export async function insertMessage(
  tx: Tx,
  conv: ConversationRow,
  values: Omit<typeof messages.$inferInsert, 'conversationId' | 'seq'>,
  attachmentFileIds: string[] = [],
): Promise<MessageRow> {
  const [row] = await tx
    .insert(messages)
    .values({ ...values, conversationId: conv.id })
    .returning();
  if (attachmentFileIds.length) {
    await tx.insert(messageAttachments).values(attachmentFileIds.map((fileId, position) => ({ messageId: row!.id, fileId, position })));
  }
  await tx
    .update(conversations)
    .set({ lastMessageSeq: row!.seq, lastActivityAt: row!.createdAt, updatedAt: row!.createdAt })
    .where(eq(conversations.id, conv.id));
  // A new message brings a "deleted for me" direct chat back.
  await tx
    .update(conversationMembers)
    .set({ hidden: false })
    .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.hidden, true)));
  if (values.senderId) {
    await tx
      .update(conversationMembers)
      .set({ lastReadSeq: row!.seq, lastPostAt: row!.createdAt, markedUnread: false, draft: '', draftUpdatedAt: null })
      .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, values.senderId)));
  }
  return row!;
}

export async function broadcastNewMessage(ctx: AppContext, conv: ConversationRow, row: MessageRow): Promise<MessageDto> {
  const [dto] = await toMessageDtos(ctx.db, [row], null, { channel: conv.type === 'channel' });
  await ctx.hub.emit(await memberIds(ctx.db, conv.id), 'message:new', { message: dto! });
  return dto!;
}

/** System/service message (member joined, pinned, title changed…). */
export async function postSystemMessage(
  ctx: AppContext,
  conv: ConversationRow,
  actorId: string | null,
  system: Record<string, unknown>,
): Promise<void> {
  const row = await ctx.db.transaction((tx) =>
    insertMessage(tx, conv, { senderId: null, type: 'system', text: '', system: { ...system, actorId } }),
  );
  await broadcastNewMessage(ctx, conv, row);
}

export async function sendMessage(ctx: AppContext, auth: AuthState, conversationId: string, input: SendInput) {
  requireVerifiedIfNeeded(ctx, auth);
  await enforce(ctx.limiter, `send:${auth.userId}`, ctx.config.isTest ? 10_000 : 30, 10);
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);

  // Idempotency: a retried request with the same clientId returns the original message.
  const [existing] = await ctx.db
    .select()
    .from(messages)
    .where(and(eq(messages.senderId, auth.userId), eq(messages.clientId, input.clientId)))
    .limit(1);
  if (existing) {
    if (existing.conversationId !== conversationId) throw errors.conflict('client_id_reused', 'Duplicate client id');
    const [dto] = await toMessageDtos(ctx.db, [existing], auth.userId, { channel: conv.type === 'channel' });
    return { message: dto!, duplicate: true };
  }

  const hasMedia = input.attachmentIds.length > 0 || Boolean(input.stickerId) || Boolean(input.gif);
  await assertCanPost(ctx, conv, member, auth.userId, hasMedia);

  const text = input.text.replace(/\r\n/g, '\n').trim() === '' ? '' : input.text.replace(/\r\n/g, '\n').replace(/^\n+|\s+$/g, '');

  let type: MessageType = 'text';
  let fileRows: Array<typeof files.$inferSelect> = [];
  if (input.attachmentIds.length) {
    const ids = [...new Set(input.attachmentIds)];
    fileRows = await ctx.db
      .select()
      .from(files)
      .where(and(inArray(files.id, ids), eq(files.ownerId, auth.userId), eq(files.purpose, 'attachment')));
    if (fileRows.length !== ids.length) throw errors.badRequest('attachment_invalid', 'One or more attachments are invalid');
    fileRows.sort((a, b) => ids.indexOf(a.id) - ids.indexOf(b.id));
    type = fileRows.length === 1 && fileRows[0]!.kind === 'voice' ? 'voice' : 'media';
    if (fileRows.some((f) => f.kind === 'voice') && fileRows.length > 1) {
      throw errors.badRequest('attachment_invalid', 'Voice messages cannot be grouped with other files');
    }
    if (text.length > LIMITS.captionText) throw errors.badRequest('caption_too_long', 'Caption is too long');
  }
  if (input.stickerId) {
    if (fileRows.length || input.gif) throw errors.badRequest('message_invalid');
    const [s] = await ctx.db.select({ id: stickers.id }).from(stickers).where(eq(stickers.id, input.stickerId));
    if (!s) throw errors.badRequest('sticker_invalid', 'Unknown sticker');
    type = 'sticker';
  }
  if (input.gif) {
    if (fileRows.length) throw errors.badRequest('message_invalid');
    for (const u of [input.gif.url, input.gif.previewUrl]) {
      const host = new URL(u).hostname;
      if (new URL(u).protocol !== 'https:' || !GIF_HOSTS.some((re) => re.test(host))) {
        throw errors.badRequest('gif_invalid', 'GIFs must come from the configured GIF provider');
      }
    }
    type = 'gif';
  }

  if (input.replyToId) {
    const [r] = await ctx.db
      .select({ id: messages.id })
      .from(messages)
      .where(and(eq(messages.id, input.replyToId), eq(messages.conversationId, conv.id), visibleTo(auth.userId, member)))
      .limit(1);
    if (!r) throw errors.badRequest('reply_invalid', 'The message you are replying to is no longer available');
  }

  // Mentions → member ids (only people in this chat get notified).
  let mentionIds: string[] = [];
  const mentionNames = conv.type === 'group' ? extractMentions(text) : [];
  if (mentionNames.length) {
    const rows = await ctx.db
      .select({ id: users.id })
      .from(users)
      .innerJoin(conversationMembers, and(eq(conversationMembers.userId, users.id), eq(conversationMembers.conversationId, conv.id)))
      .where(inArray(sql`lower(${users.username})`, mentionNames));
    mentionIds = rows.map((r) => r.id).filter((id) => id !== auth.userId);
  }

  let row: MessageRow;
  try {
    row = await ctx.db.transaction((tx) =>
      insertMessage(
        tx,
        conv,
        {
          senderId: auth.userId,
          clientId: input.clientId,
          type,
          text,
          replyToId: input.replyToId ?? null,
          stickerId: input.stickerId ?? null,
          gif: input.gif ?? null,
          mentions: mentionIds,
          hasLink: extractLinks(text).length > 0,
          signature: conv.type === 'channel' && conv.settings.signPosts ? auth.user.displayName : null,
        },
        fileRows.map((f) => f.id),
      ),
    );
  } catch (err: unknown) {
    // Concurrent retry with the same clientId lost the race — return the winner.
    if (pgCode(err) === '23505') {
      const [dup] = await ctx.db
        .select()
        .from(messages)
        .where(and(eq(messages.senderId, auth.userId), eq(messages.clientId, input.clientId)));
      if (dup) {
        const [dto] = await toMessageDtos(ctx.db, [dup], auth.userId);
        return { message: dto!, duplicate: true };
      }
    }
    throw err;
  }

  const dto = await broadcastNewMessage(ctx, conv, row);

  // Side effects that must not fail the send.
  void (async () => {
    try {
      const preview = text || (type === 'voice' ? '🎤 Voice message' : type === 'sticker' ? 'Sticker' : type === 'gif' ? 'GIF' : '📎 Attachment');
      const notes: Parameters<typeof notify>[1] = mentionIds.map((uid) => ({
        userId: uid,
        type: 'mention',
        title: `${auth.user.displayName} mentioned you in ${conv.title}`,
        body: preview,
        conversationId: conv.id,
        messageId: row.id,
        actorId: auth.userId,
      }));
      if (input.replyToId && conv.type === 'group') {
        const [orig] = await ctx.db.select({ senderId: messages.senderId }).from(messages).where(eq(messages.id, input.replyToId));
        if (orig?.senderId && orig.senderId !== auth.userId && !mentionIds.includes(orig.senderId)) {
          notes.push({
            userId: orig.senderId,
            type: 'reply',
            title: `${auth.user.displayName} replied to you in ${conv.title}`,
            body: preview,
            conversationId: conv.id,
            messageId: row.id,
            actorId: auth.userId,
          });
        }
      }
      await notify(ctx, notes);
      if (!input.silent) await pushNewMessage(ctx, conv, auth.userId, auth.user.displayName, preview, mentionIds);
    } catch (err) {
      ctx.log.error({ err }, 'post-send side effects failed');
    }
  })();

  return { message: dto, duplicate: false };
}

export async function getHistory(
  ctx: AppContext,
  userId: string,
  conversationId: string,
  q: { before?: number; after?: number; around?: number; limit: number },
) {
  const { conv, member } = await requireReadable(ctx.db, userId, conversationId);
  const vis = and(eq(messages.conversationId, conv.id), visibleTo(userId, member));
  const channel = conv.type === 'channel';
  let rows: MessageRow[];
  let hasMoreBefore = false;
  let hasMoreAfter = false;
  if (q.around) {
    const half = Math.floor(q.limit / 2);
    const older = await ctx.db.select().from(messages).where(and(vis, lte(messages.seq, q.around))).orderBy(desc(messages.seq)).limit(half + 1);
    const newer = await ctx.db.select().from(messages).where(and(vis, gt(messages.seq, q.around))).orderBy(asc(messages.seq)).limit(half + 1);
    hasMoreBefore = older.length > half;
    hasMoreAfter = newer.length > half;
    rows = [...older.slice(0, half).reverse(), ...newer.slice(0, half)];
  } else if (q.after !== undefined) {
    const r = await ctx.db.select().from(messages).where(and(vis, gt(messages.seq, q.after))).orderBy(asc(messages.seq)).limit(q.limit + 1);
    hasMoreAfter = r.length > q.limit;
    rows = r.slice(0, q.limit);
  } else {
    const r = await ctx.db
      .select()
      .from(messages)
      .where(and(vis, q.before ? lt(messages.seq, q.before) : undefined))
      .orderBy(desc(messages.seq))
      .limit(q.limit + 1);
    hasMoreBefore = r.length > q.limit;
    rows = r.slice(0, q.limit).reverse();
  }
  return { items: await toMessageDtos(ctx.db, rows, userId, { channel }), hasMoreBefore, hasMoreAfter };
}

async function loadOwnedVisibleMessage(ctx: AppContext, userId: string, messageId: string) {
  const [m] = await ctx.db.select().from(messages).where(eq(messages.id, messageId)).limit(1);
  if (!m || m.deletedAt) throw errors.notFound('message_not_found', 'Message not found');
  const access = await requireMember(ctx.db, userId, m.conversationId);
  if (m.seq <= access.member.hiddenBeforeSeq) throw errors.notFound('message_not_found', 'Message not found');
  return { m, ...access };
}

export async function editMessage(ctx: AppContext, auth: AuthState, messageId: string, text: string) {
  const { m, conv, member } = await loadOwnedVisibleMessage(ctx, auth.userId, messageId);
  if (m.senderId !== auth.userId) throw errors.forbidden('not_author', 'You can only edit your own messages');
  if (m.type === 'system' || m.type === 'sticker' || m.type === 'gif' || m.type === 'voice') {
    throw errors.badRequest('not_editable', 'This message cannot be edited');
  }
  if (conv.type === 'channel' && !can.sendMessage(permCtx(conv, member))) throw errors.forbidden();
  const unlimited = conv.type === 'channel' || conv.type === 'saved';
  if (!unlimited && Date.now() - m.createdAt.getTime() > EDIT_WINDOW_MS) {
    throw errors.forbidden('edit_window_passed', 'Messages can only be edited within 48 hours');
  }
  const clean = text.replace(/\r\n/g, '\n').replace(/\s+$/g, '');
  if (m.type === 'text' && clean.trim() === '') throw errors.badRequest('message_empty', 'Message cannot be empty');
  if (m.type === 'media' && clean.length > LIMITS.captionText) throw errors.badRequest('caption_too_long');
  if (clean === m.text) {
    const [dto] = await toMessageDtos(ctx.db, [m], auth.userId, { channel: conv.type === 'channel' });
    return dto!;
  }
  let mentionIds: string[] = [];
  const names = conv.type === 'group' ? extractMentions(clean) : [];
  if (names.length) {
    const rows = await ctx.db
      .select({ id: users.id })
      .from(users)
      .innerJoin(conversationMembers, and(eq(conversationMembers.userId, users.id), eq(conversationMembers.conversationId, conv.id)))
      .where(inArray(sql`lower(${users.username})`, names));
    mentionIds = rows.map((r) => r.id).filter((id) => id !== auth.userId);
  }
  const now = new Date();
  const [updated] = await ctx.db
    .update(messages)
    .set({ text: clean, editedAt: now, updatedAt: now, mentions: mentionIds, hasLink: extractLinks(clean).length > 0 })
    .where(and(eq(messages.id, m.id), isNull(messages.deletedAt)))
    .returning();
  if (!updated) throw errors.notFound('message_not_found');
  const [generic] = await toMessageDtos(ctx.db, [updated], null, { channel: conv.type === 'channel' });
  await ctx.hub.emit(await memberIds(ctx.db, conv.id), 'message:updated', { message: generic! });
  const [mine] = await toMessageDtos(ctx.db, [updated], auth.userId, { channel: conv.type === 'channel' });
  return mine!;
}

export async function deleteMessages(ctx: AppContext, auth: AuthState, messageIds: string[], forEveryone: boolean) {
  const rows = await ctx.db.select().from(messages).where(and(inArray(messages.id, messageIds), isNull(messages.deletedAt)));
  if (rows.length === 0) throw errors.notFound('message_not_found', 'Message not found');
  const convIds = [...new Set(rows.map((r) => r.conversationId))];
  if (convIds.length > 1) throw errors.badRequest('mixed_conversations', 'Messages must belong to one chat');
  const { conv, member } = await requireMember(ctx.db, auth.userId, convIds[0]!);
  const visible = rows.filter((r) => r.seq > member.hiddenBeforeSeq);
  if (visible.length === 0) throw errors.notFound('message_not_found');
  const pc = permCtx(conv, member);

  const everyone = forEveryone || conv.type === 'channel' || conv.type === 'saved';
  if (everyone) {
    for (const r of visible) {
      const own = r.senderId === auth.userId;
      const allowed =
        conv.type === 'saved' ||
        (conv.type === 'channel' ? can.deleteOthers(pc) : own ? r.type !== 'system' || can.deleteOthers(pc) : can.deleteOthers(pc));
      if (!allowed) throw errors.forbidden('cannot_delete', 'You cannot delete this message for everyone');
    }
    const now = new Date();
    const ids = visible.map((r) => r.id);
    await ctx.db.transaction(async (tx) => {
      await tx.update(messages).set({ deletedAt: now, updatedAt: now, text: '', gif: null, mentions: [] }).where(inArray(messages.id, ids));
      await tx.delete(messageReactions).where(inArray(messageReactions.messageId, ids));
      await tx.delete(messagePins).where(inArray(messagePins.messageId, ids));
    });
    const others = visible.filter((r) => r.senderId !== auth.userId);
    if (others.length && conv.type !== 'saved') {
      const { audit } = await import('../audit/service');
      await audit(ctx, {
        actorId: auth.userId,
        conversationId: conv.id,
        action: 'message.deleted_by_moderator',
        data: { count: others.length, authors: [...new Set(others.map((o) => o.senderId))] },
      });
    }
    await ctx.hub.emit(await memberIds(ctx.db, conv.id), 'message:deleted', { conversationId: conv.id, messageIds: ids });
    return { deleted: ids, forEveryone: true };
  }
  const ids = visible.map((r) => r.id);
  await ctx.db
    .insert(hiddenMessages)
    .values(ids.map((messageId) => ({ userId: auth.userId, messageId })))
    .onConflictDoNothing();
  await ctx.hub.emit([auth.userId], 'message:deleted', { conversationId: conv.id, messageIds: ids });
  return { deleted: ids, forEveryone: false };
}

export async function toggleReaction(ctx: AppContext, auth: AuthState, messageId: string, emoji: string) {
  await enforce(ctx.limiter, `react:${auth.userId}`, ctx.config.isTest ? 10_000 : 60, 30);
  const { m, conv, member } = await loadOwnedVisibleMessage(ctx, auth.userId, messageId);
  if (m.type === 'system') throw errors.badRequest('not_reactable');
  if (!can.react(permCtx(conv, member))) throw errors.forbidden('reactions_disabled', 'Reactions are turned off here');
  await ctx.db.transaction(async (tx) => {
    // Serialize concurrent toggles from the same user on the same message.
    await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtext(${`react:${auth.userId}:${m.id}`}))`);
    const mine = await tx
      .select()
      .from(messageReactions)
      .where(and(eq(messageReactions.messageId, m.id), eq(messageReactions.userId, auth.userId)))
      .orderBy(asc(messageReactions.createdAt));
    if (mine.some((r) => r.emoji === emoji)) {
      await tx
        .delete(messageReactions)
        .where(and(eq(messageReactions.messageId, m.id), eq(messageReactions.userId, auth.userId), eq(messageReactions.emoji, emoji)));
    } else {
      if (mine.length >= LIMITS.reactionsPerUserPerMessage) {
        // Replace the oldest reaction, like most messengers do.
        await tx
          .delete(messageReactions)
          .where(and(eq(messageReactions.messageId, m.id), eq(messageReactions.userId, auth.userId), eq(messageReactions.emoji, mine[0]!.emoji)));
      }
      await tx.insert(messageReactions).values({ messageId: m.id, userId: auth.userId, emoji }).onConflictDoNothing();
    }
    await tx.update(messages).set({ updatedAt: new Date() }).where(eq(messages.id, m.id));
  });
  const all = await ctx.db
    .select({ emoji: messageReactions.emoji, userId: messageReactions.userId, createdAt: messageReactions.createdAt })
    .from(messageReactions)
    .where(eq(messageReactions.messageId, m.id));
  const generic = summarizeReactions(all, null);
  const actorEmojis = all.filter((r) => r.userId === auth.userId).map((r) => r.emoji);
  await ctx.hub.emit(await memberIds(ctx.db, conv.id), 'message:reactions', {
    conversationId: conv.id,
    messageId: m.id,
    reactions: generic,
    actorId: auth.userId,
    actorEmojis,
  });
  return { reactions: summarizeReactions(all, auth.userId) };
}

export async function setPinned(ctx: AppContext, auth: AuthState, messageId: string, pinned: boolean) {
  const { m, conv, member } = await loadOwnedVisibleMessage(ctx, auth.userId, messageId);
  if (!can.pin(permCtx(conv, member))) throw errors.forbidden('cannot_pin', 'You cannot pin messages here');
  if (m.type === 'system') throw errors.badRequest('not_pinnable');
  let changed: boolean;
  if (pinned) {
    const r = await ctx.db
      .insert(messagePins)
      .values({ conversationId: conv.id, messageId: m.id, pinnedById: auth.userId })
      .onConflictDoNothing()
      .returning();
    changed = r.length > 0;
  } else {
    const r = await ctx.db
      .delete(messagePins)
      .where(and(eq(messagePins.conversationId, conv.id), eq(messagePins.messageId, m.id)))
      .returning();
    changed = r.length > 0;
  }
  const pins = await ctx.db
    .select({ id: messagePins.messageId })
    .from(messagePins)
    .where(eq(messagePins.conversationId, conv.id))
    .orderBy(asc(messagePins.pinnedAt));
  const ids = pins.map((p) => p.id);
  await ctx.hub.emit(await memberIds(ctx.db, conv.id), 'conversation:pins', { conversationId: conv.id, pinnedMessageIds: ids });
  if (changed && pinned && (conv.type === 'group' || conv.type === 'channel')) {
    await postSystemMessage(ctx, conv, auth.userId, { action: 'message_pinned', messageId: m.id, preview: m.text.slice(0, 80) });
  }
  return { pinnedMessageIds: ids };
}

export async function forwardMessages(
  ctx: AppContext,
  auth: AuthState,
  input: { messageIds: string[]; toConversationIds: string[]; hideSender: boolean },
) {
  requireVerifiedIfNeeded(ctx, auth);
  await enforce(ctx.limiter, `fwd:${auth.userId}`, ctx.config.isTest ? 10_000 : 20, 60);
  const src = await ctx.db.select().from(messages).where(and(inArray(messages.id, input.messageIds), isNull(messages.deletedAt)));
  if (src.length !== new Set(input.messageIds).size) throw errors.notFound('message_not_found', 'Some messages are no longer available');
  const srcConvIds = [...new Set(src.map((m) => m.conversationId))];
  if (srcConvIds.length !== 1) throw errors.badRequest('mixed_conversations', 'Forward messages from one chat at a time');
  const { conv: srcConv, member: srcMember } = await requireReadable(ctx.db, auth.userId, srcConvIds[0]!);
  if (src.some((m) => (srcMember ? m.seq <= srcMember.hiddenBeforeSeq : false) || m.type === 'system')) {
    throw errors.badRequest('not_forwardable', 'Some messages cannot be forwarded');
  }
  src.sort((a, b) => a.seq - b.seq);
  const senderIds = [...new Set(src.map((m) => m.senderId).filter((x): x is string => Boolean(x)))];
  const senderRows = senderIds.length ? await ctx.db.select({ id: users.id, name: users.displayName }).from(users).where(inArray(users.id, senderIds)) : [];
  const nameOf = new Map(senderRows.map((u) => [u.id, u.name]));
  const att = await ctx.db
    .select()
    .from(messageAttachments)
    .where(inArray(messageAttachments.messageId, src.map((m) => m.id)))
    .orderBy(asc(messageAttachments.position));

  const results: MessageDto[] = [];
  for (const targetId of [...new Set(input.toConversationIds)]) {
    const { conv, member } = await requireMember(ctx.db, auth.userId, targetId);
    const media = src.some((m) => m.type !== 'text');
    await assertCanPost(ctx, conv, member, auth.userId, media);
    const rows = await ctx.db.transaction(async (tx) => {
      const out: MessageRow[] = [];
      for (const m of src) {
        const forward = input.hideSender
          ? null
          : (m.forward ?? {
              fromName: srcConv.type === 'channel' ? srcConv.title : (nameOf.get(m.senderId ?? '') ?? 'Unknown'),
              fromUserId: srcConv.type === 'channel' ? null : m.senderId,
              fromConversationId: srcConv.type === 'channel' ? srcConv.id : null,
              originalDate: m.createdAt.toISOString(),
            });
        out.push(
          await insertMessage(
            tx,
            conv,
            {
              senderId: auth.userId,
              type: m.type,
              text: m.text,
              stickerId: m.stickerId,
              gif: m.gif,
              forward,
              hasLink: m.hasLink,
              signature: conv.type === 'channel' && conv.settings.signPosts ? auth.user.displayName : null,
            },
            att.filter((a) => a.messageId === m.id).map((a) => a.fileId),
          ),
        );
      }
      return out;
    });
    for (const r of rows) results.push(await broadcastNewMessage(ctx, conv, r));
  }
  return { messages: results };
}

export async function markRead(ctx: AppContext, auth: AuthState, conversationId: string, seq: number) {
  const { conv, member } = await requireMember(ctx.db, auth.userId, conversationId);
  const target = Math.min(seq, conv.lastMessageSeq);
  if (target <= member.lastReadSeq && !member.markedUnread) return { lastReadSeq: member.lastReadSeq };
  const [updated] = await ctx.db
    .update(conversationMembers)
    .set({ lastReadSeq: sql`greatest(${conversationMembers.lastReadSeq}, ${target})`, markedUnread: false })
    .where(and(eq(conversationMembers.conversationId, conv.id), eq(conversationMembers.userId, auth.userId)))
    .returning({ lastReadSeq: conversationMembers.lastReadSeq });
  const lastReadSeq = updated?.lastReadSeq ?? target;
  // Read receipts go to the other participants of direct chats and small groups; channels only sync own devices.
  const recipients = conv.type === 'direct' || (conv.type === 'group' && conv.memberCount <= 200) ? await memberIds(ctx.db, conv.id) : [auth.userId];
  await ctx.hub.emit(recipients, 'conversation:read', { conversationId: conv.id, userId: auth.userId, seq: lastReadSeq });
  await markNotificationsRead(ctx, auth.userId, undefined, conv.id);
  return { lastReadSeq };
}

export async function recordViews(ctx: AppContext, userId: string, conversationId: string, messageIds: string[]) {
  const { conv, member } = await requireReadable(ctx.db, userId, conversationId);
  if (conv.type !== 'channel') return { views: {} };
  const valid = await ctx.db
    .select({ id: messages.id })
    .from(messages)
    .where(and(inArray(messages.id, messageIds), eq(messages.conversationId, conv.id), visibleTo(userId, member)));
  if (valid.length) {
    await ctx.db
      .insert(messageViews)
      .values(valid.map((v) => ({ messageId: v.id, userId })))
      .onConflictDoNothing();
  }
  const counts = valid.length
    ? await ctx.db
        .select({ id: messageViews.messageId, n: sql<number>`count(*)::int` })
        .from(messageViews)
        .where(inArray(messageViews.messageId, valid.map((v) => v.id)))
        .groupBy(messageViews.messageId)
    : [];
  return { views: Object.fromEntries(counts.map((c) => [c.id, Number(c.n)])) };
}

export async function messageReadBy(ctx: AppContext, userId: string, messageId: string) {
  const { m, conv } = await loadOwnedVisibleMessage(ctx, userId, messageId);
  if (conv.type !== 'group' || m.senderId !== userId) return { userIds: [] as string[] };
  const rows = await ctx.db
    .select({ userId: conversationMembers.userId })
    .from(conversationMembers)
    .where(and(eq(conversationMembers.conversationId, conv.id), sql`${conversationMembers.lastReadSeq} >= ${m.seq}`, sql`${conversationMembers.userId} <> ${userId}`))
    .limit(100);
  return { userIds: rows.map((r) => r.userId) };
}

export type { DbOrTx };
