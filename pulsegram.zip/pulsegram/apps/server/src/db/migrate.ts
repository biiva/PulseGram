import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { migrate } from 'drizzle-orm/node-postgres/migrator';
import { createDb } from './client';

/** Locate the generated SQL migrations both from source (tsx) and from the bundled dist build. */
export function migrationsFolder(): string {
  const here = path.dirname(fileURLToPath(import.meta.url));
  const candidates = [
    path.resolve(here, '../../drizzle'), // src/db → apps/server/drizzle
    path.resolve(here, '../drizzle'), // dist → apps/server/drizzle
    path.resolve(process.cwd(), 'drizzle'),
  ];
  return candidates.find((p) => fs.existsSync(path.join(p, 'meta/_journal.json'))) ?? candidates[0]!;
}

export async function runMigrations(databaseUrl: string): Promise<void> {
  const { db, pool } = createDb(databaseUrl, 1);
  try {
    await migrate(db, { migrationsFolder: migrationsFolder() });
  } finally {
    await pool.end();
  }
}

const isMain = Boolean(process.argv[1]) && fileURLToPath(import.meta.url) === path.resolve(process.argv[1]!);
if (isMain) {
  const url = process.env.DATABASE_URL ?? 'postgres://postgres:postgres@127.0.0.1:5432/pulsegram';
  runMigrations(url)
    .then(() => {
      console.log('✔ Migrations applied');
      process.exit(0);
    })
    .catch((err: unknown) => {
      console.error('✖ Migration failed:', err);
      process.exit(1);
    });
}
