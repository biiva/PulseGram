import { drizzle, type NodePgDatabase } from 'drizzle-orm/node-postgres';
import pg from 'pg';
import * as schema from './schema';

export type Database = NodePgDatabase<typeof schema>;
/** A transaction handle has the same query API as the database. */
export type Tx = Parameters<Parameters<Database['transaction']>[0]>[0];
export type DbOrTx = Database | Tx;

// Return BIGINT columns as JS numbers (seq values stay far below 2^53).
pg.types.setTypeParser(20, (v) => Number(v));

export function createDb(url: string, max = 10): { db: Database; pool: pg.Pool } {
  const pool = new pg.Pool({ connectionString: url, max, idleTimeoutMillis: 30_000 });
  const db = drizzle(pool, { schema });
  return { db, pool };
}

export { schema };
