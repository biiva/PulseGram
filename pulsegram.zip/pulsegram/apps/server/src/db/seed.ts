/**
 * Demo data for LOCAL DEVELOPMENT ONLY.
 *
 * Creates a few clearly-labelled demo accounts (is_demo = true), a group, a public channel and
 * some messages so the UI has something to show. Refuses to run in production, because the demo
 * accounts use a well-known password. Re-running is safe (existing demo users are reused).
 *
 *   npm run db:seed
 */
import { and, eq, sql } from 'drizzle-orm';
import { DEFAULT_CHANNEL_SETTINGS, DEFAULT_GROUP_SETTINGS } from '@pulsegram/shared';
import { loadConfig } from '../config';
import { hashPassword } from '../lib/crypto';
import { ensureBuiltinStickers } from '../modules/stickers/builtin';
import { createDefaultPreferences } from '../modules/users/preferences';
import { createDb, type Database } from './client';
import { runMigrations } from './migrate';
import { contacts, conversationMembers, conversations, messages, users } from './schema';

export const DEMO_PASSWORD = 'demo-pass-123';

const PEOPLE = [
  { username: 'demo_ava', displayName: 'Ava Lindqvist (demo)', bio: 'Product designer. Coffee, typography and long walks.', statusText: 'sketching' },
  { username: 'demo_mark', displayName: 'Mark Ortega (demo)', bio: 'Backend engineer. Ask me about Postgres.', statusText: '' },
  { username: 'demo_irina', displayName: 'Ирина Волкова (demo)', bio: 'Community manager. Пишите по-русски!', statusText: 'на созвоне' },
  { username: 'demo_leo', displayName: 'Leo Park (demo)', bio: 'Plays too much chess.', statusText: '' },
];

async function ensureUser(db: Database, p: (typeof PEOPLE)[number], passwordHash: string) {
  const [existing] = await db.select().from(users).where(sql`lower(${users.username}) = ${p.username}`);
  if (existing) return existing;
  const [u] = await db
    .insert(users)
    .values({
      ...p,
      email: `${p.username}@demo.pulsegram.local`,
      emailVerifiedAt: new Date(),
      passwordHash,
      profileCompleted: true,
      isDemo: true,
      lastSeenAt: new Date(Date.now() - Math.random() * 3600_000),
    })
    .returning();
  await createDefaultPreferences(db, u!.id, p.username === 'demo_irina' ? 'ru' : 'en');
  const [saved] = await db
    .insert(conversations)
    .values({ type: 'saved', directKey: `saved:${u!.id}`, settings: DEFAULT_GROUP_SETTINGS, memberCount: 1, createdById: u!.id })
    .returning();
  await db.insert(conversationMembers).values({ conversationId: saved!.id, userId: u!.id, role: 'owner' });
  return u!;
}

async function post(db: Database, conversationId: string, senderId: string | null, text: string, minutesAgo: number, extra: Partial<typeof messages.$inferInsert> = {}) {
  const at = new Date(Date.now() - minutesAgo * 60_000);
  const [m] = await db
    .insert(messages)
    .values({ conversationId, senderId, type: 'text', text, createdAt: at, updatedAt: at, ...extra })
    .returning();
  await db.update(conversations).set({ lastMessageSeq: m!.seq, lastActivityAt: at }).where(eq(conversations.id, conversationId));
  if (senderId) {
    await db
      .update(conversationMembers)
      .set({ lastReadSeq: m!.seq })
      .where(and(eq(conversationMembers.conversationId, conversationId), eq(conversationMembers.userId, senderId)));
  }
  return m!;
}

async function main() {
  const config = loadConfig();
  if (config.isProd) {
    console.error('✖ Refusing to seed demo accounts with a known password in production.');
    process.exit(1);
  }
  await runMigrations(config.DATABASE_URL);
  const { db, pool } = createDb(config.DATABASE_URL, 2);
  try {
    await ensureBuiltinStickers({ db });
    const [already] = await db.select({ id: conversations.id }).from(conversations).where(eq(conversations.username, 'pulse_demo_news'));
    const hash = await hashPassword(DEMO_PASSWORD);
    const [ava, mark, irina, leo] = await Promise.all(PEOPLE.map((p) => ensureUser(db, p, hash)));
    if (already) {
      console.log('✔ Demo data already present — nothing to do.');
      return;
    }

    // Contacts
    for (const [a, b] of [
      [ava!, mark!],
      [mark!, ava!],
      [ava!, irina!],
      [irina!, ava!],
      [leo!, ava!],
    ] as const)
      await db.insert(contacts).values({ ownerId: a.id, contactId: b.id }).onConflictDoNothing();

    // Direct chat
    const key = ava!.id < mark!.id ? `dm:${ava!.id}:${mark!.id}` : `dm:${mark!.id}:${ava!.id}`;
    const [dm] = await db.insert(conversations).values({ type: 'direct', directKey: key, settings: DEFAULT_GROUP_SETTINGS, memberCount: 2, createdById: ava!.id, isDemo: true }).returning();
    await db.insert(conversationMembers).values([
      { conversationId: dm!.id, userId: ava!.id },
      { conversationId: dm!.id, userId: mark!.id },
    ]);
    await post(db, dm!.id, ava!.id, 'Morning! Did the migration go through?', 180);
    await post(db, dm!.id, mark!.id, 'Yep — zero downtime. Indexes built concurrently.', 175);
    await post(db, dm!.id, ava!.id, 'You are a hero 🙌', 170);
    await post(db, dm!.id, mark!.id, 'Next up: `EXPLAIN ANALYZE` on the search query.', 30);

    // Group
    const [group] = await db
      .insert(conversations)
      .values({ type: 'group', title: 'Design × Engineering (demo)', description: 'Demo group created by the seed script.', settings: DEFAULT_GROUP_SETTINGS, memberCount: 4, createdById: ava!.id, isDemo: true })
      .returning();
    await db.insert(conversationMembers).values([
      { conversationId: group!.id, userId: ava!.id, role: 'owner' },
      { conversationId: group!.id, userId: mark!.id, role: 'admin' },
      { conversationId: group!.id, userId: irina!.id, role: 'moderator' },
      { conversationId: group!.id, userId: leo!.id, role: 'member' },
    ]);
    await post(db, group!.id, null, '', 300, { type: 'system', system: { action: 'group_created', actorId: ava!.id, title: 'Design × Engineering (demo)' } });
    await post(db, group!.id, ava!.id, 'Welcome everyone! This is where design and engineering meet.', 290);
    await post(db, group!.id, irina!.id, 'Привет всем! Я буду модерировать этот чат 🙂', 280);
    await post(db, group!.id, leo!.id, 'Hi! Happy to be here.', 120);
    await post(db, group!.id, mark!.id, `@demo_ava the new chat list feels much faster`, 15, { mentions: [ava!.id] });

    // Public channel
    const [channel] = await db
      .insert(conversations)
      .values({
        type: 'channel',
        title: 'PulseGram Demo News',
        description: 'A demo channel created by the seed script. Posts and numbers here are sample data.',
        username: 'pulse_demo_news',
        isPublic: true,
        category: 'tech',
        settings: { ...DEFAULT_CHANNEL_SETTINGS, signPosts: true },
        memberCount: 3,
        createdById: mark!.id,
        isDemo: true,
      })
      .returning();
    await db.insert(conversationMembers).values([
      { conversationId: channel!.id, userId: mark!.id, role: 'owner' },
      { conversationId: channel!.id, userId: ava!.id, role: 'member' },
      { conversationId: channel!.id, userId: leo!.id, role: 'member' },
    ]);
    await post(db, channel!.id, mark!.id, 'Welcome to the demo channel. Only admins can post here; subscribers can react.', 600, { signature: 'Mark Ortega (demo)' });
    await post(db, channel!.id, mark!.id, 'Tip: press Ctrl/⌘+K anywhere to search people, chats and messages.', 60, { signature: 'Mark Ortega (demo)' });

    console.log('✔ Demo data created.');
    console.log(`  Sign in as any of: ${PEOPLE.map((p) => `${p.username}@demo.pulsegram.local`).join(', ')}`);
    console.log(`  Password: ${DEMO_PASSWORD}  (development only)`);
  } finally {
    await pool.end();
  }
}

main().catch((err: unknown) => {
  console.error(err);
  process.exit(1);
});
