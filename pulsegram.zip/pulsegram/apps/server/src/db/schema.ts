import { sql } from 'drizzle-orm';
import {
  bigserial,
  bigint,
  boolean,
  check,
  index,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  primaryKey,
  real,
  text,
  timestamp,
  uniqueIndex,
  uuid,
} from 'drizzle-orm/pg-core';
import type {
  AppearanceSettings,
  GroupSettings,
  NotificationSettings,
  PrivacySettings,
} from '@pulsegram/shared';

const ts = (name: string) => timestamp(name, { withTimezone: true, mode: 'date' });
const createdAt = () => ts('created_at').notNull().defaultNow();
const id = () => uuid('id').primaryKey().defaultRandom();

export const conversationType = pgEnum('conversation_type', ['direct', 'group', 'channel', 'saved']);
export const memberRole = pgEnum('member_role', ['owner', 'admin', 'moderator', 'member']);
export const messageType = pgEnum('message_type', ['text', 'media', 'voice', 'sticker', 'gif', 'system']);
export const attachmentKind = pgEnum('attachment_kind', ['image', 'video', 'audio', 'voice', 'file']);
export const presenceMode = pgEnum('presence_mode', ['auto', 'dnd', 'invisible']);
export const callStatus = pgEnum('call_status', [
  'ringing',
  'accepted',
  'rejected',
  'missed',
  'ended',
  'failed',
  'busy',
  'cancelled',
]);
export const tokenPurpose = pgEnum('token_purpose', ['email_verify', 'password_reset']);

// ─── Users & auth ────────────────────────────────────────────────────────────

export const users = pgTable(
  'users',
  {
    id: id(),
    email: text('email').notNull(),
    emailVerifiedAt: ts('email_verified_at'),
    passwordHash: text('password_hash').notNull(),
    username: text('username').notNull(),
    displayName: text('display_name').notNull(),
    bio: text('bio').notNull().default(''),
    phone: text('phone'),
    publicEmail: boolean('public_email').notNull().default(false),
    statusText: text('status_text').notNull().default(''),
    presenceMode: presenceMode('presence_mode').notNull().default('auto'),
    avatarFileId: uuid('avatar_file_id'),
    lastSeenAt: ts('last_seen_at'),
    profileCompleted: boolean('profile_completed').notNull().default(false),
    isDemo: boolean('is_demo').notNull().default(false),
    createdAt: createdAt(),
    updatedAt: ts('updated_at').notNull().defaultNow(),
    deletedAt: ts('deleted_at'),
  },
  (t) => [
    uniqueIndex('users_email_lower_uq').on(sql`lower(${t.email})`),
    uniqueIndex('users_username_lower_uq').on(sql`lower(${t.username})`),
    index('users_username_trgm').using('gin', sql`lower(${t.username}) gin_trgm_ops`),
    index('users_display_name_trgm').using('gin', sql`lower(${t.displayName}) gin_trgm_ops`),
  ],
);

/** Each row is one signed-in device. The raw token only ever lives in the user's httpOnly cookie. */
export const sessions = pgTable(
  'sessions',
  {
    id: id(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    tokenHash: text('token_hash').notNull(),
    deviceName: text('device_name').notNull().default(''),
    userAgent: text('user_agent').notNull().default(''),
    ip: text('ip'),
    createdAt: createdAt(),
    lastActiveAt: ts('last_active_at').notNull().defaultNow(),
    expiresAt: ts('expires_at').notNull(),
    revokedAt: ts('revoked_at'),
  },
  (t) => [uniqueIndex('sessions_token_hash_uq').on(t.tokenHash), index('sessions_user_idx').on(t.userId)],
);

/** Single-use tokens for email verification and password reset (stored hashed). */
export const authTokens = pgTable(
  'auth_tokens',
  {
    id: id(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    purpose: tokenPurpose('purpose').notNull(),
    tokenHash: text('token_hash').notNull(),
    expiresAt: ts('expires_at').notNull(),
    usedAt: ts('used_at'),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex('auth_tokens_hash_uq').on(t.tokenHash), index('auth_tokens_user_idx').on(t.userId, t.purpose)],
);

export const userPreferences = pgTable('user_preferences', {
  userId: uuid('user_id')
    .primaryKey()
    .references(() => users.id, { onDelete: 'cascade' }),
  privacy: jsonb('privacy').$type<PrivacySettings>().notNull(),
  notifications: jsonb('notifications').$type<NotificationSettings>().notNull(),
  appearance: jsonb('appearance').$type<AppearanceSettings>().notNull(),
  updatedAt: ts('updated_at').notNull().defaultNow(),
});

export const contacts = pgTable(
  'contacts',
  {
    ownerId: uuid('owner_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    contactId: uuid('contact_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    createdAt: createdAt(),
  },
  (t) => [primaryKey({ columns: [t.ownerId, t.contactId] }), index('contacts_contact_idx').on(t.contactId)],
);

export const blockedUsers = pgTable(
  'blocked_users',
  {
    blockerId: uuid('blocker_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    blockedId: uuid('blocked_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    createdAt: createdAt(),
  },
  (t) => [primaryKey({ columns: [t.blockerId, t.blockedId] }), index('blocked_blocked_idx').on(t.blockedId)],
);

// ─── Files ───────────────────────────────────────────────────────────────────

export const files = pgTable(
  'files',
  {
    id: id(),
    ownerId: uuid('owner_id').references(() => users.id, { onDelete: 'set null' }),
    storageKey: text('storage_key').notNull(),
    thumbKey: text('thumb_key'),
    kind: attachmentKind('kind').notNull(),
    mime: text('mime').notNull(),
    size: bigint('size', { mode: 'number' }).notNull(),
    name: text('name').notNull(),
    width: integer('width'),
    height: integer('height'),
    durationMs: integer('duration_ms'),
    waveform: jsonb('waveform').$type<number[]>(),
    /** 'attachment' files are only reachable via messages; 'avatar' files are visible to signed-in users. */
    purpose: text('purpose').notNull().default('attachment'),
    sha256: text('sha256').notNull(),
    createdAt: createdAt(),
  },
  (t) => [index('files_owner_idx').on(t.ownerId)],
);

// ─── Conversations ───────────────────────────────────────────────────────────

export const conversations = pgTable(
  'conversations',
  {
    id: id(),
    type: conversationType('type').notNull(),
    title: text('title').notNull().default(''),
    description: text('description').notNull().default(''),
    username: text('username'),
    avatarFileId: uuid('avatar_file_id').references(() => files.id, { onDelete: 'set null' }),
    isPublic: boolean('is_public').notNull().default(false),
    category: text('category'),
    /** Deterministic key for 1:1 and saved chats so they can never be duplicated. */
    directKey: text('direct_key'),
    settings: jsonb('settings').$type<GroupSettings>().notNull(),
    /** Channel → linked discussion group (comments). */
    discussionGroupId: uuid('discussion_group_id'),
    lastMessageSeq: bigint('last_message_seq', { mode: 'number' }).notNull().default(0),
    lastActivityAt: ts('last_activity_at').notNull().defaultNow(),
    memberCount: integer('member_count').notNull().default(0),
    isDemo: boolean('is_demo').notNull().default(false),
    createdById: uuid('created_by_id').references(() => users.id, { onDelete: 'set null' }),
    createdAt: createdAt(),
    updatedAt: ts('updated_at').notNull().defaultNow(),
    deletedAt: ts('deleted_at'),
  },
  (t) => [
    uniqueIndex('conversations_direct_key_uq').on(t.directKey),
    uniqueIndex('conversations_username_lower_uq').on(sql`lower(${t.username})`),
    index('conversations_public_idx').on(t.type, t.isPublic),
    index('conversations_title_trgm').using('gin', sql`lower(${t.title}) gin_trgm_ops`),
  ],
);

export const conversationMembers = pgTable(
  'conversation_members',
  {
    conversationId: uuid('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    role: memberRole('role').notNull().default('member'),
    joinedAt: ts('joined_at').notNull().defaultNow(),
    invitedById: uuid('invited_by_id'),
    /** Highest message seq the member has read. Read receipts are derived from this cursor. */
    lastReadSeq: bigint('last_read_seq', { mode: 'number' }).notNull().default(0),
    /** Messages with seq <= this are hidden for the member ("clear history" / joined without history). */
    hiddenBeforeSeq: bigint('hidden_before_seq', { mode: 'number' }).notNull().default(0),
    markedUnread: boolean('marked_unread').notNull().default(false),
    isPinned: boolean('is_pinned').notNull().default(false),
    pinnedAt: ts('pinned_at'),
    isArchived: boolean('is_archived').notNull().default(false),
    mutedUntil: ts('muted_until'),
    draft: text('draft').notNull().default(''),
    draftUpdatedAt: ts('draft_updated_at'),
    /** For direct chats, "delete chat for me" hides it until a new message arrives. */
    hidden: boolean('hidden').notNull().default(false),
    lastPostAt: ts('last_post_at'),
  },
  (t) => [
    primaryKey({ columns: [t.conversationId, t.userId] }),
    index('members_user_idx').on(t.userId),
    check('members_seq_nonneg', sql`${t.lastReadSeq} >= 0`),
  ],
);

export const messages = pgTable(
  'messages',
  {
    id: id(),
    /** Global monotonic sequence; ordering, cursors and unread counts use it instead of client clocks. */
    seq: bigserial('seq', { mode: 'number' }).notNull(),
    conversationId: uuid('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    senderId: uuid('sender_id').references(() => users.id, { onDelete: 'set null' }),
    clientId: uuid('client_id'),
    type: messageType('type').notNull(),
    text: text('text').notNull().default(''),
    replyToId: uuid('reply_to_id'),
    forward: jsonb('forward').$type<{
      fromName: string;
      fromUserId: string | null;
      fromConversationId: string | null;
      originalDate: string;
    }>(),
    stickerId: uuid('sticker_id'),
    gif: jsonb('gif').$type<{ url: string; previewUrl: string; width: number; height: number; title?: string }>(),
    system: jsonb('system').$type<Record<string, unknown>>(),
    mentions: jsonb('mentions').$type<string[]>().notNull().default(sql`'[]'::jsonb`),
    signature: text('signature'),
    hasLink: boolean('has_link').notNull().default(false),
    createdAt: createdAt(),
    editedAt: ts('edited_at'),
    deletedAt: ts('deleted_at'),
    /** Bumped on every change (edit, delete, reactions) — drives /sync recovery after reconnects. */
    updatedAt: ts('updated_at').notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex('messages_seq_uq').on(t.seq),
    uniqueIndex('messages_sender_client_uq').on(t.senderId, t.clientId),
    index('messages_conv_seq_idx').on(t.conversationId, t.seq),
    index('messages_conv_updated_idx').on(t.conversationId, t.updatedAt),
    index('messages_sender_idx').on(t.senderId),
    index('messages_text_trgm').using('gin', sql`lower(${t.text}) gin_trgm_ops`),
  ],
);

export const messageAttachments = pgTable(
  'message_attachments',
  {
    messageId: uuid('message_id')
      .notNull()
      .references(() => messages.id, { onDelete: 'cascade' }),
    fileId: uuid('file_id')
      .notNull()
      .references(() => files.id, { onDelete: 'cascade' }),
    position: integer('position').notNull().default(0),
  },
  (t) => [primaryKey({ columns: [t.messageId, t.fileId] }), index('attachments_file_idx').on(t.fileId)],
);

export const messageReactions = pgTable(
  'message_reactions',
  {
    messageId: uuid('message_id')
      .notNull()
      .references(() => messages.id, { onDelete: 'cascade' }),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    emoji: text('emoji').notNull(),
    createdAt: createdAt(),
  },
  (t) => [primaryKey({ columns: [t.messageId, t.userId, t.emoji] })],
);

/** "Delete for me": the message stays for everyone else. */
export const hiddenMessages = pgTable(
  'hidden_messages',
  {
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    messageId: uuid('message_id')
      .notNull()
      .references(() => messages.id, { onDelete: 'cascade' }),
    hiddenAt: ts('hidden_at').notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.messageId] })],
);

export const messagePins = pgTable(
  'message_pins',
  {
    conversationId: uuid('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    messageId: uuid('message_id')
      .notNull()
      .references(() => messages.id, { onDelete: 'cascade' }),
    pinnedById: uuid('pinned_by_id').references(() => users.id, { onDelete: 'set null' }),
    pinnedAt: ts('pinned_at').notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.conversationId, t.messageId] })],
);

/** One row per (post, viewer): channel view counts are unique viewers, never invented numbers. */
export const messageViews = pgTable(
  'message_views',
  {
    messageId: uuid('message_id')
      .notNull()
      .references(() => messages.id, { onDelete: 'cascade' }),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    viewedAt: ts('viewed_at').notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.messageId, t.userId] })],
);

export const groupInvites = pgTable(
  'group_invites',
  {
    id: id(),
    conversationId: uuid('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    token: text('token').notNull(),
    createdById: uuid('created_by_id').references(() => users.id, { onDelete: 'set null' }),
    expiresAt: ts('expires_at'),
    maxUses: integer('max_uses'),
    uses: integer('uses').notNull().default(0),
    revokedAt: ts('revoked_at'),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex('invites_token_uq').on(t.token), index('invites_conv_idx').on(t.conversationId)],
);

// ─── Social / misc ───────────────────────────────────────────────────────────

export const notifications = pgTable(
  'notifications',
  {
    id: id(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    type: text('type').notNull(),
    title: text('title').notNull(),
    body: text('body').notNull().default(''),
    conversationId: uuid('conversation_id').references(() => conversations.id, { onDelete: 'cascade' }),
    messageId: uuid('message_id').references(() => messages.id, { onDelete: 'cascade' }),
    actorId: uuid('actor_id').references(() => users.id, { onDelete: 'set null' }),
    readAt: ts('read_at'),
    createdAt: createdAt(),
  },
  (t) => [index('notifications_user_idx').on(t.userId, t.createdAt)],
);

export const pushSubscriptions = pgTable(
  'push_subscriptions',
  {
    id: id(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    sessionId: uuid('session_id').references(() => sessions.id, { onDelete: 'cascade' }),
    endpoint: text('endpoint').notNull(),
    p256dh: text('p256dh').notNull(),
    auth: text('auth').notNull(),
    createdAt: createdAt(),
  },
  (t) => [uniqueIndex('push_endpoint_uq').on(t.endpoint), index('push_user_idx').on(t.userId)],
);

export const calls = pgTable(
  'calls',
  {
    id: id(),
    conversationId: uuid('conversation_id')
      .notNull()
      .references(() => conversations.id, { onDelete: 'cascade' }),
    callerId: uuid('caller_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    calleeId: uuid('callee_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    video: boolean('video').notNull().default(false),
    status: callStatus('status').notNull().default('ringing'),
    /** Signalling is routed between exactly these two devices. */
    callerSessionId: uuid('caller_session_id'),
    calleeSessionId: uuid('callee_session_id'),
    createdAt: createdAt(),
    answeredAt: ts('answered_at'),
    endedAt: ts('ended_at'),
  },
  (t) => [index('calls_caller_idx').on(t.callerId, t.createdAt), index('calls_callee_idx').on(t.calleeId, t.createdAt)],
);

export const reports = pgTable(
  'reports',
  {
    id: id(),
    reporterId: uuid('reporter_id').references(() => users.id, { onDelete: 'set null' }),
    targetType: text('target_type').notNull(),
    targetId: uuid('target_id').notNull(),
    reason: text('reason').notNull(),
    details: text('details').notNull().default(''),
    status: text('status').notNull().default('open'),
    createdAt: createdAt(),
  },
  (t) => [index('reports_target_idx').on(t.targetType, t.targetId)],
);

export const auditLogs = pgTable(
  'audit_logs',
  {
    id: id(),
    actorId: uuid('actor_id').references(() => users.id, { onDelete: 'set null' }),
    conversationId: uuid('conversation_id').references(() => conversations.id, { onDelete: 'cascade' }),
    targetUserId: uuid('target_user_id').references(() => users.id, { onDelete: 'set null' }),
    action: text('action').notNull(),
    data: jsonb('data').$type<Record<string, unknown>>().notNull().default(sql`'{}'::jsonb`),
    ip: text('ip'),
    createdAt: createdAt(),
  },
  (t) => [index('audit_conv_idx').on(t.conversationId, t.createdAt), index('audit_actor_idx').on(t.actorId, t.createdAt)],
);

export const chatFolders = pgTable(
  'chat_folders',
  {
    id: id(),
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    name: text('name').notNull(),
    emoji: text('emoji'),
    includeTypes: jsonb('include_types').$type<Array<'direct' | 'group' | 'channel'>>().notNull(),
    includeIds: jsonb('include_ids').$type<string[]>().notNull(),
    excludeIds: jsonb('exclude_ids').$type<string[]>().notNull(),
    unreadOnly: boolean('unread_only').notNull().default(false),
    excludeMuted: boolean('exclude_muted').notNull().default(false),
    excludeArchived: boolean('exclude_archived').notNull().default(true),
    position: real('position').notNull().default(0),
    createdAt: createdAt(),
  },
  (t) => [index('folders_user_idx').on(t.userId)],
);

export const stickerSets = pgTable('sticker_sets', {
  id: id(),
  name: text('name').notNull().unique(),
  title: text('title').notNull(),
  isDemo: boolean('is_demo').notNull().default(false),
  createdAt: createdAt(),
});

export const stickers = pgTable(
  'stickers',
  {
    id: id(),
    setId: uuid('set_id')
      .notNull()
      .references(() => stickerSets.id, { onDelete: 'cascade' }),
    emoji: text('emoji').notNull(),
    /** Path of a built-in asset served by the web app, or a file id for uploaded sets. */
    assetPath: text('asset_path').notNull(),
    animated: boolean('animated').notNull().default(false),
    position: integer('position').notNull().default(0),
  },
  (t) => [index('stickers_set_idx').on(t.setId)],
);

export const userStickerSets = pgTable(
  'user_sticker_sets',
  {
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    setId: uuid('set_id')
      .notNull()
      .references(() => stickerSets.id, { onDelete: 'cascade' }),
    addedAt: ts('added_at').notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.setId] })],
);

export const favoriteStickers = pgTable(
  'favorite_stickers',
  {
    userId: uuid('user_id')
      .notNull()
      .references(() => users.id, { onDelete: 'cascade' }),
    stickerId: uuid('sticker_id')
      .notNull()
      .references(() => stickers.id, { onDelete: 'cascade' }),
    addedAt: ts('added_at').notNull().defaultNow(),
  },
  (t) => [primaryKey({ columns: [t.userId, t.stickerId] })],
);
