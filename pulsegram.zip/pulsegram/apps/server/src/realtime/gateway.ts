import { and, eq } from 'drizzle-orm';
import type { FastifyInstance } from 'fastify';
import { clientFrameSchema, WS_CLOSE, type PresenceView } from '@pulsegram/shared';
import type { AppContext } from '../context';
import { conversationMembers, conversations, users } from '../db/schema';
import { AppError } from '../lib/errors';
import { resolveSessionToken, SESSION_COOKIE } from '../modules/auth/session';
import { relaySignal } from '../modules/calls/service';
import { getPrivacyMap } from '../modules/users/preferences';
import { loadRelations, loadUserSummaries, presenceView } from '../modules/users/serialize';
import { RealtimeHub, type Connection } from './hub';

const HEARTBEAT_MS = 25_000;
const FRAME_LIMIT = 120; // frames per window
const FRAME_WINDOW_MS = 10_000;
const MAX_FRAME_BYTES = 64 * 1024;

export function allowedOrigins(ctx: AppContext): Set<string> {
  const set = new Set([new URL(ctx.config.APP_URL).origin]);
  if (!ctx.config.isProd) {
    set.add('http://localhost:5173');
    set.add('http://127.0.0.1:5173');
    set.add(`http://localhost:${ctx.config.PORT}`);
    set.add(`http://127.0.0.1:${ctx.config.PORT}`);
  }
  return set;
}

export function createPresenceResolver(ctx: AppContext) {
  return async (targetId: string, viewerIds: string[]) => {
    const out = new Map<string, PresenceView>();
    const [u] = await ctx.db.select().from(users).where(eq(users.id, targetId));
    if (!u) return out;
    const [privacy, online] = await Promise.all([getPrivacyMap(ctx.db, [targetId]), ctx.presence.onlineSet([targetId])]);
    // Which viewers are in the target's contacts / blocked by the target.
    const rel = await loadRelations(ctx.db, targetId, viewerIds);
    for (const viewerId of viewerIds) {
      out.set(
        viewerId,
        presenceView({
          online: online.has(targetId),
          presenceMode: u.presenceMode,
          lastSeenAt: u.lastSeenAt,
          privacy: privacy.get(targetId)!,
          isSelf: viewerId === targetId,
          viewerIsContact: rel.viewerContacts.has(viewerId),
          blocked: rel.blockedByViewer.has(viewerId),
          deleted: Boolean(u.deletedAt),
        }),
      );
    }
    return out;
  };
}

export function installPresence(ctx: AppContext) {
  ctx.hub.setLastDisconnectHandler(async (userId) => {
    await ctx.db.update(users).set({ lastSeenAt: new Date() }).where(eq(users.id, userId));
  });
  ctx.hub.setPresenceResolver(createPresenceResolver(ctx));
}

export async function registerGateway(app: FastifyInstance, ctx: AppContext) {
  const origins = allowedOrigins(ctx);

  app.get('/ws', { websocket: true }, async (socket, req) => {
    // Cross-site WebSocket hijacking protection: browsers always send Origin on WS upgrades.
    const origin = req.headers.origin;
    if (origin && !origins.has(origin)) {
      socket.close(WS_CLOSE.unauthorized, 'origin not allowed');
      return;
    }
    const auth = await resolveSessionToken(ctx, req.cookies[SESSION_COOKIE]);
    if (!auth) {
      socket.close(WS_CLOSE.unauthorized, 'unauthorized');
      return;
    }
    const conn: Connection = { socket, userId: auth.userId, sessionId: auth.sessionId, presenceSubs: new Set(), connectedAt: Date.now() };
    const memberCache = new Map<string, { ok: boolean; type: string; at: number }>();
    const typingSentAt = new Map<string, number>();
    let frames = 0;
    let windowStart = Date.now();
    let alive = true;

    socket.on('pong', () => {
      alive = true;
    });
    const hb = setInterval(() => {
      if (!alive) {
        socket.terminate();
        return;
      }
      alive = false;
      socket.ping();
    }, HEARTBEAT_MS);

    const send = (frame: string) => ctx.hub.sendTo(conn, frame);
    const sendError = (code: string, message: string, ref?: string) => send(RealtimeHub.frame('error', { code, message, ref }));

    async function membership(conversationId: string) {
      const cached = memberCache.get(conversationId);
      if (cached && Date.now() - cached.at < 60_000) return cached;
      const [row] = await ctx.db
        .select({ type: conversations.type })
        .from(conversationMembers)
        .innerJoin(conversations, eq(conversations.id, conversationMembers.conversationId))
        .where(and(eq(conversationMembers.conversationId, conversationId), eq(conversationMembers.userId, conn.userId)));
      const v = { ok: Boolean(row), type: row?.type ?? '', at: Date.now() };
      memberCache.set(conversationId, v);
      return v;
    }

    socket.on('message', (raw: Buffer, isBinary: boolean) => {
      void (async () => {
        const now = Date.now();
        if (now - windowStart > FRAME_WINDOW_MS) {
          windowStart = now;
          frames = 0;
        }
        if (++frames > FRAME_LIMIT) {
          socket.close(WS_CLOSE.rateLimited, 'rate limited');
          return;
        }
        if (isBinary || raw.length > MAX_FRAME_BYTES) {
          sendError('bad_frame', 'Frames must be JSON text');
          return;
        }
        let json: unknown;
        try {
          json = JSON.parse(raw.toString('utf8'));
        } catch {
          sendError('bad_frame', 'Invalid JSON');
          return;
        }
        const parsed = clientFrameSchema.safeParse(json);
        if (!parsed.success) {
          sendError('bad_frame', 'Unknown or invalid frame');
          return;
        }
        const f = parsed.data;
        try {
          switch (f.t) {
            case 'ping':
              send(RealtimeHub.frame('pong', { at: new Date().toISOString() }));
              break;
            case 'typing': {
              const m = await membership(f.d.conversationId);
              if (!m.ok || m.type === 'channel' || m.type === 'saved') return;
              const key = `${f.d.conversationId}:${f.d.kind ?? 'stop'}`;
              const last = typingSentAt.get(key) ?? 0;
              if (f.d.kind && now - last < 2500) return; // throttle "still typing" pings
              typingSentAt.set(key, now);
              const rows = await ctx.db
                .select({ userId: conversationMembers.userId })
                .from(conversationMembers)
                .where(eq(conversationMembers.conversationId, f.d.conversationId))
                .limit(501);
              if (rows.length > 500) return; // no typing indicators in very large groups
              await ctx.hub.emit(
                rows.map((r) => r.userId).filter((id) => id !== conn.userId),
                'typing:update',
                { conversationId: f.d.conversationId, userId: conn.userId, kind: f.d.kind },
              );
              break;
            }
            case 'presence:subscribe': {
              const ids = [...new Set(f.d.userIds)];
              ctx.hub.subscribePresence(conn, ids);
              // Send the current state right away (batched, privacy-filtered for this viewer).
              if (ids.length) {
                const sums = await loadUserSummaries(ctx, conn.userId, ids);
                for (const [id, sum] of sums) send(RealtimeHub.frame('presence:updated', { userId: id, presence: sum.presence }));
              }
              break;
            }
            case 'focus':
              if (!f.d.active) await ctx.db.update(users).set({ lastSeenAt: new Date() }).where(eq(users.id, conn.userId));
              break;
            case 'call:signal':
              await relaySignal(ctx, conn.userId, conn.sessionId, f.d.callId, f.d.signal);
              break;
          }
        } catch (err) {
          if (err instanceof AppError) sendError(err.code, err.message, f.id);
          else {
            req.log.error({ err }, 'ws frame handler failed');
            sendError('internal', 'Something went wrong', f.id);
          }
        }
      })();
    });

    socket.on('close', () => {
      clearInterval(hb);
      void ctx.hub.remove(conn).catch((err: unknown) => req.log.error({ err }, 'ws cleanup failed'));
    });

    await ctx.hub.add(conn);
    send(RealtimeHub.frame('session:ready', { userId: conn.userId, serverTime: new Date().toISOString(), heartbeatMs: HEARTBEAT_MS }));
  });
}

