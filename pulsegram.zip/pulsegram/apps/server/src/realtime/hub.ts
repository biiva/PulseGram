import type { WebSocket } from 'ws';
import type { PresenceView, ServerEventName, ServerEvents, ServerFrame } from '@pulsegram/shared';
import type { Broker, BrokerMessage, PresenceStore } from '../services/broker';

export interface Connection {
  socket: WebSocket;
  userId: string;
  sessionId: string;
  /** Users whose presence this connection wants to hear about. */
  presenceSubs: Set<string>;
  connectedAt: number;
}

export type PresenceResolver = (targetUserId: string, viewerIds: string[]) => Promise<Map<string, PresenceView>>;

/**
 * Tracks the WebSocket connections on this instance and delivers events only to the intended
 * users. All fan-out goes through the broker so it also works with several server instances.
 */
export class RealtimeHub {
  private byUser = new Map<string, Set<Connection>>();
  private presenceWatchers = new Map<string, Set<Connection>>();
  private resolver: PresenceResolver | null = null;
  private onLastDisconnect: ((userId: string) => Promise<void>) | null = null;

  constructor(
    private broker: Broker,
    private presence: PresenceStore,
  ) {
    broker.onMessage((m) => this.handleBroker(m));
  }

  setPresenceResolver(r: PresenceResolver) {
    this.resolver = r;
  }

  setLastDisconnectHandler(fn: (userId: string) => Promise<void>) {
    this.onLastDisconnect = fn;
  }

  static frame<K extends ServerEventName>(t: K, d: ServerEvents[K]): string {
    const f: ServerFrame<K> = { t, d, ts: new Date().toISOString() };
    return JSON.stringify(f);
  }

  /** Send an event to every live connection of the given users (on all instances). */
  async emit<K extends ServerEventName>(
    userIds: Iterable<string>,
    t: K,
    d: ServerEvents[K],
    opts: { exceptSessionId?: string } = {},
  ): Promise<void> {
    const ids = [...new Set(userIds)];
    if (ids.length === 0) return;
    await this.broker.publish({ kind: 'users', userIds: ids, frame: RealtimeHub.frame(t, d), exceptSessionId: opts.exceptSessionId });
  }

  /** Deliver to one specific device (used for WebRTC signalling). */
  async emitToSession<K extends ServerEventName>(userId: string, sessionId: string, t: K, d: ServerEvents[K]): Promise<void> {
    await this.broker.publish({ kind: 'users', userIds: [userId], frame: RealtimeHub.frame(t, d), onlySessionId: sessionId });
  }

  sendTo(conn: Connection, frame: string) {
    if (conn.socket.readyState === conn.socket.OPEN) conn.socket.send(frame);
  }

  async add(conn: Connection): Promise<void> {
    let set = this.byUser.get(conn.userId);
    if (!set) this.byUser.set(conn.userId, (set = new Set()));
    set.add(conn);
    const count = await this.presence.connect(conn.userId);
    if (count === 1) await this.broker.publish({ kind: 'presence', userId: conn.userId });
  }

  async remove(conn: Connection): Promise<void> {
    const set = this.byUser.get(conn.userId);
    if (!set?.delete(conn)) return;
    if (set.size === 0) this.byUser.delete(conn.userId);
    for (const target of conn.presenceSubs) this.presenceWatchers.get(target)?.delete(conn);
    const remaining = await this.presence.disconnect(conn.userId);
    if (remaining === 0) {
      await this.onLastDisconnect?.(conn.userId);
      await this.broker.publish({ kind: 'presence', userId: conn.userId });
    }
  }

  subscribePresence(conn: Connection, userIds: string[]) {
    // Replace the previous subscription set (client sends the full list of what is on screen).
    for (const target of conn.presenceSubs) this.presenceWatchers.get(target)?.delete(conn);
    conn.presenceSubs = new Set(userIds.slice(0, 500));
    for (const target of conn.presenceSubs) {
      let w = this.presenceWatchers.get(target);
      if (!w) this.presenceWatchers.set(target, (w = new Set()));
      w.add(conn);
    }
  }

  /** Re-broadcast a user's presence (e.g. after privacy or presence mode changes). */
  async presenceChanged(userId: string) {
    await this.broker.publish({ kind: 'presence', userId });
  }

  async revokeSession(sessionId: string) {
    await this.broker.publish({ kind: 'revoke-session', sessionId });
  }

  async revokeUser(userId: string, exceptSessionId?: string) {
    await this.broker.publish({ kind: 'revoke-user', userId, exceptSessionId });
  }

  localConnectionCount() {
    let n = 0;
    for (const s of this.byUser.values()) n += s.size;
    return n;
  }

  closeAll(code: number, reason: string) {
    for (const set of this.byUser.values()) for (const c of set) c.socket.close(code, reason);
  }

  private handleBroker(m: BrokerMessage) {
    switch (m.kind) {
      case 'users':
        for (const uid of m.userIds) {
          const set = this.byUser.get(uid);
          if (!set) continue;
          for (const c of set) {
            if (m.exceptSessionId && c.sessionId === m.exceptSessionId) continue;
            if (m.onlySessionId && c.sessionId !== m.onlySessionId) continue;
            this.sendTo(c, m.frame);
          }
        }
        break;
      case 'presence':
        void this.deliverPresence(m.userId);
        break;
      case 'revoke-session':
        for (const set of this.byUser.values())
          for (const c of set)
            if (c.sessionId === m.sessionId) {
              this.sendTo(c, RealtimeHub.frame('session:revoked', { sessionId: c.sessionId }));
              c.socket.close(4403, 'session revoked');
            }
        break;
      case 'revoke-user':
        for (const c of this.byUser.get(m.userId) ?? [])
          if (c.sessionId !== m.exceptSessionId) {
            this.sendTo(c, RealtimeHub.frame('session:revoked', { sessionId: c.sessionId }));
            c.socket.close(4403, 'session revoked');
          }
        break;
    }
  }

  private async deliverPresence(targetUserId: string) {
    const watchers = this.presenceWatchers.get(targetUserId);
    if (!watchers || watchers.size === 0 || !this.resolver) return;
    const viewerIds = [...new Set([...watchers].map((c) => c.userId))];
    let views: Map<string, PresenceView>;
    try {
      views = await this.resolver(targetUserId, viewerIds);
    } catch {
      return;
    }
    for (const c of watchers) {
      const presence = views.get(c.userId);
      if (presence) this.sendTo(c, RealtimeHub.frame('presence:updated', { userId: targetUserId, presence }));
    }
  }
}
