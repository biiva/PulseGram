import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { Client, newUser, startServer, type TestServer } from './helpers';

let srv: TestServer;
beforeAll(async () => {
  srv = await startServer();
});
afterAll(async () => {
  await srv.close();
});

const reg = (c: Client, u: string, extra: Record<string, unknown> = {}) =>
  c.post('/api/auth/register', { displayName: 'Test', username: u, email: `${u}@example.com`, password: 'Secret-pass1', acceptTerms: true, ...extra });

describe('registration', () => {
  it('creates an account, a session and a private Saved chat', async () => {
    const c = new Client(srv.base);
    const u = `reg${Date.now()}`;
    const r = await reg(c, u);
    expect(r.status).toBe(201);
    expect(r.body.me.username).toBe(u);
    expect(r.body.me.emailVerified).toBe(false);
    expect(c.jar.pg_session).toBeTruthy();
    expect(c.jar.pg_csrf).toBeTruthy();
    const list = await c.get('/api/conversations');
    expect(list.body.map((x: { type: string }) => x.type)).toEqual(['saved']);
  });

  it('never stores the password in plain text (Argon2id hash)', async () => {
    const c = await newUser(srv.base, 'Hash');
    const { users } = await import('../src/db/schema');
    const { eq } = await import('drizzle-orm');
    const [row] = await srv.ctx.db.select({ h: users.passwordHash }).from(users).where(eq(users.id, c.me!.id));
    expect(row!.h.startsWith('$argon2id$')).toBe(true);
    expect(row!.h).not.toContain('Secret-pass1');
  });

  it('rejects duplicate usernames (case-insensitive) and emails', async () => {
    const u = `dup${Date.now()}`;
    await reg(new Client(srv.base), u);
    const r1 = await reg(new Client(srv.base), u.toUpperCase(), { email: `other${u}@example.com` });
    expect(r1.status).toBe(409);
    expect(r1.body.error.code).toBe('username_taken');
    const r2 = await reg(new Client(srv.base), `x${u}`, { email: `${u}@EXAMPLE.com` });
    expect(r2.status).toBe(409);
    expect(r2.body.error.code).toBe('email_taken');
  });

  it('validates input and the honeypot', async () => {
    const r = await reg(new Client(srv.base), 'ab', { password: 'short' });
    expect(r.status).toBe(400);
    const paths = r.body.error.details.map((d: { path: string }) => d.path);
    expect(paths).toContain('username');
    expect(paths).toContain('password');
    const bot = await reg(new Client(srv.base), `bot${Date.now()}`, { website: 'http://spam.example' });
    expect(bot.status).toBe(400);
  });

  it('reports username availability', async () => {
    const c = await newUser(srv.base, 'Avail');
    const anon = new Client(srv.base);
    expect((await anon.get(`/api/auth/username-available?username=${c.me!.username}`)).body.available).toBe(false);
    expect((await anon.get(`/api/auth/username-available?username=free${Date.now()}`)).body.available).toBe(true);
  });
});

describe('login / logout / sessions', () => {
  it('logs in with correct credentials only', async () => {
    const c = await newUser(srv.base, 'Login');
    const fresh = new Client(srv.base);
    const bad = await fresh.post('/api/auth/login', { email: c.me!.email, password: 'wrong-password1' });
    expect(bad.status).toBe(401);
    expect(bad.body.error.code).toBe('invalid_credentials');
    const unknown = await fresh.post('/api/auth/login', { email: `nobody${Date.now()}@example.com`, password: 'whatever1' });
    expect(unknown.status).toBe(401);
    expect(unknown.body.error.code).toBe('invalid_credentials'); // same answer: no account enumeration
    const ok = await fresh.post('/api/auth/login', { email: c.me!.email.toUpperCase(), password: 'Secret-pass1' });
    expect(ok.status).toBe(200);
    expect((await fresh.get('/api/auth/me')).status).toBe(200);
  });

  it('locks an account after repeated failures', async () => {
    const c = await newUser(srv.base, 'Brute');
    const attacker = new Client(srv.base);
    for (let i = 0; i < 8; i++) await attacker.post('/api/auth/login', { email: c.me!.email, password: `nope-${i}x` });
    const locked = await attacker.post('/api/auth/login', { email: c.me!.email, password: 'Secret-pass1' });
    expect(locked.status).toBe(429);
    expect(locked.headers.get('retry-after')).toBeTruthy();
  });

  it('logout revokes the session server-side', async () => {
    const c = await newUser(srv.base, 'Logout');
    const stolen = { ...c.jar };
    expect((await c.post('/api/auth/logout')).status).toBe(200);
    const replay = new Client(srv.base);
    replay.jar = stolen;
    expect((await replay.get('/api/auth/me')).status).toBe(401);
  });

  it('lists and revokes other sessions', async () => {
    const a = await newUser(srv.base, 'Multi');
    const second = new Client(srv.base);
    await second.post('/api/auth/login', { email: a.me!.email, password: 'Secret-pass1' });
    const list = await a.get('/api/sessions');
    expect(list.body).toHaveLength(2);
    const other = list.body.find((s: { current: boolean }) => !s.current);
    expect((await a.del(`/api/sessions/${other.id}`)).status).toBe(200);
    expect((await second.get('/api/auth/me')).status).toBe(401);
    // Cannot revoke someone else's session.
    const b = await newUser(srv.base, 'Other');
    const bs = await b.get('/api/sessions');
    expect((await a.del(`/api/sessions/${bs.body[0].id}`)).status).toBe(404);
  });

  it('requires a CSRF token and same-origin for state-changing requests', async () => {
    const c = await newUser(srv.base, 'Csrf');
    const noToken = await c.req('PATCH', '/api/me/profile', { bio: 'x' }, { csrf: false });
    expect(noToken.status).toBe(403);
    expect(noToken.body.error.code).toBe('csrf_invalid');
    const evil = await c.req('PATCH', '/api/me/profile', { bio: 'x' }, { origin: 'https://evil.example' });
    expect(evil.status).toBe(403);
    expect((await c.patch('/api/me/profile', { bio: 'ok' })).status).toBe(200);
  });

  it('sets httpOnly session cookies', async () => {
    const c = new Client(srv.base);
    const u = `cookie${Date.now()}`;
    const r = await c.req('POST', '/api/auth/register', { displayName: 'C', username: u, email: `${u}@example.com`, password: 'Secret-pass1', acceptTerms: true });
    const cookies = r.headers.getSetCookie().join('\n');
    expect(cookies).toMatch(/pg_session=[^;]+;.*HttpOnly/i);
    expect(cookies).toMatch(/SameSite=Lax/i);
  });
});

describe('email verification and password reset', () => {
  it('verifies email through the mailed single-use link', async () => {
    const c = await newUser(srv.base, 'Verify');
    const mail = srv.ctx.mailer.outbox.find((m) => m.to === c.me!.email);
    expect(mail).toBeTruthy();
    const token = /token=([\w-]+)/.exec(mail!.text)![1];
    expect((await c.post('/api/auth/verify-email', { token })).status).toBe(200);
    expect((await c.get('/api/auth/me')).body.me.emailVerified).toBe(true);
    expect((await c.post('/api/auth/verify-email', { token })).status).toBe(400); // single use
  });

  it('resets the password and signs out all sessions without revealing accounts', async () => {
    const c = await newUser(srv.base, 'Reset');
    const anon = new Client(srv.base);
    const before = srv.ctx.mailer.outbox.length;
    const r1 = await anon.post('/api/auth/forgot-password', { email: c.me!.email });
    const r2 = await anon.post('/api/auth/forgot-password', { email: `ghost${Date.now()}@example.com` });
    expect(r1.status).toBe(200);
    expect(r2.status).toBe(200);
    expect(r1.body).toEqual(r2.body);
    await new Promise((r) => setTimeout(r, 200));
    const mails = srv.ctx.mailer.outbox.slice(before).filter((m) => m.to === c.me!.email);
    expect(mails).toHaveLength(1);
    const token = /token=([\w-]+)/.exec(mails[0]!.text)![1];
    expect((await anon.post('/api/auth/reset-password', { token, password: 'Brand-new-pass2' })).status).toBe(200);
    expect((await c.get('/api/auth/me')).status).toBe(401); // old session revoked
    expect((await anon.post('/api/auth/login', { email: c.me!.email, password: 'Brand-new-pass2' })).status).toBe(200);
    expect((await anon.post('/api/auth/reset-password', { token, password: 'Another-pass3' })).status).toBe(400);
  });

  it('changes password with the current one and revokes other devices', async () => {
    const c = await newUser(srv.base, 'Change');
    const other = new Client(srv.base);
    await other.post('/api/auth/login', { email: c.me!.email, password: 'Secret-pass1' });
    expect((await c.post('/api/auth/change-password', { currentPassword: 'bad', newPassword: 'Newer-pass9' })).status).toBe(400);
    expect((await c.post('/api/auth/change-password', { currentPassword: 'Secret-pass1', newPassword: 'Newer-pass9' })).status).toBe(200);
    expect((await c.get('/api/auth/me')).status).toBe(200);
    expect((await other.get('/api/auth/me')).status).toBe(401);
  });
});

describe('account', () => {
  it('exports data and deletes the account after password confirmation', async () => {
    const c = await newUser(srv.base, 'Gone');
    const exp = await c.get('/api/me/export');
    expect(exp.status).toBe(200);
    expect(exp.body.account.username).toBe(c.me!.username);
    expect(JSON.stringify(exp.body)).not.toContain('password');
    expect((await c.post('/api/me/delete', { password: 'wrong', confirm: 'DELETE' })).status).toBe(400);
    expect((await c.post('/api/me/delete', { password: 'Secret-pass1', confirm: 'DELETE' })).status).toBe(200);
    const relog = new Client(srv.base);
    expect((await relog.post('/api/auth/login', { email: c.me!.email, password: 'Secret-pass1' })).status).toBe(401);
  });

  it('persists preferences', async () => {
    const c = await newUser(srv.base, 'Prefs');
    const r = await c.patch('/api/me/preferences', { appearance: { theme: 'dark', accent: '#35B6FF' }, privacy: { lastSeen: 'nobody' } });
    expect(r.status).toBe(200);
    const again = await c.get('/api/me/preferences');
    expect(again.body.appearance.theme).toBe('dark');
    expect(again.body.privacy.lastSeen).toBe('nobody');
    expect((await c.patch('/api/me/preferences', { appearance: { accent: 'red' } })).status).toBe(400);
  });
});
