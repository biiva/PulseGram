import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { Client, newUser, send, startServer, type TestServer } from './helpers';

let srv: TestServer;
beforeAll(async () => {
  srv = await startServer();
});
afterAll(async () => {
  await srv.close();
});

async function group(owner: Client, members: Client[], extra: Record<string, unknown> = {}) {
  const r = await owner.post('/api/conversations/group', { title: 'Team', memberIds: members.map((m) => m.me!.id), ...extra });
  if (r.status !== 201) throw new Error(JSON.stringify(r.body));
  return r.body.id as string;
}

describe('groups', () => {
  it('creates a group, notifies invited members and posts a service message', async () => {
    const owner = await newUser(srv.base, 'Owner');
    const m1 = await newUser(srv.base, 'Member');
    const ws = await m1.socket();
    const id = await group(owner, [m1]);
    const ev = await ws.wait('conversation:new');
    expect(ev.d.conversation.id).toBe(id);
    expect(ev.d.conversation.me?.role).toBe('member');
    const hist = await m1.get(`/api/conversations/${id}/messages`);
    expect(hist.body.items[0].system.action).toBe('group_created');
    const members = await m1.get(`/api/conversations/${id}/members`);
    expect(members.body.items.map((x: { role: string }) => x.role).sort()).toEqual(['member', 'owner']);
    ws.close();
  });

  it('enforces roles on the server: members cannot moderate or escalate', async () => {
    const owner = await newUser(srv.base, 'Boss');
    const a = await newUser(srv.base, 'Alpha');
    const b = await newUser(srv.base, 'Beta');
    const id = await group(owner, [a, b]);
    expect((await a.del(`/api/conversations/${id}/members/${b.me!.id}`)).status).toBe(403);
    expect((await a.patch(`/api/conversations/${id}/members/${a.me!.id}`, { role: 'admin' })).status).toBe(403);
    expect((await a.patch(`/api/conversations/${id}/members/${b.me!.id}`, { role: 'admin' })).status).toBe(403);
    expect((await a.patch(`/api/conversations/${id}`, { title: 'Mine now' })).status).toBe(403);
    expect((await a.patch(`/api/conversations/${id}/members/${owner.me!.id}`, { role: 'owner' })).status).toBe(400);
    expect((await a.get(`/api/conversations/${id}/audit-log`)).status).toBe(403);
    // Owner promotes Alpha to admin; an admin may not promote others to admin.
    expect((await owner.patch(`/api/conversations/${id}/members/${a.me!.id}`, { role: 'admin' })).status).toBe(200);
    expect((await a.patch(`/api/conversations/${id}/members/${b.me!.id}`, { role: 'admin' })).status).toBe(403);
    expect((await a.patch(`/api/conversations/${id}/members/${b.me!.id}`, { role: 'moderator' })).status).toBe(200);
    expect((await a.del(`/api/conversations/${id}/members/${owner.me!.id}`)).status).toBe(403);
    expect((await a.del(`/api/conversations/${id}/members/${b.me!.id}`)).status).toBe(200);
    const log = await owner.get(`/api/conversations/${id}/audit-log`);
    expect(log.body.map((e: { action: string }) => e.action)).toEqual(expect.arrayContaining(['member.role_changed', 'member.removed']));
    // Removed member loses access.
    expect((await b.get(`/api/conversations/${id}/messages`)).status).toBe(404);
  });

  it('respects member permissions and slow mode', async () => {
    const owner = await newUser(srv.base, 'Perm');
    const a = await newUser(srv.base, 'PermA');
    const id = await group(owner, [a]);
    await owner.patch(`/api/conversations/${id}`, { settings: { membersCanSend: false } });
    const r = await send(a, id, 'can I talk?');
    expect(r.status).toBe(403);
    expect(r.body.error.code).toBe('cannot_send');
    await owner.patch(`/api/conversations/${id}`, { settings: { membersCanSend: true, slowModeSeconds: 60 } });
    expect((await send(a, id, 'first')).status).toBe(201);
    const slow = await send(a, id, 'second');
    expect(slow.status).toBe(429);
    expect(slow.body.error.code).toBe('slow_mode');
    expect((await send(owner, id, 'admins bypass')).status).toBe(201);
  });

  it('hides history from new members when configured', async () => {
    const owner = await newUser(srv.base, 'Hist');
    const id = await group(owner, []);
    await send(owner, id, 'before you joined');
    await owner.patch(`/api/conversations/${id}`, { settings: { historyVisibleToNewMembers: false } });
    const late = await newUser(srv.base, 'Late');
    await owner.post(`/api/conversations/${id}/members`, { userIds: [late.me!.id] });
    const hist = await late.get(`/api/conversations/${id}/messages`);
    expect(hist.body.items.some((m: { text: string }) => m.text === 'before you joined')).toBe(false);
  });

  it('honors "who can add me to groups" privacy', async () => {
    const owner = await newUser(srv.base, 'Inv');
    const shy = await newUser(srv.base, 'Shy');
    await shy.patch('/api/me/preferences', { privacy: { groupInvites: 'nobody' } });
    const id = await group(owner, [shy]);
    expect((await shy.get(`/api/conversations/${id}`)).status).toBe(404);
  });

  it('invite links: join, limits, revoke', async () => {
    const owner = await newUser(srv.base, 'Link');
    const id = await group(owner, []);
    const inv = await owner.post(`/api/conversations/${id}/invites`, { maxUses: 1 });
    expect(inv.status).toBe(200);
    const j1 = await newUser(srv.base, 'Joiner');
    expect((await j1.get(`/api/invites/${inv.body.token}`)).body.conversation.title).toBe('Team');
    expect((await j1.post(`/api/invites/${inv.body.token}/join`)).status).toBe(200);
    const j2 = await newUser(srv.base, 'TooLate');
    expect((await j2.post(`/api/invites/${inv.body.token}/join`)).status).toBe(404);
    const inv2 = await owner.post(`/api/conversations/${id}/invites`, {});
    await owner.del(`/api/conversations/${id}/invites/${inv2.body.id}`);
    expect((await j2.post(`/api/invites/${inv2.body.token}/join`)).status).toBe(404);
    // Members cannot manage links.
    expect((await j1.post(`/api/conversations/${id}/invites`, {})).status).toBe(403);
  });

  it('mentions create notifications', async () => {
    const owner = await newUser(srv.base, 'Ment');
    const a = await newUser(srv.base, 'Mentioned');
    const id = await group(owner, [a]);
    const ws = await a.socket();
    await send(owner, id, `hey @${a.me!.username} look`);
    const n = await ws.wait('notification:new', 3000, (d) => d.notification.type === 'mention');
    expect(n.d.notification.conversationId).toBe(id);
    const conv = await a.get(`/api/conversations/${id}`);
    expect(conv.body.unreadMentions).toBe(1);
    const list = await a.get('/api/notifications');
    expect(list.body.unread).toBeGreaterThan(0);
    ws.close();
  });

  it('transfers ownership with password confirmation; owner leaving hands over', async () => {
    const owner = await newUser(srv.base, 'Xfer');
    const a = await newUser(srv.base, 'Heir');
    const id = await group(owner, [a]);
    expect((await owner.post(`/api/conversations/${id}/transfer-ownership`, { userId: a.me!.id, password: 'wrong' })).status).toBe(400);
    expect((await owner.post(`/api/conversations/${id}/transfer-ownership`, { userId: a.me!.id, password: 'Secret-pass1' })).status).toBe(200);
    expect((await a.get(`/api/conversations/${id}`)).body.me.role).toBe('owner');
    expect((await owner.get(`/api/conversations/${id}`)).body.me.role).toBe('admin');
    const id2 = await group(owner, [a]);
    await owner.post(`/api/conversations/${id2}/leave`);
    expect((await a.get(`/api/conversations/${id2}`)).body.me.role).toBe('owner');
  });

  it('public groups can be found and joined without an invite', async () => {
    const owner = await newUser(srv.base, 'Pub');
    const name = `pubgroup${Date.now()}`;
    const r = await owner.post('/api/conversations/group', { title: 'Open Space', isPublic: true, username: name });
    expect(r.status).toBe(201);
    const visitor = await newUser(srv.base, 'Visitor');
    const preview = await visitor.get(`/api/conversations/${r.body.id}`);
    expect(preview.status).toBe(200);
    expect(preview.body.me).toBeNull();
    expect((await send(visitor, r.body.id, 'hi')).status).toBe(404);
    expect((await visitor.post(`/api/conversations/${r.body.id}/join`)).status).toBe(200);
    expect((await send(visitor, r.body.id, 'hi')).status).toBe(201);
    const byName = await visitor.get(`/api/users/by-username/${name}`);
    expect(byName.body).toEqual({ kind: 'conversation', conversationId: r.body.id });
  });
});

describe('channels', () => {
  it('only admins publish; subscribers read; views count unique viewers', async () => {
    const admin = await newUser(srv.base, 'Chan');
    const ch = await admin.post('/api/conversations/channel', { title: 'News', isPublic: true, username: `news${Date.now()}`, category: 'tech' });
    expect(ch.status).toBe(201);
    const id = ch.body.id;
    const post = (await send(admin, id, 'Release notes')).body;
    const sub = await newUser(srv.base, 'Sub');
    await sub.post(`/api/conversations/${id}/join`);
    const r = await send(sub, id, 'can I post?');
    expect(r.status).toBe(403);
    expect((await sub.post(`/api/messages/${post.id}/reactions`, { emoji: '👍' })).status).toBe(200);
    const v1 = await sub.post(`/api/conversations/${id}/views`, { messageIds: [post.id] });
    await sub.post(`/api/conversations/${id}/views`, { messageIds: [post.id] }); // repeat view is not counted again
    expect(v1.body.views[post.id]).toBe(1);
    const sub2 = await newUser(srv.base, 'Sub2');
    await sub2.post(`/api/conversations/${id}/join`);
    const v2 = await sub2.post(`/api/conversations/${id}/views`, { messageIds: [post.id] });
    expect(v2.body.views[post.id]).toBe(2);
    // Subscriber list is hidden from subscribers.
    const members = await sub.get(`/api/conversations/${id}/members`);
    expect(members.body.items.every((m: { role: string }) => m.role === 'owner' || m.role === 'admin')).toBe(true);
    // Explore lists it by category.
    const ex = await sub.get('/api/explore?type=channel&category=tech');
    expect(ex.body.some((c: { id: string }) => c.id === id)).toBe(true);
  });
});

describe('files', () => {
  let png: Buffer;
  beforeAll(async () => {
    const sharp = (await import('sharp')).default;
    png = await sharp({ create: { width: 64, height: 48, channels: 3, background: '#7C4DFF' } }).png().toBuffer();
  });

  it('turns undecodable "images" into a 415, not a server error', async () => {
    const a = await newUser(srv.base, 'Broken');
    const broken = Buffer.concat([Buffer.from('89504e470d0a1a0a0000000d49484452', 'hex'), Buffer.alloc(40)]);
    expect((await a.upload('/api/files', 'broken.png', broken, 'image/png')).status).toBe(415);
  });

  it('uploads an image, detects type from content, and restricts download to chat members', async () => {
    const a = await newUser(srv.base, 'Up');
    const b = await newUser(srv.base, 'Up2');
    const eve = await newUser(srv.base, 'UpEve');
    const up = await a.upload('/api/files', 'pic.jpg', png, 'image/jpeg');
    expect(up.status).toBe(201);
    expect(up.body.kind).toBe('image');
    expect(up.body.mime).toBe('image/png'); // client-sent MIME is ignored
    const conv = await a.post('/api/conversations/direct', { userId: b.me!.id });
    const m = await a.post(`/api/conversations/${conv.body.id}/messages`, { clientId: crypto.randomUUID(), text: '', attachmentIds: [up.body.id] });
    expect(m.status).toBe(201);
    expect(m.body.type).toBe('media');
    expect((await b.get(up.body.url)).status).toBe(200);
    expect((await eve.get(up.body.url)).status).toBe(404);
    const dl = await fetch(srv.base + up.body.url, { headers: { cookie: `pg_session=${b.jar.pg_session}` } });
    expect(dl.headers.get('x-content-type-options')).toBe('nosniff');
    expect(dl.headers.get('content-security-policy')).toContain('sandbox');
    // Eve cannot attach someone else's file to her own message either.
    const ec = await eve.post('/api/conversations/direct', { userId: a.me!.id });
    const steal = await eve.post(`/api/conversations/${ec.body.id}/messages`, { clientId: crypto.randomUUID(), text: '', attachmentIds: [up.body.id] });
    expect(steal.status).toBe(400);
  });

  it('rejects dangerous or disguised files and oversized uploads', async () => {
    const a = await newUser(srv.base, 'Bad');
    const elf = Buffer.concat([Buffer.from([0x7f, 0x45, 0x4c, 0x46, 2, 1, 1, 0]), Buffer.alloc(64)]);
    expect((await a.upload('/api/files', 'cute.png', elf, 'image/png')).status).toBe(415);
    const html = Buffer.from('<html><script>alert(1)</script></html>');
    expect((await a.upload('/api/files', 'page.html', html, 'text/html')).status).toBe(415);
    const txt = await a.upload('/api/files', 'notes.txt', Buffer.from('plain notes'), 'text/plain');
    expect(txt.status).toBe(201);
    expect(txt.body.kind).toBe('file');
    const big = Buffer.alloc(3 * 1024 * 1024, 1); // limit is 2 MB in tests
    expect((await a.upload('/api/files', 'big.bin', big)).status).toBe(413);
  });

  it('sets a processed avatar visible to other users', async () => {
    const a = await newUser(srv.base, 'Avatar');
    const b = await newUser(srv.base, 'Viewer');
    const r = await a.upload('/api/me/avatar', 'me.png', png, 'image/png', 'PUT');
    expect(r.status).toBe(200);
    expect(r.body.avatarUrl).toMatch(/^\/api\/files\//);
    expect((await b.get(r.body.avatarUrl)).status).toBe(200);
    await a.patch('/api/me/preferences', { privacy: { avatar: 'nobody' } });
    const prof = await b.get(`/api/users/${a.me!.id}`);
    expect(prof.body.avatarUrl).toBeNull();
  });
});

describe('folders, stickers and calls', () => {
  it('manages chat folders per user', async () => {
    const a = await newUser(srv.base, 'Folder');
    const f = await a.post('/api/folders', { name: 'Work', includeTypes: ['group'] });
    expect(f.status).toBe(200);
    expect((await a.get('/api/folders')).body).toHaveLength(1);
    const b = await newUser(srv.base, 'Folder2');
    expect((await b.del(`/api/folders/${f.body.id}`)).status).toBe(200);
    expect((await a.get('/api/folders')).body).toHaveLength(1); // b could not delete a's folder
  });

  it('sends built-in stickers', async () => {
    const a = await newUser(srv.base, 'Stick');
    const b = await newUser(srv.base, 'Stick2');
    const sets = await a.get('/api/stickers');
    const sticker = sets.body.sets[0].stickers[0];
    const conv = await a.post('/api/conversations/direct', { userId: b.me!.id });
    const m = await a.post(`/api/conversations/${conv.body.id}/messages`, { clientId: crypto.randomUUID(), stickerId: sticker.id });
    expect(m.status).toBe(201);
    expect(m.body.sticker.url).toMatch(/\/stickers\//);
  });

  it('call lifecycle with signalling routed to the accepting device only', async () => {
    const a = await newUser(srv.base, 'Caller');
    const b = await newUser(srv.base, 'Callee');
    const conv = await a.post('/api/conversations/direct', { userId: b.me!.id });
    const wsA = await a.socket();
    const wsB = await b.socket();
    const call = await a.post('/api/calls', { conversationId: conv.body.id, video: false });
    expect(call.body.status).toBe('ringing');
    await wsB.wait('call:incoming');
    expect((await a.post(`/api/calls/${call.body.id}/accept`)).status).toBe(403); // caller can't accept
    expect((await b.post(`/api/calls/${call.body.id}/accept`)).body.status).toBe('accepted');
    await wsA.wait('call:updated', 3000, (d) => d.call.status === 'accepted');
    wsA.send({ t: 'call:signal', d: { callId: call.body.id, signal: { kind: 'offer', sdp: 'v=0' } } });
    const sig = await wsB.wait('call:signal');
    expect(sig.d.signal).toEqual({ kind: 'offer', sdp: 'v=0' });
    // A third party cannot inject signals.
    const eve = await newUser(srv.base, 'Spy');
    const wsE = await eve.socket();
    wsE.send({ t: 'call:signal', d: { callId: call.body.id, signal: { kind: 'offer', sdp: 'evil' } } });
    expect(await wsB.none('call:signal', 400)).toBe(true);
    expect((await b.post(`/api/calls/${call.body.id}/end`)).body.status).toBe('ended');
    const hist = await a.get('/api/calls');
    expect(hist.body[0].status).toBe('ended');
    const ice = await a.get('/api/calls/ice-servers');
    expect(ice.body.turnConfigured).toBe(false);
    wsA.close();
    wsB.close();
    wsE.close();
  });

  it('reports not-configured integrations honestly', async () => {
    const a = await newUser(srv.base, 'Cfg');
    const gifs = await a.get('/api/gifs?q=cat');
    expect(gifs.status).toBe(503);
    expect(gifs.body.error.code).toBe('not_configured');
    const cfg = await a.get('/api/config');
    expect(cfg.body.e2ee).toBe(false);
    expect(cfg.body.turnConfigured).toBe(false);
    const health = await a.get('/api/health');
    expect(health.body.status).toBe('ok');
  });
});
