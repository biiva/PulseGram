import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { dm, newUser, send, startServer, uuid, type TestServer } from './helpers';

let srv: TestServer;
beforeAll(async () => {
  srv = await startServer();
});
afterAll(async () => {
  await srv.close();
});

describe('direct chats', () => {
  it('opening a DM is idempotent and both sides see the same chat', async () => {
    const a = await newUser(srv.base, 'Ann');
    const b = await newUser(srv.base, 'Ben');
    const id1 = await dm(a, b);
    const id2 = await dm(b, a);
    expect(id1).toBe(id2);
    // An empty DM opened by someone else stays out of the recipient's list until the first message.
    expect((await b.get('/api/conversations')).body.some((c: { id: string }) => c.id === id1)).toBe(false);
    await send(a, id1, 'hello');
    const list = await b.get('/api/conversations');
    const c = list.body.find((x: { id: string }) => x.id === id1);
    expect(c.title).toBe('Ann');
    expect(c.unreadCount).toBe(1);
    expect(c.lastMessage.text).toBe('hello');
  });

  it('delivers messages in real time only to participants', async () => {
    const a = await newUser(srv.base, 'Ava');
    const b = await newUser(srv.base, 'Bo');
    const eve = await newUser(srv.base, 'Eve');
    const id = await dm(a, b);
    const wsB = await b.socket();
    const wsEve = await eve.socket();
    const r = await send(a, id, 'secret plans');
    expect(r.status).toBe(201);
    const f = await wsB.wait('message:new');
    expect(f.d.message.text).toBe('secret plans');
    expect(f.d.message.id).toBe(r.body.id);
    expect(await wsEve.none('message:new')).toBe(true);
    wsB.close();
    wsEve.close();
  });

  it('assigns server-side timestamps and monotonic sequence numbers', async () => {
    const a = await newUser(srv.base, 'Seq');
    const b = await newUser(srv.base, 'Seq2');
    const id = await dm(a, b);
    const m1 = (await send(a, id, 'one')).body;
    const m2 = (await send(b, id, 'two', { createdAt: '1999-01-01T00:00:00Z' })).body;
    expect(m2.seq).toBeGreaterThan(m1.seq);
    expect(new Date(m2.createdAt).getFullYear()).toBeGreaterThan(2000);
  });

  it('deduplicates retries with the same clientId', async () => {
    const a = await newUser(srv.base, 'Dup');
    const b = await newUser(srv.base, 'Dup2');
    const id = await dm(a, b);
    const clientId = uuid();
    const r1 = await a.post(`/api/conversations/${id}/messages`, { clientId, text: 'once' });
    const r2 = await a.post(`/api/conversations/${id}/messages`, { clientId, text: 'once' });
    expect(r1.status).toBe(201);
    expect(r2.status).toBe(200);
    expect(r2.body.id).toBe(r1.body.id);
    // Concurrent retries also collapse into one message.
    const cid = uuid();
    const results = await Promise.all([1, 2, 3].map(() => a.post(`/api/conversations/${id}/messages`, { clientId: cid, text: 'race' })));
    expect(new Set(results.map((r) => r.body.id)).size).toBe(1);
    const hist = await b.get(`/api/conversations/${id}/messages`);
    expect(hist.body.items.filter((m: { text: string }) => m.text === 'race')).toHaveLength(1);
  });

  it('paginates history with cursors', async () => {
    const a = await newUser(srv.base, 'Page');
    const b = await newUser(srv.base, 'Page2');
    const id = await dm(a, b);
    for (let i = 0; i < 25; i++) await send(a, id, `m${i}`);
    const p1 = await b.get(`/api/conversations/${id}/messages?limit=10`);
    expect(p1.body.items.map((m: { text: string }) => m.text)).toEqual(Array.from({ length: 10 }, (_, i) => `m${15 + i}`));
    expect(p1.body.hasMoreBefore).toBe(true);
    const p2 = await b.get(`/api/conversations/${id}/messages?limit=10&before=${p1.body.items[0].seq}`);
    expect(p2.body.items[9].text).toBe('m14');
    const around = await b.get(`/api/conversations/${id}/messages?limit=6&around=${p2.body.items[5].seq}`);
    expect(around.body.items.length).toBeGreaterThanOrEqual(5);
    expect(around.body.hasMoreAfter).toBe(true);
  });

  it('edits only own messages within the window and broadcasts the change', async () => {
    const a = await newUser(srv.base, 'Ed');
    const b = await newUser(srv.base, 'Ed2');
    const id = await dm(a, b);
    const m = (await send(a, id, 'typo')).body;
    const wsB = await b.socket();
    expect((await b.patch(`/api/messages/${m.id}`, { text: 'hacked' })).status).toBe(403);
    const r = await a.patch(`/api/messages/${m.id}`, { text: 'fixed' });
    expect(r.status).toBe(200);
    expect(r.body.editedAt).toBeTruthy();
    const f = await wsB.wait('message:updated');
    expect(f.d.message.text).toBe('fixed');
    wsB.close();
  });

  it('deletes for everyone (own) and for me (others)', async () => {
    const a = await newUser(srv.base, 'Del');
    const b = await newUser(srv.base, 'Del2');
    const id = await dm(a, b);
    const mine = (await send(a, id, 'oops')).body;
    const theirs = (await send(b, id, 'from b')).body;
    // A cannot delete B's message for everyone in a DM…
    expect((await a.post('/api/messages/delete', { messageIds: [theirs.id], forEveryone: true })).status).toBe(403);
    // …but can hide it for themselves.
    expect((await a.post('/api/messages/delete', { messageIds: [theirs.id], forEveryone: false })).status).toBe(200);
    expect((await a.get(`/api/conversations/${id}/messages`)).body.items.some((m: { id: string }) => m.id === theirs.id)).toBe(false);
    expect((await b.get(`/api/conversations/${id}/messages`)).body.items.some((m: { id: string }) => m.id === theirs.id)).toBe(true);
    const wsB = await b.socket();
    expect((await a.del(`/api/messages/${mine.id}?forEveryone=true`)).status).toBe(200);
    await wsB.wait('message:deleted', 3000, (d) => d.messageIds.includes(mine.id));
    expect((await b.get(`/api/conversations/${id}/messages`)).body.items.some((m: { id: string }) => m.id === mine.id)).toBe(false);
    wsB.close();
  });

  it('replies, reactions and pins persist', async () => {
    const a = await newUser(srv.base, 'React');
    const b = await newUser(srv.base, 'React2');
    const id = await dm(a, b);
    const m = (await send(a, id, 'question?')).body;
    const reply = (await send(b, id, 'answer!', { replyToId: m.id })).body;
    expect(reply.replyTo.id).toBe(m.id);
    const wsA = await a.socket();
    const r = await b.post(`/api/messages/${m.id}/reactions`, { emoji: '🔥' });
    expect(r.body.reactions).toEqual([expect.objectContaining({ emoji: '🔥', count: 1, mine: true })]);
    const ev = await wsA.wait('message:reactions');
    expect(ev.d.reactions[0]!.mine).toBe(false); // generic payload; clients keep their own flags
    expect(ev.d.actorEmojis).toEqual(['🔥']);
    await b.post(`/api/messages/${m.id}/reactions`, { emoji: '🔥' }); // toggle off
    expect((await b.post(`/api/messages/${m.id}/reactions`, { emoji: 'not-emoji' })).status).toBe(400);
    expect((await a.post(`/api/messages/${m.id}/pin`)).status).toBe(200);
    const conv = await b.get(`/api/conversations/${id}`);
    expect(conv.body.pinnedMessageIds).toEqual([m.id]);
    const hist = await a.get(`/api/conversations/${id}/messages`);
    expect(hist.body.items.find((x: { id: string }) => x.id === m.id).reactions).toEqual([]);
    wsA.close();
  });

  it('tracks read receipts', async () => {
    const a = await newUser(srv.base, 'Read');
    const b = await newUser(srv.base, 'Read2');
    const id = await dm(a, b);
    const m = (await send(a, id, 'did you read this')).body;
    const wsA = await a.socket();
    expect((await b.post(`/api/conversations/${id}/read`, { seq: m.seq })).status).toBe(200);
    const ev = await wsA.wait('conversation:read', 3000, (d) => d.userId === b.me!.id);
    expect(ev.d.seq).toBe(m.seq);
    expect((await a.get(`/api/conversations/${id}`)).body.peerReadSeq).toBe(m.seq);
    expect((await b.get(`/api/conversations/${id}`)).body.unreadCount).toBe(0);
    wsA.close();
  });

  it('forwards messages and saves to Saved messages', async () => {
    const a = await newUser(srv.base, 'Fwd');
    const b = await newUser(srv.base, 'Fwd2');
    const id = await dm(a, b);
    const m = (await send(b, id, 'worth keeping')).body;
    const saved = (await a.get('/api/conversations')).body.find((c: { type: string }) => c.type === 'saved');
    const r = await a.post('/api/messages/forward', { messageIds: [m.id], toConversationIds: [saved.id] });
    expect(r.status).toBe(200);
    expect(r.body.messages[0].forward.fromName).toBe('Fwd2');
    // Saved messages are private to their owner.
    expect((await b.get(`/api/conversations/${saved.id}/messages`)).status).toBe(404);
  });

  it('blocking stops messages and calls', async () => {
    const a = await newUser(srv.base, 'Blk');
    const b = await newUser(srv.base, 'Blk2');
    const id = await dm(a, b);
    await send(a, id, 'hi');
    expect((await b.post('/api/blocks', { userId: a.me!.id })).status).toBe(200);
    const r = await send(a, id, 'are you there?');
    expect(r.status).toBe(403);
    expect(r.body.error.code).toBe('blocked');
    expect((await a.post('/api/calls', { conversationId: id })).status).toBe(403);
    expect((await b.get('/api/blocks')).body.map((u: { id: string }) => u.id)).toEqual([a.me!.id]);
    await b.del(`/api/blocks/${a.me!.id}`);
    expect((await send(a, id, 'now?')).status).toBe(201);
  });

  it('typing indicators reach the other participant only', async () => {
    const a = await newUser(srv.base, 'Typ');
    const b = await newUser(srv.base, 'Typ2');
    const id = await dm(a, b);
    await send(a, id, 'x');
    const wsA = await a.socket();
    const wsB = await b.socket();
    wsA.send({ t: 'typing', d: { conversationId: id, kind: 'text' } });
    const f = await wsB.wait('typing:update');
    expect(f.d).toEqual({ conversationId: id, userId: a.me!.id, kind: 'text' });
    expect(await wsA.none('typing:update')).toBe(true);
    // Not a member → ignored.
    const eve = await newUser(srv.base, 'TypEve');
    const wsE = await eve.socket();
    wsE.send({ t: 'typing', d: { conversationId: id, kind: 'text' } });
    expect(await wsB.none('typing:update', 400, (d) => d.userId === eve.me!.id)).toBe(true);
    wsA.close();
    wsB.close();
    wsE.close();
  });

  it('recovers missed events through /sync after a disconnect', async () => {
    const a = await newUser(srv.base, 'Sync');
    const b = await newUser(srv.base, 'Sync2');
    const id = await dm(a, b);
    const since = new Date().toISOString();
    await new Promise((r) => setTimeout(r, 10));
    const m = (await send(a, id, 'while you were away')).body;
    await a.patch(`/api/messages/${m.id}`, { text: 'while you were away (edited)' });
    const r = await b.get(`/api/sync?since=${encodeURIComponent(since)}`);
    expect(r.status).toBe(200);
    expect(r.body.messages.find((x: { id: string }) => x.id === m.id).text).toContain('edited');
    expect(r.body.conversations.some((c: { id: string }) => c.id === id)).toBe(true);
  });

  it('presence respects privacy settings', async () => {
    const a = await newUser(srv.base, 'Pres');
    const b = await newUser(srv.base, 'Pres2');
    await dm(a, b);
    const wsA = await a.socket();
    const wsB = await b.socket();
    wsB.send({ t: 'presence:subscribe', d: { userIds: [a.me!.id] } });
    const f = await wsB.wait('presence:updated', 3000, (d) => d.userId === a.me!.id);
    expect(f.d.presence.kind).toBe('online');
    await a.patch('/api/me/preferences', { privacy: { online: 'nobody', lastSeen: 'nobody' } });
    const f2 = await wsB.wait('presence:updated', 3000, (d) => d.userId === a.me!.id && d.presence.kind !== 'online');
    expect(f2.d.presence.kind).toBe('recently'); // approximate only, never the exact time
    wsA.close();
    wsB.close();
  });
});

describe('access control (IDOR)', () => {
  it('outsiders cannot read, write, react, pin, edit or search in other chats', async () => {
    const a = await newUser(srv.base, 'Own');
    const b = await newUser(srv.base, 'Own2');
    const eve = await newUser(srv.base, 'Intruder');
    const id = await dm(a, b);
    const m = (await send(a, id, 'private topic zebra')).body;
    expect((await eve.get(`/api/conversations/${id}`)).status).toBe(404);
    expect((await eve.get(`/api/conversations/${id}/messages`)).status).toBe(404);
    expect((await send(eve, id, 'let me in')).status).toBe(404);
    expect((await eve.post(`/api/messages/${m.id}/reactions`, { emoji: '👍' })).status).toBe(404);
    expect((await eve.post(`/api/messages/${m.id}/pin`)).status).toBe(404);
    expect((await eve.patch(`/api/messages/${m.id}`, { text: 'x' })).status).toBe(404);
    expect((await eve.post('/api/messages/delete', { messageIds: [m.id], forEveryone: true })).status).toBe(404);
    expect((await eve.post('/api/messages/forward', { messageIds: [m.id], toConversationIds: [id] })).status).toBe(404);
    expect((await eve.get(`/api/conversations/${id}/media`)).status).toBe(404);
    const s = await eve.get('/api/search?q=zebra');
    expect(s.body.messages).toHaveLength(0);
    const s2 = await a.get('/api/search?q=zebra');
    expect(s2.body.messages).toHaveLength(1);
    expect((await eve.get(`/api/search?q=zebra&conversationId=${id}`)).status).toBe(404);
  });

  it('rejects unauthenticated access and websocket connections', async () => {
    const r = await fetch(`${srv.base}/api/conversations`);
    expect(r.status).toBe(401);
    const { WsClient } = await import('./helpers');
    await expect(WsClient.connect(srv.base.replace('http', 'ws') + '/ws', 'pg_session=forged')).rejects.toThrow();
  });

  it('rejects websocket connections from foreign origins', async () => {
    const a = await newUser(srv.base, 'Origin');
    const { WsClient } = await import('./helpers');
    await expect(WsClient.connect(srv.base.replace('http', 'ws') + '/ws', `pg_session=${a.jar.pg_session}`, 'https://evil.example')).rejects.toThrow();
  });
});
