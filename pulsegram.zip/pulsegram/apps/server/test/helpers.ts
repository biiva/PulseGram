import type { AddressInfo } from 'node:net';
import { randomUUID } from 'node:crypto';
import WebSocket from 'ws';
import type { ServerFrame } from '@pulsegram/shared';
import { buildApp, type BuiltApp } from '../src/app';
import { loadConfig } from '../src/config';
import { TEST_DATABASE_URL } from './globalSetup';

export interface TestServer extends BuiltApp {
  base: string;
}

export async function startServer(env: Record<string, string> = {}): Promise<TestServer> {
  const config = loadConfig({
    NODE_ENV: 'test',
    LOG_LEVEL: 'silent',
    DATABASE_URL: TEST_DATABASE_URL,
    APP_URL: 'http://localhost:5173',
    APP_SECRET: 'test-secret-test-secret-test-secret',
    STORAGE_LOCAL_DIR: `./data/test-uploads-${process.pid}`,
    MAX_UPLOAD_MB: '2',
    ...env,
  });
  const built = await buildApp(config);
  await built.app.listen({ host: '127.0.0.1', port: 0 });
  const port = (built.app.server.address() as AddressInfo).port;
  return { ...built, base: `http://127.0.0.1:${port}` };
}

export interface Res<T = any> {
  status: number;
  body: T;
  headers: Headers;
}

/** Minimal browser-like client: cookie jar + automatic CSRF header. */
export class Client {
  jar: Record<string, string> = {};
  me: { id: string; username: string; email: string } | null = null;
  constructor(private base: string) {}

  async req<T = any>(method: string, path: string, body?: unknown, opts: { csrf?: boolean; origin?: string; raw?: RequestInit["body"]; headers?: Record<string, string> } = {}): Promise<Res<T>> {
    const headers: Record<string, string> = { ...opts.headers };
    const cookie = Object.entries(this.jar)
      .map(([k, v]) => `${k}=${v}`)
      .join('; ');
    if (cookie) headers.cookie = cookie;
    if (opts.csrf !== false && this.jar.pg_csrf) headers['x-csrf-token'] = decodeURIComponent(this.jar.pg_csrf);
    if (opts.origin) headers.origin = opts.origin;
    let payload: RequestInit["body"] = opts.raw;
    if (body !== undefined && !opts.raw) {
      headers['content-type'] = 'application/json';
      payload = JSON.stringify(body);
    } else if (!opts.raw && method !== 'GET' && method !== 'DELETE') {
      headers['content-type'] = 'application/json';
      payload = '{}';
    }
    const r = await fetch(this.base + path, { method, headers, body: payload });
    for (const sc of r.headers.getSetCookie()) {
      const [kv] = sc.split(';');
      const i = kv!.indexOf('=');
      const k = kv!.slice(0, i);
      const v = kv!.slice(i + 1);
      if (!v || /expires=Thu, 01 Jan 1970/i.test(sc)) delete this.jar[k];
      else this.jar[k] = v;
    }
    const text = await r.text();
    let json: unknown = text;
    try {
      json = text ? JSON.parse(text) : undefined;
    } catch {
      /* keep text */
    }
    return { status: r.status, body: json as T, headers: r.headers };
  }

  get<T = any>(p: string) {
    return this.req<T>('GET', p);
  }
  post<T = any>(p: string, b?: unknown) {
    return this.req<T>('POST', p, b);
  }
  patch<T = any>(p: string, b?: unknown) {
    return this.req<T>('PATCH', p, b);
  }
  del<T = any>(p: string) {
    return this.req<T>('DELETE', p);
  }

  async upload(path: string, filename: string, data: Buffer, mime = 'application/octet-stream', method = 'POST') {
    const fd = new FormData();
    fd.append('file', new Blob([new Uint8Array(data)], { type: mime }), filename);
    return this.req(method, path, undefined, { raw: fd });
  }

  socket(): Promise<WsClient> {
    return WsClient.connect(this.base.replace('http', 'ws') + '/ws', `pg_session=${this.jar.pg_session}`);
  }
}

export class WsClient {
  frames: ServerFrame[] = [];
  private waiters: Array<{ pred: (f: ServerFrame) => boolean; resolve: (f: ServerFrame) => void }> = [];
  constructor(public ws: WebSocket) {
    ws.on('message', (d) => {
      const f = JSON.parse(String(d)) as ServerFrame;
      this.frames.push(f);
      this.waiters = this.waiters.filter((w) => {
        if (w.pred(f)) {
          w.resolve(f);
          return false;
        }
        return true;
      });
    });
  }
  static connect(url: string, cookie: string, origin = 'http://localhost:5173'): Promise<WsClient> {
    return new Promise((resolve, reject) => {
      const ws = new WebSocket(url, { headers: { cookie, origin } });
      const c = new WsClient(ws);
      c.wait('session:ready', 5000).then(() => resolve(c), reject);
      ws.on('error', reject);
    });
  }
  wait<K extends ServerFrame['t']>(t: K, timeout = 3000, pred: (d: any) => boolean = () => true): Promise<ServerFrame<K>> {
    const existing = this.frames.find((f) => f.t === t && pred(f.d));
    if (existing) {
      this.frames.splice(this.frames.indexOf(existing), 1);
      return Promise.resolve(existing as ServerFrame<K>);
    }
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(`timeout waiting for ${t}`)), timeout);
      this.waiters.push({
        pred: (f) => f.t === t && pred(f.d),
        resolve: (f) => {
          clearTimeout(timer);
          const i = this.frames.indexOf(f);
          if (i >= 0) this.frames.splice(i, 1);
          resolve(f as ServerFrame<K>);
        },
      });
    });
  }
  /** Assert nothing matching arrives within `ms`. */
  async none(t: string, ms = 400, pred: (d: any) => boolean = () => true) {
    await new Promise((r) => setTimeout(r, ms));
    return !this.frames.some((f) => f.t === t && pred(f.d));
  }
  send(frame: unknown) {
    this.ws.send(JSON.stringify(frame));
  }
  close() {
    this.ws.close();
  }
}

let counter = 0;
export async function newUser(base: string, name = 'User'): Promise<Client> {
  const c = new Client(base);
  const u = `${name.toLowerCase().replace(/[^a-z]/g, '') || 'user'}${Date.now().toString(36)}${counter++}`;
  const r = await c.post('/api/auth/register', {
    displayName: name,
    username: u,
    email: `${u}@example.com`,
    password: 'Secret-pass1',
    acceptTerms: true,
  });
  if (r.status !== 201) throw new Error(`register failed: ${r.status} ${JSON.stringify(r.body)}`);
  c.me = { id: r.body.me.id, username: u, email: `${u}@example.com` };
  return c;
}

export const uuid = () => randomUUID();

export async function dm(a: Client, b: Client): Promise<string> {
  const r = await a.post('/api/conversations/direct', { userId: b.me!.id });
  if (r.status !== 200) throw new Error(`dm failed ${r.status}`);
  return r.body.id as string;
}

export async function send(c: Client, conversationId: string, text: string, extra: Record<string, unknown> = {}) {
  return c.post(`/api/conversations/${conversationId}/messages`, { clientId: uuid(), text, ...extra });
}
