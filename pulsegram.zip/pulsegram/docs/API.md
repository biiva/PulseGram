# PulseGram REST API

База: `/api`. Формат — JSON. Аутентификация — cookie `pg_session` (httpOnly). Для всех изменяющих запросов нужен заголовок `X-CSRF-Token` со значением cookie `pg_csrf`. Схемы тел — `packages/shared/src/schemas.ts`, типы ответов — `packages/shared/src/types.ts`.

Ошибки: `{"error": {"code": "…", "message": "…", "details": …}}`. Частые коды: `validation_failed` (400, `details` — список `{path, code}`), `unauthorized` (401), `forbidden`/`csrf_invalid` (403), `not_found` (404 — также для чужих чатов), `username_taken`/`email_taken` (409), `payload_too_large` (413), `unsupported_media_type` (415), `rate_limited`/`slow_mode` (429, заголовок `Retry-After`), `not_configured` (503).

## Система

| Метод | Путь | Описание |
|---|---|---|
| GET | `/health` | Состояние БД/Redis/хранилища, аптайм |
| GET | `/config` | Публичная конфигурация: какие интеграции настроены, лимит загрузки, `e2ee: false` |

## Аутентификация и сеансы

| Метод | Путь | Описание |
|---|---|---|
| GET | `/auth/username-available?username=` | Проверка username |
| POST | `/auth/register` | `{displayName, username, email, password, acceptTerms, captchaToken?, language?}` → 201 `{me, preferences, verificationSent}` |
| POST | `/auth/login` | `{email, password, deviceName?}` → `{me, preferences}` |
| POST | `/auth/logout` | Завершить текущий сеанс |
| GET | `/auth/me` | Текущий пользователь и настройки |
| POST | `/auth/verify-email` | `{token}` |
| POST | `/auth/resend-verification` | Повторить письмо |
| POST | `/auth/forgot-password` | `{email}` — одинаковый ответ для любых адресов |
| POST | `/auth/reset-password` | `{token, password}` — завершает все сеансы |
| POST | `/auth/change-password` | `{currentPassword, newPassword}` — завершает остальные сеансы |
| GET | `/sessions` | Устройства |
| DELETE | `/sessions/:id` | Завершить сеанс |
| POST | `/sessions/revoke-others` | Завершить все, кроме текущего |

## Пользователи, профиль, контакты

| Метод | Путь | Описание |
|---|---|---|
| GET | `/users/search?q=` | Поиск по имени и @username |
| GET | `/users?ids=a,b` | Краткие карточки (до 200) |
| GET | `/users/:id` | Профиль с учётом приватности |
| GET | `/users/by-username/:username` | Пользователь или публичный чат |
| PATCH | `/me/profile` | Имя, username, био, телефон, статус, режим присутствия, публичный email |
| PUT/DELETE | `/me/avatar` | Загрузить (multipart) / удалить аватар |
| GET/PATCH | `/me/preferences` | `{privacy?, notifications?, appearance?}` |
| GET | `/me/export` | Экспорт данных (JSON-файл) |
| POST | `/me/delete` | `{password, confirm: "DELETE"}` |
| GET/POST | `/contacts` | Список / добавить `{userId}` |
| DELETE | `/contacts/:id` | Удалить контакт |
| GET/POST | `/blocks` | Список / заблокировать `{userId}` |
| DELETE | `/blocks/:id` | Разблокировать |
| POST | `/reports` | `{targetType: user|message|conversation, targetId, reason, details?}` |

## Чаты

| Метод | Путь | Описание |
|---|---|---|
| GET | `/conversations` | Мои чаты с последним сообщением, непрочитанным, персональными настройками |
| POST | `/conversations/direct` | `{userId}` — открыть (идемпотентно) личный чат |
| POST | `/conversations/group` | `{title, description?, memberIds, isPublic, username?}` |
| POST | `/conversations/channel` | `{title, description?, isPublic, username?, category}` |
| GET | `/conversations/:id` | Чат (публичные — превью без членства) |
| PATCH | `/conversations/:id` | Название, описание, публичность, username, категория, `settings`, `discussionGroupId` (admin+) |
| PUT/DELETE | `/conversations/:id/avatar` | Аватар чата |
| PATCH | `/conversations/:id/me` | `{isPinned?, isArchived?, mutedUntil?, draft?, markUnread?}` |
| POST | `/conversations/:id/read` | `{seq}` — курсор прочтения |
| POST | `/conversations/:id/clear` | Очистить историю у себя |
| POST | `/conversations/:id/leave` | Покинуть (для личного чата — «удалить у себя») |
| DELETE | `/conversations/:id` | Удалить группу/канал (owner) |
| POST | `/conversations/:id/join` | Вступить в публичный чат |
| GET | `/conversations/:id/members?q=&limit=&offset=` | Участники (подписчиков каналов видят только админы) |
| POST | `/conversations/:id/members` | `{userIds}` |
| PATCH | `/conversations/:id/members/:userId` | `{role}` |
| DELETE | `/conversations/:id/members/:userId` | Исключить |
| POST | `/conversations/:id/transfer-ownership` | `{userId, password}` |
| GET | `/conversations/:id/audit-log` | Журнал (admin+) |
| GET/POST | `/conversations/:id/invites` | Ссылки-приглашения `{expiresInHours, maxUses}` |
| DELETE | `/conversations/:id/invites/:inviteId` | Отозвать |
| GET | `/invites/:token` | Превью приглашения |
| POST | `/invites/:token/join` | Вступить |
| GET | `/explore?q=&type=&category=` | Каталог публичных каналов и групп |

## Сообщения

| Метод | Путь | Описание |
|---|---|---|
| GET | `/conversations/:id/messages?before=&after=&around=&limit=` | История (курсор — `seq`) |
| POST | `/conversations/:id/messages` | `{clientId, text, replyToId?, attachmentIds?, stickerId?, gif?, silent?}` → 201, повтор с тем же `clientId` → 200 и то же сообщение |
| PATCH | `/messages/:id` | `{text}` |
| DELETE | `/messages/:id?forEveryone=true` | Удалить одно |
| POST | `/messages/delete` | `{messageIds, forEveryone}` |
| POST | `/messages/:id/reactions` | `{emoji}` — переключить |
| POST/DELETE | `/messages/:id/pin` | Закрепить / открепить |
| GET | `/conversations/:id/pins` | Закреплённые сообщения |
| GET | `/messages/:id/read-by` | Кто прочитал (свои сообщения в группе) |
| POST | `/messages/forward` | `{messageIds, toConversationIds, hideSender}` |
| POST | `/conversations/:id/views` | `{messageIds}` — просмотры постов канала |
| GET | `/conversations/:id/media?kind=media|file|audio|voice|link&before=` | Общие медиа |
| GET | `/search?q=&conversationId=&senderId=&type=&from=&to=&before=` | Поиск |
| GET | `/sync?since=<ISO>` | Изменения после переподключения |

## Файлы

| Метод | Путь | Описание |
|---|---|---|
| POST | `/files?as=voice|file` | Загрузка (multipart, поле `file`) → `AttachmentDto` |
| GET | `/files/:id[?download=1]` | Скачать (проверка доступа, Range) |
| GET | `/files/:id/thumb` | Миниатюра |

## Звонки, уведомления, прочее

| Метод | Путь | Описание |
|---|---|---|
| POST | `/calls` | `{conversationId, video}` |
| POST | `/calls/:id/accept|reject|end` | Управление звонком |
| GET | `/calls`, `/calls/active`, `/calls/ice-servers` | История, активный звонок, STUN/TURN |
| GET | `/notifications` | Уведомления + число непрочитанных |
| POST | `/notifications/read` | `{ids?}` |
| DELETE | `/notifications` | Очистить |
| POST | `/push/subscribe`, `/push/unsubscribe` | Web Push |
| GET/POST | `/folders` | Папки |
| PUT/DELETE | `/folders/:id` | Изменить / удалить |
| POST | `/folders/order` | `{ids}` |
| GET | `/stickers` | Наборы и избранное |
| POST/DELETE | `/stickers/:id/favorite` | Избранные стикеры |
| GET | `/gifs?q=` | GIF через серверный прокси (503 `not_configured`, если ключа нет) |

## WebSocket

`GET /ws` (тот же cookie-сеанс, проверка `Origin`). Протокол описан в [ARCHITECTURE.md](ARCHITECTURE.md#realtime-протокол) и типизирован в `packages/shared/src/realtime.ts`.
